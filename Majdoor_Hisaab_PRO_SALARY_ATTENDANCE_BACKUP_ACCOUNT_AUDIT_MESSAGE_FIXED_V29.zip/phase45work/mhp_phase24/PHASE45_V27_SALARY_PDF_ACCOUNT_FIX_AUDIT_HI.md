# Majdoor Hisaab PRO V27 – Salary rate, PDF sharing and Google account picker

## Changes
- Salary employee card now explicitly displays exact daily rate to 2 decimals using monthly salary / actual calendar days in selected month. Earned salary remains calculated as monthly salary * attended days / calendar days, without rounding the daily rate before multiplication.
- FileProvider now exposes both cache/reports/ and cache/salary_reports/. This fixes salary PDF sharing where the generated PDF was outside the only configured reports root.
- Google Drive account change now opens Android's explicit Google account picker. The selected email is passed to Google Sign-In using setAccountName after signing out the previous selection.
- App version bumped to 1.88.0 (versionCode 88).
- GitHub workflow ZIP_NAME updated to this V27 archive.

## Validation
- 36/36 repository Python static audit scripts passed.
- Salary quick action/account picker/daily rate audit: 11/11 passed.
- AndroidManifest.xml and FileProvider file_paths.xml parse successfully.
- ZIP integrity checked after packaging.

## Not verified
- Android Gradle/Kotlin compilation and device runtime tests could not run in this environment. Gradle wrapper bootstrap attempted to download its wrapper JAR but network DNS for raw.githubusercontent.com was unavailable.
- Google OAuth still requires the correct Android OAuth client (package com.majdoor.hisaabpro and release signing SHA-1) and Drive API enabled in Google Cloud.
