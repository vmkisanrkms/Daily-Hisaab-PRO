#!/usr/bin/env python3
from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER=ROOT.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
STATUS=ROOT.parent.parent/'PHASE24_REQUESTED_97_POINT_STATUS.csv'
MATRIX=ROOT/'FEATURE_PRESERVATION_MATRIX_PHASE24.csv'
WORKFLOW=ROOT/'.github/workflows/majdoor-hisaab.yml'
s=SOURCE.read_text(encoding='utf-8'); w=WORKFLOW.read_text(encoding='utf-8')
tracker=list(csv.DictReader(TRACKER.open(encoding='utf-8-sig',newline='')))
status=list(csv.DictReader(STATUS.open(encoding='utf-8-sig',newline='')))
by={r['ID']:r for r in tracker}; st={r['ID']:r for r in status}
checks=[]
def check(label,ok): checks.append((label,bool(ok)))
check('PIN stores salted digest, not raw PIN', 'custom_pin_salt' in s and 'custom_pin_hash' in s and 'pinDigest(salt,pin)' in s and 'PBKDF2WithHmacSHA256' in s and 'PIN_HASH_ITERATIONS = 120_000' in s and 'putInt("custom_pin_iterations",PIN_HASH_ITERATIONS)' in s)
check('PIN verification uses constant-time digest compare', 'MessageDigest.isEqual' in s)
check('PIN setup/change/remove requires existing PIN when configured', 'configured && requireCurrentPin && !verifyCustomPin(context,currentPin)' in s and 'saveCustomPin(context,null)' in s and 'PIN भूल गए? फोन लॉक से रीसेट करें' in s and 'requireCurrentPin=!pinResetAuthorized' in s)
check('PIN is constrained to 4–8 digits', 'newPin.length !in 4..8' in s and 'pin.length !in 4..8' in s)
check('Five failed PIN attempts trigger a 30-second delay', 'attempts>=5' in s and 'now+30_000L' in s)
check('Custom PIN unlock has device credential fallback', 'CustomPinUnlockGate(onUnlocked=' in s and 'onUseDeviceCredential={useDeviceCredentialFallback=true}' in s)
check('App lock is still honored before showing app data', 'if(!appUnlocked && settingBool(context, "app_lock_enabled", true))' in s)
check('All text inputs use shared AppTextField except its Material wrapper', s.count('AppTextField(')>=60 and s.count('MaterialOutlinedTextField(')==1 and 'private fun AppTextField(' in s)
check('Shared form wrapper standardizes shape and theme colors', 'shape: Shape = RoundedCornerShape(14.dp)' in s and 'colors=colors ?: OutlinedTextFieldDefaults.colors()' in s)
check('Shared state component supports loading/empty/error/success/info', all(f'"{k}"' in s for k in ['loading','empty','error','success','info']) and 'private fun SharedStatePanel(' in s)
check('Shared empty cards route through state component', 'private fun EmptyCard(text:String){SharedStatePanel("कोई रिकॉर्ड नहीं",text,"empty")}' in s)
check('Startup loading and startup failure use shared state component', 'SharedStatePanel("ऐप शुरू हो रहा है"' in s and 'SharedStatePanel("ऐप डेटा शुरू नहीं हो सका"' in s)
check('Backup/restore status uses shared success/error/info state', 'SharedStatePanel("Backup / Restore स्थिति",status,statusKind)' in s)
check('Feature matrix contains all 97 requested point IDs', len(status)==97 and len({r['ID'] for r in status})==97 and {r['ID'] for r in status}=={r['ID'] for r in tracker if r['ID'] in {x['ID'] for x in status}})
with MATRIX.open(encoding='utf-8-sig',newline='') as f: matrix=list(csv.DictReader(f))
check('Feature matrix has at least 250 explicit action cases',len(matrix)>=250)
check('Every requested point has at least two action cases',all(sum(1 for x in matrix if x['Screen_ID']==r['ID'])>=2 for r in status))
check('Every matrix case includes an expected result and honest pending runtime status',all(x['Expected_Result'].strip() and x['Runtime_Status'].startswith('NOT RUN') for x in matrix))
check('Q01 tracker records complete matrix with runtime pending',by.get('Q01',{}).get('Implementation_Status')=='IMPLEMENTED' and by.get('Q01',{}).get('Test_Status')=='NOT TESTED')
check('A02, P03, P06 source implementation statuses updated',all(by.get(k,{}).get('Implementation_Status')=='IMPLEMENTED' for k in ['A02','P03','P06']))
check('Workflow expects exact V29 source ZIP', 'ZIP_NAME: \"Majdoor_Hisaab_PRO_SALARY_ATTENDANCE_BACKUP_ACCOUNT_AUDIT_MESSAGE_FIXED_V29.zip\"' in w)
check('Workflow selects canonical redesign source', '*/original_source_project/mhp/gradlew' in w)
check('Workflow compiles release and runs accounting unit tests', ':app:compileReleaseKotlin' in w and ':app:testReleaseUnitTest' in w)
check('Workflow requires permanent signing secrets and has no debug fallback', all(k in w for k in ['ANDROID_KEYSTORE_BASE64','ANDROID_KEYSTORE_PASSWORD','ANDROID_KEY_ALIAS','ANDROID_KEY_PASSWORD']) and 'no debug/temporary signing fallback' in w)
check('Workflow validates package, APK signature and alignment before upload', 'EXPECTED_PACKAGE' in w and '"$APKSIGNER" verify --verbose' in w and '"$ZIPALIGN" -c -P 16 -v 4 "$APK"' in w)
check('Q09 remains honest until secrets and CI run are available',by.get('Q09',{}).get('Implementation_Status')=='IN PROGRESS' and by.get('Q09',{}).get('Test_Status')=='NOT TESTED')
check('No Android runtime status is falsely marked tested for five points',all(by.get(k,{}).get('Test_Status')=='NOT TESTED' for k in ['A02','P03','P06','Q01','Q09']))
for label,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY: {sum(ok for _,ok in checks)}/{len(checks)} PASS, {sum(not ok for _,ok in checks)} FAIL; matrix cases={len(matrix)}')
sys.exit(0 if all(ok for _,ok in checks) else 1)
