# Daily Hisaab PRO — Android प्रोजेक्ट

यह एक नया Android प्रोजेक्ट है: `com.dailyhisaab.pro`

## शामिल सुविधाएँ
- हिंदी UI: खर्च और कमाई अलग-अलग दर्ज करना
- Room/SQLite में स्थायी स्थानीय रिकॉर्ड
- मासिक कमाई, खर्च और शेष का सारांश
- मासिक PDF रिपोर्ट
- JSON बैकअप और रिस्टोर
- Android फ़ाइल पिकर के जरिए मोबाइल स्टोरेज या Google Drive में बैकअप सेव/खोलना
- PIN सेटअप और PIN बदलना; PIN को salted PBKDF2 hash के रूप में सेव करना, 5 गलत प्रयासों के बाद 30 सेकंड लॉक और ऐप बैकग्राउंड में जाने पर दोबारा PIN माँगना
- हाल के लेन-देन पर टैप करके एडिट, लंबे टैप से पुष्टि के बाद डिलीट
- बैकअप रिस्टोर से पहले ऐप/डेटा validation और overwrite confirmation
- बड़े मासिक PDF के लिए multi-page output
- GitHub Actions से मैन्युअल Release APK build

## Google Drive बैकअप कैसे काम करता है?
बैकअप/रिस्टोर Android के सिस्टम फ़ाइल पिकर से होता है। फ़ाइल पिकर में Google Drive उपलब्ध हो और उसमें लॉगिन हो, तो Drive फ़ोल्डर चुनकर JSON बैकअप सेव या रिस्टोर कर सकते हैं। ऐप को अलग से Drive OAuth secret की जरूरत नहीं होती।

## GitHub Actions सेटअप
1. इस ZIP की सामग्री GitHub repository में डालें।
2. GitHub Actions workflow Gradle 8.11.1 install करके wrapper generate करता है।
3. GitHub repository → Settings → Secrets and variables → Actions में ये secrets जोड़ें:
   - `ANDROID_KEYSTORE_BASE64` — release `.jks` फ़ाइल का Base64
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
4. Actions → **Daily Hisaab PRO — Release APK** → **Run workflow**।
5. `Daily-Hisaab-PRO-Release` artifact से APK और SHA-256 checksum डाउनलोड करें।

### Keystore को Base64 में बदलना
Linux/macOS:
```bash
base64 -w 0 release-key.jks
```
macOS पर यदि `-w` उपलब्ध नहीं:
```bash
base64 release-key.jks | tr -d '\n'
```

## Build
Android Studio में खोलें, JDK 17 चुनें, Android SDK 36 install करें और `assembleRelease` चलाएँ।

## महत्वपूर्ण
- इस source ZIP में Gradle wrapper JAR शामिल नहीं है; GitHub Actions workflow build के दौरान Gradle 8.11.1 install करके wrapper generate और verify करता है। Android Studio में खोलते समय IDE यदि wrapper माँगे, तो `gradle wrapper --gradle-version 8.11.1` चलाएँ।
- यह प्रारंभिक source project है, अभी इस वातावरण में Android SDK build, device runtime test, PIN brute-force protection, encrypted database, and restore-on-existing-data confirmation audit नहीं किए गए हैं। वास्तविक Release APK बनने से पहले Android Studio/GitHub Actions में build और device पर परीक्षण करें।
- PIN स्थानीय SharedPreferences में रखा जाता है; यह शुरुआती सुरक्षा है, उच्च-सुरक्षा encrypted vault नहीं।
