# Daily Hisaab PRO — फीचर ऑडिट

## स्रोत में मौजूद सुविधाएँ
- PIN सेटअप और PIN लॉगिन; PIN salted PBKDF2 hash के रूप में रखा जाता है।
- लगातार 5 गलत PIN प्रयासों पर 30 सेकंड का अस्थायी लॉक।
- ऐप बैकग्राउंड में जाने पर दोबारा PIN माँगने का व्यवहार।
- होम डैशबोर्ड: इस महीने की कमाई, खर्च और बचत।
- खर्च/कमाई जोड़ना; रकम, श्रेणी, विवरण, भुगतान माध्यम और तारीख।
- लेन-देन सूची; टैप करके एडिट और हटाने की पुष्टि।
- मासिक सारांश और श्रेणीवार खर्च रिपोर्ट।
- बहु-पृष्ठ मासिक PDF निर्यात।
- JSON बैकअप और पुष्टि के बाद ट्रांज़ैक्शन का transactional restore।
- PIN बदलने की सेटिंग।
- DB save/delete तथा backup/PDF output असफल होने पर error message।

## महत्वपूर्ण सीमाएँ / शेष सत्यापन
- Google Drive का उपयोग Android System File Picker से होता है; ऐप में अलग Google Drive API/OAuth integration नहीं है। Drive विकल्प तभी दिखेगा जब डिवाइस पर Drive उपलब्ध/साइन-इन हो।
- इस वातावरण में Android SDK/Gradle उपलब्ध नहीं मिला, इसलिए वास्तविक APK compile, device install, UI interaction और runtime test नहीं किए गए।
- Release workflow को GitHub Actions में चलाने के लिए repository secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD` आवश्यक हैं।
- ZIP integrity और source-level checks, वास्तविक Android build/runtime verification के बराबर नहीं हैं।
