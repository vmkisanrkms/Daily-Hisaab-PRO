package com.dailyhisaab.pro

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64

class MainActivity : AppCompatActivity() {
    private val db by lazy { AppDatabase.get(this) }
    private lateinit var content: LinearLayout
    private lateinit var headerBalance: TextView
    private var currentItems: List<Transaction> = emptyList()
    private var selectedDate = System.currentTimeMillis()
    private var currentScreen = "HOME"
    private var uiReady = false
    private var requiresUnlock = false
    private var externalPickerOpen = false
    private var pinPromptShowing = false
    private val green = Color.rgb(23, 107, 87)
    private val pale = Color.rgb(235, 246, 241)
    private val ink = Color.rgb(30, 48, 43)
    private val fmt = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))

    private val backupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        externalPickerOpen = false
        if (uri != null) exportBackup(uri)
    }
    private val restoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        externalPickerOpen = false
        if (uri != null) restoreBackup(uri)
    }
    private val pdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        externalPickerOpen = false
        if (uri != null) exportPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!ensurePin()) return
        buildUi()
        lifecycleScope.launch {
            db.transactionDao().observeAll().collectLatest {
                currentItems = it
                renderDashboard()
            }
        }
    }

    private fun ensurePin(): Boolean {
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        val savedHash = prefs.getString("pin_hash", null)
        val savedSalt = prefs.getString("pin_salt", null)
        if (savedHash == null || savedSalt == null) {
            val input = EditText(this).apply {
                hint = "4 से 6 अंकों का PIN"
                inputType = 18
            }
            AlertDialog.Builder(this).setTitle("अपना PIN बनाएँ")
                .setMessage("आपके हिसाब को सुरक्षित रखने के लिए PIN सेट करें।")
                .setView(input).setCancelable(false)
                .setPositiveButton("सेव करें") { _, _ ->
                    val pin = input.text.toString()
                    if (pin.length in 4..6 && pin.all { it.isDigit() }) {
                        savePin(pin)
                        openMainUi()
                    } else {
                        Toast.makeText(this, "PIN 4 से 6 अंकों का रखें", Toast.LENGTH_LONG).show()
                        finish()
                    }
                }.show()
            return false
        }
        promptPin(savedSalt, savedHash)
        return false
    }

    private fun promptPin(savedSalt: String, savedHash: String) {
        if (pinPromptShowing || isFinishing) return
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        val lockoutUntil = prefs.getLong("pin_lockout_until", 0L)
        val now = System.currentTimeMillis()
        if (lockoutUntil > now) {
            val seconds = ((lockoutUntil - now + 999) / 1000)
            AlertDialog.Builder(this).setTitle("PIN अस्थायी रूप से लॉक है")
                .setMessage("कई गलत प्रयास हुए। कृपया $seconds सेकंड बाद दोबारा कोशिश करें।")
                .setCancelable(false).setPositiveButton("ठीक है") { _, _ -> finish() }.show()
            return
        }
        val input = EditText(this).apply { hint = "PIN दर्ज करें"; inputType = 18 }
        pinPromptShowing = true
        AlertDialog.Builder(this).setTitle("Daily Hisaab PRO")
            .setMessage("अपना PIN डालें").setView(input).setCancelable(false)
            .setPositiveButton("खोलें") { _, _ ->
                pinPromptShowing = false
                if (verifyPin(input.text.toString(), savedSalt, savedHash)) {
                    prefs.edit().remove("pin_failed_attempts").remove("pin_lockout_until").apply()
                    requiresUnlock = false
                    openMainUi()
                } else {
                    val attempts = prefs.getInt("pin_failed_attempts", 0) + 1
                    val editor = prefs.edit().putInt("pin_failed_attempts", attempts)
                    if (attempts >= 5) {
                        editor.putLong("pin_lockout_until", System.currentTimeMillis() + 30_000L)
                            .putInt("pin_failed_attempts", 0)
                    }
                    editor.apply()
                    if (attempts >= 5) {
                        Toast.makeText(this, "5 गलत प्रयास। 30 सेकंड के लिए PIN लॉक किया गया।", Toast.LENGTH_LONG).show()
                        finish()
                    } else {
                        Toast.makeText(this, "गलत PIN। बाकी प्रयास: ${5 - attempts}", Toast.LENGTH_LONG).show()
                        window.decorView.post { promptPin(savedSalt, savedHash) }
                    }
                }
            }.setNegativeButton("बंद करें") { _, _ ->
                pinPromptShowing = false
                finish()
            }.setOnCancelListener {
                pinPromptShowing = false
                finish()
            }.show()
    }

    private fun openMainUi() {
        if (!uiReady) {
            buildUi()
            uiReady = true
            lifecycleScope.launch {
                db.transactionDao().observeAll().collectLatest {
                    currentItems = it
                    renderDashboard()
                }
            }
        } else {
            renderDashboard()
        }
    }

    override fun onStop() {
        super.onStop()
        if (uiReady && !externalPickerOpen && !isChangingConfigurations) {
            requiresUnlock = true
        }
    }

    override fun onResume() {
        super.onResume()
        if (requiresUnlock && uiReady && !externalPickerOpen) {
            requiresUnlock = false
            val prefs = getSharedPreferences("secure", MODE_PRIVATE)
            val salt = prefs.getString("pin_salt", null)
            val hash = prefs.getString("pin_hash", null)
            if (salt != null && hash != null) promptPin(salt, hash)
        }
    }

    private fun savePin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = pinHash(pin, salt)
        getSharedPreferences("secure", MODE_PRIVATE).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .remove("pin")
            .apply()
    }

    private fun pinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun verifyPin(pin: String, saltText: String, hashText: String): Boolean {
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            val expected = Base64.decode(hashText, Base64.NO_WRAP)
            java.security.MessageDigest.isEqual(pinHash(pin, salt), expected)
        } catch (_: Exception) { false }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 250, 248))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(green)
        }
        top.addView(label("Daily Hisaab PRO", 23f, Color.WHITE, true))
        top.addView(label("आपकी कमाई और खर्च — एक ही जगह", 13f, Color.rgb(220, 240, 232), false))
        root.addView(top)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderDashboard()
    }

    private fun renderDashboard() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        if (currentScreen != "HOME") {
            renderSecondaryScreen()
            return
        }
        val now = Calendar.getInstance()
        now.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(now)
        val start = now.timeInMillis
        val endCal = Calendar.getInstance(); endCal.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(endCal); endCal.add(Calendar.MONTH, 1)
        val monthItems = currentItems.filter { it.dateMillis >= start && it.dateMillis < endCal.timeInMillis }
        val income = monthItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
        val expense = monthItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }

        content.addView(label("नमस्ते! आज का हिसाब", 19f, ink, true))
        content.addView(label("इस महीने की स्थिति", 13f, Color.DKGRAY, false))
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cards.addView(summaryCard("कमाई", money(income), Color.rgb(18, 122, 81)), LinearLayout.LayoutParams(0, dp(94), 1f))
        cards.addView(summaryCard("खर्च", money(expense), Color.rgb(190, 72, 60)), LinearLayout.LayoutParams(0, dp(94), 1f).apply { leftMargin = dp(8) })
        content.addView(cards)
        val balance = income - expense
        content.addView(summaryCard("महीने की बचत (कमाई − खर्च)", money(balance), green), LinearLayout.LayoutParams(-1, dp(76)).apply { topMargin = dp(8) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("+ खर्च जोड़ें") { showTransactionDialog("EXPENSE") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        actions.addView(actionButton("+ कमाई जोड़ें") { showTransactionDialog("INCOME") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(8) })
        content.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(smallButton("मासिक PDF") { externalPickerOpen = true; pdfLauncher.launch("Daily_Hisaab_${monthName()}.pdf") }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(smallButton("बैकअप") { externalPickerOpen = true; backupLauncher.launch("Daily_Hisaab_Backup.json") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        tools.addView(smallButton("रिस्टोर") { externalPickerOpen = true; restoreLauncher.launch(arrayOf("application/json", "text/*")) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        content.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        content.addView(label("सभी सुविधाएँ", 18f, ink, true).apply { setPadding(0, dp(18), 0, dp(7)) })
        val navRows = listOf(
            listOf("📒 लेन-देन सूची" to "TRANSACTIONS", "📊 मासिक रिपोर्ट" to "REPORT"),
            listOf("🧾 श्रेणीवार रिपोर्ट" to "CATEGORIES", "📄 PDF रिपोर्ट" to "PDF"),
            listOf("☁ बैकअप / रिस्टोर" to "BACKUP", "⚙ सेटिंग्स" to "SETTINGS")
        )
        navRows.forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEachIndexed { index, pair ->
                row.addView(smallButton(pair.first) { currentScreen = pair.second; renderDashboard() },
                    LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (index > 0) leftMargin = dp(7) })
            }
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }

        content.addView(label("हाल के लेन-देन", 18f, ink, true).apply { setPadding(0, dp(20), 0, dp(8)) })
        if (currentItems.isEmpty()) {
            content.addView(label("अभी कोई हिसाब नहीं है। ‘खर्च जोड़ें’ या ‘कमाई जोड़ें’ दबाकर शुरुआत करें।", 14f, Color.GRAY, false))
        } else {
            currentItems.take(50).forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(13), dp(10), dp(13), dp(10))
                    setBackgroundColor(Color.WHITE)
                }
                val line1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val title = "${if (item.type == "EXPENSE") "खर्च" else "कमाई"} • ${item.category}"
                line1.addView(label(title, 15f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
                val amountColor = if (item.type == "EXPENSE") Color.rgb(190, 72, 60) else Color.rgb(18, 122, 81)
                line1.addView(label("${if (item.type == "EXPENSE") "−" else "+"}${money(item.amountPaise)}", 15f, amountColor, true))
                row.addView(line1)
                row.addView(label("${fmt.format(Date(item.dateMillis))} • ${item.paymentMethod}${if (item.note.isNotBlank()) " • ${item.note}" else ""}", 12f, Color.GRAY, false))
                row.isClickable = true
                row.setOnClickListener { showTransactionDialog(item.type, item) }
                row.setOnLongClickListener {
                    AlertDialog.Builder(this)
                        .setTitle("लेन-देन हटाएँ?")
                        .setMessage("${item.category} • ${money(item.amountPaise)} को हटाना चाहते हैं?")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("हटाएँ") { _, _ ->
                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    db.transactionDao().delete(item)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड नहीं हट पाया: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.show()
                    true
                }
                content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
        }
        content.addView(smallButton("PIN बदलें") { changePin() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(12) })
    }

    private fun renderSecondaryScreen() {
        val title = when (currentScreen) {
            "TRANSACTIONS" -> "सभी लेन-देन"
            "REPORT" -> "मासिक रिपोर्ट"
            "CATEGORIES" -> "श्रेणीवार रिपोर्ट"
            "PDF" -> "PDF रिपोर्ट"
            "BACKUP" -> "बैकअप और रिस्टोर"
            "SETTINGS" -> "सेटिंग्स"
            else -> "Daily Hisaab PRO"
        }
        content.addView(actionButton("← होम स्क्रीन") { currentScreen = "HOME"; renderDashboard() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        content.addView(label(title, 22f, ink, true))
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); startOfMonth(this) }
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val monthItems = currentItems.filter { it.dateMillis >= start && it.dateMillis < end }
        val income = monthItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
        val expense = monthItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
        when (currentScreen) {
            "TRANSACTIONS" -> {
                content.addView(actionButton("+ खर्च जोड़ें") { showTransactionDialog("EXPENSE") })
                content.addView(actionButton("+ कमाई जोड़ें") { showTransactionDialog("INCOME") }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
                if (currentItems.isEmpty()) content.addView(label("अभी कोई लेन-देन नहीं है।", 15f, Color.GRAY, false))
                currentItems.forEach { item ->
                    val row = summaryCard("${if (item.type == "EXPENSE") "खर्च" else "कमाई"} • ${item.category} • ${fmt.format(Date(item.dateMillis))}",
                        "${if (item.type == "EXPENSE") "−" else "+"}${money(item.amountPaise)}", if (item.type == "EXPENSE") Color.rgb(190,72,60) else Color.rgb(18,122,81))
                    row.setOnClickListener { showTransactionDialog(item.type, item) }
                    row.isClickable = true
                    row.setOnLongClickListener {
                        AlertDialog.Builder(this)
                            .setTitle("लेन-देन हटाएँ?")
                            .setMessage("${item.category} • ${money(item.amountPaise)} को हटाना चाहते हैं?")
                            .setNegativeButton("रद्द करें", null)
                            .setPositiveButton("हटाएँ") { _, _ ->
                                lifecycleScope.launch(Dispatchers.IO) {
                                    db.transactionDao().delete(item)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }.show()
                        true
                    }
                    content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
                }
            }
            "REPORT" -> {
                content.addView(summaryCard("कुल कमाई", money(income), Color.rgb(18,122,81)), LinearLayout.LayoutParams(-1, dp(76)).apply { topMargin = dp(8) })
                content.addView(summaryCard("कुल खर्च", money(expense), Color.rgb(190,72,60)), LinearLayout.LayoutParams(-1, dp(76)).apply { topMargin = dp(8) })
                content.addView(summaryCard("बचत / शेष", money(income-expense), green), LinearLayout.LayoutParams(-1, dp(76)).apply { topMargin = dp(8) })
                content.addView(label("इस महीने कुल ${monthItems.size} लेन-देन दर्ज हैं।", 15f, ink, false))
            }
            "CATEGORIES" -> {
                monthItems.filter { it.type == "EXPENSE" }.groupBy { it.category }.entries.sortedByDescending { e -> e.value.sumOf { it.amountPaise } }.forEach { entry ->
                    val amount = entry.value.sumOf { it.amountPaise }
                    val percent = if (expense > 0) amount * 100.0 / expense else 0.0
                    content.addView(summaryCard(entry.key, "${money(amount)}  •  ${String.format(Locale.US, "%.1f", percent)}%", green), LinearLayout.LayoutParams(-1, dp(70)).apply { topMargin = dp(7) })
                }
                if (monthItems.none { it.type == "EXPENSE" }) content.addView(label("इस महीने खर्च का डेटा नहीं है।", 15f, Color.GRAY, false))
            }
            "PDF" -> {
                content.addView(label("मौजूदा महीने की पूरी लेन-देन रिपोर्ट PDF में सेव करें।", 15f, Color.DKGRAY, false))
                content.addView(actionButton("📄 मासिक PDF बनाएँ") { externalPickerOpen = true; pdfLauncher.launch("Daily_Hisaab_${monthName()}.pdf") }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })
            }
            "BACKUP" -> {
                content.addView(label("बैकअप फ़ाइल मोबाइल में सेव करें या Android फ़ाइल पिकर में Google Drive चुनें।", 14f, Color.DKGRAY, false))
                content.addView(actionButton("⬇ मोबाइल / Drive में बैकअप") { externalPickerOpen = true; backupLauncher.launch("Daily_Hisaab_Backup.json") }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
                content.addView(actionButton("⬆ बैकअप रिस्टोर करें") { externalPickerOpen = true; restoreLauncher.launch(arrayOf("application/json", "text/*")) }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
                content.addView(label("ध्यान दें: रिस्टोर करने पर मौजूदा रिकॉर्ड बैकअप के रिकॉर्ड से बदलेंगे।", 13f, Color.rgb(160,75,35), false))
            }
            "SETTINGS" -> {
                content.addView(summaryCard("ऐप सुरक्षा", "PIN लॉक चालू", green), LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(8) })
                content.addView(actionButton("🔒 PIN बदलें") { changePin() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
                content.addView(label("Daily Hisaab PRO • संस्करण 1.0.0", 13f, Color.GRAY, false))
            }
        }
    }

    private fun startOfMonth(cal: Calendar) {
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    }

    private fun showTransactionDialog(type: String, existing: Transaction? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(6), dp(20), dp(2))
        }
        val amount = EditText(this).apply {
            hint = "रकम (₹)"; inputType = 8194
            if (existing != null) setText(String.format(Locale.US, "%.2f", existing.amountPaise / 100.0))
        }
        val category = Spinner(this).apply {
            val defaults = if (type == "EXPENSE") listOf("घर / राशन", "दूध / सब्ज़ी", "बिजली / पानी", "पेट्रोल / यात्रा", "दवा / स्वास्थ्य", "मोबाइल / इंटरनेट", "बच्चे / शिक्षा", "कपड़े", "मनोरंजन", "अन्य")
                else listOf("वेतन", "व्यापार", "खेती", "किराया", "वापसी / रिफंड", "अन्य")
            val options = if (existing != null && existing.category !in defaults) defaults + existing.category else defaults
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
        }
        val note = EditText(this).apply { hint = "विवरण (वैकल्पिक)"; if (existing != null) setText(existing.note) }
        val method = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("नकद", "UPI", "बैंक", "कार्ड", "अन्य"))
        }
        if (existing != null) selectedDate = existing.dateMillis else selectedDate = System.currentTimeMillis()
        val dateBtn = Button(this).apply { text = "तारीख: ${fmt.format(Date(selectedDate))}" }
        if (existing != null) {
            val categoryIndex = (category.adapter as ArrayAdapter<String>).getPosition(existing.category)
            if (categoryIndex >= 0) category.setSelection(categoryIndex)
            val methodIndex = (method.adapter as ArrayAdapter<String>).getPosition(existing.paymentMethod)
            if (methodIndex >= 0) method.setSelection(methodIndex)
        }
        dateBtn.setOnClickListener {
            val c = Calendar.getInstance().apply { timeInMillis = selectedDate }
            DatePickerDialog(this@MainActivity, { _, y, m, d ->
                val newC = Calendar.getInstance()
                newC.set(y, m, d, 12, 0, 0); selectedDate = newC.timeInMillis
                dateBtn.text = "तारीख: ${fmt.format(Date(selectedDate))}"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        box.addView(amount); box.addView(category); box.addView(note); box.addView(method); box.addView(dateBtn)
        val dialog = AlertDialog.Builder(this).setTitle(
            if (existing != null) "लेन-देन सुधारें" else if (type == "EXPENSE") "नया खर्च जोड़ें" else "नई कमाई जोड़ें"
        ).setView(box).setNegativeButton("रद्द करें", null)
            .setPositiveButton("सेव करें") { _, _ ->
                val value = amount.text.toString().trim().replace(",", ".").toDoubleOrNull()
                if (value == null || value <= 0 || value > 1000000000) {
                    Toast.makeText(this, "सही रकम दर्ज करें", Toast.LENGTH_LONG).show()
                } else {
                    val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
                    cal.set(Calendar.HOUR_OF_DAY, 12); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                    val item = Transaction(
                        id = existing?.id ?: 0,
                        type = type, amountPaise = (value * 100).toLong(),
                        category = category.selectedItem.toString(), note = note.text.toString().trim(),
                        paymentMethod = method.selectedItem.toString(), dateMillis = cal.timeInMillis,
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    )
                    lifecycleScope.launch(Dispatchers.IO) {
                        try {
                            if (existing == null) db.transactionDao().insert(item)
                            else db.transactionDao().update(item)
                            withContext(Dispatchers.Main) {
                                selectedDate = System.currentTimeMillis()
                                Toast.makeText(this@MainActivity, if (existing == null) "हिसाब सेव हो गया" else "हिसाब अपडेट हो गया", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "हिसाब सेव नहीं हुआ: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }
        if (existing != null) {
            dialog.setNeutralButton("हटाएँ") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("लेन-देन हटाएँ?")
                    .setMessage("${existing.category} • ${money(existing.amountPaise)} का रिकॉर्ड हमेशा के लिए हट जाएगा।")
                    .setNegativeButton("रद्द करें", null)
                    .setPositiveButton("हाँ, हटाएँ") { _, _ ->
                        lifecycleScope.launch(Dispatchers.IO) {
                            db.transactionDao().delete(existing)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }.show()
            }
        }
        dialog.show()
    }

    private fun exportBackup(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                db.transactionDao().allNow().forEach { t ->
                    arr.put(JSONObject().apply {
                        put("id", t.id); put("type", t.type); put("amountPaise", t.amountPaise)
                        put("category", t.category); put("note", t.note); put("paymentMethod", t.paymentMethod)
                        put("dateMillis", t.dateMillis); put("createdAt", t.createdAt)
                    })
                }
                val payload = JSONObject().put("app", "Daily Hisaab PRO").put("version", 1)
                    .put("exportedAt", System.currentTimeMillis()).put("transactions", arr).toString(2)
                val output = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("चुनी गई जगह पर फ़ाइल नहीं बनाई जा सकी")
                output.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "बैकअप सेव हो गया", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "बैकअप नहीं बन पाया: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun restoreBackup(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val raw = contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                } ?: throw IllegalStateException("फ़ाइल नहीं खुली")
                val obj = JSONObject(raw)
                if (obj.optString("app") != "Daily Hisaab PRO") {
                    throw IllegalArgumentException("यह Daily Hisaab PRO की बैकअप फ़ाइल नहीं है")
                }
                val arr = obj.getJSONArray("transactions")
                val items = mutableListOf<Transaction>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val type = o.getString("type")
                    val amount = o.getLong("amountPaise")
                    val date = o.getLong("dateMillis")
                    if (type !in listOf("INCOME", "EXPENSE") || amount <= 0L || date <= 0L) {
                        throw IllegalArgumentException("बैकअप में गलत रिकॉर्ड है (क्रम ${i + 1})")
                    }
                    items.add(Transaction(
                        type = type,
                        amountPaise = amount,
                        category = o.optString("category", "अन्य"),
                        note = o.optString("note", ""),
                        paymentMethod = o.optString("paymentMethod", "नकद"),
                        dateMillis = date,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
                withContext(Dispatchers.Main) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("बैकअप रिस्टोर करें?")
                        .setMessage("${items.size} रिकॉर्ड रिस्टोर होंगे। मौजूदा हिसाब हटकर बैकअप का हिसाब आ जाएगा। पहले मौजूदा डेटा का बैकअप ले लें।")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("रिस्टोर करें") { _, _ ->
                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    db.withTransaction {
                                        db.transactionDao().clearAll()
                                        if (items.isNotEmpty()) db.transactionDao().insertAll(items)
                                    }
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "${items.size} रिकॉर्ड रिस्टोर हुए", Toast.LENGTH_LONG).show()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिस्टोर असफल: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "रिस्टोर असफल: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun exportPdf(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val cal = Calendar.getInstance()
                cal.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(cal)
                val start = cal.timeInMillis
                cal.add(Calendar.MONTH, 1)
                val end = cal.timeInMillis
                val items = db.transactionDao().forPeriod(start, end)
                val income = items.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                val expense = items.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                val pdf = PdfDocument()
                val pageWidth = 595
                val pageHeight = 842
                val margin = 32f
                val rowHeight = 24f
                val rowsPerPage = 26
                val pages = maxOf(1, (items.size + rowsPerPage - 1) / rowsPerPage)
                val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(23, 107, 87); textSize = 20f
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.DKGRAY; textSize = 9.5f
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                }
                val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(235, 246, 241); textSize = 9f
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.LTGRAY; strokeWidth = 0.7f
                }
                for (pageNumber in 0 until pages) {
                    val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber + 1).create()
                    val page = pdf.startPage(info)
                    val canvas = page.canvas
                    canvas.drawText("Daily Hisaab PRO", margin, 42f, titlePaint)
                    bodyPaint.textSize = 10f
                    canvas.drawText("मासिक रिपोर्ट: ${monthName()}    पृष्ठ ${pageNumber + 1}/$pages", margin, 62f, bodyPaint)
                    if (pageNumber == 0) {
                        bodyPaint.textSize = 10f
                        canvas.drawText("कुल कमाई: ${money(income)}", margin, 84f, bodyPaint)
                        canvas.drawText("कुल खर्च: ${money(expense)}", 220f, 84f, bodyPaint)
                        canvas.drawText("शेष: ${money(income - expense)}", 400f, 84f, bodyPaint)
                    }
                    var y = if (pageNumber == 0) 112f else 82f
                    canvas.drawRect(margin, y - 14f, pageWidth - margin, y + 5f, headerPaint)
                    bodyPaint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    canvas.drawText("तारीख", margin + 3f, y, bodyPaint)
                    canvas.drawText("प्रकार", margin + 73f, y, bodyPaint)
                    canvas.drawText("श्रेणी / विवरण", margin + 135f, y, bodyPaint)
                    canvas.drawText("तरीका", margin + 365f, y, bodyPaint)
                    canvas.drawText("रकम", margin + 445f, y, bodyPaint)
                    y += 22f
                    bodyPaint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    val from = pageNumber * rowsPerPage
                    val to = minOf(items.size, from + rowsPerPage)
                    for (i in from until to) {
                        val t = items[i]
                        val dateText = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(t.dateMillis))
                        val typeText = if (t.type == "INCOME") "कमाई" else "खर्च"
                        val detail = (t.category + if (t.note.isNotBlank()) " / " + t.note else "")
                        canvas.drawText(dateText, margin + 3f, y, bodyPaint)
                        canvas.drawText(typeText, margin + 73f, y, bodyPaint)
                        canvas.drawText(detail.take(34), margin + 135f, y, bodyPaint)
                        canvas.drawText(t.paymentMethod.take(10), margin + 365f, y, bodyPaint)
                        canvas.drawText(money(t.amountPaise), margin + 445f, y, bodyPaint)
                        canvas.drawLine(margin, y + 7f, pageWidth - margin, y + 7f, linePaint)
                        y += rowHeight
                    }
                    if (items.isEmpty()) {
                        canvas.drawText("इस महीने कोई रिकॉर्ड नहीं है।", margin + 3f, y, bodyPaint)
                    }
                    pdf.finishPage(page)
                }
                val output = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("चुनी गई जगह पर PDF नहीं बनाई जा सकी")
                output.use { pdf.writeTo(it) }
                pdf.close()
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "मासिक PDF सेव हो गई (${pages} पृष्ठ)", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "PDF नहीं बनी: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun changePin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        val oldPin = EditText(this).apply { hint = "मौजूदा PIN"; inputType = 18 }
        val newPin = EditText(this).apply { hint = "नया 4–6 अंकों का PIN"; inputType = 18 }
        box.addView(oldPin); box.addView(newPin)
        AlertDialog.Builder(this).setTitle("PIN बदलें").setView(box)
            .setNegativeButton("रद्द", null).setPositiveButton("सेव") { _, _ ->
                val prefs = getSharedPreferences("secure", MODE_PRIVATE)
                val savedHash = prefs.getString("pin_hash", null)
                val savedSalt = prefs.getString("pin_salt", null)
                val newValue = newPin.text.toString()
                if (savedHash == null || savedSalt == null || !verifyPin(oldPin.text.toString(), savedSalt, savedHash)) {
                    Toast.makeText(this, "मौजूदा PIN गलत है", Toast.LENGTH_LONG).show()
                } else if (newValue.length in 4..6 && newValue.all { it.isDigit() }) {
                    savePin(newValue)
                    Toast.makeText(this, "PIN सुरक्षित रूप से बदल गया", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN 4 से 6 अंकों का होना चाहिए", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun summaryCard(title: String, value: String, color: Int): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        card.addView(label(title, 12f, Color.DKGRAY, false))
        card.addView(label(value, 19f, color, true))
        return card
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setBackgroundColor(green); setTextColor(Color.WHITE); setOnClickListener { action() }
    }
    private fun smallButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 12f; setOnClickListener { action() }
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun money(paise: Long): String = "₹ " + String.format(Locale.US, "%,.2f", paise / 100.0)
    private fun monthName(): String = SimpleDateFormat("yyyy_MM", Locale.US).format(Date())
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
