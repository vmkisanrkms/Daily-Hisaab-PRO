plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.majdoor.hisaabpro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.majdoor.hisaabpro"
        minSdk = 23
        targetSdk = 36
        versionCode = 90
        versionName = "1.90.0"
    }

    // Read the permanent signing values from the environment at Gradle
    // configuration time. The workflow also passes them explicitly to the
    // assemble step so they cannot be lost between GitHub Actions steps.
    // Accept both canonical and legacy environment names so the signing
    // configuration remains compatible with the GitHub Actions workflow.
    val releaseKeystore = providers.environmentVariable("KEYSTORE_FILE").orNull
        ?: providers.environmentVariable("KS_KEYSTORE_FILE").orNull
    val releaseStorePassword = providers.environmentVariable("KEYSTORE_PASSWORD").orNull
        ?: providers.environmentVariable("KS_PASSWORD").orNull
    val releaseKeyAlias = providers.environmentVariable("KEY_ALIAS").orNull
        ?: providers.environmentVariable("KS_ALIAS").orNull
    val releaseKeyPassword = providers.environmentVariable("KEY_PASSWORD").orNull
        ?: providers.environmentVariable("KS_KEY_PASSWORD").orNull

    signingConfigs {
        if (!releaseKeystore.isNullOrBlank()) {
            require(!releaseStorePassword.isNullOrBlank()) {
                "KEYSTORE_PASSWORD is missing for Release signing."
            }
            require(!releaseKeyAlias.isNullOrBlank()) {
                "KEY_ALIAS is missing for Release signing."
            }
            require(!releaseKeyPassword.isNullOrBlank()) {
                "KEY_PASSWORD is missing for Release signing."
            }
            create("release") {
                storeFile = file(releaseKeystore)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (!releaseKeystore.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.05.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.0")
    implementation("androidx.navigation:navigation-compose:2.9.0")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
