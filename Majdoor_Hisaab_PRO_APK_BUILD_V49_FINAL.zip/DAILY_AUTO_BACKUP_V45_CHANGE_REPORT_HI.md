# Daily Automatic Backup — V45

## क्या जोड़ा गया
- रोज़ रात 10:00 बजे (फोन के local time) automatic backup schedule।
- Backup फोन के app-private `files/automatic_backups/` folder में ZIP के रूप में बनता है।
- नया backup बनने के बाद ZIP validation की जाती है।
- अधिकतम 14 नवीनतम verified daily backups रखे जाते हैं; पुराने snapshots उसके बाद हटते हैं।
- फोन restart, app update, समय/समय-क्षेत्र बदलने पर अगला daily alarm फिर schedule होता है।
- App launch और resume पर schedule भी सुनिश्चित होता है।
- पहले से जुड़ा Google account उपलब्ध हो तो receiver background में Drive upload का प्रयास करता है।
- Drive account न जुड़ा हो या OAuth/remote consent/network में दिक्कत हो तो local backup फिर भी सुरक्षित रहता है और Drive sync status preference में दर्ज होता है।
- Backup failure का status/error preference में दर्ज होता है; पिछला local backup नहीं हटाया जाता।

## सुरक्षा/व्यवहार
- Local snapshots app-private storage में हैं; दूसरे apps सामान्यतः उन्हें सीधे नहीं पढ़ सकते।
- Google Drive background upload केवल पहले से linked account पर best-effort है। यदि Google को दोबारा user consent चाहिए, background task UI नहीं खोल सकता; local backup सुरक्षित रहेगा और Drive sync असफल दर्ज होगा।
- Android battery optimization / Doze के कारण `setAndAllowWhileIdle` alarm 10 PM के ठीक उसी मिनट के बजाय कुछ देर बाद चल सकता है।
- App data uninstall/clear करने पर app-private backups भी हट सकते हैं; इसलिए Drive sync या समय-समय पर manual export महत्वपूर्ण है।

## Verification
- ZIP integrity और manifest receiver declarations जाँचे गए।
- Kotlin compile का प्रयास किया, लेकिन Gradle wrapper bootstrap `raw.githubusercontent.com` DNS failure से रुक गया। Kotlin compilation और real-device schedule/Drive runtime अभी सत्यापित नहीं हैं।
