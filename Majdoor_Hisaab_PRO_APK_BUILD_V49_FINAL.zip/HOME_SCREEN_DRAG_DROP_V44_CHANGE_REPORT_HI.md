# Home Screen Drag & Drop — V44

## लागू बदलाव
- Home Screen के 14 मुख्य मॉड्यूल कार्ड अब एक ही reorderable grid में हैं।
- किसी कार्ड को long-press करके ऊपर/नीचे या दूसरे स्थान पर drag करने पर कार्ड insertion-style में नई जगह जाता है।
- बीच के कार्ड अपने-आप एक-एक स्थान खिसकते हैं; खाली जगह नहीं रहती।
- दो-कॉलम layout बना रहता है।
- नया क्रम `SharedPreferences` में `dashboard_shortcut_order_v1` के अंतर्गत सेव होता है।
- ऐप दोबारा खोलने पर सेव किया गया क्रम लोड होता है।
- `रीसेट` से मूल क्रम वापस किया जा सकता है।
- कार्ड के मौजूदा route/onClick को यथावत रखा गया है; मॉड्यूल के अंदरूनी स्क्रीन और डेटा मॉडल में बदलाव नहीं किया गया।

## शामिल कार्ड
खेत, फसल, खर्च, बिक्री, काम दर्ज करें, काम की सूची, मजदूरी-दर इतिहास, आय और मुनाफा,
गन्ना पर्ची, गन्ना छिलाई, दिहाड़ी मजदूर, Salary Employee, रिपोर्ट सेंटर, सेटिंग व अन्य विकल्प।

## Static verification
- Kotlin source में drag gesture handler मौजूद।
- सभी 14 shortcut IDs की default सूची मौजूद।
- Saved order persistence और reset action मौजूद।
- ZIP integrity test पास।

## Build verification limitation
Gradle compile शुरू नहीं हो सका क्योंकि wrapper bootstrap को `raw.githubusercontent.com` से डाउनलोड करने के लिए नेटवर्क/DNS उपलब्ध नहीं था। इसलिए इस ZIP के लिए APK compile और वास्तविक फोन पर drag gesture runtime test प्रमाणित नहीं हैं।
