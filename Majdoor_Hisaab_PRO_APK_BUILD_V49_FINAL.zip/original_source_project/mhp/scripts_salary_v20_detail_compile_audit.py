from pathlib import Path
import re
source = (Path(__file__).parent / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
start = source.index('private fun SalaryEmployeeDetailScreen(')
end = source.index('private fun shareSalaryEmployeePdf(', start)
detail = source[start:end]
checks = {
    'detail screen declares absent count before interpolation': 'val absentDays=record.daily.values.count{it.status=="भांजी"||it.status=="अनुपस्थित"||it.status=="छुट्टी"}' in detail and not re.search(r'\$absent(?![A-Za-z])', detail),
    'detail screen declares present, absent, leave counts': all(x in detail for x in ['val presentDays=', 'val absentDays=', 'val leaveDays=']),
    'detail screen calculates unmarked eligible days': 'val unmarkedDays=' in detail and 'eligibleDays-presentDays-halfDays-absentDays-leaveDays' in detail,
    'detail balance exposes overpayment instead of hiding it': 'val overpaid=(-netBalance).coerceAtLeast(0.0)' in detail and '"अधिक भुगतान"' in detail,
    'detail attendance summary uses declared counters': all(x in detail for x in ['$presentDays', '$halfDays', '${absentDays+leaveDays}', '$unmarkedDays']),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
