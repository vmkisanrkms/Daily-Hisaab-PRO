from pathlib import Path
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text()
checks={
 'payment history rows are tappable': 'showPaymentEditor=true' in s and 'एडिट / हटाएँ' in s,
 'payment history opens existing month editor': 'SalaryMonthDialog(employee=employee,month=month,initial=record' in s,
 'edit/delete actions exist in payment editor': 'Text("एडिट")' in s and 'Text("हटाएँ"' in s,
 'payment edits are protected by device credential': 'भुगतान इतिहास बदलें' in s and 'DeviceCredentialGate(' in s,
 'updated payment record is persisted': 'saveSalaryMonth(context,employee.id,month,updated)' in s,
 'detail screen refreshes after save': 'refresh++' in s,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY: {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
