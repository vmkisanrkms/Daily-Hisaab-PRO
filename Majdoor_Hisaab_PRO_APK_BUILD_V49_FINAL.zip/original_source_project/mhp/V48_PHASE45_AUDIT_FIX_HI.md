# V48 — Phase 45 APK Audit Fix

## Screenshot में मिला failure
`Run source regression audits` में `scripts_redesign_phase13_work_wages_profitability_audit.py` का यह check FAIL था:
`F01 dashboard action routed to saved attendance field picker`

## कारण
V46/V47 Dashboard अब पुराने `DashboardModule(...)` declarations के बजाय reorderable `DashboardShortcut(...)` model से shortcuts बनाता है। Audit script पुराने UI declaration को ही पहचान रही थी, जबकि route mapping में `"work_entry"->Screen.AttendanceFields` मौजूद है।

## सुधार
Audit assertion को पुराने और नए दोनों implementation forms पहचानने योग्य बनाया:
- पुराने `DashboardModule(...)`
- नए `DashboardShortcut("work_entry", "🧾", "काम दर्ज करें", ...)`

Dashboard UI, attendance picker, database, गन्ना पर्ची और गन्ना छिलाई module में कोई बदलाव नहीं किया।

## Verification
`python scripts_redesign_phase13_work_wages_profitability_audit.py`:
**20 PASS, 0 FAIL**

ZIP integrity: verified after packaging.
Full GitHub audit chain, Kotlin compilation, signing and APK build: अभी GitHub Actions में दोबारा verify करना बाकी है।
