from pathlib import Path
import sys

root = Path(__file__).resolve().parent
main = root / "app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt"
source = main.read_text(encoding="utf-8")
receiver = (root / "app/src/main/java/com/majdoor/hisaabpro/SalaryAutoAttendanceReceiver.kt").read_text(encoding="utf-8")
checks = {
    "half-day status included in salary calculation at 0.5 weight": '"आधा दिन"->0.5' in source,
    "half-day quick action is available in employee attendance row": 'Text("½ आधा दिन"' in source,
    "half-day option available in salary detail editor": 'listOf("उपस्थित","आधा दिन","भांजी")' in source,
    "half-day status accepted by attendance validation": 'status !in setOf("उपस्थित","आधा दिन","भांजी")' in source,
    "half-day status persists through JSON load and save": 'status in setOf("उपस्थित","आधा दिन","अनुपस्थित","छुट्टी","भांजी")' in source,
    "auto attendance preserves any manually marked day": 'if (daily.has(today)) return@forEach' in receiver,
    "date and join-date validation remains": 'selectedAttendanceDate>=emp.joinDate' in source,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
print(f"RESULT: {sum(checks.values())}/{len(checks)} PASS")
if not all(checks.values()):
    sys.exit(1)
