#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).resolve().parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'attendance option is the first item inside Salary employee screen':'private fun SalaryEmployeeScreen' in s and 'Text(if (attendanceOnly) "आज की हाजिरी खुली है" else "आज की हाजिरी"' in s,
 'attendance mode toggles from the Salary employee module only':'attendanceOnly = !attendanceOnly' in s and 'Screen.SalaryEmployees->SalaryEmployeeScreen' in s,
 'attendance mode defaults to today':'if (attendanceOnly) { selectedAttendanceDate = today(); employeeSearch = ""; showArchived = false }' in s,
 'attendance list remains employee-by-employee':'items(filteredEmployees,key={it.id}) { emp ->' in s and 'Button(onClick={if(validDate(selectedAttendanceDate)' in s,
 'no bulk Save All attendance control added':'Save All' not in s and 'सभी की हाजिरी सेव करें' not in s,
 'attendance-only mode hides unrelated employee management controls':'if (!attendanceOnly)' in s and 'if(showArchived && !attendanceOnly)' in s,
 'selected date and back-date picker remain available':'हाजिरी की पूरी तारीख (YYYY-MM-DD)' in s and 'datePicker.maxDate=System.currentTimeMillis()' in s,
 'per-employee attendance still passes through device credential and persistence verification':'pendingAttendanceSave?.let' in s and 'check(savedStatus == requestedStatus)' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
