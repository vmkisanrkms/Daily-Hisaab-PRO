# Majdoor Hisaab PRO V49 — Final Corrected Build Handover

## Corrections included
1. Phase 14 K01 report-centre dashboard audit recognizes both legacy `DashboardModule` and current `DashboardShortcut` declarations.
2. Phase 20 Backup/Restore audit no longer treats raw punctuation counts inside Kotlin string templates as compiler syntax validation. It checks source presence; Kotlin syntax remains the responsibility of the real Gradle compile step.
3. Phase 21 workflow ZIP assertion now checks the exact V49 source ZIP.
4. GitHub Actions workflow now selects `Majdoor_Hisaab_PRO_APK_BUILD_V49_FINAL.zip`.
5. APK artifact name updated to `Majdoor-Hisaab-PRO-V49-RELEASE.apk`.
6. Existing V48 fixes, dashboard routes, accounting, Ganna modules and backup code are retained.

## Targeted verification
- Phase 14 Reports/PDF audit: 22/22 PASS.
- Phase 20 Backup/Restore audit: 27/27 PASS.
- Phase 21 Shared UI/workflow audit: 24/24 PASS.
- Phase 13 Work/Wages/Profitability audit: 20/20 PASS.
- Phase 27 requested UI audit: 15/15 PASS.
- Phase 45 handover audit: 14/14 PASS.
- Phase 29 Fandi quick-entry audit: 14/14 PASS.
- Phase 28 Drive backup feedback audit: 9/9 PASS.
- ZIP integrity: checked after packaging.

## Release limitations
Kotlin compilation, Android resource processing, unit tests, permanent signing secrets, release APK assembly, APK signature/alignment and real-device runtime are not verified in this environment. The GitHub Actions workflow must complete those steps before this is called a verified APK release.

## GitHub upload instruction
Upload this ZIP to the repository root with the exact name:
`Majdoor_Hisaab_PRO_APK_BUILD_V49_FINAL.zip`
Then run the workflow: **Build and sign Phase 45 Release APK**.
