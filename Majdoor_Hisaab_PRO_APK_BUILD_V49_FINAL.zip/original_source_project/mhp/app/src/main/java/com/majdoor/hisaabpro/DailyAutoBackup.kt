package com.majdoor.hisaabpro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private const val DAILY_BACKUP_ACTION = "com.majdoor.hisaabpro.DAILY_AUTO_BACKUP"
private const val DAILY_BACKUP_PREFS = "mhpro_daily_backup_v1"
private const val DAILY_BACKUP_HOUR = 22
private const val DAILY_BACKUP_MINUTE = 0

/** Schedules one local, app-private backup around 10 PM (Android may defer it in Doze). */
fun runDailyAutoBackupNow(context: Context) {
    val intent = Intent(context, DailyAutoBackupReceiver::class.java).setAction(DAILY_BACKUP_ACTION)
    context.sendBroadcast(intent)
}
fun scheduleDailyAutoBackup(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, DailyAutoBackupReceiver::class.java).setAction(DAILY_BACKUP_ACTION)
    val pending = PendingIntent.getBroadcast(
        context, 72041, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val next = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, DAILY_BACKUP_HOUR)
        set(Calendar.MINUTE, DAILY_BACKUP_MINUTE)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    } else {
        alarm.set(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    }
}

/** Metadata is stored separately so the Backup screen can show the last automatic run. */
data class DailyBackupStatus(
    val status: String,
    val lastSuccessAt: Long,
    val fileName: String,
    val sizeBytes: Long,
    val driveStatus: String,
    val error: String
)

fun readDailyBackupStatus(context: Context): DailyBackupStatus {
    val prefs = context.getSharedPreferences(DAILY_BACKUP_PREFS, Context.MODE_PRIVATE)
    return DailyBackupStatus(
        prefs.getString("last_status", "PENDING").orEmpty(),
        prefs.getLong("last_success_at", 0L),
        prefs.getString("last_file", "").orEmpty(),
        prefs.getLong("last_size_bytes", 0L),
        prefs.getString("drive_sync_status", "अभी तक Drive sync नहीं चला").orEmpty(),
        prefs.getString("last_error", "").orEmpty()
    )
}

fun listDailyAutoBackups(context: Context): List<File> =
    File(context.filesDir, "automatic_backups").listFiles()
        ?.filter { it.isFile && it.name.startsWith("Majdoor_Hisaab_PRO_Auto_") && it.extension == "zip" }
        ?.sortedByDescending { it.lastModified() }
        ?: emptyList()

class DailyAutoBackupReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != DAILY_BACKUP_ACTION) return
        val app = context.applicationContext
        val pending = goAsync()
        executor.execute {
            try {
                val folder = File(app.filesDir, "automatic_backups")
                if (!folder.exists() && !folder.mkdirs()) {
                    throw IllegalStateException("फोन में automatic backup folder नहीं बन पाया।")
                }
                val date = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val output = File(folder, "Majdoor_Hisaab_PRO_Auto_$date.zip")
                val store = Store(app)
                store.createBackupZip(output)
                store.validateBackupZip(output)
                if (!output.isFile || output.length() <= 0L) {
                    throw IllegalStateException("Backup file खाली बनी।")
                }
                // Retain the latest 14 verified daily snapshots; never delete a file before
                // the newly generated backup has passed validation.
                folder.listFiles()
                    ?.filter { it.isFile && it.name.startsWith("Majdoor_Hisaab_PRO_Auto_") && it.extension == "zip" }
                    ?.sortedByDescending { it.lastModified() }
                    ?.drop(14)
                    ?.forEach { it.delete() }

                var driveSyncStatus = "Google Drive account linked नहीं है; local backup सुरक्षित है।"
                val drive = GoogleDriveDirect(app)
                val account = drive.lastAccount()
                if (account != null) {
                    driveSyncStatus = try {
                        val uploaded = drive.upload(account, output)
                        "Google Drive पर भी upload सफल: $uploaded"
                    } catch (driveError: Throwable) {
                        "Local backup सफल; Google Drive sync नहीं हुआ: ${(driveError.message ?: driveError.javaClass.simpleName).take(300)}"
                    }
                }
                val prefs = app.getSharedPreferences(DAILY_BACKUP_PREFS, Context.MODE_PRIVATE)
                prefs.edit()
                    .putLong("last_success_at", System.currentTimeMillis())
                    .putString("last_file", output.name)
                    .putLong("last_size_bytes", output.length())
                    .putString("last_status", "SUCCESS")
                    .putString("drive_sync_status", driveSyncStatus)
                    .remove("last_error")
                    .commit()
            } catch (error: Throwable) {
                app.getSharedPreferences(DAILY_BACKUP_PREFS, Context.MODE_PRIVATE).edit()
                    .putString("last_status", "FAILED")
                    .putString("last_error", (error.message ?: error.javaClass.simpleName).take(500))
                    .commit()
            } finally {
                scheduleDailyAutoBackup(app)
                pending.finish()
            }
        }
    }

    companion object {
        private val executor = Executors.newSingleThreadExecutor()
    }
}

class DailyAutoBackupBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            scheduleDailyAutoBackup(context)
        }
    }
}
