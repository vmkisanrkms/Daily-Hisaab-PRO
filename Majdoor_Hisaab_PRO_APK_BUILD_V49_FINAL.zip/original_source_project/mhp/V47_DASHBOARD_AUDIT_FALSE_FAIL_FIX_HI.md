# V47 — GitHub APK Build Audit False-Fail Fix

## Screenshot failure
GitHub Actions Phase 45 source regression audit stopped at `scripts_phase27_requested_ui_fixes_audit.py`:
- `dashboard has direct cane parchi shortcut` — FAIL
- `dashboard has direct cane peeling shortcut` — FAIL
The dashboard actually renders both cards from `DashboardShortcut` data through `ReorderableDashboardGrid`. The audit script only recognized older inline `Text` / `DashboardModule` implementations.

## Fix
Updated the two audit assertions to also recognize:
- `DashboardShortcut("cane", "🌾", "गन्ना पर्ची", ...)`
- `DashboardShortcut("cane_peeling", "🌿", "गन्ना छिलाई", ...)`

No dashboard UI, routes, database, Ganna Parchi, or Ganna Chhilai behavior was changed.

## Verification
- Ran `python scripts_phase27_requested_ui_fixes_audit.py`
- Result: **15/15 PASS, 0 FAIL**
- ZIP integrity checked after packaging.
- The full 40-script GitHub audit chain was not completed in this environment (execution interrupted); Android Kotlin compilation and APK signing are still to be verified by GitHub Actions.
