package com.majdoor.hisaabpro

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class SalaryAutoAttendanceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != "com.majdoor.hisaabpro.SALARY_AUTO_ATTENDANCE_5PM") return
        val prefs = context.getSharedPreferences("mhpro_salary_auto_attendance_v1", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("enabled_employee_ids", emptySet())?.toSet().orEmpty()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val month = today.take(7)
        val store = context.getSharedPreferences("mhpro_salary_employees_v1", Context.MODE_PRIVATE)
        val employees = runCatching { JSONArray(store.getString("employees", "[]") ?: "[]") }.getOrDefault(JSONArray())
        // Archived/deleted employees are no longer active; prune them from Auto to avoid stale daily alarms.
        val activeIds = (0 until employees.length()).mapNotNull { employees.optJSONObject(it)?.optString("id") }.toSet()
        val validIds = ids.intersect(activeIds)
        if (validIds != ids) prefs.edit().putStringSet("enabled_employee_ids", validIds).commit()
        val names = mutableListOf<String>()
        validIds.forEach { id ->
            val employee = (0 until employees.length()).mapNotNull { employees.optJSONObject(it) }.firstOrNull { it.optString("id") == id } ?: return@forEach
            if (employee.optString("joinDate").isNotBlank() && today < employee.optString("joinDate")) return@forEach
            val key = "month_${id}_$month"
            val record = runCatching { JSONObject(store.getString(key, "{}") ?: "{}") }.getOrDefault(JSONObject())
            val daily = record.optJSONObject("daily") ?: JSONObject()
            // Any existing manual mark (especially भांजी) is authoritative and is never overwritten.
            if (daily.has(today)) return@forEach
            daily.put(today, JSONObject().put("status", "उपस्थित").put("note", "Auto हाजिरी • शाम 5 बजे"))
            record.put("daily", daily)
            if (store.edit().putString(key, record.toString()).commit()) names.add(employee.optString("name", "कर्मचारी"))
        }
        if (names.isNotEmpty()) showNotification(context, names)
        scheduleNext(context)
    }

    private fun showNotification(context: Context, names: List<String>) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("salary_auto_attendance", "Salary Auto Attendance", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "शाम 5 बजे कर्मचारी की Auto हाजिरी" })
        }
        val open = PendingIntent.getActivity(context, 5107, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val body = names.joinToString("، ") { "$it – उपस्थित" }
        manager.notify(5108, NotificationCompat.Builder(context, "salary_auto_attendance")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("हाजिरी लग गई")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open).setAutoCancel(true).build())
    }

    companion object {
        fun scheduleNext(context: Context) {
            val prefs = context.getSharedPreferences("mhpro_salary_auto_attendance_v1", Context.MODE_PRIVATE)
            if (prefs.getStringSet("enabled_employee_ids", emptySet()).isNullOrEmpty()) {
                val cancelIntent = Intent(context, SalaryAutoAttendanceReceiver::class.java).setAction("com.majdoor.hisaabpro.SALARY_AUTO_ATTENDANCE_5PM")
                val cancelPending = PendingIntent.getBroadcast(context, 5105, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(cancelPending)
                return
            }
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, SalaryAutoAttendanceReceiver::class.java).setAction("com.majdoor.hisaabpro.SALARY_AUTO_ATTENDANCE_5PM")
            val pending = PendingIntent.getBroadcast(context, 5105, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.cancel(pending)
            val next = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 17); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
            try {
                if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) throw SecurityException("Exact alarm permission not granted")
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
            } catch (_: SecurityException) {
                // Android may defer this fallback; the Salary screen explicitly warns the user.
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
            }
        }
    }
}

class SalaryAutoAttendanceBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED || intent?.action == Intent.ACTION_TIME_CHANGED || intent?.action == Intent.ACTION_TIMEZONE_CHANGED) {
            SalaryAutoAttendanceReceiver.scheduleNext(context)
        }
    }
}
