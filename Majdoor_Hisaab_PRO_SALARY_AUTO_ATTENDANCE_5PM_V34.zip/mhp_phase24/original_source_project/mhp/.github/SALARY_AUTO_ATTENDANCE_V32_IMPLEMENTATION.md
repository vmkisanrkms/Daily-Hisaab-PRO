# Salary Auto Attendance V32

- Per-employee Auto/Manual switch in Salary Employee list.
- Auto attendance scheduled for 5:00 PM local device time. Exact alarm is requested through Android special app access; fallback uses allow-while-idle alarm when exact access is unavailable.
- Receiver writes only if the employee has no attendance entry for that date. Existing manual उपस्थित or भांजी entries are preserved.
- Notification is shown for successfully auto-marked employees. Notification permission is requested on app launch on Android 13+.
- Auto schedule is restored after device reboot, app update, clock/time-zone changes, and app launch/resume.
- Manual options are उपस्थित and भांजी only. Legacy छुट्टी/अनुपस्थित records are normalized as भांजी when read; old data is preserved in storage format.
- Existing same-day correction path allows changing भांजी to उपस्थित using the उपस्थित action.
- Only Salary Employee attendance module was changed; Ganna Chhilayi and Ganna Parchi source modules were not edited.

Build note: source-level and archive checks are performed in this workspace. A full Android Gradle/Kotlin build and physical-device 5 PM alarm test require GitHub Actions/device execution.
