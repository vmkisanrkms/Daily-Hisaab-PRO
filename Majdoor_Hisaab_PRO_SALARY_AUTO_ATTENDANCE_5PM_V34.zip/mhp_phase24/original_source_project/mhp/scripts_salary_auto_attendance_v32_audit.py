#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).parent
main=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
receiver=(root/'app/src/main/java/com/majdoor/hisaabpro/SalaryAutoAttendanceReceiver.kt').read_text(encoding='utf-8')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
checks={
 '5 PM alarm scheduling': 'Calendar.HOUR_OF_DAY, 17' in receiver,
 'Exact alarm permission check': 'canScheduleExactAlarms()' in receiver,
 'Inexact fallback when exact alarm unavailable': 'setAndAllowWhileIdle' in receiver,
 'Explicit exact-alarm warning in Salary UI': 'Exact Alarm अनुमति बंद है' in main,
 'Notification permission warning in Salary UI': 'Notification अनुमति बंद है' in main,
 'Notification permission guarded before notify': 'POST_NOTIFICATIONS' in receiver,
 'Existing daily manual mark is never overwritten': 'if (daily.has(today)) return@forEach' in receiver,
 'Archived/deleted IDs pruned': 'ids.intersect(activeIds)' in receiver,
 'No-active-ID alarm cancellation': 'cancel(cancelPending)' in receiver,
 'Reboot/time/timezone reschedule receiver': all(x in manifest for x in ['BOOT_COMPLETED','TIME_SET','TIMEZONE_CHANGED','MY_PACKAGE_REPLACED']),
 'Receiver declared': 'SalaryAutoAttendanceReceiver' in manifest,
 'Boot receiver declared': 'SalaryAutoAttendanceBootReceiver' in manifest,
 'Main screen uses shared schedule implementation': 'SalaryAutoAttendanceReceiver.scheduleNext(context)' in main,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'RESULT: {sum(checks.values())}/{len(checks)} passed')
if not all(checks.values()): raise SystemExit(1)
