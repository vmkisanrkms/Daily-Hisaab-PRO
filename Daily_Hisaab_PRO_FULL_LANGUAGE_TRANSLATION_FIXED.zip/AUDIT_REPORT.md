# Daily Hisaab PRO — Audit and Fix Report

Date: 2026-10-19
Specification: `MASTER_PROMPT_HINDI.txt` and `Daily_Hisaab_PRO_MASTER_PROMPT.zip`.

## Fixes included in this source revision

- Source project is packaged at the ZIP root (no enclosing `dh_editfix/` folder).
- Enforced the offline-only design in the source audit: no `android.permission.INTERNET`, no Firebase/Supabase database SDK, and the primary database remains the private local Room/SQLite file `daily_hisaab.db`.
- Added Room `CategoryEntity` and `AppSettingEntity` tables, DAOs, version 2 → 3 migration, category indexes, default category seeding on both fresh install and migration.
- Transaction form and category shortcuts now observe categories from Room. Settings contains a custom category manager; custom categories can be added and deleted, default categories are protected.
- Non-secret preferences (theme, Auto Lock, biometric enabled, lockout deadline and wrong attempts) are mirrored to Room `app_settings`; PIN hash remains salted PBKDF2 in DataStore and is not duplicated into the Room settings table.
- Added optional AndroidX BiometricPrompt login using strong biometric, availability checks, PIN fallback, and a lockout check before opening the app.
- Added SQLite database export after WAL checkpoint and SQLite restore with bounded input, `quick_check`, database version, required transaction-column and trigger/view checks, explicit overwrite confirmation, and app recreation after replacement.
- Added pure money input validation rejecting blank, zero, negative, malformed comma grouping, more than two decimal places and overflow; added unit tests.
- Kept JSON backup validation and atomic Room replacement; added SQLite backup/restore options in the UI.
- Updated GitHub Actions to set up Gradle 8.11.1, generate the official Gradle Wrapper in CI, then run clean unit tests and Release assembly, signing/alignment verification, SHA-256, a verification report, build log, and source ZIP including the generated wrapper JAR. CI results remain pending until the workflow is actually run.
- Existing fixes remain: indexed transaction table, migrations, date-grouped transaction list, dashboard date picker, PDF date/category filters and history, bounded JSON parsing, settings, lockout, and CSV/PDF sharing.

## Checks actually run in this environment

- Final source ZIP integrity: verified with Python `zipfile.testzip()`; project is at ZIP root and contains 41 files.
- `scripts/audit_source.py`: 62/62 source/static assertions passed (includes explicit offline-only database and permission checks).
- Pure Kotlin smoke checks: 12 assertions passed for money validation and lockout policy; 6 transaction-filter smoke assertions passed (combined filters, date bounds, sorting and search). Total pure Kotlin smoke assertions: 18.
- SQLite schema/default-category smoke checks: 4 assertions passed using Python SQLite.
- Kotlin parser-only pass: no syntax/parser errors (`expecting`, `unexpected tokens`, or similar) detected. This is not Kotlin type-checking or Android compilation; the local compiler has no Android/Compose/Room dependency classpath.
- Workflow YAML parsed using PyYAML. PyYAML 1.1 represents GitHub's `on` key as boolean; GitHub Actions uses its own YAML handling.
- Gradle build attempt: `./gradlew --version` failed before Gradle started because this environment cannot resolve `services.gradle.org` (`curl: (6) Could not resolve host`).

## Not verified / external requirements

1. Full Gradle/Kotlin compilation, Room KSP schema validation, JUnit suite, Release APK build, APK signing, `zipalign`, checksum of an actual APK, and installation on device/emulator have **not** run because Gradle could not be downloaded in this environment.
2. This hand-built source ZIP does not embed the official binary `gradle-wrapper.jar` because the Gradle distribution host could not be reached from this environment. GitHub Actions generates the official wrapper JAR and now places it in the CI source ZIP; a successful CI run is still needed to verify this path.
3. Native Google Drive OAuth/API is intentionally not part of this app. The Android system file picker may expose Drive as a file destination; if not, backup can be saved locally. This is file-based backup only, not an online database or automatic sync.
4. UI is Hindi-only; the settings screen explicitly says so. Full English localization remains unimplemented.
5. SQLite backup/restore source is implemented but not device-tested. Only a matching version-3 database with the expected transaction schema is accepted by the restore flow.
6. Reference-image visual fidelity, screen size/insets/keyboard/rotation, actual biometric hardware, process death and device-clock manipulation behavior, PDF Hindi glyph rendering, spreadsheet compatibility, and end-to-end backup/restore need an Android device/emulator.
7. A signed production APK requires GitHub secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. Without them, workflow labels output as unsigned.

## Offline database requirement

No online database is configured or required. The app has no INTERNET permission; its data remains on the phone in Room/SQLite. Backup is a user-selected file export/import through Android Storage Access Framework. Drive, if offered by the system picker, is only a file destination.

## Honest release status

This is an updated source ZIP, not a certified release APK. Do not mark runtime/build checks as passed until a GitHub Actions run succeeds and the APK is installed and tested. Use the `NOT TESTED` statuses in the accompanying checklist for those steps.
