# Daily Hisaab PRO — UI, Language and App Lock Update

## Implemented in source
- Added a persisted App Lock setting. When enabled, the app asks for the PIN on launch; when disabled, launch opens Home directly. Disabling lock does not delete the saved PIN or transactions.
- Auto Lock on background is now conditioned on App Lock being enabled.
- Added persistent language choice: Hindi, English, Punjabi (Gurmukhi).
- Added translations for key Home, settings, PIN, navigation, transaction, report, backup and category labels. Some long/dynamic messages and generated PDF/CSV content remain Hindi; this is a first-pass localization, not a complete professional translation of every string.
- Added distinct category icons for food, home, milk, groceries, fuel, medicine, fees, bills, shopping and agriculture.
- Added farming categories: seeds/sowing, fertilizer, crop protection, tractor/ploughing, irrigation/diesel, harvest/labour, sugarcane, wheat/other crops, crop-sale income.
- New farming categories are inserted idempotently on app startup so existing installs receive them without database migration or data loss.
- Data remains on-device in Room/SQLite. No online database or Internet permission was added.

## Validation status
- ZIP archive integrity is checked after packaging.
- Full Android Gradle/Compose compilation and device testing were not run in this environment. Please run GitHub Actions before installing the build.
