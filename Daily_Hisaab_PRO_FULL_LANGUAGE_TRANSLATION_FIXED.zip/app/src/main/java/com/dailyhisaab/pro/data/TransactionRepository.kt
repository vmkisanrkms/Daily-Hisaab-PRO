package com.dailyhisaab.pro.data

import kotlinx.coroutines.flow.Flow

/** Keeps UI screens independent from Room implementation details. */
class TransactionRepository(private val dao: TransactionDao) {
    fun observeAll(): Flow<List<Transaction>> = dao.observeAll()
    suspend fun getById(id: Long): Transaction? = dao.getById(id)
    suspend fun insert(transaction: Transaction): Long = dao.insert(transaction)
    suspend fun update(transaction: Transaction) = dao.update(transaction)
    suspend fun delete(transaction: Transaction) = dao.delete(transaction)
    suspend fun deleteAll() = dao.deleteAll()
    suspend fun replaceAll(transactions: List<Transaction>) = dao.replaceAll(transactions)
    suspend fun sumBetween(type: String, from: Long, to: Long): Long = dao.sumBetween(type, from, to)
    suspend fun expenseByCategory(from: Long, to: Long): List<CategoryTotal> = dao.expenseByCategory(from, to)
}
