package com.dailyhisaab.pro.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Transaction as RoomTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC, id DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Transaction?

    @Insert
    suspend fun insert(transaction: Transaction): Long

    @Insert
    suspend fun insertAll(transactions: List<Transaction>)

    @RoomTransaction
    suspend fun replaceAll(transactions: List<Transaction>) {
        deleteAll()
        if (transactions.isNotEmpty()) insertAll(transactions.map { it.copy(id = 0) })
    }

    @Update
    suspend fun update(transaction: Transaction)

    @Delete
    suspend fun delete(transaction: Transaction)

    @Query("DELETE FROM transactions")
    suspend fun deleteAll()

    @Query("SELECT COALESCE(SUM(amountPaise), 0) FROM transactions WHERE type = :type AND dateMillis >= :from AND dateMillis < :to")
    suspend fun sumBetween(type: String, from: Long, to: Long): Long

    @Query("SELECT category, COALESCE(SUM(amountPaise),0) AS total FROM transactions WHERE type='EXPENSE' AND dateMillis >= :from AND dateMillis < :to GROUP BY category ORDER BY total DESC")
    suspend fun expenseByCategory(from: Long, to: Long): List<CategoryTotal>
}
