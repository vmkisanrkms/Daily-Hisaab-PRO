package com.dailyhisaab.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "transactions",
    indices = [
        Index(value = ["dateMillis"]),
        Index(value = ["type", "dateMillis"]),
        Index(value = ["category", "dateMillis"]),
        Index(value = ["paymentMethod", "dateMillis"])
    ]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amountPaise: Long,
    val category: String,
    val description: String,
    val dateMillis: Long,
    val paymentMethod: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)
