package com.dailyhisaab.pro.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

/** Shared integer-paise calculations used by dashboard/report/export consistency tests. */
data class ReportTotals(val incomePaise: Long, val expensePaise: Long) {
    val netPaise: Long get() = incomePaise - expensePaise
}

object ReportMath {
    fun totals(items: List<Transaction>): ReportTotals = ReportTotals(
        incomePaise = items.asSequence().filter { it.type == "INCOME" }.sumOf { it.amountPaise },
        expensePaise = items.asSequence().filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
    )

    fun expenseByCategory(items: List<Transaction>): Map<String, Long> = items.asSequence()
        .filter { it.type == "EXPENSE" }
        .groupBy { it.category }
        .mapValues { (_, rows) -> rows.sumOf { it.amountPaise } }
        .toSortedMap()

    fun csvAmount(amountPaise: Long): String = BigDecimal.valueOf(amountPaise, 2)
        .setScale(2, RoundingMode.UNNECESSARY).toPlainString()

    fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    fun csvRow(values: List<String>): String = values.joinToString(",") { csvCell(it) }
}
