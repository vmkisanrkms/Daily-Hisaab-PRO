package com.dailyhisaab.pro.data

/** Applies all transaction-list filters together using AND semantics. Dates are local-midnight millis. */
internal fun filterTransactions(
    transactions: List<Transaction>,
    query: String = "",
    type: String = "ALL",
    category: String = "सभी श्रेणियाँ",
    paymentMethod: String = "सभी भुगतान",
    fromDateMillis: Long? = null,
    toDateMillis: Long? = null
): List<Transaction> {
    if (fromDateMillis != null && toDateMillis != null && fromDateMillis > toDateMillis) return emptyList()
    val needle = query.trim()
    val toExclusive = toDateMillis?.let { millis ->
        java.util.Calendar.getInstance().apply {
            timeInMillis = millis
            add(java.util.Calendar.DAY_OF_MONTH, 1)
        }.timeInMillis
    }
    return transactions.asSequence().filter { t ->
        val searchMatches = needle.isBlank() ||
            t.description.contains(needle, ignoreCase = true) ||
            t.category.contains(needle, ignoreCase = true) ||
            t.paymentMethod.contains(needle, ignoreCase = true) ||
            (t.amountPaise / 100L).toString().contains(needle, ignoreCase = true) ||
            "%.2f".format(java.util.Locale.US, t.amountPaise / 100.0).contains(needle, ignoreCase = true)
        val typeMatches = type == "ALL" || t.type == type
        val categoryMatches = category == "सभी श्रेणियाँ" || t.category == category
        val paymentMatches = paymentMethod == "सभी भुगतान" || t.paymentMethod == paymentMethod
        val fromMatches = fromDateMillis == null || t.dateMillis >= fromDateMillis
        val toMatches = toExclusive == null || t.dateMillis < toExclusive
        searchMatches && typeMatches && categoryMatches && paymentMatches && fromMatches && toMatches
    }.sortedWith(compareByDescending<Transaction> { it.dateMillis }.thenByDescending { it.id }).toList()
}

