package com.dailyhisaab.pro.data

import java.math.BigDecimal

/** Parse rupee input exactly into integer paise; reject malformed grouping, >2 decimals and overflow. */
fun parseAmountPaise(raw: String, maxPaise: Long = 9_000_000_000_000L): Long? {
    val text = raw.trim()
    if (text.isEmpty()) return null
    if (!text.matches(Regex("(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\\.[0-9]{1,2})?"))) return null
    return try {
        val paise = BigDecimal(text.replace(",", "")).movePointRight(2).longValueExact()
        paise.takeIf { it in 1L..maxPaise }
    } catch (_: Exception) { null }
}
