package com.dailyhisaab.pro.data
data class CategoryTotal(val category: String, val total: Long)
