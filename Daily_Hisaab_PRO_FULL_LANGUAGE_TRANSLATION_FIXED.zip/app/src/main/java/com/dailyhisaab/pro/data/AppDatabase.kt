package com.dailyhisaab.pro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Transaction::class, CategoryEntity::class, AppSettingEntity::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        private val DEFAULT_CATEGORIES = listOf(
            "घर" to "EXPENSE", "खाना" to "EXPENSE", "दूध" to "EXPENSE", "राशन" to "EXPENSE", "पेट्रोल" to "EXPENSE",
            "दवा" to "EXPENSE", "फीस" to "EXPENSE", "बिल" to "EXPENSE", "शॉपिंग" to "EXPENSE", "अन्य" to "EXPENSE",
            "बीज और बुवाई" to "EXPENSE", "खाद और उर्वरक" to "EXPENSE", "दवा और कीटनाशक" to "EXPENSE", "ट्रैक्टर और जुताई" to "EXPENSE", "सिंचाई और डीजल" to "EXPENSE", "कटाई और मजदूरी" to "EXPENSE", "गन्ने की खेती" to "EXPENSE", "गेहूँ और अन्य फसल" to "EXPENSE",
            "वेतन" to "INCOME", "बिजनेस" to "INCOME", "फ्रीलांस" to "INCOME", "किराया" to "INCOME", "खेती" to "INCOME", "बिक्री" to "INCOME", "फसल बिक्री की कमाई" to "INCOME", "ब्याज" to "INCOME", "अन्य" to "INCOME"
        )
        private fun seedCategories(db: SupportSQLiteDatabase) {
            val now = System.currentTimeMillis()
            DEFAULT_CATEGORIES.forEach { (name, type) ->
                db.execSQL("INSERT OR IGNORE INTO categories(name, transactionType, isDefault, createdAtMillis) VALUES(?, ?, 1, ?)", arrayOf(name, type, now))
            }
        }
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_transactions_dateMillis ON transactions(dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_transactions_type_dateMillis ON transactions(type, dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_transactions_category_dateMillis ON transactions(category, dateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_transactions_paymentMethod_dateMillis ON transactions(paymentMethod, dateMillis)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, transactionType TEXT NOT NULL, isDefault INTEGER NOT NULL, createdAtMillis INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_categories_name_transactionType ON categories(name, transactionType)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (key TEXT NOT NULL PRIMARY KEY, value TEXT NOT NULL, updatedAtMillis INTEGER NOT NULL)")
                seedCategories(db)
            }
        }
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "daily_hisaab.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        seedCategories(db)
                    }
                })
                .build().also { INSTANCE = it }
        }
        /** Atomically replace the live DB after validation, retaining a rollback copy until installed. */
        fun replaceFromValidatedBackup(context: Context, backup: java.io.File) = synchronized(this) {
            require(backup.isFile && backup.length() > 0L) { "SQLite बैकअप खाली है" }
            val target = context.applicationContext.getDatabasePath("daily_hisaab.db")
            target.parentFile?.mkdirs()
            val incoming = java.io.File(target.parentFile, "daily_hisaab.restore.tmp")
            val previous = java.io.File(target.parentFile, "daily_hisaab.previous.tmp")
            backup.copyTo(incoming, overwrite = true)
            require(incoming.length() == backup.length()) { "SQLite बैकअप कॉपी अधूरी है" }
            INSTANCE?.close()
            INSTANCE = null
            listOf("-wal", "-shm", "-journal").forEach { suffix -> java.io.File(target.absolutePath + suffix).delete() }
            previous.delete()
            val hadTarget = target.exists()
            if (hadTarget && !target.renameTo(previous)) {
                incoming.delete()
                error("मौजूदा डेटाबेस सुरक्षित नहीं किया जा सका; रिस्टोर रद्द")
            }
            try {
                if (!incoming.renameTo(target)) error("नया डेटाबेस स्थापित नहीं हो सका")
                previous.delete()
            } catch (failure: Exception) {
                target.delete()
                if (hadTarget && previous.exists()) previous.renameTo(target)
                incoming.delete()
                throw failure
            }
        }
    }
}
