package com.dailyhisaab.pro.data

/** Pure lockout rules so the PIN cooldown can be unit-tested without Android runtime. */
object LockoutPolicy {
    const val MAX_FAILED_ATTEMPTS = 5
    const val LOCK_DURATION_MILLIS = 30_000L

    fun shouldLock(failedAttempts: Int): Boolean = failedAttempts >= MAX_FAILED_ATTEMPTS

    fun remainingSeconds(lockUntilMillis: Long, nowMillis: Long): Int {
        val remaining = (lockUntilMillis - nowMillis).coerceAtLeast(0L)
        return if (remaining == 0L) 0 else ((remaining + 999L) / 1_000L).toInt()
    }

    fun isLocked(lockUntilMillis: Long, nowMillis: Long): Boolean = lockUntilMillis > nowMillis
}
