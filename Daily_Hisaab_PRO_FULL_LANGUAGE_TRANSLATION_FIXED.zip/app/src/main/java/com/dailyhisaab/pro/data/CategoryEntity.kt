package com.dailyhisaab.pro.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "categories", indices = [Index(value = ["name", "transactionType"], unique = true)])
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val transactionType: String,
    val isDefault: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)
