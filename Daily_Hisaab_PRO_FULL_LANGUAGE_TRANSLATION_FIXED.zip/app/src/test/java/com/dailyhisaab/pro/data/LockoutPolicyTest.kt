package com.dailyhisaab.pro.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LockoutPolicyTest {
    @Test fun locksOnFifthFailureOnly() {
        assertFalse(LockoutPolicy.shouldLock(4))
        assertTrue(LockoutPolicy.shouldLock(5))
        assertTrue(LockoutPolicy.shouldLock(6))
    }

    @Test fun deadlineSurvivesRestartBecauseItIsAnAbsoluteTimestamp() {
        val deadline = 130_000L
        assertTrue(LockoutPolicy.isLocked(deadline, 100_000L))
        assertEquals(30, LockoutPolicy.remainingSeconds(deadline, 100_000L))
        assertEquals(10, LockoutPolicy.remainingSeconds(deadline, 120_001L))
    }

    @Test fun roundsRemainingSecondsUpAndExpiresAtDeadline() {
        assertEquals(1, LockoutPolicy.remainingSeconds(1_001L, 1_000L))
        assertEquals(0, LockoutPolicy.remainingSeconds(1_000L, 1_000L))
        assertFalse(LockoutPolicy.isLocked(1_000L, 1_000L))
    }

    @Test fun expiredDeadlineHasNoNegativeCountdown() {
        assertEquals(0, LockoutPolicy.remainingSeconds(10L, 20L))
        assertFalse(LockoutPolicy.isLocked(10L, 20L))
    }
}
