package com.dailyhisaab.pro

import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

class MoneyAndReportTest {
    @Test fun rupeesConvertToPaisePrecisely() {
        assertEquals(12345L, BigDecimal("123.45").multiply(BigDecimal(100)).longValueExact())
    }
    @Test fun categoryPercentagesCanSumFromPaiseTotals() {
        val amounts = listOf(35000L, 65000L)
        assertEquals(100L, amounts.sum() * 100 / amounts.sum())
    }
}
