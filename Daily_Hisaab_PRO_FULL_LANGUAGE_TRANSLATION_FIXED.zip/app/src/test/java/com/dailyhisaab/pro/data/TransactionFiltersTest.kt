package com.dailyhisaab.pro.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TransactionFiltersTest {
    private fun day(year: Int, month: Int, day: Int): Long = java.util.Calendar.getInstance().apply {
        set(year, month - 1, day, 12, 0, 0); set(java.util.Calendar.MILLISECOND, 0)
        set(java.util.Calendar.HOUR_OF_DAY, 0)
    }.timeInMillis
    private val d1 = day(2026, 1, 10)
    private val d2 = day(2026, 1, 11)
    private val d3 = day(2026, 1, 12)
    private val rows = listOf(
        Transaction(id=1, type="EXPENSE", amountPaise=12500, category="खाना", description="दूध और नाश्ता", dateMillis=d1 + 23*60*60*1000L, paymentMethod="UPI"),
        Transaction(id=2, type="INCOME", amountPaise=250000, category="खेती", description="फसल बिक्री", dateMillis=d2 + 12*60*60*1000L, paymentMethod="बैंक"),
        Transaction(id=3, type="EXPENSE", amountPaise=12500, category="खाना", description="राशन", dateMillis=d3 + 12*60*60*1000L, paymentMethod="नकद")
    )

    @Test fun allFiltersCombineWithAndSemantics() {
        val result = filterTransactions(rows, query="दूध", type="EXPENSE", category="खाना", paymentMethod="UPI", fromDateMillis=d1, toDateMillis=d1)
        assertEquals(listOf(1L), result.map { it.id })
    }

    @Test fun dateRangeIncludesBothWholeDays() {
        val result = filterTransactions(rows, fromDateMillis=d1, toDateMillis=d3)
        assertEquals(listOf(3L, 2L, 1L), result.map { it.id })
    }

    @Test fun wrongDateRangeReturnsNoRows() {
        assertTrue(filterTransactions(rows, fromDateMillis=d3, toDateMillis=d1).isEmpty())
    }

    @Test fun resetDefaultsReturnAllSortedRows() {
        assertEquals(listOf(3L, 2L, 1L), filterTransactions(rows).map { it.id })
    }

    @Test fun searchIsCaseInsensitiveAndMatchesAmount() {
        assertEquals(listOf(2L), filterTransactions(rows, query="फसल").map { it.id })
        assertEquals(listOf(3L, 1L), filterTransactions(rows, query="125").map { it.id })
    }

    @Test fun dateRangeIncludesLateNightTransactionsAndExcludesNextDay() {
        val result = filterTransactions(rows, fromDateMillis=d1, toDateMillis=d1)
        assertEquals(listOf(1L), result.map { it.id })
    }

    @Test fun allFourDimensionsCanFilterAtOnce() {
        val result = filterTransactions(rows, query="दूध", type="EXPENSE", category="खाना", paymentMethod="UPI", fromDateMillis=d1, toDateMillis=d1)
        assertEquals(listOf(1L), result.map { it.id })
    }
}
