package com.dailyhisaab.pro

import com.dailyhisaab.pro.data.ReportMath
import com.dailyhisaab.pro.data.Transaction
import org.junit.Assert.assertEquals
import org.junit.Test

class ReportExportConsistencyTest {
    private fun rows() = listOf(
        Transaction(id=1, type="INCOME", amountPaise=125050, category="खेती", description="गन्ना, भुगतान", dateMillis=1_790_000_000_000, paymentMethod="बैंक"),
        Transaction(id=2, type="EXPENSE", amountPaise=2599, category="डीजल", description="ट्रैक्टर \"मरम्मत\"", dateMillis=1_790_000_100_000, paymentMethod="नकद"),
        Transaction(id=3, type="EXPENSE", amountPaise=10000, category="बीज", description="गेहूँ", dateMillis=1_790_000_200_000, paymentMethod="नकद"),
        Transaction(id=4, type="EXPENSE", amountPaise=2501, category="डीजल", description="खेत", dateMillis=1_790_000_300_000, paymentMethod="UPI")
    )

    @Test fun dashboardAndReportTotalsUseSamePaiseDataset() {
        val totals = ReportMath.totals(rows())
        assertEquals(125050L, totals.incomePaise)
        assertEquals(15100L, totals.expensePaise)
        assertEquals(109950L, totals.netPaise)
    }

    @Test fun categoryBreakdownAddsToTotalExpenseExactly() {
        val byCategory = ReportMath.expenseByCategory(rows())
        assertEquals(mapOf("डीजल" to 5100L, "बीज" to 10000L), byCategory)
        assertEquals(ReportMath.totals(rows()).expensePaise, byCategory.values.sum())
    }

    @Test fun csvAmountKeepsPaisePrecisionWithoutDoubleRounding() {
        assertEquals("1250.50", ReportMath.csvAmount(125050))
        assertEquals("0.01", ReportMath.csvAmount(1))
        assertEquals("-0.01", ReportMath.csvAmount(-1))
    }

    @Test fun csvEscapesCommasQuotesAndHindiText() {
        assertEquals("\"गन्ना, भुगतान\"", ReportMath.csvCell("गन्ना, भुगतान"))
        assertEquals("\"ट्रैक्टर \"\"मरम्मत\"\"\"", ReportMath.csvCell("ट्रैक्टर \"मरम्मत\""))
    }

    @Test fun reportTotalsRemainEqualAfterBackupRestoreStyleCopy() {
        val before = rows()
        val afterRestore = before.map { it.copy() }
        assertEquals(ReportMath.totals(before), ReportMath.totals(afterRestore))
        assertEquals(ReportMath.expenseByCategory(before), ReportMath.expenseByCategory(afterRestore))
    }
}
