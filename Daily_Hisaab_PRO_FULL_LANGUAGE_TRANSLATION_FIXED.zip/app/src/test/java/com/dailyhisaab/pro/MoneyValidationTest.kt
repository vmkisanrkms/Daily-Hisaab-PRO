package com.dailyhisaab.pro

import com.dailyhisaab.pro.data.parseAmountPaise
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyValidationTest {
    @Test fun acceptsRupeesAndPaiseExactly() {
        assertEquals(12345L, parseAmountPaise("123.45"))
        assertEquals(1234500L, parseAmountPaise("12,345"))
        assertEquals(1L, parseAmountPaise("0.01"))
    }
    @Test fun rejectsEmptyZeroNegativeAndMalformedInput() {
        assertNull(parseAmountPaise(""))
        assertNull(parseAmountPaise("0"))
        assertNull(parseAmountPaise("-1"))
        assertNull(parseAmountPaise("1,,200"))
        assertNull(parseAmountPaise("12.345"))
        assertNull(parseAmountPaise("abc"))
    }
    @Test fun rejectsOverflowAndTooLargeValues() {
        assertNull(parseAmountPaise("999999999999999999999999"))
        assertNull(parseAmountPaise("90000000000.01"))
    }
}
