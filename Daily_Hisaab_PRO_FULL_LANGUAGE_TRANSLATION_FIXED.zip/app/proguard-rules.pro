# No custom shrinking rules required while minification is disabled.
