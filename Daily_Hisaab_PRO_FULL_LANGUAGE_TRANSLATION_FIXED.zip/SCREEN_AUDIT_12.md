# Daily Hisaab PRO — 12 Screen Code-Level Audit

Date: 2026-10-19
Scope: source ZIP inspection, static assertions, focused pure Kotlin smoke tests. No Android emulator/device was available in this audit run.

## Screen-by-screen results

| # | Screen | Code-level result | Runtime status |
|---:|---|---|---|
| 1 | Login / PIN setup | PBKDF2 PIN hash, confirm-PIN setup, PIN verify, forgot-PIN confirmation and optional biometric route present. Added guard against repeated taps submitting the same 4-digit PIN more than once. Biometric button now appears only when enabled in Settings. | Not tested on device |
| 2 | Home dashboard | Date selector, today/selected-day totals, month summary, add expense/income shortcuts, category shortcuts, recent transactions and report shortcuts present. Data observed from Room flow. | Not tested on device |
| 3 | Add expense | Amount validation, category selection, optional description, date picker, payment chips and save state present. Added explicit calendar icon affordance for date selection. | Not tested on device |
| 4 | Add income | Shared transaction form supports income type, category, description, date, payment and save validation. | Not tested on device |
| 5 | Transaction list | Search, type/category/payment/date filters, reset, count, empty state, date grouping and edit navigation present. Filter helper uses AND semantics and inclusive local-day end date. | Not tested on device |
| 6 | Edit/delete transaction | Existing row is re-fetched before update/delete; delete confirmation and duplicate-save guard present. Back now returns to transaction list and asks before discarding unsaved edits. | Not tested on device |
| 7 | Monthly report | Month selector, income/expense/net cards, category totals and links to category/PDF reports present. Replaced the unlabeled two-bar chart with a five-week income/expense chart with labels and legend. | Not tested on device |
| 8 | Category report | Month selector, donut chart, category totals/percentages and tap-through filtering present. Added an explicit no-expense empty state. Reports bottom-nav selection now remains active on this sub-screen. | Not tested on device |
| 9 | PDF report | Monthly summary, transaction and category PDF modes; optional date/category filters; open/share recent PDFs present. Date-range validation exists. | PDF output totals and Hindi layout not device-tested |
| 10 | Backup / restore | JSON and SQLite file backup/restore paths present. JSON restore validates version, record count and transaction fields; SQLite restore checks integrity/schema/version before replacement. File picker can use Drive if the Android document provider offers it; no native Drive OAuth or online database. | Actual backup/restore and restart persistence not tested |
| 11 | Settings | PIN change, Auto Lock, optional biometric, Light/Dark/System theme, CSV export, clear-data confirmation, category management, Hindi-only disclosure, about and share options present. | Not tested on device |
| 12 | PIN lockout | Five-failure lockout policy and persisted deadline/countdown share the PIN UI route; input is rejected during active lockout. | Timing and lifecycle not device-tested |

## Code-level corrections made in this audit

1. Added Android system Back handling for secondary screens; edit returns to the transaction list.
2. Added confirmation before discarding unsaved transaction form/edit changes.
3. Added a PIN verification in-flight guard to prevent repeated taps from triggering multiple PIN checks.
4. Added a clear calendar icon action to the transaction date field.
5. Changed the monthly chart to five labeled week buckets with income/expense legend.
6. Added an explicit empty state to the category report.
7. Kept the Reports bottom-navigation item selected on Category and PDF sub-screens.
8. Hid the biometric action unless biometric login is enabled in Settings.

## Verification performed

- `scripts/audit_source.py`: 70/70 static assertions passed.
- Focused Kotlin smoke test: 12 money-validation and PIN-lockout assertions passed.
- Kotlin parser check: no syntax/parser diagnostics were found; full compilation was not possible because Android/Compose/Room dependencies were unavailable locally.
- ZIP integrity check after packaging: expected to be repeated on the generated archive.

## Not verified / release blockers

- Full Gradle/JDK/Android SDK build and unit-test suite.
- Android emulator/physical-device UI, back/bottom navigation, PIN and biometric behavior.
- Screen-by-screen screenshot comparison against `design/reference_12_screens.png`.
- Actual PDF/CSV total reconciliation and Hindi PDF rendering on device.
- JSON/SQLite backup restore, record counts and totals before/after restart.
- Release APK assembly, zipalign, signature verification, SHA-256 of APK, clean install and upgrade test.

This is a source/code-level audit, not a claim that all screens are runtime-verified or that a signed release APK has been produced.
