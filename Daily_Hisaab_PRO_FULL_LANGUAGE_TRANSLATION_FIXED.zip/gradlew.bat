@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_HOME=%GRADLE_USER_HOME%\wrapper\dists\gradle-8.11.1-bin\manual"
set "DIST=%DIST_HOME%\gradle-8.11.1"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%DIST_HOME%" mkdir "%DIST_HOME%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/gradle-8.11.1-bin.zip'; $z=Join-Path $env:GRADLE_USER_HOME 'wrapper\dists\gradle-8.11.1-bin\manual\gradle.zip'; $h=Join-Path $env:GRADLE_USER_HOME 'wrapper\dists\gradle-8.11.1-bin\manual\gradle.zip.sha256'; Invoke-WebRequest $u -OutFile $z; Invoke-WebRequest ($u+'.sha256') -OutFile $h; $expected=(Get-Content $h -Raw).Trim().Split(' ')[0]; $actual=(Get-FileHash $z -Algorithm SHA256).Hash.ToLower(); if($actual -ne $expected.ToLower()){throw 'Gradle SHA-256 verification failed'}; Expand-Archive -Path $z -DestinationPath '%DIST_HOME%' -Force; Remove-Item $z,$h -Force"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
