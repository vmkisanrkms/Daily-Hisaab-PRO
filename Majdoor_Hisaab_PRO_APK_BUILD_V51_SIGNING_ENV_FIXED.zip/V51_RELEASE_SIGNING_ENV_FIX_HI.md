# V51 Release Signing Environment Fix

## Root cause
The uploaded V51 project read signing values from `KEYSTORE_FILE`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD` in `app/build.gradle.kts`. The GitHub Actions run reached `:app:packageRelease` but Gradle reported that the release SigningConfig had no `storePassword`.

## Changes
- `app/build.gradle.kts` now reads the four values using Gradle's environment provider and validates the three password/alias values before creating the release signing config.
- `.github/workflows/majdoor-hisaab.yml` now passes the keystore path and signing secrets explicitly to the `Assemble Release APK` step, instead of relying only on values propagated from a prior step through `GITHUB_ENV`.
- The keystore itself and its passwords are not included in this ZIP.
- Package, application ID, database logic, and app features were not changed.

## Verification
- Source ZIP extraction and re-packaging completed.
- ZIP integrity test passed.
- The Gradle/Kotlin build has not been run in this environment. The next GitHub Actions run must verify `:app:assembleRelease` and APK signature validation.
