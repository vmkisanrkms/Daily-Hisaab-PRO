package com.majdoor.hisaabpro

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.app.DatePickerDialog
import android.app.KeyguardManager
import android.hardware.biometrics.BiometricPrompt as PlatformBiometricPrompt
import android.os.CancellationSignal
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.content.ContentResolver
import android.accounts.Account
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.OutlinedTextField as MaterialOutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.roundToInt
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.concurrent.Executors
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private var Green = Color(0xFF0B6B4A)
private var GreenDark = Color(0xFF064C36)
private var Bg = Color(0xFFF6FAF8)
private var CardBg = Color.White
private val DarkBg = Color(0xFF101714)
private val DarkCardBg = Color(0xFF1B2420)
private val DarkGreen = Color(0xFF8AD5AE)
private const val APP_PREFS = "mhpro_app_preferences"
private const val THEME_KEY = "theme_mode"
private const val SETTINGS_PREFS = "mhpro_settings_v1"
private fun settingBool(context: Context, key: String, default: Boolean = false): Boolean =
    context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).getBoolean(key, default)
private fun settingString(context: Context, key: String, default: String = ""): String =
    context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).getString(key, default).orEmpty()
private fun saveSetting(context: Context, key: String, value: Boolean) {
    context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
}
private fun saveSetting(context: Context, key: String, value: String) {
    context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).edit().putString(key, value).apply()
}

/** Store only a salted SHA-256 digest; never persist the raw in-app PIN. */
private fun hasCustomPin(context: Context): Boolean = settingString(context, "custom_pin_hash").isNotBlank() && settingString(context, "custom_pin_salt").isNotBlank()
private const val PIN_HASH_ITERATIONS = 120_000
private fun pinDigest(salt: String, pin: String, iterations: Int = PIN_HASH_ITERATIONS): String {
    val spec=PBEKeySpec(pin.toCharArray(),Base64.decode(salt,Base64.NO_WRAP),iterations,256)
    return try { Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,Base64.NO_WRAP) }
    finally { spec.clearPassword() }
}
private fun saveCustomPin(context: Context, pin: String?): Boolean {
    val prefs=context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
    val edit=prefs.edit()
    if(pin.isNullOrBlank()) {
        edit.remove("custom_pin_hash").remove("custom_pin_salt").remove("custom_pin_failed_attempts").remove("custom_pin_locked_until")
    } else {
        val salt=ByteArray(16).also { SecureRandom().nextBytes(it) }.let { Base64.encodeToString(it, Base64.NO_WRAP) }
        edit.putString("custom_pin_salt",salt).putString("custom_pin_hash",pinDigest(salt,pin)).putInt("custom_pin_iterations",PIN_HASH_ITERATIONS).putInt("custom_pin_failed_attempts",0).putLong("custom_pin_locked_until",0L)
    }
    return edit.commit()
}
private fun verifyCustomPin(context: Context, pin: String): Boolean {
    val prefs=context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE)
    val now=System.currentTimeMillis()
    if(now < prefs.getLong("custom_pin_locked_until",0L)) return false
    val salt=prefs.getString("custom_pin_salt","").orEmpty()
    val expected=prefs.getString("custom_pin_hash","").orEmpty()
    val iterations=prefs.getInt("custom_pin_iterations",PIN_HASH_ITERATIONS).coerceIn(50_000,500_000)
    val matches=runCatching { MessageDigest.isEqual(expected.toByteArray(),pinDigest(salt,pin,iterations).toByteArray()) }.getOrDefault(false)
    if(matches) {
        prefs.edit().putInt("custom_pin_failed_attempts",0).putLong("custom_pin_locked_until",0L).commit()
        return true
    }
    val attempts=prefs.getInt("custom_pin_failed_attempts",0)+1
    prefs.edit().putInt("custom_pin_failed_attempts",if(attempts>=5)0 else attempts).putLong("custom_pin_locked_until",if(attempts>=5)now+30_000L else 0L).commit()
    return false
}

private fun savedThemeMode(context: Context): String =
    context.getSharedPreferences(APP_PREFS, Context.MODE_PRIVATE)
        .getString(THEME_KEY, "system")?.takeIf { it in setOf("light", "dark", "system") } ?: "system"

private const val SALARY_AUTO_PREFS = "mhpro_salary_auto_attendance_v1"
private const val SALARY_AUTO_IDS = "enabled_employee_ids"
private const val SALARY_AUTO_ACTION = "com.majdoor.hisaabpro.SALARY_AUTO_ATTENDANCE_5PM"
private const val SALARY_AUTO_CHANNEL = "salary_auto_attendance"
private fun salaryAutoIds(context: Context): Set<String> = context.getSharedPreferences(SALARY_AUTO_PREFS, Context.MODE_PRIVATE).getStringSet(SALARY_AUTO_IDS, emptySet())?.toSet() ?: emptySet()
private fun setSalaryAuto(context: Context, employeeId: String, enabled: Boolean) {
    val ids = salaryAutoIds(context).toMutableSet()
    if (enabled) ids.add(employeeId) else ids.remove(employeeId)
    context.getSharedPreferences(SALARY_AUTO_PREFS, Context.MODE_PRIVATE).edit().putStringSet(SALARY_AUTO_IDS, ids).commit()
    scheduleSalaryAutoAttendance(context)
}
private fun scheduleSalaryAutoAttendance(context: Context) {
    // Keep one scheduling implementation for app launch, toggle changes and reboot/time changes.
    SalaryAutoAttendanceReceiver.scheduleNext(context)
}

internal data class Labour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
internal data class SalaryEmployee(val id:String,val name:String,val mobile:String,val role:String,val monthlySalary:Double,val joinDate:String)
internal data class SalaryDay(val status:String="हाजिरी नहीं",val note:String="")
internal data class SalaryPayment(val date:String,val amount:Double,val note:String="")
internal data class SalaryMonth(val absentDays:Int=0,val advance:Double=0.0,val paid:Double=0.0,val daily:Map<String,SalaryDay> = emptyMap(),val salaryAtMonth:Double=0.0,val payments:List<SalaryPayment> = emptyList())

// Single source of truth used by Dashboard, Employee List, Detail, editor preview and reports.
// Missing and भांजी days earn no salary; उपस्थित earns a full day and आधा दिन earns 0.5 day.
private fun salaryEarnedForRange(employee:SalaryEmployee, month:String, record:SalaryMonth, from:String?=null, to:String?=null):Double {
    val days=monthDays(month).coerceAtLeast(1)
    val monthStart="$month-01"
    val monthEnd="$month-${days.toString().padStart(2,'0')}"
    val join=employee.joinDate.takeIf{validDate(it)} ?: monthStart
    val start=maxOf(monthStart, join, from?.takeIf{validDate(it)} ?: monthStart)
    val end=minOf(monthEnd, to?.takeIf{validDate(it)} ?: monthEnd)
    if(start>end) return 0.0
    val base=record.salaryAtMonth.takeIf{it.isFinite() && it>0.0} ?: employee.monthlySalary
    if(!base.isFinite() || base<=0.0) return 0.0
    val presentEquivalent=record.daily.entries.sumOf{(date,day)->if(date in start..end) when(day.status){"उपस्थित"->1.0;"आधा दिन"->0.5;else->0.0} else 0.0}
    return (base * presentEquivalent / days).coerceAtLeast(0.0)
}
internal data class FandiLabour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
internal data class Field(val id:String,val name:String,val address:String,val area:String,val photo:String)
internal data class Crop(val id:String,val fieldId:String,val name:String,val variety:String,val sowingDate:String,val season:String)
internal data class Expense(val id:String,val fieldId:String,val cropId:String,val type:String,val item:String,val qty:String,val unit:String,val amount:Double,val date:String)
internal data class Sale(val id:String,val fieldId:String,val cropId:String,val qty:Double,val unit:String,val rate:Double,val total:Double,val buyer:String,val date:String)
internal data class Attendance(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val fraction:Double,val rate:Double)
internal data class Payment(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val amount:Double)
internal data class LabourClosure(val id:String,val labourId:String,val throughDate:String,val wage:Double,val paid:Double,val closedAt:Long)
internal data class WageRate(val id:String,val labourId:String,val effectiveDate:String,val rate:Double)
internal data class CanePrice(val id:String,val season:String,val effectiveDate:String,val rate:Double)
internal data class CaneParchi(val id:String,val name:String,val fatherName:String,val code:String,val date:String,val weight:Double,val rate:Double,val photo:String,val remark:String,val season:String,val fieldId:String="")
internal data class CanePeeling(val id:String,val labourId:String,val fieldId:String,val date:String,val fandi:Double,val rate:Double,val total:Double)
internal data class CanePeelingPayment(val id:String,val labourId:String,val date:String,val amount:Double,val method:String,val note:String)

private sealed class Screen {
    data object Home:Screen()
    data object LabourList:Screen()
    data object SalaryDashboard:Screen()
    data object SalaryEmployees:Screen()
    data object SalaryReports:Screen()
    data class SalaryEmployeeDetail(val id:String):Screen()
    data object DailyLabourHome:Screen()
    data object DailyLabourAccounts:Screen()
    data object AllLabourReport:Screen()
    data object ReportCentre:Screen()
    data object ReportType:Screen()
    data object AttendanceFields:Screen()
    data object FieldList:Screen()
    data class ExpenseList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class SaleList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class CropList(val fieldId:String?=null):Screen()
    data class LabourDetail(val id:String):Screen()
    data class FieldDetail(val id:String):Screen()
    data class CropDetail(val id:String):Screen()
    data class Attendance(val fieldId:String?=null):Screen()
    data object AttendanceHistory:Screen()
    data object TodayAttendance:Screen()
    data object Backup:Screen()
    data object Profile:Screen()
    data object CaneParchi:Screen()
    data object CanePeeling:Screen()
    data object WorkList:Screen()
    data object WageRateHistory:Screen()
    data object Profitability:Screen()
}


/** Stable, locale-independent search normalization shared by Hindi and English search boxes. */
private fun normalizeSearch(value: String): String {
    val devanagariDigits = charArrayOf('०','१','२','३','४','५','६','७','८','९')
    return buildString(value.length) {
        value.lowercase(Locale.ROOT).forEach { ch ->
            val digitIndex = devanagariDigits.indexOf(ch)
            val normalized = if (digitIndex >= 0) ('0'.code + digitIndex).toChar() else ch
            if (normalized.isLetterOrDigit()) append(normalized)
        }
    }
}

private fun searchMatches(query: String, vararg values: String?): Boolean {
    val q = normalizeSearch(query)
    return q.isBlank() || values.any { normalizeSearch(it.orEmpty()).contains(q) }
}

private fun encodeScreenState(screen: Screen): String {
    val raw = when (screen) {
        Screen.Home -> "home"; Screen.LabourList -> "labour"; Screen.SalaryDashboard -> "salary_dashboard"; Screen.SalaryEmployees -> "salary_employees"; Screen.SalaryReports -> "salary_reports"; is Screen.SalaryEmployeeDetail -> "salary_employee_detail\u001f${screen.id}"; Screen.DailyLabourHome -> "daily"
        Screen.DailyLabourAccounts -> "daily_accounts"; Screen.AllLabourReport -> "all_report"
        Screen.ReportCentre -> "report_centre"; Screen.ReportType -> "report_type"
        Screen.AttendanceFields -> "attendance_fields"; Screen.FieldList -> "fields"
        is Screen.ExpenseList -> "expense\u001f${screen.fieldId.orEmpty()}\u001f${screen.cropId.orEmpty()}"
        is Screen.SaleList -> "sale\u001f${screen.fieldId.orEmpty()}\u001f${screen.cropId.orEmpty()}"
        is Screen.CropList -> "crops\u001f${screen.fieldId.orEmpty()}"
        is Screen.LabourDetail -> "labour_detail\u001f${screen.id}"
        is Screen.FieldDetail -> "field_detail\u001f${screen.id}"
        is Screen.CropDetail -> "crop_detail\u001f${screen.id}"
        is Screen.Attendance -> "attendance\u001f${screen.fieldId.orEmpty()}"
        Screen.AttendanceHistory -> "attendance_history"; Screen.TodayAttendance -> "today_attendance"
        Screen.Backup -> "backup"; Screen.Profile -> "profile"; Screen.CaneParchi -> "cane_parchi"
        Screen.CanePeeling -> "cane_peeling"; Screen.WorkList -> "work_list"
        Screen.WageRateHistory -> "rate_history"; Screen.Profitability -> "profitability"
    }
    return android.util.Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
}

private fun decodeScreenState(encoded: String): Screen? = runCatching {
    val raw = String(android.util.Base64.decode(encoded, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING), Charsets.UTF_8)
    val parts = raw.split('\u001f')
    when (parts[0]) {
        "home" -> Screen.Home; "labour" -> Screen.LabourList; "salary_dashboard" -> Screen.SalaryDashboard; "salary_employees" -> Screen.SalaryEmployees; "salary_reports" -> Screen.SalaryReports; "salary_employee_detail" -> Screen.SalaryEmployeeDetail(parts.getOrElse(1) { "" }); "daily" -> Screen.DailyLabourHome
        "daily_accounts" -> Screen.DailyLabourAccounts; "all_report" -> Screen.AllLabourReport
        "report_centre" -> Screen.ReportCentre; "report_type" -> Screen.ReportType
        "attendance_fields" -> Screen.AttendanceFields; "fields" -> Screen.FieldList
        "expense" -> Screen.ExpenseList(parts.getOrNull(1)?.ifBlank { null }, parts.getOrNull(2)?.ifBlank { null })
        "sale" -> Screen.SaleList(parts.getOrNull(1)?.ifBlank { null }, parts.getOrNull(2)?.ifBlank { null })
        "crops" -> Screen.CropList(parts.getOrNull(1)?.ifBlank { null })
        "labour_detail" -> Screen.LabourDetail(parts.getOrElse(1) { "" })
        "field_detail" -> Screen.FieldDetail(parts.getOrElse(1) { "" })
        "crop_detail" -> Screen.CropDetail(parts.getOrElse(1) { "" })
        "attendance" -> Screen.Attendance(parts.getOrNull(1)?.ifBlank { null })
        "attendance_history" -> Screen.AttendanceHistory; "today_attendance" -> Screen.TodayAttendance
        "backup" -> Screen.Backup; "profile" -> Screen.Profile; "cane_parchi" -> Screen.CaneParchi
        "cane_peeling" -> Screen.CanePeeling; "work_list" -> Screen.WorkList
        "rate_history" -> Screen.WageRateHistory; "profitability" -> Screen.Profitability
        else -> null
    }
}.getOrNull()


private const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
private const val DRIVE_FOLDER_NAME = "Majdoor Hisaab PRO"

private class NeedRemoteConsent(val consentIntent: Intent, message: String) : IllegalStateException(message)

internal class GoogleDriveDirect(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_drive",Context.MODE_PRIVATE)
    private fun signInOptions():GoogleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestScopes(Scope(DRIVE_FILE_SCOPE))
        .build()
    fun signInIntent(accountEmail:String?=null):Intent {
        val builder=GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DRIVE_FILE_SCOPE))
        if(!accountEmail.isNullOrBlank()) builder.setAccountName(accountEmail)
        return GoogleSignIn.getClient(context,builder.build()).signInIntent
    }
    fun prepareFreshSignIn(onReady:()->Unit){
        prefs.edit().remove("email").apply()
        GoogleSignIn.getClient(context,signInOptions()).signOut().addOnCompleteListener { onReady() }
    }
    fun lastAccount():GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)
    fun saveAccount(account:GoogleSignInAccount){ prefs.edit().putString("email",account.email.orEmpty()).apply() }
    fun accountLabel():String = lastAccount()?.email ?: prefs.getString("email",null) ?: "Google Account नहीं जुड़ा"

    private fun token(account:GoogleSignInAccount):String{
        val acc:Account=account.account ?: throw IllegalStateException("Google Account उपलब्ध नहीं है।")
        return try {
            GoogleAuthUtil.getToken(context,acc,"oauth2:$DRIVE_FILE_SCOPE")
        } catch (consent:UserRecoverableAuthException) {
            // Do not launch UI from this IO-thread token request. Return the SDK-provided
            // consent intent to the Compose Activity Result handler, which owns retry policy.
            val consentIntent = consent.intent
            if (consentIntent != null) {
                throw NeedRemoteConsent(
                    consentIntent,
                    "Google Drive की अतिरिक्त अनुमति आवश्यक है। अनुमति स्क्रीन खोलें और फिर कार्रवाई जारी रखें।"
                )
            } else {
                throw IllegalStateException(
                    "Google Drive consent Intent उपलब्ध नहीं है। कृपया Backup/Restore दोबारा शुरू करें।"
                )
            }
        }
    }
    private fun request(method:String,url:String,token:String,body:ByteArray?=null,contentType:String?=null):ByteArray{
        val c=(URL(url).openConnection() as HttpURLConnection).apply{
            requestMethod=method
            setRequestProperty("Authorization","Bearer $token")
            connectTimeout=30000; readTimeout=60000
            if(body!=null){doOutput=true; setRequestProperty("Content-Type",contentType ?: "application/octet-stream")}
        }
        if(body!=null) c.outputStream.use{it.write(body)}
        val code=c.responseCode
        val stream=if(code in 200..299)c.inputStream else (c.errorStream ?: c.inputStream)
        val bytes=stream.use{it.readBytes()}
        if(code !in 200..299) throw IllegalStateException("Google Drive error $code: ${bytes.toString(Charsets.UTF_8).take(300)}")
        return bytes
    }
    private fun jsonGet(url:String,token:String):JSONObject=JSONObject(request("GET",url,token).toString(Charsets.UTF_8))

    private fun ensureFolder(token:String):String{
        val q=URLEncoder.encode("name='$DRIVE_FOLDER_NAME' and mimeType='application/vnd.google-apps.folder' and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&pageSize=10&fields=files(id,name)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files!=null && files.length()>0) return files.getJSONObject(0).getString("id")
        val meta=JSONObject().apply{put("name",DRIVE_FOLDER_NAME);put("mimeType","application/vnd.google-apps.folder")}
        return JSONObject(request("POST","https://www.googleapis.com/drive/v3/files?fields=id",token,meta.toString().toByteArray(Charsets.UTF_8),"application/json").toString(Charsets.UTF_8)).getString("id")
    }
    fun upload(account:GoogleSignInAccount,zip:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val boundary="mhpro_${System.currentTimeMillis()}"
        val meta=JSONObject().apply{
            put("name",zip.name)
            put("mimeType","application/octet-stream")
            put("parents",org.json.JSONArray().put(folder))
        }.toString()
        val head=("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n").toByteArray()
        val tail="\r\n--$boundary--\r\n".toByteArray()
        val bytes=zip.readBytes()
        val payload=ByteArray(head.size+bytes.size+tail.size)
        System.arraycopy(head,0,payload,0,head.size);System.arraycopy(bytes,0,payload,head.size,bytes.size);System.arraycopy(tail,0,payload,head.size+bytes.size,tail.size)
        val result=request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name",token,payload,"multipart/related; boundary=$boundary")
        return JSONObject(result.toString(Charsets.UTF_8)).optString("name",zip.name)
    }
    fun downloadLatest(account:GoogleSignInAccount,out:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val q=URLEncoder.encode("'$folder' in parents and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&orderBy=createdTime desc&pageSize=20&fields=files(id,name,createdTime,mimeType)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files==null || files.length()==0) throw IllegalStateException("Google Drive में कोई backup नहीं मिला।")
        var chosen:JSONObject?=null
        for(i in 0 until files.length()){
            val f=files.getJSONObject(i)
            if(f.optString("name").endsWith(".mhbackup",true)){chosen=f;break}
        }
        val file=chosen ?: throw IllegalStateException("Google Drive folder में कोई वैध .mhbackup फ़ाइल नहीं मिली। कोई दूसरी फ़ाइल restore नहीं की गई।")
        val id=file.getString("id")
        val data=request("GET","https://www.googleapis.com/drive/v3/files/$id?alt=media",token)
        out.outputStream().use{it.write(data)}
        return file.optString("name","backup.mhbackup")
    }
}

internal class Store(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
    var labours by mutableStateOf(loadLabours()); private set
    var fandiLabours by mutableStateOf(loadFandiLabours()); private set
    var fields by mutableStateOf(loadFields()); private set
    var crops by mutableStateOf(loadCrops()); private set
    var expenses by mutableStateOf(loadExpenses()); private set
    var sales by mutableStateOf(loadSales()); private set
    var attendances by mutableStateOf(loadAttendance()); private set
    var payments by mutableStateOf(loadPayments()); private set
    var labourClosures by mutableStateOf(loadLabourClosures()); private set
    var lockedLabourMonths by mutableStateOf(loadLockedLabourMonths()); private set
    var rates by mutableStateOf(loadRates()); private set
    var fandiRate by mutableStateOf(prefs.getString("fandiRate","5")?.toDoubleOrNull() ?: 5.0); private set
    var canePrices by mutableStateOf(loadCanePrices()); private set
    var caneParchis by mutableStateOf(loadCaneParchis()); private set
    var canePeelings by mutableStateOf(loadCanePeelings()); private set
    var canePeelingPayments by mutableStateOf(loadCanePeelingPayments()); private set

    init {
        // One-time compatibility migration: only workers already referenced by old
        // Fandi records are copied into the new independent Fandi labour list.
        // Daily labour records are never copied wholesale.
        if(fandiLabours.isEmpty() && canePeelings.isNotEmpty()){
            val ids=canePeelings.map{it.labourId}.distinct()
            val migrated=ids.mapNotNull{id->labours.firstOrNull{it.id==id}?.let{l->FandiLabour(l.id,l.name,l.address,l.rate,l.mobile,l.photo)}}
            if(migrated.isNotEmpty()){
                fandiLabours=migrated.distinctBy{it.id}
                write("fandiLabour",fandiLabours,::obj)
            }
        }
        normalizeFandiData()
    }

    private fun normalizeFandiData(){
        fun nameKey(v:String)=v.trim().lowercase(Locale.ROOT).replace(Regex("\\s+")," ")
        fun phoneKey(v:String)=v.filter{it.isDigit()}
        val canonical=mutableListOf<FandiLabour>()
        val idMap=mutableMapOf<String,String>()
        fandiLabours.forEach{worker->
            val nk=nameKey(worker.name)
            val ph=phoneKey(worker.mobile)
            // Product rule: a normalized worker name must be unique. For legacy data,
            // map same-name profiles to the first profile and preserve their linked history.
            // A matching valid phone also identifies the same profile even if the name changed.
            val prior=canonical.firstOrNull{old->
                (nk.isNotBlank() && nameKey(old.name)==nk) || (ph.length>=7 && phoneKey(old.mobile).length>=7 && ph==phoneKey(old.mobile))
            }
            if(prior==null){canonical.add(worker);idMap[worker.id]=worker.id}
            else{
                idMap[worker.id]=prior.id
                val merged=prior.copy(
                    address=prior.address.ifBlank{worker.address},
                    mobile=prior.mobile.ifBlank{worker.mobile},
                    photo=prior.photo.ifBlank{worker.photo}
                )
                canonical[canonical.indexOfFirst{it.id==prior.id}]=merged
            }
        }
        val mappedRows=canePeelings.map{row->row.copy(labourId=idMap[row.labourId]?:row.labourId)}
        // Consolidate legacy duplicate rows by ADDING their quantities, never replacing 10 with 15.
        val uniqueRows=linkedMapOf<String,CanePeeling>()
        mappedRows.forEach{row->
            val key="${row.labourId}|${row.fieldId}|${row.date}"
            val old=uniqueRows[key]
            uniqueRows[key]=if(old==null) row else {
                val f=old.fandi+row.fandi
                val amount=old.total+row.total
                old.copy(fandi=f,total=amount,rate=if(f>0) amount/f else old.rate)
            }
        }
        val cleanRows=uniqueRows.values.toList()
        val cleanPayments=canePeelingPayments.map{payment->payment.copy(labourId=idMap[payment.labourId]?:payment.labourId)}
        if(canonical!=fandiLabours){fandiLabours=canonical;write("fandiLabour",fandiLabours,::obj)}
        if(cleanRows!=canePeelings){canePeelings=cleanRows;write("canePeeling",canePeelings,::obj)}
        if(cleanPayments!=canePeelingPayments){canePeelingPayments=cleanPayments;write("canePeelingPayment",canePeelingPayments,::obj)}
    }

    private fun read(key:String)=JSONArray(prefs.getString(key,"[]") ?: "[]")
    private fun str(o:JSONObject,k:String)=o.optString(k,"")
    private fun num(o:JSONObject,k:String)=o.optDouble(k,0.0)
    private fun save(key:String,a:JSONArray){prefs.edit().putString(key,a.toString()).apply()}
    private fun <T> JSONArray.mapList(mapper:(JSONObject)->T): List<T> = (0 until length()).map { mapper(getJSONObject(it)) }

    private fun loadLabours()=read("labour").mapList{Labour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFandiLabours()=read("fandiLabour").mapList{FandiLabour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFields():List<Field>{
        val raw=read("field").mapList{Field(str(it,"id"),str(it,"name"),str(it,"address"),str(it,"area"),str(it,"photo"))}
        val order=prefs.getString("fieldOrder","").orEmpty().split('|').filter{it.isNotBlank()}
        if(order.isEmpty()) return raw
        val byId=raw.associateBy{it.id}
        return order.mapNotNull{byId[it]} + raw.filter{it.id !in order}
    }
    private fun loadCrops()=read("crop").mapList{Crop(str(it,"id"),str(it,"fieldId"),str(it,"name"),str(it,"variety"),str(it,"sowingDate"),str(it,"season"))}
    private fun loadExpenses()=read("expense").mapList{Expense(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),str(it,"type"),str(it,"item"),str(it,"qty"),str(it,"unit"),num(it,"amount"),str(it,"date"))}
    private fun loadSales()=read("sale").mapList{Sale(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),num(it,"qty"),str(it,"unit"),num(it,"rate"),num(it,"total"),str(it,"buyer"),str(it,"date"))}
    private fun loadAttendance():List<Attendance>{
        val raw=read("attendance").mapList{Attendance(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"fraction"),num(it,"rate"))}
        // Backward compatibility: an old attendance without cropId can be safely
        // attached to the only crop in that field. If multiple crops exist, keep
        // it field-level because assigning it to a crop would be guesswork.
        return raw.map{a->
            if(a.cropId.isBlank()){
                val matches=crops.filter{it.fieldId==a.fieldId}
                if(matches.size==1) a.copy(cropId=matches.first().id) else a
            } else a
        }
    }
    private fun loadPayments()=read("payment").mapList{Payment(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"amount"))}
    private fun loadLabourClosures()=read("labourClosure").mapList{LabourClosure(str(it,"id"),str(it,"labourId"),str(it,"throughDate"),num(it,"wage"),num(it,"paid"),it.optLong("closedAt",0L))}
    private fun loadLockedLabourMonths():List<String> = read("lockedLabourMonths").mapList{str(it,"month")}.filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    private fun loadRates()=read("rateHistory").mapList{WageRate(str(it,"id"),str(it,"labourId"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCanePrices()=read("canePriceHistory").mapList{CanePrice(str(it,"id"),str(it,"season"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCaneParchis()=read("caneParchi").mapList{CaneParchi(str(it,"id"),str(it,"name"),str(it,"fatherName"),str(it,"code"),str(it,"date"),num(it,"weight"),num(it,"rate"),str(it,"photo"),str(it,"remark"),str(it,"season"),str(it,"fieldId"))}
    private fun loadCanePeelings()=read("canePeeling").mapList{CanePeeling(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"date"),num(it,"fandi"),num(it,"rate"),num(it,"total"))}
    private fun loadCanePeelingPayments()=read("canePeelingPayment").mapList{CanePeelingPayment(str(it,"id"),str(it,"labourId"),str(it,"date"),num(it,"amount"),str(it,"method"),str(it,"note"))}

    private fun obj(x:Labour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:FandiLabour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:Field)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("area",x.area);put("photo",x.photo)}
    private fun obj(x:Crop)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("name",x.name);put("variety",x.variety);put("sowingDate",x.sowingDate);put("season",x.season)}
    private fun obj(x:Expense)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("type",x.type);put("item",x.item);put("qty",x.qty);put("unit",x.unit);put("amount",x.amount);put("date",x.date)}
    private fun obj(x:Sale)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("qty",x.qty);put("unit",x.unit);put("rate",x.rate);put("total",x.total);put("buyer",x.buyer);put("date",x.date)}
    private fun obj(x:Attendance)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("fraction",x.fraction);put("rate",x.rate)}
    private fun obj(x:Payment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("amount",x.amount)}
    private fun obj(x:LabourClosure)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("throughDate",x.throughDate);put("wage",x.wage);put("paid",x.paid);put("closedAt",x.closedAt)}
    private fun obj(x:WageRate)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CanePrice)=JSONObject().apply{put("id",x.id);put("season",x.season);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CaneParchi)=JSONObject().apply{put("id",x.id);put("name",x.name);put("fatherName",x.fatherName);put("code",x.code);put("date",x.date);put("weight",x.weight);put("rate",x.rate);put("photo",x.photo);put("remark",x.remark);put("season",x.season);put("fieldId",x.fieldId)}
    private fun obj(x:CanePeeling)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("date",x.date);put("fandi",x.fandi);put("rate",x.rate);put("total",x.total)}
    private fun obj(x:CanePeelingPayment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("date",x.date);put("amount",x.amount);put("method",x.method);put("note",x.note)}
    private fun <T> write(key:String,list:List<T>,mapper:(T)->JSONObject){save(key,JSONArray(list.map(mapper)))}

    private val backupKeys = listOf("labour","fandiLabour","field","crop","expense","sale","attendance","payment","labourClosure","lockedLabourMonths","rateHistory","canePriceHistory","caneParchi","canePeeling","canePeelingPayment")

    @Synchronized fun createBackupZip(output:File){
        val parent=output.absoluteFile.parentFile ?: throw IllegalStateException("Backup folder उपलब्ध नहीं है।")
        if(!parent.exists() && !parent.mkdirs()) throw IllegalStateException("Backup folder नहीं बन सका।")
        val staging=File(parent, output.name+".staging-"+UUID.randomUUID())
        val previous=File(parent, output.name+".previous-"+UUID.randomUUID())
        var previousMoved=false
        try {
            val root=JSONObject().apply{
                put("schemaVersion",2)
                put("app","Majdoor Hisaab PRO")
                put("appVersion",BuildConfig.VERSION_NAME)
                put("createdAt",System.currentTimeMillis())
                put("fandiRate",fandiRate)
                put("fieldOrder",prefs.getString("fieldOrder", "").orEmpty())
                backupKeys.forEach{put(it,read(it))}
                val salaryData=JSONObject()
                context.getSharedPreferences("mhpro_salary_employees_v1",Context.MODE_PRIVATE).all.forEach{(key,value)->if(value is String) salaryData.put(key,value)}
                put("salaryData",salaryData)
            }
            val photoPaths=(labours.map{it.photo}+fandiLabours.map{it.photo}+fields.map{it.photo}+caneParchis.map{it.photo}).filter{it.isNotBlank()}
                .map{File(it)}.filter{it.isFile}.distinctBy{it.absolutePath}
            val photoMap=JSONObject()
            photoPaths.forEachIndexed{index,file->
                val safeBase=file.name.replace(Regex("[^A-Za-z0-9._-]"),"_")
                photoMap.put(file.absolutePath,"${index}_${safeBase}")
            }
            root.put("photoMap",photoMap)
            ZipOutputStream(FileOutputStream(staging)).use{zos->
                zos.putNextEntry(ZipEntry("backup.json"))
                zos.write(root.toString().toByteArray(Charsets.UTF_8))
                zos.closeEntry()
                photoPaths.forEach{file->
                    val safe=photoMap.optString(file.absolutePath)
                    if(safe.isBlank()) return@forEach
                    zos.putNextEntry(ZipEntry("photos/$safe"))
                    file.inputStream().use{it.copyTo(zos)}
                    zos.closeEntry()
                }
            }
            if(!staging.isFile || staging.length()<=0L) throw IllegalStateException("Backup खाली बना है।")
            validateBackupZip(staging)
            // Keep an existing destination recoverable until the new archive is validated and installed.
            if(output.exists()) {
                if(!output.renameTo(previous)) throw IllegalStateException("पुराना backup सुरक्षित नहीं रखा जा सका; नया backup नहीं लिखा गया।")
                previousMoved=true
            }
            if(!staging.renameTo(output)) throw IllegalStateException("सत्यापित backup अंतिम जगह पर सेव नहीं हो सका।")
            if(!output.isFile || output.length()<=0L) throw IllegalStateException("Backup सेव होने की पुष्टि नहीं हुई।")
            validateBackupZip(output)
            previous.delete()
        } catch(error:Throwable) {
            if(output.exists() && previousMoved) output.delete()
            if(previousMoved && previous.exists()) previous.renameTo(output)
            throw error
        } finally {
            staging.delete()
            if(!previousMoved) previous.delete()
        }
    }

    fun validateBackupZip(input:File){
        if(!input.isFile || input.length()<=0L) throw IllegalArgumentException("Backup file खाली है या उपलब्ध नहीं है।")
        var backupJson:String?=null
        var total=0L
        val seenEntries=mutableSetOf<String>()
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry ?: break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                val name=entry.name.replace('\\','/')
                if(name.isBlank() || name.contains("..") || name.startsWith("/") || Regex("^[A-Za-z]:").containsMatchIn(name)) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(!seenEntries.add(name)) throw IllegalArgumentException("Backup में duplicate file entry है: $name")
                if(!entry.isDirectory){
                    val bytes=zis.readBytes(); total+=bytes.size
                    if(total>100L*1024L*1024L) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
                    if(name=="backup.json") backupJson=bytes.toString(Charsets.UTF_8)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson ?: throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Backup app match नहीं करता।")
        if(root.optInt("schemaVersion",0) !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        validateBackupArrays(root)
    }

    private fun validateBackupArrays(root:JSONObject){
        // Validate every present data collection before restore writes anything. Missing
        // collections remain backward-compatible with older schema versions.
        backupKeys.forEach { key ->
            val value=root.opt(key)
            if(value == null && root.optInt("schemaVersion",0) >= 2) throw IllegalArgumentException("Backup अधूरा है: '$key' रिकॉर्ड मौजूद नहीं हैं।")
            if(value == null) return@forEach
            if(value !is JSONArray) throw IllegalArgumentException("Backup में '$key' का format गलत है।")
            for(i in 0 until value.length()) {
                if(value.opt(i) !is JSONObject) throw IllegalArgumentException("Backup में '$key' का रिकॉर्ड #${i+1} गलत है।")
            }
        }
        val fandiRateValue=root.optDouble("fandiRate", Double.NaN)
        if(!fandiRateValue.isNaN() && (!fandiRateValue.isFinite() || fandiRateValue<=0.0))
            throw IllegalArgumentException("Backup में फांदी रेट गलत है।")
        val order=root.opt("fieldOrder")
        if(order!=null && order !is String) throw IllegalArgumentException("Backup में खेतों का क्रम गलत है।")
    }

    @Synchronized fun restoreBackupZip(input:File):String{
        // Validate independently so no caller can bypass archive/schema checks.
        validateBackupZip(input)
        var backupJson:String?=null
        val photoEntries=mutableListOf<Pair<String,ByteArray>>()
        var total=0L
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry?:break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                if(entry.isDirectory){zis.closeEntry();continue}
                val name=entry.name.replace('\\','/')
                if(name.contains("..") || name.startsWith("/")) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(name.startsWith("photos/") && name.removePrefix("photos/").isBlank()) throw IllegalArgumentException("Backup photo entry गलत है।")
                val bytes=zis.readBytes()
                total+=bytes.size
                if(total>100L*1024L*1024L) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
                when{
                    name=="backup.json" -> backupJson=bytes.toString(Charsets.UTF_8)
                    name.startsWith("photos/") -> photoEntries.add(name.removePrefix("photos/") to bytes)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson?:throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO")
            throw IllegalArgumentException("Backup app match नहीं करता।")
        val schema=root.optInt("schemaVersion",0)
        if(schema !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        validateBackupArrays(root)
        val photoMap=root.optJSONObject("photoMap") ?: JSONObject()
        val restoredPhotoNames=mutableMapOf<String,String>()
        fun restoredPath(original:String):String{
            if(original.isBlank()) return ""
            val backupName=photoMap.optString(original,"")
            if(backupName.isNotBlank()) return restoredPhotoNames[File(backupName).name].orEmpty()
            // Backward compatibility for schema v1 backups: match by original basename.
            val legacy=File(original).name
            val candidate=photoEntries.firstOrNull{File(it.first).name.endsWith("_$legacy") || File(it.first).name==legacy}
            return candidate?.let{restoredPhotoNames[File(it.first).name].orEmpty()} ?: ""
        }
        // Stage photo bytes first. A corrupt/unwritable photo must not destroy the
        // current database before the restore has a complete replacement ready.
        val photoDir=File(context.filesDir,"photos")
        val stagingDir=File(context.filesDir,"photos_restore_${UUID.randomUUID()}")
        val previousDir=File(context.filesDir,"photos_previous_${UUID.randomUUID()}")
        if(!stagingDir.mkdirs() && !stagingDir.isDirectory) throw IllegalStateException("Restore के लिए अस्थायी photo folder नहीं बन सका।")
        try {
            photoEntries.forEach{(name,bytes)->
                if(name.isBlank()) return@forEach
                val safe=File(name).name
                File(stagingDir,safe).outputStream().use{it.write(bytes)}
                restoredPhotoNames[safe]=File(photoDir,safe).absolutePath
            }
        } catch(error:Throwable) {
            stagingDir.deleteRecursively()
            throw error
        }

        // Rewrite every restored photo reference before committing any data. This keeps
        // the complete restore in one preference commit instead of a series of post-commit writes.
        listOf("labour","fandiLabour","field","caneParchi").forEach { key ->
            val rows=root.optJSONArray(key) ?: return@forEach
            for(i in 0 until rows.length()) {
                val row=rows.optJSONObject(i) ?: continue
                val original=row.optString("photo","")
                if(original.isNotBlank()) row.put("photo",restoredPath(original))
            }
        }
        val oldValues=backupKeys.associateWith{prefs.getString(it,null)}
        val oldFieldOrder=prefs.getString("fieldOrder",null)
        val oldFandiRate=prefs.getString("fandiRate",null)
        val salaryPrefs=context.getSharedPreferences("mhpro_salary_employees_v1",Context.MODE_PRIVATE)
        val oldSalaryValues=salaryPrefs.all.mapNotNull{(k,v)->(v as? String)?.let{k to it}}.toMap()
        val restoredSalaryData=root.optJSONObject("salaryData")
        if(root.has("salaryData") && restoredSalaryData==null) throw IllegalArgumentException("Backup में Salary Employee डेटा का format गलत है।")
        if(restoredSalaryData!=null){val keys=restoredSalaryData.keys();while(keys.hasNext()){val key=keys.next();if(restoredSalaryData.opt(key) !is String) throw IllegalArgumentException("Backup में Salary Employee रिकॉर्ड गलत है।")}}
        val savedFieldOrder=root.optString("fieldOrder", "")
        val restoredFandiRate=root.optDouble("fandiRate", Double.NaN).takeIf{it.isFinite() && it>0} ?: 5.0
        var previousMoved=false
        var stagedMoved=false
        try {
            if(photoDir.exists()) {
                if(!photoDir.renameTo(previousDir)) throw IllegalStateException("पुरानी photos सुरक्षित रखते हुए restore शुरू नहीं हो सका।")
                previousMoved=true
            }
            if(!stagingDir.renameTo(photoDir)) throw IllegalStateException("नई photos restore नहीं हो सकीं।")
            stagedMoved=true
            val editor=prefs.edit()
            backupKeys.forEach{key->editor.putString(key,(root.optJSONArray(key) ?: JSONArray()).toString())}
            if(savedFieldOrder.isNotBlank()) editor.putString("fieldOrder",savedFieldOrder) else editor.remove("fieldOrder")
            editor.putString("fandiRate",restoredFandiRate.toString())
            if(!editor.commit()) throw IllegalStateException("Restore data save नहीं हो सका। पुराना data वापस रखा जा रहा है।")
            if(restoredSalaryData!=null){val salaryEditor=salaryPrefs.edit().clear();val salaryKeys=restoredSalaryData.keys();while(salaryKeys.hasNext()){val key=salaryKeys.next();salaryEditor.putString(key,restoredSalaryData.getString(key))};if(!salaryEditor.commit()) throw IllegalStateException("Salary Employee डेटा restore नहीं हो सका।") }
            fandiRate=restoredFandiRate
        } catch(error:Throwable) {
            val rollback=prefs.edit()
            oldValues.forEach{(key,value)->if(value==null) rollback.remove(key) else rollback.putString(key,value)}
            if(oldFieldOrder==null) rollback.remove("fieldOrder") else rollback.putString("fieldOrder",oldFieldOrder)
            if(oldFandiRate==null) rollback.remove("fandiRate") else rollback.putString("fandiRate",oldFandiRate)
            rollback.commit()
            val salaryRollback=salaryPrefs.edit().clear();oldSalaryValues.forEach{(k,v)->salaryRollback.putString(k,v)};salaryRollback.commit()
            if(stagedMoved) photoDir.deleteRecursively() else stagingDir.deleteRecursively()
            if(previousMoved && previousDir.exists()) previousDir.renameTo(photoDir)
            throw error
        }
        // Keep the old photos until all in-memory models have reloaded successfully.
        try {
            labours=loadLabours(); fandiLabours=loadFandiLabours(); fields=loadFields(); crops=loadCrops()
            expenses=loadExpenses(); sales=loadSales(); attendances=loadAttendance(); payments=loadPayments()
            labourClosures=loadLabourClosures(); lockedLabourMonths=loadLockedLabourMonths(); rates=loadRates()
            canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()
        } catch(error:Throwable) {
            val rollback=prefs.edit()
            oldValues.forEach{(key,value)->if(value==null) rollback.remove(key) else rollback.putString(key,value)}
            if(oldFieldOrder==null) rollback.remove("fieldOrder") else rollback.putString("fieldOrder",oldFieldOrder)
            if(oldFandiRate==null) rollback.remove("fandiRate") else rollback.putString("fandiRate",oldFandiRate)
            val rollbackSaved=rollback.commit()
            val salaryRollback=salaryPrefs.edit().clear();oldSalaryValues.forEach{(k,v)->salaryRollback.putString(k,v)};salaryRollback.commit()
            if(photoDir.exists()) photoDir.deleteRecursively()
            if(previousMoved && previousDir.exists()) previousDir.renameTo(photoDir)
            fandiRate=oldFandiRate?.toDoubleOrNull() ?: 5.0
            runCatching {
                labours=loadLabours(); fandiLabours=loadFandiLabours(); fields=loadFields(); crops=loadCrops()
                expenses=loadExpenses(); sales=loadSales(); attendances=loadAttendance(); payments=loadPayments()
                labourClosures=loadLabourClosures(); lockedLabourMonths=loadLockedLabourMonths(); rates=loadRates()
                canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()
            }
            throw IllegalStateException(if(rollbackSaved) "Restore पूरा नहीं हो सका। पुराना data वापस रखा गया है।" else "Restore विफल हुआ और rollback की पुष्टि नहीं हो सकी। ऐप का data साफ़ न करें; तुरंत बंद करके दोबारा खोलें।",error)
        }
        previousDir.deleteRecursively()
        return root.optString("createdAt","")
    }

    fun addCanePrice(x:CanePrice){
        canePrices=canePrices.filterNot{it.season==x.season && it.effectiveDate==x.effectiveDate}+x
        write("canePriceHistory",canePrices,::obj)
    }
    fun caneRateFor(season:String,date:String):Double=
        canePrices.filter{it.season==season && validDate(it.effectiveDate) && it.effectiveDate<=date}
            .maxByOrNull{it.effectiveDate}?.rate ?: 400.0
    fun canePricesFor(season:String)=canePrices.filter{it.season==season}.sortedByDescending{it.effectiveDate}.distinctBy{it.effectiveDate}
    private fun normalizedParchiCode(code:String)=code.trim().filter{it.isDigit()}
    private fun validCaneParchi(x:CaneParchi):Boolean =
        x.id.isNotBlank() && x.name.isNotBlank() && x.fatherName.isNotBlank() &&
            Regex("\\d{6,7}").matches(normalizedParchiCode(x.code)) &&
            validDate(x.date) && x.date<=today() && x.season==caneSeason(x.date) &&
            x.weight.isFinite() && x.weight>0.0 && x.rate.isFinite() && x.rate>0.0 &&
            (x.weight*x.rate).isFinite() && (x.weight*x.rate)>0.0
    @Synchronized fun addCaneParchi(x:CaneParchi):Boolean{
        if(!validDate(x.date)) return false
        val normalized=x.copy(code=normalizedParchiCode(x.code),date=x.date.trim(),season=caneSeason(x.date))
        if(!validCaneParchi(normalized)) return false
        if(caneParchis.any{it.id==normalized.id || (it.season==normalized.season && normalizedParchiCode(it.code)==normalized.code)}) return false
        caneParchis=caneParchis+normalized
        write("caneParchi",caneParchis,::obj)
        return true
    }
    @Synchronized fun updateCaneParchi(x:CaneParchi):Boolean{
        if(caneParchis.none{it.id==x.id} || !validDate(x.date)) return false
        val normalized=x.copy(code=normalizedParchiCode(x.code),date=x.date.trim(),season=caneSeason(x.date))
        if(!validCaneParchi(normalized)) return false
        if(caneParchis.any{it.id!=normalized.id && it.season==normalized.season && normalizedParchiCode(it.code)==normalized.code}) return false
        caneParchis=caneParchis.map{if(it.id==normalized.id)normalized else it}
        write("caneParchi",caneParchis,::obj)
        return true
    }
    @Synchronized fun deleteCaneParchi(id:String):Boolean{
        if(id.isBlank() || caneParchis.none{it.id==id}) return false
        caneParchis=caneParchis.filterNot{it.id==id}
        write("caneParchi",caneParchis,::obj)
        return true
    }
    @Synchronized fun addCanePeeling(x:CanePeeling):Boolean{
        // Validate at the Store boundary too; UI validation alone is not sufficient.
        if(x.id.isBlank() || fandiLabours.none{it.id==x.labourId} || (x.fieldId.isNotBlank() && fields.none{it.id==x.fieldId}) ||
            !validDate(x.date) || !x.fandi.isFinite() || x.fandi<=0.0 || !x.rate.isFinite() || x.rate<=0.0) return false
        if(canePeelings.any{it.id==x.id || (it.labourId==x.labourId&&it.fieldId==x.fieldId&&it.date==x.date)}) return false
        val normalized=x.copy(total=x.fandi*x.rate)
        if(!normalized.total.isFinite() || normalized.total<=0.0) return false
        canePeelings=canePeelings+normalized
        write("canePeeling",canePeelings,::obj)
        return true
    }
    @Synchronized fun updateCanePeeling(x:CanePeeling):Boolean{
        if(canePeelings.none{it.id==x.id} || fandiLabours.none{it.id==x.labourId} || (x.fieldId.isNotBlank() && fields.none{it.id==x.fieldId}) ||
            !validDate(x.date) || !x.fandi.isFinite() || x.fandi<=0.0 || !x.rate.isFinite() || x.rate<=0.0) return false
        if(canePeelings.any{it.id!=x.id && it.labourId==x.labourId&&it.fieldId==x.fieldId&&it.date==x.date}) return false
        val normalized=x.copy(total=x.fandi*x.rate)
        if(!normalized.total.isFinite() || normalized.total<=0.0) return false
        canePeelings=canePeelings.map{if(it.id==x.id)normalized else it}
        write("canePeeling",canePeelings,::obj)
        return true
    }
    @Synchronized fun deleteCanePeeling(id:String):Boolean{
        val row=canePeelings.firstOrNull{it.id==id} ?: return false
        // Do not remove earning rows after payments exist for this worker; edit the row instead.
        if(canePeelingPayments.any{it.labourId==row.labourId}) return false
        canePeelings=canePeelings.filterNot{it.id==id};write("canePeeling",canePeelings,::obj);return true
    }
    @Synchronized fun addCanePeelingPayment(x:CanePeelingPayment):Boolean{
        if(x.id.isBlank() || canePeelingPayments.any{it.id==x.id} || fandiLabours.none{it.id==x.labourId} || !validDate(x.date) || !x.amount.isFinite() || x.amount<=0.0) return false
        canePeelingPayments=canePeelingPayments+x.copy(note=x.note.trim(),method=x.method.ifBlank{"नकद"})
        write("canePeelingPayment",canePeelingPayments,::obj);return true
    }
    @Synchronized fun updateCanePeelingPayment(x:CanePeelingPayment):Boolean{
        if(canePeelingPayments.none{it.id==x.id} || fandiLabours.none{it.id==x.labourId} || !validDate(x.date) || !x.amount.isFinite() || x.amount<=0.0) return false
        canePeelingPayments=canePeelingPayments.map{if(it.id==x.id)x.copy(note=x.note.trim(),method=x.method.ifBlank{"नकद"}) else it}
        write("canePeelingPayment",canePeelingPayments,::obj);return true
    }
    @Synchronized fun deleteCanePeelingPayment(id:String):Boolean{
        if(canePeelingPayments.none{it.id==id}) return false
        canePeelingPayments=canePeelingPayments.filterNot{it.id==id};write("canePeelingPayment",canePeelingPayments,::obj);return true
    }

    fun persistPhoto(uriString:String, owner:String):String {
        if(uriString.isBlank() || uriString.startsWith("file://")) return uriString
        return try {
            val uri=Uri.parse(uriString)
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return ""
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun persistBitmapPhoto(bitmap:Bitmap, owner:String):String {
        return try {
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG,90,out) }
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    private fun normalizedLabourName(value:String)=value.trim().replace(Regex("\\s+")," ").lowercase(java.util.Locale.ROOT)
    fun labourNameExists(name:String,excludeId:String?=null):Boolean{
        val normalized=normalizedLabourName(name)
        return normalized.isNotBlank() && labours.any{it.id!=excludeId && normalizedLabourName(it.name)==normalized}
    }
    @Synchronized fun addLabour(x:Labour):Boolean{
        if(x.name.isBlank() || labourNameExists(x.name)) return false
        labours=labours+x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        write("labour",labours,::obj)
        if(x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
        return true
    }
    @Synchronized fun updateLabour(x:Labour):Boolean{
        if(x.name.isBlank() || labourNameExists(x.name,x.id)) return false
        val normalized=x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        val old=labours.firstOrNull{it.id==x.id}
        labours=labours.map{if(it.id==x.id)normalized else it}
        write("labour",labours,::obj)
        if(old!=null && old.rate!=x.rate && x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
        return true
    }
    @Synchronized fun deleteLabour(id:String):Boolean{
        // Preserve wage/payment history; hard-delete only unused workers.
        val hasHistory=attendances.any{it.labourId==id} || payments.any{it.labourId==id} || rates.any{it.labourId==id} || canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}
        if(hasHistory) return false
        labours=labours.filterNot{it.id==id};write("labour",labours,::obj);return true
    }

    @Synchronized fun updateFandiRate(value:Double):Boolean{
        if(!value.isFinite() || value<=0.0) return false
        // Commit synchronously so the saved rate survives process/app restarts before UI closes.
        if(!prefs.edit().putString("fandiRate",value.toString()).commit()) return false
        fandiRate=value
        return true
    }
    @Synchronized fun addFandiLabour(x:FandiLabour):Boolean{
        val key=x.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
        if(key.isBlank() || fandiLabours.any{it.id==x.id || it.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)==key}) return false
        val phone=x.mobile.filter{it.isDigit()}
        if(phone.length>=7 && fandiLabours.any{val old=it.mobile.filter{c->c.isDigit()};old.length>=7&&old==phone}) return false
        fandiLabours=fandiLabours+x
        write("fandiLabour",fandiLabours,::obj)
        return true
    }
    @Synchronized fun updateFandiLabour(x:FandiLabour):Boolean{
        if(fandiLabours.none{it.id==x.id}) return false
        val key=x.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
        if(key.isBlank() || fandiLabours.any{it.id!=x.id && it.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)==key}) return false
        val phone=x.mobile.filter{it.isDigit()}
        if(phone.length>=7 && fandiLabours.any{it.id!=x.id && it.mobile.filter{c->c.isDigit()}.let{old->old.length>=7&&old==phone}}) return false
        fandiLabours=fandiLabours.map{if(it.id==x.id)x else it}
        write("fandiLabour",fandiLabours,::obj)
        return true
    }
    // Historical worker accounts must never be erased by deleting a profile.
    @Synchronized fun deleteFandiLabour(id:String):Boolean{
        if(fandiLabours.none{it.id==id}) return false
        if(canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}) return false
        fandiLabours=fandiLabours.filterNot{it.id==id}
        write("fandiLabour",fandiLabours,::obj)
        return true
    }

    private fun persistFieldOrder(){prefs.edit().putString("fieldOrder",fields.joinToString("|"){it.id}).apply()}
    fun moveField(id:String,delta:Int){
        val from=fields.indexOfFirst{it.id==id}; val to=from+delta
        if(from<0 || to !in fields.indices) return
        val reordered=fields.toMutableList(); val item=reordered.removeAt(from); reordered.add(to,item)
        fields=reordered; persistFieldOrder()
    }
    fun addField(x:Field){fields=fields+x;write("field",fields,::obj);persistFieldOrder()}
    fun updateField(x:Field){fields=fields.map{if(it.id==x.id)x else it};write("field",fields,::obj)}
    @Synchronized fun deleteField(id:String):Boolean{
        // Preserve field-linked financial and crop history.
        val cropIds=crops.filter{it.fieldId==id}.map{it.id}.toSet()
        val hasHistory=expenses.any{it.fieldId==id || it.cropId in cropIds} || sales.any{it.fieldId==id || it.cropId in cropIds} || attendances.any{it.fieldId==id || it.cropId in cropIds} || payments.any{it.fieldId==id || it.cropId in cropIds} || canePeelings.any{it.fieldId==id}
        if(hasHistory) return false
        fields=fields.filterNot{it.id==id};persistFieldOrder();crops=crops.filterNot{it.fieldId==id};write("field",fields,::obj);write("crop",crops,::obj);return true
    }

    fun addCrop(x:Crop):Boolean{
        if(x.id.isBlank() || x.name.isBlank() || fields.none{it.id==x.fieldId} || crops.any{it.id==x.id || (it.fieldId==x.fieldId && it.name.trim().equals(x.name.trim(),true))}) return false
        crops=crops+x.copy(name=x.name.trim());write("crop",crops,::obj);return true
    }
    @Synchronized fun updateCrop(x:Crop):Boolean{
        val old=crops.firstOrNull{it.id==x.id}?:return false
        if(x.name.isBlank() || fields.none{it.id==x.fieldId} || crops.any{it.id!=x.id && it.fieldId==x.fieldId && it.name.trim().equals(x.name.trim(),true)}) return false
        val hasHistory=expenses.any{it.cropId==x.id} || sales.any{it.cropId==x.id} || attendances.any{it.cropId==x.id} || payments.any{it.cropId==x.id}
        // A crop's parent field cannot be changed once financial/attendance history exists.
        if(hasHistory && old.fieldId!=x.fieldId) return false
        crops=crops.map{if(it.id==x.id)x.copy(name=x.name.trim()) else it};write("crop",crops,::obj);return true
    }
    @Synchronized fun deleteCrop(id:String):Boolean{
        if(crops.none{it.id==id}) return false
        val hasHistory=expenses.any{it.cropId==id} || sales.any{it.cropId==id} || attendances.any{it.cropId==id} || payments.any{it.cropId==id}
        if(hasHistory) return false
        crops=crops.filterNot{it.id==id};write("crop",crops,::obj);return true
    }

    private fun validFieldCrop(fieldId:String,cropId:String):Boolean =
        fields.any{it.id==fieldId} && (cropId.isBlank() || crops.any{it.id==cropId && it.fieldId==fieldId})
    fun fieldCropIntegrityIssues(fieldId:String?=null,cropId:String?=null):List<String> {
        val issues=mutableListOf<String>()
        fun check(kind:String,rowField:String,rowCrop:String,rowId:String){
            if(rowCrop.isBlank()) return
            val crop=crops.firstOrNull{it.id==rowCrop}
            val relevant=fieldId==null && cropId==null || fieldId!=null && (rowField==fieldId || crop?.fieldId==fieldId) || cropId!=null && rowCrop==cropId
            if(relevant && (crop==null || crop.fieldId!=rowField)) issues.add("$kind रिकॉर्ड $rowId: खेत और फसल का लिंक मेल नहीं खाता")
        }
        expenses.forEach{check("खर्च",it.fieldId,it.cropId,it.id)}
        sales.forEach{check("बिक्री",it.fieldId,it.cropId,it.id)}
        attendances.forEach{check("हाजिरी",it.fieldId,it.cropId,it.id)}
        payments.forEach{check("भुगतान",it.fieldId,it.cropId,it.id)}
        return issues.distinct()
    }
    private fun validExpense(x:Expense):Boolean = x.id.isNotBlank() && validDate(x.date) && validFieldCrop(x.fieldId,x.cropId) && x.amount.isFinite() && x.amount>0.0
    private fun validSale(x:Sale):Boolean = x.id.isNotBlank() && validDate(x.date) && validFieldCrop(x.fieldId,x.cropId) && x.qty.isFinite() && x.qty>0.0 && x.rate.isFinite() && x.rate>0.0 && x.unit.isNotBlank()
    @Synchronized fun addExpense(x:Expense):Boolean{
        if(!validExpense(x) || expenses.any{it.id==x.id}) return false
        expenses=expenses+x;write("expense",expenses,::obj);return true
    }
    @Synchronized fun updateExpense(x:Expense):Boolean{
        if(expenses.none{it.id==x.id} || !validExpense(x)) return false
        expenses=expenses.map{if(it.id==x.id)x else it};write("expense",expenses,::obj);return true
    }
    @Synchronized fun deleteExpense(id:String):Boolean{
        if(expenses.none{it.id==id}) return false
        expenses=expenses.filterNot{it.id==id};write("expense",expenses,::obj);return true
    }

    @Synchronized fun addSale(x:Sale):Boolean{
        if(!validSale(x) || sales.any{it.id==x.id}) return false
        val safe=x.copy(total=x.qty*x.rate)
        if(!safe.total.isFinite() || safe.total<=0.0) return false
        sales=sales+safe;write("sale",sales,::obj);return true
    }
    @Synchronized fun updateSale(x:Sale):Boolean{
        if(sales.none{it.id==x.id} || !validSale(x)) return false
        val safe=x.copy(total=x.qty*x.rate)
        if(!safe.total.isFinite() || safe.total<=0.0) return false
        sales=sales.map{if(it.id==x.id)safe else it};write("sale",sales,::obj);return true
    }
    @Synchronized fun deleteSale(id:String):Boolean{
        if(sales.none{it.id==id}) return false
        sales=sales.filterNot{it.id==id};write("sale",sales,::obj);return true
    }

    fun isClosedDate(labourId:String,date:String)=latestClosure(labourId)?.throughDate?.let{date<=it}?:false
    fun isMonthLocked(date:String):Boolean = date.length>=7 && date.substring(0,7) in lockedLabourMonths
    fun setLabourMonthLocked(month:String,locked:Boolean):Boolean {
        if(!month.matches(Regex("\\d{4}-\\d{2}"))) return false
        lockedLabourMonths=(if(locked) (lockedLabourMonths+month) else lockedLabourMonths.filterNot{it==month}).distinct().sortedDescending()
        save("lockedLabourMonths",JSONArray().apply{lockedLabourMonths.forEach{put(JSONObject().put("month",it))}})
        return true
    }
    private fun validPayment(x:Payment):Boolean = x.id.isNotBlank() && labours.any{it.id==x.labourId} && validDate(x.date) && x.amount.isFinite() && x.amount>0.0 && (x.fieldId.isBlank() || validFieldCrop(x.fieldId,x.cropId)) && (x.fieldId.isNotBlank() || x.cropId.isBlank())
    @Synchronized fun addPayment(x:Payment):Boolean{
        if(!validPayment(x) || payments.any{it.id==x.id} || isClosedDate(x.labourId,x.date) || isMonthLocked(x.date)) return false
        payments=payments+x;write("payment",payments,::obj);return true
    }
    @Synchronized fun updatePayment(x:Payment):Boolean{
        val old=payments.firstOrNull{it.id==x.id}?:return false
        // A payment belongs to the original worker; editing cannot silently transfer history.
        if(x.labourId!=old.labourId || !validPayment(x) || isClosedDate(old.labourId,old.date) || isClosedDate(x.labourId,x.date) || isMonthLocked(old.date) || isMonthLocked(x.date)) return false
        payments=payments.map{if(it.id==x.id)x else it};write("payment",payments,::obj);return true
    }
    @Synchronized fun deletePayment(id:String):Boolean{
        val row=payments.firstOrNull{it.id==id}?:return false
        if(isClosedDate(row.labourId,row.date) || isMonthLocked(row.date)) return false
        payments=payments.filterNot{it.id==id};write("payment",payments,::obj);return true
    }
    fun latestClosure(labourId:String):LabourClosure? = labourClosures.filter{it.labourId==labourId}.maxByOrNull{it.throughDate}
    data class BalanceBreakdown(val oldDue:Double,val currentDue:Double,val advance:Double,val totalOutstanding:Double,val currentWages:Double,val currentPayments:Double)
    fun balanceBreakdown(labourId:String):BalanceBreakdown {
        val closed=latestClosure(labourId)
        val closedThrough=closed?.throughDate.orEmpty()
                // Locked months are finalized accounting buckets too. Keep them in old debt/credit,
        // while excluding dates already covered by a later closure to avoid double counting.
        val lockedWages=attendances.filter{it.labourId==labourId && it.date>closedThrough && isMonthLocked(it.date) && it.fraction>0.0}.sumOf{it.fraction*it.rate}
        val lockedPayments=payments.filter{it.labourId==labourId && it.date>closedThrough && isMonthLocked(it.date)}.sumOf{it.amount}
        val currentWages=attendances.filter{it.labourId==labourId && it.date>closedThrough && !isMonthLocked(it.date) && it.fraction>0.0}.sumOf{attendanceWage(it.fraction,it.rate)}
        val currentPayments=payments.filter{it.labourId==labourId && it.date>closedThrough && !isMonthLocked(it.date)}.sumOf{it.amount}
        val balance=calculateAccountingBalance(
            closureWage=closed?.wage ?: 0.0, closurePaid=closed?.paid ?: 0.0,
            lockedWages=lockedWages, lockedPayments=lockedPayments,
            currentWages=currentWages, currentPayments=currentPayments
        )
        return BalanceBreakdown(oldDue=balance.oldDue,currentDue=balance.currentDue,advance=balance.advance,totalOutstanding=balance.totalOutstanding,currentWages=balance.currentWages,currentPayments=balance.currentPayments)
    }
    fun closeLabourAccount(labourId:String,throughDate:String,wage:Double,paid:Double):Boolean {
        if(!validDate(throughDate)) return false
        val old=latestClosure(labourId)
        if(old!=null && throughDate<=old.throughDate) return false
        val closure=LabourClosure(UUID.randomUUID().toString(),labourId,throughDate,wage,paid,System.currentTimeMillis())
        labourClosures=labourClosures+closure
        write("labourClosure",labourClosures,::obj)
        return true
    }
    fun closureHistory(labourId:String?=null)=labourClosures.filter{labourId==null||it.labourId==labourId}.sortedByDescending{it.throughDate}
    fun setRate(x:WageRate){rates=rates.filterNot{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}+x;write("rateHistory",rates,::obj)}
    fun attendanceConflict(x:Attendance):String?{
        val existingSame=attendances.firstOrNull{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.date==x.date
        }
        val otherTotal=attendances.filter{
            it.labourId==x.labourId &&
            it.date==x.date &&
            it.id!=existingSame?.id
        }.sumOf{it.fraction}
        if(otherTotal+x.fraction>1.0001){
            return if(otherTotal>=0.9999) "इस तारीख में इस मजदूर की पूरी 1 दिन की हाजिरी पहले से लगी है।" else "इस तारीख में इस मजदूर की ${if(otherTotal>=0.5) "आधी" else "कुछ"} हाजिरी पहले से लगी है। बाकी जगह केवल बची हुई हाजिरी लग सकती है।"
        }
        return null
    }
    @Synchronized fun upsertAttendance(x:Attendance):String?{
        if(isMonthLocked(x.date)) return "${monthTitle(x.date.take(7))} का हिसाब लॉक है। पुरानी हाजिरी सुरक्षित है; नई हाजिरी चालू महीने में दर्ज करें।"
        val closedThrough=latestClosure(x.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && x.date<=closedThrough) return "इस मजदूर का ${closedThrough} तक का हिसाब फाइनल है। पुरानी तारीख में बदलाव नहीं हो सकता।"
        val conflict=attendanceConflict(x)
        if(conflict!=null) return conflict
        val existing=attendances.firstOrNull{it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date}
        val safeRow=if(existing!=null) x.copy(id=existing.id) else x
        attendances=attendances.filterNot{it.labourId==safeRow.labourId && it.fieldId==safeRow.fieldId && it.date==safeRow.date}+safeRow
        write("attendance",attendances,::obj)
        return null
    }
    fun deleteAttendance(id:String):Boolean{
        val row=attendances.firstOrNull{it.id==id}?:return false
        if(isMonthLocked(row.date)) return false
        val closedThrough=latestClosure(row.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && row.date<=closedThrough) return false
        attendances=attendances.filterNot{it.id==id};write("attendance",attendances,::obj);return true
    }
    fun rateFor(labourId:String,date:String):Double{
        val l=labours.firstOrNull{it.id==labourId}?:return 0.0
        val applicable=rates.filter{it.labourId==labourId && validDate(it.effectiveDate) && it.effectiveDate<=date}
        return applicable.maxByOrNull{it.effectiveDate}?.rate ?: l.rate
    }
    fun rateHistoryFor(labourId:String)=rates.filter{it.labourId==labourId}.sortedByDescending{it.effectiveDate}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        scheduleSalaryAutoAttendance(this)
        scheduleDailyAutoBackup(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5106) }
        setContent {
            var themeMode by rememberSaveable { mutableStateOf(savedThemeMode(this@MainActivity)) }
            val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
            val useDark = when(themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
            // Keep legacy screens that use shared Bg/CardBg constants in sync with the selected theme.
            Bg = if(useDark) DarkBg else Color(0xFFF6FAF8)
            CardBg = if(useDark) DarkCardBg else Color.White
            Green = if(useDark) DarkGreen else Color(0xFF0B6B4A)
            GreenDark = if(useDark) Color(0xFFB6F1CF) else Color(0xFF064C36)
            MaterialTheme(
                colorScheme = if(useDark) darkColorScheme(
                    primary = DarkGreen,
                    onPrimary = Color(0xFF003824),
                    primaryContainer = Color(0xFF15583D),
                    onPrimaryContainer = Color(0xFFB6F1CF),
                    secondary = Color(0xFFACD4BD),
                    onSecondary = Color(0xFF193829),
                    background = DarkBg,
                    surface = DarkCardBg,
                    onSurface = Color(0xFFE0E8E2),
                    error = Color(0xFFFFB4AB),
                    onError = Color(0xFF690005)
                ) else lightColorScheme(
                    primary = Green,
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFE4F2E9),
                    onPrimaryContainer = GreenDark,
                    secondary = Color(0xFF47745E),
                    onSecondary = Color.White,
                    background = Bg,
                    surface = CardBg,
                    onSurface = Color(0xFF1B2821),
                    error = Color(0xFFB3261E),
                    onError = Color.White
                )
            ) {
                CompositionLocalProvider(LocalThemeMode provides themeMode) {
                    MajdoorApp(onThemeModeChange = { mode ->
                        if(mode in setOf("light","dark","system")) {
                            themeMode = mode
                            getSharedPreferences(APP_PREFS, Context.MODE_PRIVATE).edit().putString(THEME_KEY, mode).apply()
                        }
                    })
                }
            }
        }
    }
    override fun onResume() {
        super.onResume()
        scheduleSalaryAutoAttendance(this)
    }
}

private val LocalThemeMode = staticCompositionLocalOf { "system" }

/** App-wide standardized form control: consistent shape, colors, spacing and accessibility defaults. */
@Composable
private fun AppTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    label: (@Composable () -> Unit)? = null,
    placeholder: (@Composable () -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    minLines: Int = 1,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    shape: Shape = RoundedCornerShape(14.dp),
    colors: TextFieldColors? = null
) {
    MaterialOutlinedTextField(
        value=value, onValueChange=onValueChange, modifier=modifier, enabled=enabled,
        label=label, placeholder=placeholder, leadingIcon=leadingIcon, trailingIcon=trailingIcon,
        singleLine=singleLine, maxLines=maxLines, minLines=minLines,
        keyboardOptions=keyboardOptions, visualTransformation=visualTransformation,
        shape=shape, colors=colors ?: OutlinedTextFieldDefaults.colors()
    )
}

/** Shared loading/empty/error/success panel used by launch, lists and feedback messages. */
@Composable
private fun SharedStatePanel(
    title: String,
    message: String,
    kind: String = "empty",
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val tint = when(kind) { "error" -> MaterialTheme.colorScheme.error; "success" -> Color(0xFF0B6B4A); "loading" -> MaterialTheme.colorScheme.primary; else -> MaterialTheme.colorScheme.onSurfaceVariant }
    Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=CardBg)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(8.dp)) {
            when(kind) {
                "loading" -> CircularProgressIndicator(color=tint, modifier=Modifier.size(28.dp))
                "error" -> Icon(Icons.Default.ErrorOutline, contentDescription=null, tint=tint, modifier=Modifier.size(28.dp))
                "success" -> Icon(Icons.Default.CheckCircle, contentDescription=null, tint=tint, modifier=Modifier.size(28.dp))
                else -> Icon(Icons.Default.Info, contentDescription=null, tint=tint, modifier=Modifier.size(28.dp))
            }
            Text(title, fontWeight=FontWeight.Bold, color=tint)
            Text(message, color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp)
            if(actionLabel!=null && onAction!=null) OutlinedButton(onClick=onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun PinManagementDialog(onClose: () -> Unit, requireCurrentPin: Boolean = true) {
    val context=LocalContext.current
    val configured=hasCustomPin(context)
    var currentPin by rememberSaveable { mutableStateOf("") }
    var newPin by rememberSaveable { mutableStateOf("") }
    var confirmPin by rememberSaveable { mutableStateOf("") }
    var removePin by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf("") }
    SimpleDialog(if(configured) "ऐप PIN बदलें" else "ऐप PIN सेट करें", onClose) {
        Text("4 से 8 अंकों का PIN चुनें। PIN का मूल अंक सेव नहीं होता; केवल salted hash इसी फोन में रखा जाता है।", fontSize=12.sp, color=Color.Gray)
        if(configured && requireCurrentPin) AppTextField(value=currentPin,onValueChange={currentPin=it.filter(Char::isDigit).take(8);error=""},label={Text("मौजूदा PIN")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),visualTransformation=PasswordVisualTransformation())
        if(!removePin) {
            AppTextField(value=newPin,onValueChange={newPin=it.filter(Char::isDigit).take(8);error=""},label={Text("नया PIN (4–8 अंक)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),visualTransformation=PasswordVisualTransformation())
            AppTextField(value=confirmPin,onValueChange={confirmPin=it.filter(Char::isDigit).take(8);error=""},label={Text("नया PIN दोबारा लिखें")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),visualTransformation=PasswordVisualTransformation())
        }
        if(configured) Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=removePin,onCheckedChange={removePin=it;error=""}); Text("कस्टम PIN हटाएँ") }
        if(error.isNotBlank()) SharedStatePanel("PIN सेट नहीं हुआ",error,"error")
        Button(modifier=Modifier.fillMaxWidth(),onClick={
            when {
                configured && requireCurrentPin && !verifyCustomPin(context,currentPin) -> error="मौजूदा PIN गलत है या कुछ समय के लिए लॉक है।"
                removePin && !configured -> error="कोई कस्टम PIN सेट नहीं है।"
                removePin -> if(saveCustomPin(context,null)) onClose() else error="PIN हटाया नहीं जा सका।"
                newPin.length !in 4..8 -> error="PIN 4 से 8 अंकों का होना चाहिए।"
                newPin != confirmPin -> error="दोनों PIN एक जैसे नहीं हैं।"
                !saveCustomPin(context,newPin) -> error="PIN सुरक्षित रूप से सेव नहीं हो सका।"
                else -> onClose()
            }
        }) { Text(if(removePin) "PIN हटाएँ" else "PIN सेव करें") }
    }
}

@Composable
private fun CustomPinUnlockGate(onUnlocked: () -> Unit, onUseDeviceCredential: () -> Unit, onCancel: () -> Unit) {
    val context=LocalContext.current
    var pin by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    Surface(Modifier.fillMaxSize(), color=Bg) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment=Alignment.Center) {
            Card(Modifier.fillMaxWidth().widthIn(max=420.dp), shape=RoundedCornerShape(24.dp), colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("🔐",fontSize=42.sp)
                    Text("Majdoor Hisaab PRO",fontWeight=FontWeight.ExtraBold,fontSize=22.sp)
                    Text("अपना ऐप PIN डालें",color=MaterialTheme.colorScheme.onSurfaceVariant)
                    AppTextField(value=pin,onValueChange={pin=it.filter(Char::isDigit).take(8);error=""},modifier=Modifier.fillMaxWidth(),label={Text("4–8 अंकों का PIN")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),visualTransformation=PasswordVisualTransformation())
                    if(error.isNotBlank()) SharedStatePanel("लॉक नहीं खुला",error,"error")
                    Button(onClick={if(pin.length !in 4..8) error="PIN 4 से 8 अंक का होना चाहिए" else if(verifyCustomPin(context,pin)) onUnlocked() else error="PIN गलत है या 30 सेकंड का सुरक्षा विराम लागू है।"},modifier=Modifier.fillMaxWidth()) { Text("ऐप खोलें") }
                    TextButton(onClick=onUseDeviceCredential) { Text("फोन के PIN / बायोमेट्रिक से खोलें") }
                    TextButton(onClick=onCancel) { Text("ऐप बंद करें") }
                }
            }
        }
    }
}


private fun driveErrorMessage(action:String,error:Throwable):String{
    val causes=generateSequence(error){it.cause}.toList()
    val root=causes.lastOrNull() ?: error
    val detail=(causes.mapNotNull{it.message}.joinToString(" | ").ifBlank{"Unknown error"}).take(500)
    val developerError=causes.any{(it as? ApiException)?.statusCode==10} || detail.contains("DEVELOPER_ERROR",ignoreCase=true) || detail.contains("status=10",ignoreCase=true)
    return when {
        developerError ->
            "$action असफल: Google OAuth configuration गलत है (status 10)। Package com.majdoor.hisaabpro और इसी Release APK की signing SHA-1 वाला Android OAuth client बनाएं/जाँचें, Google Drive API enable करें, फिर उसी stable keystore से APK rebuild करें।"
        detail.contains("PERMISSION_DENIED",ignoreCase=true) || detail.contains("insufficient",ignoreCase=true) ->
            "$action असफल: Google Drive permission नहीं मिली। Account दोबारा चुनें और Drive file access अनुमति दें। विवरण: $detail"
        else -> "$action असफल: $detail"
    }
}

@Composable private fun MajdoorApp(onThemeModeChange:(String)->Unit){
    val context=LocalContext.current
    val activity=context as? Activity
    var startupReady by remember { mutableStateOf(false) }
    var storageError by remember { mutableStateOf("") }
    var storeState by remember { mutableStateOf<Store?>(null) }
    LaunchedEffect(Unit) {
        delay(350)
        val result = runCatching { Store(context) }
        storeState = result.getOrNull()
        storageError = result.exceptionOrNull()?.message.orEmpty()
        startupReady = true
    }
    if(!startupReady) {
        Box(Modifier.fillMaxSize().background(Bg).padding(24.dp), contentAlignment=Alignment.Center) {
            Column(Modifier.widthIn(max=420.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("🌾", fontSize=54.sp)
                Text("Majdoor Hisaab PRO", fontSize=24.sp, fontWeight=FontWeight.ExtraBold, color=GreenDark)
                SharedStatePanel("ऐप शुरू हो रहा है","आपका स्थानीय हिसाब सुरक्षित रूप से तैयार हो रहा है…","loading")
            }
        }
        return
    }
    if(storeState == null || storageError.isNotBlank()) {
        Box(Modifier.fillMaxSize().background(Bg).padding(24.dp), contentAlignment=Alignment.Center) {
            Card(colors=CardDefaults.cardColors(containerColor=CardBg), shape=RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(24.dp), verticalArrangement=Arrangement.spacedBy(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    SharedStatePanel("ऐप डेटा शुरू नहीं हो सका",storageError.ifBlank { "स्थानीय डेटा उपलब्ध नहीं है।" },"error")
                    Text("यह ऐप ऑफलाइन काम करता है। इंटरनेट कनेक्शन की जरूरत नहीं है। डेटा साफ़ न करें; दोबारा खोलें या बैकअप सहायता लें।", color=Color.Gray)
                    Button(onClick={ (context as? Activity)?.recreate() }) { Text("दोबारा कोशिश करें") }
                }
            }
        }
        return
    }
    val store: Store = storeState ?: return
    val drive=remember{GoogleDriveDirect(context)}
    val scope=rememberCoroutineScope()
    var driveAccount by remember{mutableStateOf(drive.lastAccount())}
    var driveBusy by remember{mutableStateOf(false)}
    var pendingDriveAction by rememberSaveable{mutableStateOf("")}
    var consentRetryInProgress by rememberSaveable{mutableStateOf(false)}
    val stack = rememberSaveable(
        saver = androidx.compose.runtime.saveable.listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<Screen>, String>(
            save = { screens -> screens.map(::encodeScreenState) },
            restore = { saved -> androidx.compose.runtime.mutableStateListOf<Screen>().apply {
                addAll(saved.mapNotNull(::decodeScreenState).ifEmpty { listOf(Screen.Home) })
            } }
        )
    ) { mutableStateListOf<Screen>(Screen.Home) }
    val screen=stack.last()
    var appUnlocked by remember{mutableStateOf(false)} // Re-authenticate after Activity recreation; never restore an unlocked security gate from saved state.
    var useDeviceCredentialFallback by rememberSaveable { mutableStateOf(false) }
    var backgroundAt by remember { mutableLongStateOf(0L) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, appUnlocked) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) backgroundAt = System.currentTimeMillis()
            if (event == Lifecycle.Event.ON_START && appUnlocked && settingBool(context, "app_lock_enabled", true)) {
                val timeout = settingString(context, "auto_lock_timeout", "immediate").let {
                    when (it) { "1m" -> 60_000L; "5m" -> 300_000L; "15m" -> 900_000L; "30m" -> 1_800_000L; "never" -> Long.MAX_VALUE; else -> 0L }
                }
                if (backgroundAt > 0L && System.currentTimeMillis() - backgroundAt >= timeout) appUnlocked = false
                backgroundAt = 0L
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    var backupStatus by rememberSaveable{mutableStateOf("")}
    var showBackupReminder by rememberSaveable{mutableStateOf(false)}
    var restorePending by rememberSaveable{mutableStateOf(false)}
    var restoreFilePath by rememberSaveable{mutableStateOf("")}
    var restoreDeleteAfterUse by rememberSaveable{mutableStateOf(true)}
    val restoreFile = restoreFilePath.takeIf{it.isNotBlank()}?.let(::File)
    val driveSignInLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        // Google Sign-In may return useful Status data even when resultCode is not RESULT_OK.
        // Always inspect the returned intent so OAuth/configuration failures are not hidden as cancellation.
        val returnedIntent=result.data
        if(returnedIntent==null){
            driveAccount=null
            backupStatus="Google Sign-In पूरा नहीं हुआ (resultCode=${result.resultCode}, data=null). दोबारा कोशिश करें; अगर बार-बार हो तो Release SHA-1/OAuth configuration जाँचें।"
        } else {
            runCatching{GoogleSignIn.getSignedInAccountFromIntent(returnedIntent).getResult(ApiException::class.java)}
                .onSuccess{account->
                    driveAccount=account
                    drive.saveAccount(account)
                    backupStatus="Google Account जुड़ गया: ${account.email ?: ""}"
                }
                .onFailure{error->
                    driveAccount=null
                    val code=(error as? ApiException)?.statusCode
                    val codeText=code?.let { "$it (${CommonStatusCodes.getStatusCodeString(it)})" } ?: "unknown"
                    val resultText=if(result.resultCode==Activity.RESULT_OK) "OK" else "${result.resultCode}"
                    backupStatus=if(code==10) "Google Sign-In failed: status=10 (DEVELOPER_ERROR). यह आम तौर पर Google Cloud OAuth configuration mismatch है। Android OAuth client में package com.majdoor.hisaabpro और इसी Release keystore का SHA-1 दर्ज करें; Google Drive API enable करें। फिर नया APK बनाकर दोबारा कोशिश करें।" else "Google Sign-In failed: status=$codeText, resultCode=$resultText. ${error.message ?: "Google account/Drive permission पूरी नहीं हुई"}"
                }
        }
    }
    var startDriveAction: (String, Boolean) -> Unit = { _, _ -> }
    val driveConsentLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        val action=pendingDriveAction
        pendingDriveAction="" // consume before any retry; duplicate results cannot repeat the operation
        if(action.isBlank()) return@rememberLauncherForActivityResult
        if(result.resultCode==Activity.RESULT_OK){
            consentRetryInProgress=true
            driveBusy=false
            startDriveAction(action, true)
        }else{
            consentRetryInProgress=false
            driveBusy=false
            backupStatus=if(action=="backup") "Google Drive Backup रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Backup दबाएँ।" else "Google Drive Restore रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Restore दबाएँ।"
        }
    }
    val createBackupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->
        if(uri==null){
            backupStatus="Backup save नहीं किया गया। Google Drive चुनकर फिर Backup बनाएं।"
        } else {
            val temp=File(context.cacheDir,"mhpro_backup_${System.currentTimeMillis()}.zip")
            runCatching{
                store.createBackupZip(temp)
                store.validateBackupZip(temp)
                val expectedBytes=temp.length()
                val copied=context.contentResolver.openOutputStream(uri)?.use{out->
                    temp.inputStream().use{input->
                        val count=input.copyTo(out)
                        out.flush()
                        count
                    }
                } ?: throw IllegalStateException("Backup location open नहीं हुई।")
                if(copied!=expectedBytes) throw IllegalStateException("Backup पूरा save नहीं हुआ (लिखे गए bytes का मिलान नहीं हुआ)।")
                val verify=File(context.cacheDir,"mhpro_backup_verify_${System.currentTimeMillis()}.mhbackup")
                try {
                    context.contentResolver.openInputStream(uri)?.use{input->verify.outputStream().use{input.copyTo(it)}}
                        ?: throw IllegalStateException("सेव हुए backup को दोबारा पढ़कर जाँचा नहीं जा सका।")
                    store.validateBackupZip(verify)
                } finally { verify.delete() }
                recordBackupHistory(context,uri.lastPathSegment ?: "Majdoor_Hisaab_PRO_Backup.mhbackup",expectedBytes,"Local/SAF")
                backupStatus="Backup बनाकर सेव और सत्यापित कर लिया गया।"
            }.onFailure{
                backupStatus="Backup सेव/सत्यापित नहीं हो सका। मौजूदा app data सुरक्षित है। कारण: ${it.message ?: "Unknown error"}"
            }
            temp.delete()
        }
    }
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            var temp:File?=null
            runCatching{
                temp=File(context.cacheDir,"mhpro_restore_${System.currentTimeMillis()}.mhbackup")
                context.contentResolver.openInputStream(uri)?.use{input->temp!!.outputStream().use{input.copyTo(it)}}
                    ?: throw IllegalStateException("Backup file open नहीं हुई।")
                if(temp!!.length()<=0L) throw IllegalStateException("चुनी गई backup file खाली है।")
                store.validateBackupZip(temp!!)
                restoreFilePath=temp.absolutePath
                restoreDeleteAfterUse=true
                restorePending=true
                backupStatus="Backup file सत्यापित है। Restore से पहले पुष्टि और screen-lock जाँच होगी।"
            }.onFailure{
                temp?.delete()
                backupStatus="Restore शुरू नहीं किया गया। चुनी गई file गलत/अधूरी है; मौजूदा data में कोई बदलाव नहीं हुआ। कारण: ${it.message ?: "Unknown error"}"
            }
        } else {
            backupStatus="Restore रद्द किया गया। मौजूदा data में कोई बदलाव नहीं हुआ।"
        }
    }
    startDriveAction = start@{ action, isConsentRetry ->
        // Every tap must show a visible state; never silently ignore a duplicate tap.
        if(driveBusy || pendingDriveAction.isNotBlank()) {
            backupStatus = if(pendingDriveAction.isNotBlank()) "Google Drive की अनुमति स्क्रीन खुली है। अनुमति पूरी करें या वापस आकर फिर कोशिश करें।" else "पिछला Google Drive काम अभी चल रहा है। कृपया पूरा होने तक प्रतीक्षा करें।"
            return@start
        }
        if(!isConsentRetry) consentRetryInProgress=false
        val account=driveAccount
        if(account==null){
            backupStatus="Google Account चयन खोला जा रहा है…"
            runCatching { driveSignInLauncher.launch(drive.signInIntent()) }.onFailure { error -> backupStatus=driveErrorMessage("Google Account",error) }
            return@start
        }
        driveBusy=true
        backupStatus=if(action=="backup") "Backup शुरू हुआ है: पहले फोन में डेटा पैक हो रहा है, फिर Google Drive पर upload होगा…" else "Google Drive में नवीनतम backup खोजा जा रहा है…"
        scope.launch{
            val result=runCatching{withContext(Dispatchers.IO){
                if(action=="backup"){
                    val temp=File(context.cacheDir,"mhpro_drive_upload_${System.currentTimeMillis()}.mhbackup")
                    try{
                        withContext(Dispatchers.Main){ backupStatus="Backup फ़ाइल बनाई जा रही है…" }
                        store.createBackupZip(temp)
                        store.validateBackupZip(temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Backup खाली बना है; Drive पर upload नहीं किया गया।")
                        val sizeKb=(temp.length()/1024.0).toInt().coerceAtLeast(1)
                        withContext(Dispatchers.Main){ backupStatus="Backup तैयार (${sizeKb} KB)। Google Drive पर upload हो रहा है…" }
                        val uploadedName=drive.upload(account,temp)
                        recordBackupHistory(context,uploadedName,temp.length(),"Google Drive")
                        uploadedName
                    }finally{temp.delete()}
                }else{
                    val temp=File(context.cacheDir,"mhpro_drive_restore_${System.currentTimeMillis()}.mhbackup")
                    try{
                        val name=drive.downloadLatest(account,temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Drive से खाली backup मिला।")
                        store.validateBackupZip(temp)
                        name to temp
                    }catch(e:Throwable){temp.delete();throw e}
                }
            }}
            result.onSuccess{value->
                if(action=="backup") backupStatus="✓ Google Drive Backup सफल! फ़ाइल: $value • ${SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(Date())}. Backup history में दर्ज हो गया है।"
                else {
                    @Suppress("UNCHECKED_CAST")
                    val pair=value as Pair<String,File>
                    restoreFilePath=pair.second.absolutePath
                    restoreDeleteAfterUse=true
                    restorePending=true
                    backupStatus="Drive backup '${pair.first}' सत्यापित है। Restore दबाकर पुष्टि करें।"
                }
                consentRetryInProgress=false
                driveBusy=false
            }.onFailure{error->
                if(error is NeedRemoteConsent && !consentRetryInProgress){
                    pendingDriveAction=action
                    // Launch the exact recoverable consent intent once, on the foreground UI.
                    runCatching{driveConsentLauncher.launch(error.consentIntent)}.onFailure{launchError->
                        pendingDriveAction=""
                        backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",launchError)
                        driveBusy=false
                    }
                }else{
                    consentRetryInProgress=false
                    pendingDriveAction=""
                    backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",error)
                    driveBusy=false
                }
            }
        }
    }
    if(!appUnlocked && settingBool(context, "app_lock_enabled", true)){
        if(hasCustomPin(context) && !useDeviceCredentialFallback) {
            CustomPinUnlockGate(onUnlocked={appUnlocked=true},onUseDeviceCredential={useDeviceCredentialFallback=true},onCancel={activity?.finish()})
        } else {
            DeviceCredentialGate("Majdoor Hisaab PRO खोलें","App का data देखने के लिए Android screen lock से पुष्टि करें।",{appUnlocked=true;useDeviceCredentialFallback=false},{useDeviceCredentialFallback=false;activity?.finish()})
            SharedStatePanel("ऐप लॉक","App खोलने के लिए PIN या फोन screen lock से पुष्टि करें।","info")
        }
        return
    }
    fun go(s:Screen){
        if(stack.lastOrNull()==s) return
        stack.add(s)
    }
    fun goRoot(s:Screen){
        stack.clear(); stack.add(s)
    }
    LaunchedEffect(appUnlocked, screen) {
        if (appUnlocked && screen == Screen.Home && settingBool(context, "backup_reminder_enabled", true)) {
            val history = runCatching { JSONArray(context.getSharedPreferences("mhpro_backup_history", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]") }.getOrNull()
            val lastBackupAt = history?.optJSONObject(0)?.optLong("createdAt", 0L) ?: 0L
            val prefs = context.getSharedPreferences("mhpro_backup_history", Context.MODE_PRIVATE)
            val dismissedAt = prefs.getLong("reminder_dismissed_at", 0L)
            val now = System.currentTimeMillis()
            val overdue = lastBackupAt == 0L || now - lastBackupAt >= 7L * 24L * 60L * 60L * 1000L
            val recentlyDismissed = dismissedAt > lastBackupAt && now - dismissedAt < 24L * 60L * 60L * 1000L
            if (overdue && !recentlyDismissed) showBackupReminder = true
        }
    }
    if (showBackupReminder) AlertDialog(
        onDismissRequest = { showBackupReminder = false; context.getSharedPreferences("mhpro_backup_history", Context.MODE_PRIVATE).edit().putLong("reminder_dismissed_at", System.currentTimeMillis()).apply() },
        title = { Text("बैकअप बनाना न भूलें") },
        text = { Text("पिछले 7 दिनों में सत्यापित बैकअप नहीं मिला। डेटा सुरक्षित रखने के लिए अभी बैकअप बनाना उचित होगा।") },
        confirmButton = { TextButton(onClick = { showBackupReminder = false; context.getSharedPreferences("mhpro_backup_history", Context.MODE_PRIVATE).edit().putLong("reminder_dismissed_at", System.currentTimeMillis()).apply(); goRoot(Screen.Backup) }) { Text("Backup खोलें") } },
        dismissButton = { TextButton(onClick = { showBackupReminder = false; context.getSharedPreferences("mhpro_backup_history", Context.MODE_PRIVATE).edit().putLong("reminder_dismissed_at", System.currentTimeMillis()).apply() }) { Text("बाद में") } }
    )
    fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }
    val isRoot=screen is Screen.Home||screen is Screen.Profile||screen is Screen.LabourList||screen is Screen.SalaryDashboard||screen is Screen.SalaryEmployees||screen is Screen.FieldList||screen is Screen.ExpenseList&&screen.fieldId==null&&screen.cropId==null||screen is Screen.SaleList&&screen.fieldId==null&&screen.cropId==null||(screen is Screen.CropList&&screen.fieldId==null)
    restoreFile?.let{file->
        DeviceCredentialGate("Backup Restore करें","Backup data से app का मौजूदा data replace होगा। Android screen lock से पुष्टि करें।",{
            runCatching{store.restoreBackupZip(file);backupStatus="Backup सफलतापूर्वक restore और जाँच लिया गया।"}.onFailure{backupStatus="Restore विफल हुआ। पुराने data को सुरक्षित रखने/वापस रखने की कोशिश की गई है। App data साफ़ न करें। कारण: ${it.message ?: "Unknown error"}"}
            if(restoreDeleteAfterUse) file.delete();restoreFilePath="";restorePending=false;restoreDeleteAfterUse=true
        },{if(restoreDeleteAfterUse) file.delete();restoreFilePath="";restorePending=false;restoreDeleteAfterUse=true})
    }
    BackHandler(enabled=true){
        when {
            stack.size > 1 -> back()
            screen !is Screen.Home -> goRoot(Screen.Home)
            else -> (context as? Activity)?.finish()
        }
    }
    Surface(Modifier.fillMaxSize(),color=Bg){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.TopCenter){Column(Modifier.widthIn(max=900.dp).fillMaxSize()){
        TopBar(title=screenHeader(screen).first,subtitle=screenHeader(screen).second,canBack=!isRoot,onBack={if(isRoot) goRoot(Screen.Home) else back()},onProfile={goRoot(Screen.Profile)})
        Box(Modifier.weight(1f).fillMaxWidth().imePadding()){when(val s=screen){
            Screen.Home->Dashboard(store){key->goRoot(when(key){"attendance"->Screen.AttendanceFields;"attendance_fields"->Screen.AttendanceFields;"daily_labour"->Screen.DailyLabourHome;"salary_employees"->Screen.SalaryDashboard;"attendance_history"->Screen.AttendanceHistory;"today_attendance"->Screen.TodayAttendance;"backup"->Screen.Backup;"workers"->Screen.LabourList;"labour"->Screen.LabourList;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();"cane"->Screen.CaneParchi;"cane_peeling"->Screen.CanePeeling;"work_entry"->Screen.AttendanceFields;"work_list"->Screen.WorkList;"rate_history"->Screen.WageRateHistory;"profitability"->Screen.Profitability;"reports"->Screen.ReportCentre;"more"->Screen.Profile;else->Screen.CropList()})}
            Screen.SalaryDashboard->SalaryDashboardScreen(onEmployees={go(Screen.SalaryEmployees)},onReports={go(Screen.SalaryReports)})
            Screen.SalaryEmployees->SalaryEmployeeScreen(onEmployeeDetail={go(Screen.SalaryEmployeeDetail(it))})
            Screen.SalaryReports->SalaryReportsScreen(onBack={back()})
            is Screen.SalaryEmployeeDetail->SalaryEmployeeDetailScreen(s.id,onBack={back()})
            Screen.DailyLabourHome->DailyLabourHomeScreen(onAttendance={go(Screen.AttendanceFields)},onAccounts={go(Screen.DailyLabourAccounts)},onWorkers={go(Screen.LabourList)})
            Screen.DailyLabourAccounts->DailyLabourAccountsScreen(store,onWorkers={go(Screen.LabourList)},onFieldReport={go(Screen.FieldList)},onAttendanceHistory={go(Screen.AttendanceHistory)},onToday={go(Screen.TodayAttendance)},onAllReport={go(Screen.AllLabourReport)},onPayments={go(Screen.LabourList)},onBack={back()})
            Screen.AllLabourReport->AllLabourReportScreen(store,onBack={back()},onWorker={go(Screen.LabourDetail(it))},onAttendance={go(Screen.AttendanceFields)})
            Screen.ReportCentre->ReportCentreScreen(onBack={back()},onReportTypes={go(Screen.ReportType)},onLabourReport={go(Screen.AllLabourReport)},onAttendance={go(Screen.AttendanceHistory)},onWork={go(Screen.WorkList)},onProfitability={go(Screen.Profitability)})
            Screen.ReportType->ReportTypeSelectionScreen(onBack={back()},onLabourReport={go(Screen.AllLabourReport)},onAttendance={go(Screen.AttendanceHistory)},onWork={go(Screen.WorkList)},onProfitability={go(Screen.Profitability)},onExpenses={go(Screen.ExpenseList())},onSales={go(Screen.SaleList())})
            Screen.AttendanceFields->AttendanceFieldPickerScreen(store,onSelect={go(Screen.Attendance(it))},onBack={back()})
            Screen.LabourList->LabourScreen(store,{go(Screen.LabourDetail(it))},{go(Screen.AttendanceFields)})
            Screen.FieldList->FieldScreen(store){go(Screen.FieldDetail(it))}
            is Screen.ExpenseList->ExpenseScreen(store,s.fieldId,s.cropId){goRoot(Screen.ExpenseList(s.fieldId,s.cropId))}
            is Screen.SaleList->SaleScreen(store,s.fieldId,s.cropId)
            is Screen.CropList->CropScreen(store,s.fieldId){go(Screen.CropDetail(it))}
            is Screen.LabourDetail->LabourDetail(store,s.id,{back()})
            is Screen.FieldDetail->FieldDetail(store,s.id,{back()},{go(Screen.CropDetail(it))},{go(Screen.Attendance(s.id))},{go(Screen.ExpenseList(s.id,null))},{go(Screen.SaleList(s.id,null))},{go(Screen.CropList(s.id))})
            is Screen.CropDetail->CropDetail(store,s.id,{back()},{go(Screen.ExpenseList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))},{go(Screen.SaleList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))})
            is Screen.Attendance->AttendanceScreen(store,s.fieldId,{back()})
            Screen.AttendanceHistory->AttendanceHistoryScreen(store,{back()})
            Screen.TodayAttendance->TodayAttendanceScreen(store,{back()})
            Screen.Backup->BackupScreen(
                store, backupStatus, { msg -> backupStatus=msg },
                { createBackupLauncher.launch("Majdoor_Hisaab_PRO_Backup_${today()}.mhbackup") },
                { restoreLauncher.launch(arrayOf("application/zip","application/octet-stream")) },
                drive.accountLabel(), driveBusy,
                {
                    // Use Google's own account chooser. AccountManager's legacy chooser returned
                    // a selected email on some devices but did not reliably complete OAuth sign-in.
                    backupStatus="Google Account चुनने की स्क्रीन खोली जा रही है…"
                    runCatching {
                        drive.prepareFreshSignIn { driveSignInLauncher.launch(drive.signInIntent()) }
                    }.onFailure { error -> backupStatus="Google Account चयन नहीं खुला: ${error.message ?: "कृपया दोबारा कोशिश करें"}" }
                },
                { startDriveAction("backup", false) },
                { startDriveAction("restore", false) },
                { file ->
                    runCatching {
                        store.validateBackupZip(file)
                        restoreFilePath=file.absolutePath
                        restoreDeleteAfterUse=false
                        restorePending=true
                        backupStatus="Automatic Backup चुना गया है। Restore की पुष्टि करें।"
                    }.onFailure { backupStatus="Automatic Backup जाँच में विफल: ${it.message ?: "अज्ञात त्रुटि"}" }
                }
            )
            Screen.Profile->ProfileScreen(onBackup={goRoot(Screen.Backup)},themeMode=LocalThemeMode.current,onThemeModeChange=onThemeModeChange,onNavigate={key->goRoot(when(key){"labour"->Screen.LabourList;"workers"->Screen.LabourList;"field"->Screen.FieldList;"crop"->Screen.CropList();"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();"cane"->Screen.CaneParchi;"cane_peeling"->Screen.CanePeeling;"attendance"->Screen.AttendanceFields;"reports"->Screen.ReportCentre;else->Screen.Backup})})
            Screen.CaneParchi->CaneParchiDashboardScreen(store)
            Screen.CanePeeling->CanePeelingScreen(store,{back()})
            Screen.WorkList->WorkListScreen(store,onBack={back()},onAddWork={go(Screen.AttendanceFields)},onWorker={go(Screen.LabourDetail(it))})
            Screen.WageRateHistory->WageRateHistoryScreen(store,onBack={back()},onWorker={go(Screen.LabourDetail(it))})
            Screen.Profitability->ProfitabilityScreen(store,onBack={back()},onField={go(Screen.FieldDetail(it))})
        }}
        if(isRoot) BottomBar(screen){key->goRoot(when(key){"home"->Screen.Home;"labour"->Screen.LabourList;"field"->Screen.FieldList;else->Screen.Profile})}
    }}}
}

private fun screenHeader(screen: Screen): Pair<String, String> = when (screen) {
    Screen.Home -> "आज का डैशबोर्ड" to "मजदूरी • खेत • खर्च • बिक्री"
    Screen.LabourList -> "मजदूर" to "सूची, विवरण और हिसाब"
    Screen.SalaryDashboard -> "Salary Dashboard" to "कर्मचारी • सैलरी • हाजिरी • भुगतान"
    Screen.SalaryEmployees -> "कर्मचारी सूची" to "हाजिरी • छुट्टी • भुगतान • पूरा हिसाब"
    Screen.SalaryReports -> "Salary Reports" to "महीनेवार वेतन • भुगतान • बकाया रिपोर्ट"
    is Screen.SalaryEmployeeDetail -> "कर्मचारी की पूरी डिटेल" to "प्रोफाइल • सैलरी • हाजिरी • भुगतान"
    Screen.DailyLabourHome -> "दिहाड़ी मजदूर" to "हाजिरी और मासिक हिसाब"
    Screen.DailyLabourAccounts -> "मासिक खाते" to "महीनेवार मजदूरी और भुगतान"
    Screen.AllLabourReport -> "मजदूर रिपोर्ट" to "हाजिरी और बकाया"
    Screen.ReportCentre -> "रिपोर्ट सेंटर" to "सभी रिपोर्ट एक जगह"
    Screen.ReportType -> "रिपोर्ट का प्रकार" to "PDF/हिसाब चुनें"
    Screen.AttendanceFields -> "हाजिरी" to "पहले खेत चुनें"
    Screen.FieldList -> "खेत" to "खेत और खेती का हिसाब"
    is Screen.ExpenseList -> "खर्च" to "खेती लागत और इतिहास"
    is Screen.SaleList -> "बिक्री" to "उत्पादन और आमदनी"
    is Screen.CropList -> "फसल" to "फसल और सीजन"
    is Screen.LabourDetail -> "मजदूर का विवरण" to "हाजिरी • भुगतान • लेजर"
    is Screen.FieldDetail -> "खेत का विवरण" to "लागत • फसल • बिक्री"
    is Screen.CropDetail -> "फसल का विवरण" to "लागत • बिक्री • लाभ"
    is Screen.Attendance -> "हाजिरी दर्ज करें" to "तारीख और मजदूर चुनें"
    Screen.AttendanceHistory -> "हाजिरी इतिहास" to "सेव किए गए रिकॉर्ड"
    Screen.TodayAttendance -> "आज की हाजिरी" to "आज के वास्तविक रिकॉर्ड"
    Screen.Backup -> "बैकअप और रिस्टोर" to "डेटा सुरक्षित रखें"
    Screen.Profile -> "और विकल्प" to "रिपोर्ट • सेटिंग • सुरक्षा"
    Screen.CaneParchi -> "गन्ना पर्ची" to "सीजन • तौल • भुगतान"
    Screen.CanePeeling -> "गन्ना छिलाई" to "फांदी • मजदूर • भुगतान"
    Screen.WorkList -> "काम की सूची" to "हाजिरी से जुड़े वास्तविक काम और मजदूरी"
    Screen.WageRateHistory -> "दिहाड़ी दर इतिहास" to "मजदूरवार लागू तारीख और दर"
    Screen.Profitability -> "आय और मुनाफा" to "बिक्री घटाकर मजदूरी और खेती खर्च"
}

@Composable private fun TopBar(title:String,subtitle:String?=null,canBack:Boolean=true,onBack:()->Unit,onProfile:(()->Unit)?=null){
    Surface(color=GreenDark, shadowElevation=2.dp) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=10.dp, vertical=9.dp),
            verticalAlignment=Alignment.CenterVertically
        ) {
            IconButton(onClick=onBack, modifier=Modifier.size(42.dp)) {
                Icon(
                    imageVector=if(canBack) Icons.Default.ArrowBack else Icons.Default.Home,
                    contentDescription=if(canBack) "पीछे जाएँ" else "होम",
                    tint=Color.White
                )
            }
            Image(painterResource(R.drawable.majdoor_logo_small), null, Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)), contentScale=ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(2.dp)) {
                Text(title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=15.sp, maxLines=1)
                if(!subtitle.isNullOrBlank()) Text(subtitle, color=Color.White.copy(alpha=.78f), fontSize=10.sp, maxLines=1)
            }
            if(onProfile!=null) {
                IconButton(onClick=onProfile, modifier=Modifier.size(42.dp)) {
                    Icon(Icons.Default.AccountCircle, contentDescription="प्रोफाइल और सेटिंग", tint=Color.White, modifier=Modifier.size(27.dp))
                }
            }
        }
    }
}

@Composable private fun BottomBar(screen:Screen,onTab:(String)->Unit){
    val current = when(screen) {
        Screen.Home -> "home"
        Screen.LabourList, Screen.DailyLabourHome, Screen.DailyLabourAccounts, Screen.AttendanceFields, Screen.AttendanceHistory, Screen.TodayAttendance -> "labour"
        Screen.FieldList, is Screen.FieldDetail, is Screen.CropDetail -> "field"
        Screen.Profile, Screen.Backup -> "more"
        else -> "more"
    }
    Surface(color=Color.White, shadowElevation=10.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal=8.dp, vertical=5.dp),
            horizontalArrangement=Arrangement.SpaceAround,
            verticalAlignment=Alignment.CenterVertically
        ) {
            listOf(
                Triple("home", Icons.Default.Home, "होम"),
                Triple("labour", Icons.Default.Groups, "मजदूर"),
                Triple("field", Icons.Default.Landscape, "खेत"),
                Triple("more", Icons.Default.Menu, "और")
            ).forEach { (key, icon, label) ->
                val selected = current == key
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onTab(key) }.padding(horizontal=4.dp, vertical=5.dp),
                    horizontalAlignment=Alignment.CenterHorizontally,
                    verticalArrangement=Arrangement.spacedBy(2.dp)
                ) {
                    Box(
                        Modifier.clip(RoundedCornerShape(12.dp))
                            .background(if(selected) Color(0xFFE4F2E9) else Color.Transparent)
                            .padding(horizontal=17.dp, vertical=4.dp)
                    ) {
                        Icon(icon, contentDescription=label, modifier=Modifier.size(21.dp), tint=if(selected) Green else Color(0xFF6D7972))
                    }
                    Text(label, fontSize=10.sp, fontWeight=if(selected) FontWeight.Bold else FontWeight.Medium, color=if(selected) GreenDark else Color(0xFF6D7972))
                }
            }
        }
    }
}

@Composable private fun DailyLabourHomeScreen(onAttendance:()->Unit,onAccounts:()->Unit,onWorkers:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFE8F4EC))) {
            Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text("दिहाड़ी मजदूर",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                Text("मजदूरों की हाजिरी, मजदूरी, भुगतान और महीने का हिसाब",fontSize=13.sp,color=Color(0xFF345448))
            }
        }
        Button(onClick=onAttendance,modifier=Modifier.fillMaxWidth().heightIn(min=58.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) {
            Icon(Icons.Default.Fingerprint,contentDescription=null);Spacer(Modifier.width(8.dp));Text("हाजिरी लगाएँ",fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,contentDescription=null)
        }
        OutlinedButton(onClick=onAccounts,modifier=Modifier.fillMaxWidth().heightIn(min=58.dp)) {
            Icon(Icons.Default.ReceiptLong,contentDescription=null);Spacer(Modifier.width(8.dp));Text("हिसाब देखें",fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,contentDescription=null)
        }
        SmallAction("👷 मजदूर जोड़ें / सूची देखें",onWorkers)
    }
}

@Composable private fun DailyLabourAccountsScreen(store:Store,onWorkers:()->Unit,onFieldReport:()->Unit,onAttendanceHistory:()->Unit,onToday:()->Unit,onAllReport:()->Unit,onPayments:()->Unit,onBack:()->Unit){
    var selectedMonth by rememberSaveable { mutableStateOf("") }
    var lockConfirm by rememberSaveable { mutableStateOf(false) }
    var monthWorkerQuery by rememberSaveable { mutableStateOf("") }
    val monthKeys=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}).filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    val months=(monthKeys+store.lockedLabourMonths).distinct().sortedDescending()
    if(selectedMonth.isNotBlank()){
        val month=selectedMonth
        val monthAttendance=store.attendances.filter{it.date.startsWith(month)}
        val monthPayments=store.payments.filter{it.date.startsWith(month)}
        val rows=store.labours.mapNotNull{l->
            val a=monthAttendance.filter{it.labourId==l.id}
            val p=monthPayments.filter{it.labourId==l.id}
            if(a.isEmpty()&&p.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},p.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        val visibleRows = rows.filter { r -> monthWorkerQuery.isBlank() || r.labour.name.contains(monthWorkerQuery.trim(), ignoreCase=true) || r.labour.mobile.contains(monthWorkerQuery.trim(), ignoreCase=true) || r.labour.address.contains(monthWorkerQuery.trim(), ignoreCase=true) }
        val monthFullDays = monthAttendance.count { it.fraction == 1.0 }
        val monthHalfDays = monthAttendance.count { it.fraction == 0.5 }
        val monthAbsents = monthAttendance.count { it.fraction == 0.0 }
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=GreenDark); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",rows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान",rows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",rows.sumOf{it.wage-it.paid})} }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.weight(1f)){RedesignMetric("पूरे दिन",monthFullDays.toString(),Modifier.fillMaxWidth())}
                        Box(Modifier.weight(1f)){RedesignMetric("आधे दिन",monthHalfDays.toString(),Modifier.fillMaxWidth())}
                        Box(Modifier.weight(1f)){RedesignMetric("अनुपस्थित",monthAbsents.toString(),Modifier.fillMaxWidth())}
                    }
                    if(month !in store.lockedLabourMonths) Button(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                item {
                    AppTextField(value=monthWorkerQuery,onValueChange={monthWorkerQuery=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                        placeholder={Text("मजदूर का नाम, मोबाइल या पता खोजें")},leadingIcon={Icon(Icons.Default.Search,contentDescription="खोजें")},
                        trailingIcon={if(monthWorkerQuery.isNotBlank()) IconButton(onClick={monthWorkerQuery=""}){Icon(Icons.Default.Close,contentDescription="खोज साफ करें")} },
                        shape=RoundedCornerShape(14.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White))
                    Text("मजदूर खाते (${visibleRows.size}/${rows.size})",fontWeight=FontWeight.Bold,color=GreenDark)
                }
                items(visibleRows,key={it.labour.id}) { r->
                    val days=monthAttendance.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                            Text(r.labour.name,fontWeight=FontWeight.Bold,color=GreenDark,fontSize=16.sp)
                            Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                            Text("इस महीने भुगतान ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=GreenDark)
                        }
                    } }
                }
                if(rows.isEmpty()) item { EmptyCard("इस महीने कोई हिसाब दर्ज नहीं है।") }
                else if(visibleRows.isEmpty()) item { EmptyCard("इस खोज से कोई मजदूर नहीं मिला।") }
            }
        }
        if(lockConfirm) AlertDialog(onDismissRequest={lockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "इस महीने की हाजिरी में बदलाव फिर से किया जा सकेगा। पुरानी जानकारी सुरक्षित रहेगी।" else "इस महीने की हाजिरी और हिसाब सुरक्षित हो जाएगा। महीना खोलकर जानकारी देख सकते हैं; बाद के महीनों का काम जारी रहेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);lockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={lockConfirm=false}){Text("रद्द करें")}})
        return
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        DetailTopBar("हिसाब देखें",onBack)
        SmallAction("👷 मजदूरवार हिसाब",onWorkers)
        SmallAction("💸 मजदूर चुनकर भुगतान करें",onPayments)
        SmallAction("🌾 खेतवार हिसाब",onFieldReport)
        SmallAction("📅 तारीखवार हाजिरी रिपोर्ट",onAttendanceHistory)
        SmallAction("📋 आज की हाजिरी",onToday)
        SmallAction("📑 सभी मजदूरों की संयुक्त रिपोर्ट / PDF",onAllReport)
        if(months.isNotEmpty()) {
            Text("महीने का हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=GreenDark)
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                items(months,key={it}) { month ->
                    Card(Modifier.fillMaxWidth().clickable{selectedMonth=month;monthWorkerQuery=""},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Row(Modifier.padding(horizontal=14.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
                            Text(monthTitle(month),Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark)
                            Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,contentDescription=null,tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                        }
                    }
                }
            }
        } else Text("अभी कोई महीने का हिसाब नहीं है।",fontSize=12.sp,color=Color.Gray)
    }
}

internal data class LabourReportRow(val labour:Labour,val wage:Double,val paid:Double,val workDays:Double,val halfDays:Int)

@Composable private fun ReportCentreScreen(onBack:()->Unit,onReportTypes:()->Unit,onLabourReport:()->Unit,onAttendance:()->Unit,onWork:()->Unit,onProfitability:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        DetailTopBar("रिपोर्ट सेंटर",onBack)
        Text("रिपोर्ट और PDF",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Text("अपने रिकॉर्ड के आधार पर रिपोर्ट चुनें। रिपोर्ट में उपलब्ध सेव किए गए डेटा का ही उपयोग होगा।",fontSize=13.sp,color=Color.Gray)
        ReportChoiceCard("📑","मजदूर हिसाब रिपोर्ट","मजदूरी • भुगतान • बकाया • PDF",onLabourReport)
        ReportChoiceCard("📅","हाजिरी रिपोर्ट","तारीखवार सेव किए गए हाजिरी रिकॉर्ड",onAttendance)
        ReportChoiceCard("🧾","काम और मजदूरी","काम की सूची और रिकॉर्ड विवरण",onWork)
        ReportChoiceCard("💹","आय और मुनाफा","बिक्री • खर्च • खेतवार लाभ",onProfitability)
        Button(onClick=onReportTypes,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Text("रिपोर्ट का प्रकार चुनें")}
    }
}

@Composable private fun ReportTypeSelectionScreen(onBack:()->Unit,onLabourReport:()->Unit,onAttendance:()->Unit,onWork:()->Unit,onProfitability:()->Unit,onExpenses:()->Unit,onSales:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        DetailTopBar("रिपोर्ट का प्रकार",onBack)
        Text("किस प्रकार की रिपोर्ट चाहिए?",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Text("नीचे चुनने पर संबंधित मॉड्यूल के वास्तविक रिकॉर्ड खुलेंगे।",fontSize=12.sp,color=Color.Gray)
        ReportChoiceCard("👷","मजदूर और भुगतान","मजदूरी, भुगतान और बकाया",onLabourReport)
        ReportChoiceCard("📆","हाजिरी","तारीखवार हाजिरी",onAttendance)
        ReportChoiceCard("🧾","काम और मजदूरी","काम के रिकॉर्ड",onWork)
        ReportChoiceCard("🌾","खर्च रिपोर्ट","खेती लागत और खर्च",onExpenses)
        ReportChoiceCard("🧺","बिक्री रिपोर्ट","फसल बिक्री और आमदनी",onSales)
        ReportChoiceCard("📈","मुनाफा रिपोर्ट","खेतवार आय और लागत",onProfitability)
    }
}

@Composable private fun ReportChoiceCard(icon:String,title:String,subtitle:String,onClick:()->Unit){
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFE8F4EC)),contentAlignment=Alignment.Center){Text(icon,fontSize=24.sp)}
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,fontSize=16.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text(subtitle,fontSize=12.sp,color=Color.Gray)}
            Icon(Icons.Default.ChevronRight,null,tint=GreenDark)
        }
    }
}

@Composable private fun AllLabourReportScreen(store:Store,onBack:()->Unit,onWorker:(String)->Unit,onAttendance:()->Unit){
    val context=LocalContext.current
    val firstDate=(store.attendances.map{it.date}+store.payments.map{it.date}).filter{validDate(it)}.minOrNull() ?: today()
    var startDate by rememberSaveable{mutableStateOf(firstDate)}
    var endDate by rememberSaveable{mutableStateOf(today())}
    var allFields by rememberSaveable{mutableStateOf(true)}
    val selectedFields= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var allCrops by rememberSaveable{mutableStateOf(true)}
    val selectedCrops= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var allWorkers by rememberSaveable{mutableStateOf(true)}
    val selectedReportWorkers= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val selectedWorkers= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var selectedLockMonth by rememberSaveable{mutableStateOf("")}
    var showCustomReport by rememberSaveable{mutableStateOf(false)}
    var showPdfPreview by rememberSaveable{mutableStateOf(false)}
    var monthLockConfirm by rememberSaveable{mutableStateOf(false)}
    var validation by rememberSaveable{mutableStateOf("")}
    val lockMonths=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}+store.lockedLabourMonths).filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    if(showCustomReport) {
        val reportFields=store.fields
        val reportCrops=store.crops
        val chosenFieldIds=if(allFields) reportFields.map{it.id}.toSet() else selectedFields.toSet()
        val chosenCropIds=if(allCrops) reportCrops.map{it.id}.toSet() else selectedCrops.toSet()
        val chosenWorkerIds=if(allWorkers) store.labours.map{it.id}.toSet() else selectedReportWorkers.toSet()
        val rangeValid = validDate(startDate) && validDate(endDate) && startDate <= endDate
        val inRange:(String)->Boolean = { date -> rangeValid && date >= startDate && date <= endDate }
        val matchingAttendance=store.attendances.filter{inRange(it.date) && it.labourId in chosenWorkerIds && (allFields || it.fieldId in chosenFieldIds) && (allCrops || it.cropId in chosenCropIds)}
        val matchingPayments=store.payments.filter{inRange(it.date) && it.labourId in chosenWorkerIds && (allFields || it.fieldId in chosenFieldIds) && (allCrops || it.cropId in chosenCropIds)}
        val selectedAttendanceForReport=matchingAttendance.sortedWith(compareBy<Attendance>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
        val selectedPaymentsForReport=matchingPayments.sortedWith(compareBy<Payment>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
        val matchingLabourIds=(matchingAttendance.map{it.labourId}+matchingPayments.map{it.labourId}).toSet()
        val reportRows=store.labours.filter{it.id in matchingLabourIds}.map{labour->
            val a=matchingAttendance.filter{it.labourId==labour.id}
            val payments=matchingPayments.filter{it.labourId==labour.id}
            LabourReportRow(labour,a.sumOf{it.fraction*it.rate},payments.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        val totalWage=reportRows.sumOf{it.wage}; val totalPaid=reportRows.sumOf{it.paid}
        if(showPdfPreview) {
            Column(Modifier.fillMaxSize().background(Bg)) {
                DetailTopBar("K05 • PDF पूर्वावलोकन",{showPdfPreview=false})
                LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("PDF में शामिल होने वाला विवरण",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("तारीख: ${displayDate(startDate)} से ${displayDate(endDate)}");Text("मजदूर: ${if(allWorkers)"सभी मजदूर" else store.labours.filter{it.id in chosenWorkerIds}.joinToString(", "){it.name}}",fontSize=12.sp);Text("खेत: ${if(allFields)"सभी खेत" else store.fields.filter{it.id in chosenFieldIds}.joinToString(", "){it.name}}",fontSize=12.sp);Text("फसल: ${if(allCrops)"सभी फसलें" else store.crops.filter{it.id in chosenCropIds}.joinToString(", "){it.name}}",fontSize=12.sp);Divider();Text("हाजिरी ${quantity(selectedAttendanceForReport.sumOf{it.fraction})} दिन • मजदूरी ₹${money(selectedAttendanceForReport.sumOf{it.fraction*it.rate})}");Text("भुगतान ₹${money(selectedPaymentsForReport.sumOf{it.amount})} • अनुमानित बकाया ₹${money(selectedAttendanceForReport.sumOf{it.fraction*it.rate}-selectedPaymentsForReport.sumOf{it.amount})}")}} }
                    item { Text("हाजिरी और मजदूरी (${selectedAttendanceForReport.size})",fontWeight=FontWeight.Bold,color=GreenDark) }
                    items(selectedAttendanceForReport,key={"preview_att_"+it.id}) { a -> val worker=store.labours.firstOrNull{it.id==a.labourId}?.name?:"मजदूर रिकॉर्ड नहीं मिला";val field=store.fields.firstOrNull{it.id==a.fieldId}?.name?:"खेत रिकॉर्ड नहीं मिला";Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(10.dp)){Text("${displayDate(a.date)} • $worker",fontWeight=FontWeight.SemiBold,color=GreenDark);Text("$field • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी / अनुपस्थित" else "${quantity(a.fraction)} दिन"} • ₹${money(a.fraction*a.rate)}",fontSize=12.sp,color=Color.Gray)}} }
                    item { Text("भुगतान (${selectedPaymentsForReport.size})",fontWeight=FontWeight.Bold,color=GreenDark) }
                    items(selectedPaymentsForReport,key={"preview_pay_"+it.id}) { pay -> val worker=store.labours.firstOrNull{it.id==pay.labourId}?.name?:"मजदूर रिकॉर्ड नहीं मिला";val field=store.fields.firstOrNull{it.id==pay.fieldId}?.name?:"खेत रिकॉर्ड नहीं मिला";Card(shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(10.dp)){Text("${displayDate(pay.date)} • $worker",fontWeight=FontWeight.SemiBold,color=GreenDark);Text("$field • भुगतान ₹${money(pay.amount)}",fontSize=12.sp,color=Color.Gray)}} }
                    item { Button(onClick={exportDateFieldReportPdf(context,"रिपोर्ट_${System.currentTimeMillis()}","तारीख: ${displayDate(startDate)} से ${displayDate(endDate)} • मजदूर: ${if(allWorkers)"सभी मजदूर" else store.labours.filter{it.id in chosenWorkerIds}.joinToString(", "){it.name}} • खेत: ${if(allFields)"सभी खेत" else store.fields.filter{it.id in chosenFieldIds}.joinToString(", "){it.name}} • फसल: ${if(allCrops)"सभी फसलें" else store.crops.filter{it.id in chosenCropIds}.joinToString(", "){it.name}}",selectedAttendanceForReport,selectedPaymentsForReport,store,aggregateWorkerView=true,background=true)},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(8.dp));Text("PDF बनाएं और साझा करें")} }
                    item { OutlinedButton(onClick={showPdfPreview=false},modifier=Modifier.fillMaxWidth()){Text("फ़िल्टर बदलें")} }
                }
            }
            return
        }
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar("रिपोर्ट फ़िल्टर",{showPdfPreview=false;showCustomReport=false})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Text("K03 • रिपोर्ट की तारीख सीमा",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Text("शुरुआती और अंतिम तारीख दोनों शामिल होंगी।",fontSize=12.sp,color=Color.Gray) }
                item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)){ AttendanceDateButton(startDate){ picked -> startDate=picked; validation="" } }
                    Box(Modifier.weight(1f)){ AttendanceDateButton(endDate){ picked -> endDate=picked; validation="" } }
                } }
                if(!rangeValid) item { Text("तारीख सीमा गलत है। शुरुआती तारीख अंतिम तारीख से आगे नहीं हो सकती।",color=Color(0xFFB3261E),fontSize=12.sp) }
                item { Divider(); Text("K04 • मजदूर चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=allWorkers,onCheckedChange={allWorkers=it;if(it)selectedReportWorkers.clear()});Text("सभी मजदूर",fontWeight=FontWeight.Bold,color=GreenDark) } }
                if(!allWorkers) items(store.labours,key={"worker_filter_"+it.id}) { labour ->
                    Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).clickable{if(labour.id in selectedReportWorkers)selectedReportWorkers.remove(labour.id)else selectedReportWorkers.add(labour.id)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=labour.id in selectedReportWorkers,onCheckedChange={v->if(v){if(labour.id !in selectedReportWorkers)selectedReportWorkers.add(labour.id)}else selectedReportWorkers.remove(labour.id)})
                        Column { Text(labour.name,color=GreenDark,fontWeight=FontWeight.Medium); if(labour.mobile.isNotBlank())Text(labour.mobile,fontSize=11.sp,color=Color.Gray) }
                    }
                }
                item { Divider(); Text("खेत चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=allFields,onCheckedChange={allFields=it;if(it)selectedFields.clear()});Text("सभी खेत",fontWeight=FontWeight.Bold,color=GreenDark) } }
                items(reportFields,key={"field_"+it.id}) { field ->
                    Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).clickable{allFields=false;if(field.id in selectedFields)selectedFields.remove(field.id)else selectedFields.add(field.id)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=allFields || field.id in selectedFields,onCheckedChange={v->if(allFields && !v){allFields=false;selectedFields.addAll(reportFields.filter{it.id!=field.id}.map{it.id})}else{allFields=false;if(v){if(field.id !in selectedFields)selectedFields.add(field.id)}else selectedFields.remove(field.id)}})
                        Text(field.name.ifBlank{"नाम रहित खेत"},color=GreenDark,fontWeight=FontWeight.Medium)
                    }
                }
                item { Divider(); Text("फसल चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=allCrops,onCheckedChange={allCrops=it;if(it)selectedCrops.clear()});Text("सभी फसलें",fontWeight=FontWeight.Bold,color=GreenDark) } }
                if(!allCrops) items(reportCrops.filter{allFields || it.fieldId in chosenFieldIds},key={"crop_filter_"+it.id}) { crop ->
                    val cropFieldName=reportFields.firstOrNull{it.id==crop.fieldId}?.name.orEmpty()
                    Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).clickable{if(crop.id in selectedCrops)selectedCrops.remove(crop.id)else selectedCrops.add(crop.id)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=crop.id in selectedCrops,onCheckedChange={v->if(v){if(crop.id !in selectedCrops)selectedCrops.add(crop.id)}else selectedCrops.remove(crop.id)})
                        Column { Text(crop.name,color=GreenDark,fontWeight=FontWeight.Medium); Text(cropFieldName,fontSize=11.sp,color=Color.Gray) }
                    }
                }
                item {
                    Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("चुनी रिपोर्ट का सार",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Text("मजदूर ${reportRows.size} • हाजिरी ${quantity(matchingAttendance.sumOf{it.fraction})} दिन")
                        Text("मजदूरी ₹${money(totalWage)} • भुगतान ₹${money(totalPaid)} • बकाया ₹${money(totalWage-totalPaid)}")
                        Button(onClick={
                            if(!rangeValid) { validation="तारीख सीमा सही करें।"; return@Button }
                            if(!allWorkers && selectedReportWorkers.isEmpty()) { validation="कम से कम एक मजदूर चुनें।"; return@Button }
                            if(!allFields && selectedFields.isEmpty()) { validation="कम से कम एक खेत चुनें।"; return@Button }
                            if(!allCrops && selectedCrops.isEmpty()) { validation="कम से कम एक फसल चुनें।"; return@Button }
                            val selectedAttendance=selectedAttendanceForReport
                            val selectedPayments=selectedPaymentsForReport
                            if(selectedAttendance.isEmpty()&&selectedPayments.isEmpty()) validation="चुनी तारीख, मजदूर, खेत और फसल में कोई हाजिरी या भुगतान नहीं मिला।" else {
                                val detailLines=buildList {
                                    add("हाजिरी और मजदूरी का खेतवार विवरण")
                                    selectedAttendance.forEach{a->val labour=store.labours.firstOrNull{it.id==a.labourId}?.name?:"मजदूर हटाया गया";val field=store.fields.firstOrNull{it.id==a.fieldId}?.name?:"खेत हटाया गया";val attendance=if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी / अनुपस्थित" else "${quantity(a.fraction)} दिन";add("${displayDate(a.date)} • खेत $field • $labour • $attendance • मजदूरी ₹${money(a.fraction*a.rate)}")}
                                    add("भुगतान का विवरण")
                                    selectedPayments.forEach{pay->val labour=store.labours.firstOrNull{it.id==pay.labourId}?.name?:"मजदूर हटाया गया";val field=store.fields.firstOrNull{it.id==pay.fieldId}?.name?:"खेत हटाया गया";add("${displayDate(pay.date)} • खेत $field • $labour • भुगतान ₹${money(pay.amount)}")}
                                    add("कुल हाजिरी: ${quantity(selectedAttendance.sumOf{it.fraction})} दिन")
                                    add("कुल मजदूरी: ₹${money(selectedAttendance.sumOf{it.fraction*it.rate})}")
                                    add("चुने रिकॉर्ड के भुगतान: ₹${money(selectedPayments.sumOf{it.amount})}")
                                }
                                showPdfPreview=true
                            }
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text("चुनी तारीख, मजदूर, खेत और फसल की PDF बनाएँ") }
                        if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                    } }
                }
            }
        }
        return
    }
    if(selectedLockMonth.isNotBlank()) {
        val month=selectedLockMonth
        val ma=store.attendances.filter{it.date.startsWith(month)}
        val mp=store.payments.filter{it.date.startsWith(month)}
        val monthRows=store.labours.mapNotNull{l->
            val a=ma.filter{it.labourId==l.id}; val pay=mp.filter{it.labourId==l.id}
            if(a.isEmpty()&&pay.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},pay.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedLockMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=GreenDark); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",monthRows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान",monthRows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",monthRows.sumOf{it.wage-it.paid})} }
                    if(month !in store.lockedLabourMonths) Button(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                items(monthRows,key={it.labour.id}) { r ->
                    val days=ma.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    val checked = r.labour.id in selectedWorkers
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                            androidx.compose.material3.Checkbox(
                                checked = checked,
                                onCheckedChange = { value ->
                                    if (value) { if (r.labour.id !in selectedWorkers) selectedWorkers.add(r.labour.id) }
                                    else selectedWorkers.remove(r.labour.id)
                                }
                            )
                            Column(Modifier.weight(1f).padding(start=6.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                                Text(r.labour.name,fontWeight=FontWeight.Bold,color=GreenDark,fontSize=16.sp)
                                Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                                Text("इस महीने भुगतान ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=GreenDark)
                            }
                        }
                    }
                }
                item {
                    val picked = monthRows.filter { it.labour.id in selectedWorkers }
                    val wage = picked.sumOf { it.wage }; val paid = picked.sumOf { it.paid }
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Text("PDF / फोटो रिपोर्ट के लिए मजदूर चुनें",fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("चुने गए ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",fontSize=12.sp,color=Color.Gray)
                            ExportButtons(onPhoto={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportReportPhoto(context,"महीने_${month}_${System.currentTimeMillis()}","${monthTitle(month)} • चुने मजदूर ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",picked.map{"${it.labour.name} • काम ${quantity(it.workDays)} दिन • मजदूरी ₹${money(it.wage)} • भुगतान ₹${money(it.paid)} • बकाया ₹${money(it.wage-it.paid)}"})},onPdf={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportAllWorkersLedgerPdf(context,"${month}_chune_mazdoor",monthTitle(month),"सभी खेत",picked,wage,paid,background=true)})
                            if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                        }
                    }
                }
                if(monthRows.isEmpty()) item { Text("इस महीने कोई हिसाब दर्ज नहीं है।",color=Color.Gray) }
            }
        }
        if(monthLockConfirm) AlertDialog(onDismissRequest={monthLockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "पुरानी जानकारी सुरक्षित रहेगी। अनलॉक करने पर इस महीने की हाजिरी में बदलाव किया जा सकेगा।" else "इस महीने का हिसाब सुरक्षित रहेगा। पुराना हिसाब देखने के लिए महीना हमेशा खुल सकेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);monthLockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={monthLockConfirm=false}){Text("रद्द करें")}})
        return
    }
    // Main entry for the joint report: show only month names and lock icons.
    // Tapping a month opens its full month ledger above; keep report filters off this landing screen.
    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("सभी मजदूरों का हिसाब", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Button(onClick={showCustomReport=true;showPdfPreview=false;selectedFields.clear();selectedCrops.clear();selectedReportWorkers.clear();allFields=true;allCrops=true;allWorkers=true;startDate=firstDate;endDate=today();validation=""},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Icon(Icons.Default.PictureAsPdf,null); Spacer(Modifier.width(8.dp)); Text("तारीख, मजदूर, खेत और फसल की PDF रिपोर्ट") } }
            item { Text("महीने का हिसाब", fontWeight=FontWeight.ExtraBold, fontSize=20.sp, color=GreenDark) }
            items(lockMonths, key={it}) { month ->
                Card(Modifier.fillMaxWidth().clickable { selectedLockMonth = month }, shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(containerColor=CardBg)) {
                    Row(Modifier.padding(horizontal=16.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(monthTitle(month), Modifier.weight(1f), fontWeight=FontWeight.Bold, fontSize=17.sp, color=GreenDark)
                        Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen, contentDescription=null, tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                    }
                }
            }
            if(lockMonths.isEmpty()) item { Text("अभी कोई महीने का हिसाब नहीं है।", color=Color.Gray) }
        }
    }
    return

}


@Composable private fun AttendanceFieldPickerScreen(store:Store,onSelect:(String)->Unit,onBack:()->Unit){
    var addField by rememberSaveable{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("हाजिरी के लिए खेत चुनें",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Button(onClick={addField=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("नया खेत जोड़ें")}}
            items(store.fields,key={it.id}){f->
                val cropNames=store.crops.filter{it.fieldId==f.id}.joinToString(" • "){it.name}.ifBlank{"फसल नहीं जोड़ी गई"}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.fillMaxWidth().clickable{onSelect(f.id)}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Landscape,null,tint=Green,modifier=Modifier.size(34.dp));Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)){Text(f.name.ifBlank{"नाम रहित खेत"},fontSize=18.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text("${f.area.ifBlank{"रकबा नहीं दिया"}} • $cropNames",fontSize=12.sp,color=Color.Gray)}
                        Icon(Icons.Default.ChevronRight,null,tint=Green)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),horizontalArrangement=Arrangement.End){
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,null);Text("ऊपर")}
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,null);Text("नीचे")}
                    }
                }
            }
            if(store.fields.isEmpty()) item{Text("अभी कोई खेत नहीं है। पहले नया खेत जोड़ें।",color=Color.Gray)}
        }
    }
    if(addField) FieldDialog(store,null){addField=false}
}

@Composable
private fun SalaryDashboardScreen(onEmployees: () -> Unit, onReports: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val employees = remember(refresh) { loadSalaryEmployees(context) }
    var month by rememberSaveable { mutableStateOf(SimpleDateFormat("yyyy-MM", Locale.US).format(Date())) }
    val activeMonth = month.takeIf { isValidSalaryMonth(it) } ?: SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val rows = remember(employees, activeMonth, refresh) {
        employees.map { employee ->
            val record = loadSalaryMonth(context, employee.id, activeMonth)
            val days = monthDays(activeMonth).coerceAtLeast(1)
            val earned = salaryEarnedForRange(employee, activeMonth, record)
            val paid = record.paid + record.payments.sumOf { it.amount }
            Triple(employee, record, Triple(earned, paid, (earned - record.advance - paid).coerceAtLeast(0.0)))
        }
    }
    val totalEarned = rows.sumOf { it.third.first }
    val totalPaid = rows.sumOf { it.third.second + it.second.advance }
    val totalBalance = rows.sumOf { it.third.third }
    val todayRecords = rows.mapNotNull { it.second.daily[today()]?.status }
    val present = todayRecords.count { it == "उपस्थित" }
    val leave = todayRecords.count { it == "छुट्टी" }
    val absent = todayRecords.count { it == "अनुपस्थित" }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F3EC))) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Salary / कर्मचारी", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = GreenDark)
                    Text("मासिक वेतन, हाजिरी और भुगतान का पूरा सारांश", fontSize = 13.sp, color = Color(0xFF345448))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("महीना", fontWeight = FontWeight.Bold, color = GreenDark)
                        Spacer(Modifier.width(10.dp))
                        AppTextField(value = month, onValueChange = { value -> if (value.matches(Regex("\\d{0,4}(-\\d{0,2})?")) && (value.length < 7 || isValidSalaryMonth(value))) month = value }, label = { Text("YYYY-MM") }, modifier = Modifier.weight(1f), singleLine = true)
                        TextButton(onClick = { month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date()); refresh++ }) { Text("आज") }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                SalaryDashboardMetric("कुल कर्मचारी", "${employees.size}", Color(0xFFDCEEFF), Modifier.weight(1f))
                SalaryDashboardMetric("बनी सैलरी", "₹${money(totalEarned)}", Color(0xFFDDF6E9), Modifier.weight(1f))
            }
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                SalaryDashboardMetric("कुल भुगतान", "₹${money(totalPaid)}", Color(0xFFFFEFD4), Modifier.weight(1f))
                SalaryDashboardMetric("बाकी सैलरी", "₹${money(totalBalance)}", Color(0xFFFFE1E4), Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("आज की हाजिरी • ${today()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GreenDark)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SalaryDashboardMetric("उपस्थित", "$present", Color(0xFFDDF6E9), Modifier.weight(1f))
                        SalaryDashboardMetric("छुट्टी", "$leave", Color(0xFFFFEFD4), Modifier.weight(1f))
                        SalaryDashboardMetric("अनुपस्थित", "$absent", Color(0xFFE8EDF4), Modifier.weight(1f))
                    }
                    Text("जिन कर्मचारियों की आज की हाजिरी दर्ज नहीं हुई है: ${(employees.size - todayRecords.size).coerceAtLeast(0)}", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
        item {
            Button(onClick = onEmployees, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenDark)) {
                Icon(Icons.Default.Groups, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("कर्मचारी सूची खोलें", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { OutlinedButton(onClick = onReports, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Salary Reports देखें") } }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F7F4))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("महीने का हिसाब", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GreenDark)
                    SalaryDashboardLine("कुल बनी सैलरी", "₹${money(totalEarned)}")
                    SalaryDashboardLine("कुल भुगतान और एडवांस", "₹${money(totalPaid)}")
                    HorizontalDivider(color = Color(0xFFDCE7E0))
                    SalaryDashboardLine("बाकी सैलरी", "₹${money(totalBalance)}", true)
                }
            }
        }
        if (rows.isNotEmpty()) item {
            Text("सबसे पहले बाकी भुगतान वाले कर्मचारी", fontWeight = FontWeight.Bold, color = GreenDark, fontSize = 15.sp)
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                rows.sortedByDescending { it.third.third }.take(5).forEach { row ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(row.first.name, fontWeight = FontWeight.Bold)
                                Text("मासिक सैलरी ₹${money(row.first.monthlySalary)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("₹${money(row.third.third)} बाकी", color = Color(0xFFB42332), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SalaryDashboardMetric(label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = tint), elevation = CardDefaults.cardElevation(0.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, fontSize = 11.sp, color = Color(0xFF42564B))
            Text(value, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF173E2C), maxLines = 1)
        }
    }
}

@Composable
private fun SalaryDashboardLine(label: String, value: String, emphasis: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = if (emphasis) Color(0xFF9B2633) else Color(0xFF45564D), fontWeight = if (emphasis) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontSize = 14.sp, color = if (emphasis) Color(0xFFB42332) else Color(0xFF173E2C), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SalaryReportsScreen(onBack:()->Unit){
    val context=LocalContext.current
    val todayText=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    var fromDate by rememberSaveable { mutableStateOf(todayText.take(8)+"01") }
    var toDate by rememberSaveable { mutableStateOf(todayText) }
    var query by rememberSaveable { mutableStateOf("") }
    var employees by remember { mutableStateOf(loadSalaryEmployees(context)) }
    var refreshEmployees by remember { mutableIntStateOf(0) }
    LaunchedEffect(refreshEmployees) { employees = loadSalaryEmployees(context) }
    val dateRangeValid=validDate(fromDate)&&validDate(toDate)&&fromDate<=toDate
    val months=remember(fromDate,toDate){
        if(!dateRangeValid) emptyList() else runCatching {
            val f=SimpleDateFormat("yyyy-MM",Locale.US)
            val c=Calendar.getInstance().apply{time=f.parse(fromDate.take(7))!!;set(Calendar.DAY_OF_MONTH,1)}
            val last=f.parse(toDate.take(7))!!;val out=mutableListOf<String>()
            while(!c.time.after(last)&&out.size<240){out.add(f.format(c.time));c.add(Calendar.MONTH,1)}
            out
        }.getOrDefault(emptyList())
    }
    data class RangeRow(val employee:SalaryEmployee,val present:Int,val absent:Int,val leave:Int,val unmarked:Int,val earned:Double,val advances:Double,val legacyPaid:Double,val payments:Double,val paymentCount:Int,val notes:List<String>)
    val rows=if(dateRangeValid) employees.filter{query.isBlank()||searchMatches(query,it.name,it.mobile)}.map{emp->
        var present=0;var absent=0;var leave=0;var unmarked=0;var earned=0.0;var advances=0.0;var legacyPaid=0.0;var payments=0.0;var paymentCount=0;val notes=mutableListOf<String>()
        months.forEach{m->
            val rec=loadSalaryMonth(context,emp.id,m)
            val monthDaysCount=monthDays(m).coerceAtLeast(1)
            val monthStart="$m-01";val monthEnd="$m-${monthDaysCount.toString().padStart(2,'0')}"
            // Salary must never accrue before the employee's recorded joining date.
            // ISO yyyy-MM-dd strings can be compared lexicographically.
            val employmentStart=emp.joinDate.takeIf{validDate(it)} ?: monthStart
            val rangeStart=maxOf(fromDate,monthStart,employmentStart)
            val rangeEnd=minOf(toDate,monthEnd)
            val rangeDays=if(rangeStart<=rangeEnd) runCatching{
                val f=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
                (((f.parse(rangeEnd)!!.time-f.parse(rangeStart)!!.time)/86400000L)+1L).toInt().coerceAtLeast(0)
            }.getOrDefault(0) else 0
            val daysInRange=if(rangeDays>0) rec.daily.filterKeys{it in rangeStart..rangeEnd} else emptyMap()
            val presentInRange=daysInRange.values.count{it.status=="उपस्थित"}
            val absentInRange=daysInRange.values.count{it.status=="भांजी"||it.status=="अनुपस्थित"||it.status=="छुट्टी"}
            val leaveInRange=0
            val unmarkedInRange=(rangeDays-presentInRange-absentInRange-leaveInRange).coerceAtLeast(0)
            // Same central calculation as Dashboard and Employee Detail.
            earned+=salaryEarnedForRange(emp,m,rec,rangeStart,rangeEnd)
            present+=presentInRange;absent+=absentInRange;leave+=leaveInRange;unmarked+=unmarkedInRange
            if(rangeDays>0){advances+=rec.advance;legacyPaid+=rec.paid}
            daysInRange.toSortedMap().forEach{(date,day)->if(day.note.isNotBlank())notes.add("$date • ${day.status} • ${day.note}")}
            if(rangeDays>0) rec.payments.filter{it.date in rangeStart..rangeEnd}.forEach{pay->payments+=pay.amount;paymentCount++;notes.add("${pay.date} • भुगतान ₹${money(pay.amount)}${if(pay.note.isNotBlank())" • ${pay.note}" else ""}")}
        }
        RangeRow(emp,present,absent,leave,unmarked,earned,advances,legacyPaid,payments,paymentCount,notes)
    } else emptyList()
    val totalPayments=rows.sumOf{it.payments};val totalPresent=rows.sumOf{it.present};val totalAbsent=rows.sumOf{it.absent};val totalLeave=rows.sumOf{it.leave}
    val totalUnmarked=rows.sumOf{it.unmarked};val totalEarned=rows.sumOf{it.earned};val totalAdvances=rows.sumOf{it.advances};val totalLegacyPaid=rows.sumOf{it.legacyPaid}
    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("तारीख के अनुसार Salary रिपोर्ट",fontWeight=FontWeight.ExtraBold,fontSize=21.sp,color=GreenDark)
            Text("किसी भी तारीख से किसी भी तारीख तक हाजिरी और दर्ज भुगतान की PDF बनाएँ।",fontSize=13.sp,color=Color.Gray)}
        item{Text("शुरुआती तारीख (YYYY-MM-DD)",fontWeight=FontWeight.SemiBold);AppTextField(fromDate,{v->if(v.length<=10&&v.matches(Regex("[0-9-]*")))fromDate=v},label={Text("जैसे 2026-10-01")},singleLine=true)}
        item{Text("अंतिम तारीख (YYYY-MM-DD)",fontWeight=FontWeight.SemiBold);AppTextField(toDate,{v->if(v.length<=10&&v.matches(Regex("[0-9-]*")))toDate=v},label={Text("जैसे 2026-10-30")},singleLine=true)}
        if(!dateRangeValid)item{Text("कृपया सही तारीख भरें और शुरुआती तारीख अंतिम तारीख से पहले रखें।",color=Color(0xFFB42332),fontWeight=FontWeight.SemiBold)}
        item{AppTextField(query,{query=it},label={Text("कर्मचारी का नाम / मोबाइल खोजें")},singleLine=true)}
        item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE7F3EC)),shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("${if(dateRangeValid)"$fromDate से $toDate" else "तारीख चुनें"} • ${rows.size} कर्मचारी",fontWeight=FontWeight.Bold,fontSize=16.sp)
            SalaryDashboardLine("कुल उपस्थित दिन","$totalPresent");SalaryDashboardLine("कुल अनुपस्थित / छुट्टी","${totalAbsent+totalLeave}");SalaryDashboardLine("हाजिरी दर्ज नहीं (वेतन नहीं जुड़ा)","$totalUnmarked")
            SalaryDashboardLine("अनुमानित बनी सैलरी","₹${money(totalEarned)}")
            SalaryDashboardLine("संबंधित महीनों का एडवांस","₹${money(totalAdvances)}")
            SalaryDashboardLine("पुराना बिना तारीख वाला भुगतान","₹${money(totalLegacyPaid)}")
            SalaryDashboardLine("तारीखवार दर्ज भुगतान","₹${money(totalPayments)}",true)
            Text("नोट: वेतन में केवल दर्ज उपस्थित दिन जोड़े गए हैं। भांजी और हाजिरी दर्ज नहीं वाले दिन वेतन योग्य नहीं हैं। एडवांस और पुराने भुगतान संबंधित महीने के कुल हैं।",fontSize=11.sp,color=Color.Gray)
        }}}
        item{Button(onClick={
            val lines=mutableListOf<String>();lines.add("अवधि: $fromDate से $toDate");lines.add("कुल कर्मचारी: ${rows.size}");lines.add("")
            rows.forEachIndexed{idx,r->lines.add("${idx+1}. ${r.employee.name} • मोबाइल ${r.employee.mobile.ifBlank{"—"}}");lines.add("नौकरी शुरू होने की तारीख: ${r.employee.joinDate}");lines.add("अनुमानित बनी सैलरी: ₹${money(r.earned)}");lines.add("उपस्थित: ${r.present} • अनुपस्थित: ${r.absent} • छुट्टी: ${r.leave} • हाजिरी दर्ज नहीं: ${r.unmarked}");lines.add("संबंधित महीनों का एडवांस: ₹${money(r.advances)} • पुराना बिना तारीख वाला भुगतान: ₹${money(r.legacyPaid)}");lines.add("चुनी अवधि में तारीखवार भुगतान: ₹${money(r.payments)} • प्रविष्टियाँ: ${r.paymentCount}");r.notes.forEach{lines.add("   $it")};lines.add("")}
            lines.add("कुल अनुमानित बनी सैलरी: ₹${money(totalEarned)}")
            lines.add("कुल उपस्थित: $totalPresent • कुल अनुपस्थित: $totalAbsent • कुल छुट्टी: $totalLeave • हाजिरी दर्ज नहीं: $totalUnmarked")
            lines.add("संबंधित महीनों का एडवांस: ₹${money(totalAdvances)} • पुराना बिना तारीख वाला भुगतान: ₹${money(totalLegacyPaid)}")
            lines.add("चुनी अवधि में तारीखवार दर्ज भुगतान: ₹${money(totalPayments)}")
            lines.add("नोट: वेतन में केवल दर्ज उपस्थित दिन जोड़े गए हैं। भांजी और हाजिरी दर्ज नहीं वाले दिन वेतन योग्य नहीं हैं। एडवांस और पुराने भुगतान संबंधित महीने के कुल हैं; तारीखवार भुगतान नहीं।")
            exportReportPdf(context,"तारीखवार Salary रिपोर्ट","अवधि $fromDate से $toDate • ${rows.size} कर्मचारी • दर्ज भुगतान ₹${money(totalPayments)}",lines,hindiSafeWrap=true)
        },modifier=Modifier.fillMaxWidth(),enabled=dateRangeValid&&rows.isNotEmpty(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(8.dp));Text("चुनी हुई तारीखों की PDF बनाएँ / शेयर करें")}}
        if(dateRangeValid&&rows.isEmpty())item{Text("इस फ़िल्टर में कोई कर्मचारी रिकॉर्ड नहीं मिला।",color=Color.Gray)}
        items(rows.size){i->val r=rows[i];Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(14.dp)){Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            Text(r.employee.name,fontWeight=FontWeight.Bold,fontSize=16.sp);Text("नौकरी शुरू: ${r.employee.joinDate}",fontSize=12.sp,color=Color.Gray);Text("उपस्थित ${r.present} • भांजी ${r.absent+r.leave} • हाजिरी दर्ज नहीं ${r.unmarked}")
            Text("दर्ज भुगतान ₹${money(r.payments)} (${r.paymentCount} प्रविष्टियाँ)",color=GreenDark,fontWeight=FontWeight.SemiBold)
        }}}
        item{OutlinedButton(onClick={refreshEmployees++},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(6.dp));Text("कर्मचारी सूची रीफ्रेश करें")}}
        item{OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text("वापस जाएँ")}}
    }
}

@Composable
private fun SalaryEmployeeScreen(onEmployeeDetail:(String)->Unit){
    val context=LocalContext.current
    var employees by remember { mutableStateOf(loadSalaryEmployees(context)) }
    // Compose must observe Auto/Manual preference changes; SharedPreferences alone does not trigger recomposition.
    var autoAttendanceIds by remember { mutableStateOf(salaryAutoIds(context)) }
    var archivedEmployees by remember { mutableStateOf(loadArchivedSalaryEmployees(context)) }
    var showArchived by rememberSaveable { mutableStateOf(false) }
    var attendanceOnly by rememberSaveable { mutableStateOf(false) }
    var selectedAttendanceDate by rememberSaveable { mutableStateOf(today()) }
    var employeeSearch by rememberSaveable { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<SalaryEmployee?>(null) }
    var selected by remember { mutableStateOf<SalaryEmployee?>(null) }
    var quickHoliday by remember { mutableStateOf<SalaryEmployee?>(null) }
    var quickPayment by remember { mutableStateOf<SalaryEmployee?>(null) }
    var paymentDate by remember { mutableStateOf(today()) }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentNote by remember { mutableStateOf("") }
    var protectedEdit by remember { mutableStateOf<SalaryEmployee?>(null) }
    var protectedDelete by remember { mutableStateOf<SalaryEmployee?>(null) }
    var pendingAttendanceSave by remember { mutableStateOf<Triple<SalaryEmployee,String,String>?>(null) }
    var pendingHolidaySave by remember { mutableStateOf<Pair<SalaryEmployee,Pair<String,String>>?>(null) }
    var pendingSalarySave by remember { mutableStateOf<Pair<SalaryEmployee,SalaryMonth>?>(null) }
    var pendingPaymentSave by remember { mutableStateOf<Pair<SalaryEmployee,SalaryPayment>?>(null) }
    var holidayNote by remember { mutableStateOf("") }
    val currentMonth=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
    val activeMonth = selectedAttendanceDate.takeIf { validDate(it) }?.take(7) ?: currentMonth
    val datePickerCalendar = remember(selectedAttendanceDate) { Calendar.getInstance().apply { runCatching { time = SimpleDateFormat("yyyy-MM-dd",Locale.US).apply { isLenient=false }.parse(selectedAttendanceDate) ?: Date() } } }
    val filteredEmployees = if (attendanceOnly) employees else employees.filter { employeeSearch.isBlank() || it.name.contains(employeeSearch.trim(), ignoreCase = true) || it.mobile.contains(employeeSearch.trim()) }
    val salaryRows = employees.map { emp ->
        val rec = loadSalaryMonth(context, emp.id, activeMonth)
        val daysInMonth = monthDays(activeMonth).coerceAtLeast(1)
        val earnedSalary = salaryEarnedForRange(emp, activeMonth, rec)
        val paidAmount = rec.paid + rec.payments.sumOf { it.amount }
        Triple(emp, rec, Triple(earnedSalary, paidAmount, (earnedSalary - rec.advance - paidAmount).coerceAtLeast(0.0)))
    }
    val totalEarned = salaryRows.sumOf { it.third.first }
    val totalPaid = salaryRows.sumOf { it.third.second + it.second.advance }
    val totalBalance = salaryRows.sumOf { it.third.third }
    // The attendance summary must follow the date selected by the user, not silently show today's counts.
    val selectedDateRecords = salaryRows.mapNotNull { row -> row.second.daily[selectedAttendanceDate]?.status }
    val selectedDatePresent = selectedDateRecords.count { it == "उपस्थित" }
    val selectedDateHalf = selectedDateRecords.count { it == "आधा दिन" }
    val selectedDateLeave = selectedDateRecords.count { it == "भांजी" || it == "छुट्टी" }
    val selectedDateAbsent = 0
    val selectedDateUnmarked = (employees.size - selectedDateRecords.size).coerceAtLeast(0)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF07543F)),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().clickable {
                attendanceOnly = !attendanceOnly
                if (attendanceOnly) { selectedAttendanceDate = today(); employeeSearch = ""; showArchived = false }
            }) {
                Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                        Text(if (attendanceOnly) "आज की हाजिरी खुली है" else "आज की हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
                        Text(if (attendanceOnly) "हर कर्मचारी के सामने अलग-अलग हाजिरी लगाएँ" else "सबसे पहले यहाँ टैप करके कर्मचारीवार हाजिरी लगाएँ",fontSize=12.sp,color=Color(0xFFD8EEE5))
                    }
                    Text(if (attendanceOnly) "सूची पर लौटें  ‹" else "खोलें  ›",fontWeight=FontWeight.Bold,color=Color.White)
                }
            }
        }
        if (!attendanceOnly) item {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("कर्मचारी सूची",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                    Text("${employees.size} कर्मचारी • $activeMonth",fontSize=12.sp,color=Color.Gray)
                }
                IconButton(onClick={editing=null;showAdd=true}) { Text("＋👤",fontSize=21.sp,color=GreenDark) }
                IconButton(onClick={showArchived=!showArchived}) { Text("⬇️",fontSize=18.sp) }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE7F3EC)),shape=RoundedCornerShape(15.dp)) {
                Column(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=9.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text(if (attendanceOnly) "आज की हाजिरी • $selectedAttendanceDate" else "हाजिरी की तारीख",fontSize=14.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        AppTextField(value=selectedAttendanceDate,onValueChange={v->if(v.length<=10&&v.matches(Regex("[0-9-]*"))&&(v.length<10||validDate(v)))selectedAttendanceDate=v},label={Text("हाजिरी की पूरी तारीख (YYYY-MM-DD)")},modifier=Modifier.weight(1f),singleLine=true)
                        IconButton(onClick={DatePickerDialog(context,{_,year,monthOfYear,dayOfMonth->selectedAttendanceDate=String.format(Locale.US,"%04d-%02d-%02d",year,monthOfYear+1,dayOfMonth)},datePickerCalendar.get(Calendar.YEAR),datePickerCalendar.get(Calendar.MONTH),datePickerCalendar.get(Calendar.DAY_OF_MONTH)).apply { datePicker.maxDate=System.currentTimeMillis();show() } }) { Icon(Icons.Default.CalendarMonth,"तारीख चुनें",tint=GreenDark) }
                        TextButton(onClick={selectedAttendanceDate=today()}){Text("आज")}
                    }
                    Text("उपस्थित $selectedDatePresent • आधा दिन $selectedDateHalf • भांजी $selectedDateLeave • दर्ज नहीं $selectedDateUnmarked",fontSize=11.sp,color=GreenDark,fontWeight=FontWeight.SemiBold)
                }
            }
        }
        if (!attendanceOnly) {
            item {
                AppTextField(value=employeeSearch,onValueChange={employeeSearch=it},label={Text("नाम / मोबाइल खोजें")},singleLine=true,modifier=Modifier.fillMaxWidth())
            }
        }
        if(showArchived && !attendanceOnly) {
            if(archivedEmployees.isEmpty()) item { Text("आर्काइव में कोई कर्मचारी नहीं है।",color=Color.Gray) }
            items(archivedEmployees,key={"archived_${it.id}"}) { archived ->
                Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(14.dp)){
                    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){Text(archived.name,fontWeight=FontWeight.Bold);Text("₹${money(archived.monthlySalary)} • ${archived.mobile}",fontSize=12.sp,color=Color.Gray)}
                        TextButton(onClick={
                            employees=(employees+archived).distinctBy{it.id}.sortedBy{it.name.lowercase(Locale.ROOT)}
                            saveSalaryEmployees(context,employees)
                            archivedEmployees=archivedEmployees.filterNot{it.id==archived.id}
                            saveArchivedSalaryEmployees(context,archivedEmployees)
                        }){Text("वापस लाएँ")}
                    }
                }
            }
        }
        if(employees.isEmpty()) item { Text("अभी कोई कर्मचारी नहीं जोड़ा गया है।",modifier=Modifier.padding(12.dp),color=Color.Gray) }
        else if(filteredEmployees.isEmpty()) item { Text("इस नाम या मोबाइल नंबर से कोई कर्मचारी नहीं मिला।",modifier=Modifier.padding(12.dp),color=Color.Gray) }
        items(filteredEmployees,key={it.id}) { emp ->
            val record=loadSalaryMonth(context,emp.id,activeMonth);val days=monthDays(activeMonth)
            val base=record.salaryAtMonth.takeIf{it>0.0}?:emp.monthlySalary
            val earned=salaryEarnedForRange(emp,activeMonth,record)
            val paid=record.paid+record.payments.sumOf{it.amount};val balance=(earned-record.advance-paid).coerceAtLeast(0.0)
            val attendanceStatus=record.daily[selectedAttendanceDate]?.status?:"—"
            Card(shape=RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text(emp.name,Modifier.weight(1f).clickable{onEmployeeDetail(emp.id)},fontSize=19.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                        IconButton(onClick={protectedEdit=emp},modifier=Modifier.size(38.dp)){Icon(Icons.Default.Edit,"कर्मचारी एडिट करें",tint=GreenDark)}
                        IconButton(onClick={protectedDelete=emp},modifier=Modifier.size(38.dp)){Text("⬇️",fontSize=18.sp)}
                    }
                    Text("मासिक सैलरी ₹${money(base)}   •   दैनिक दर ₹${String.format(Locale.US,"%.2f",base/days.coerceAtLeast(1))} ($days दिन)   •   $selectedAttendanceDate: ${if(attendanceStatus=="छुट्टी"||attendanceStatus=="अनुपस्थित")"भांजी" else attendanceStatus}",fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(if (emp.id in autoAttendanceIds) "Auto हाजिरी चालू • रोज़ शाम 5 बजे" else "Manual हाजिरी", fontSize=12.sp, fontWeight=FontWeight.Bold, color=GreenDark)
                            Text("Auto में भी भांजी दर्ज करने पर वही सुरक्षित रहेगी", fontSize=10.sp, color=Color.Gray)
                            if (Build.VERSION.SDK_INT >= 31 && !(context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()) {
                                Text("चेतावनी: Exact Alarm अनुमति बंद है; 5 बजे की हाजिरी देर से लग सकती है।", fontSize=10.sp, color=Color(0xFFB45309))
                            }
                            if (Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                Text("चेतावनी: Notification अनुमति बंद है; हाजिरी की सूचना नहीं दिखेगी।", fontSize=10.sp, color=Color(0xFFB45309))
                            }
                        }
                        Switch(checked=emp.id in autoAttendanceIds, onCheckedChange={enabled ->
                            setSalaryAuto(context, emp.id, enabled)
                            autoAttendanceIds = salaryAutoIds(context)
                            if (enabled && Build.VERSION.SDK_INT >= 31) {
                                val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                if (!alarm.canScheduleExactAlarms()) {
                                    runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                }
                            }
                        })
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("बनी ₹${money(earned)}",color=GreenDark);Text("भुगतान ₹${money(paid)}",color=Color(0xFF2563EB));Text("बाकी ₹${money(balance)}",color=Color(0xFFB45309),fontWeight=FontWeight.Bold)}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        Button(onClick={if(validDate(selectedAttendanceDate)&&selectedAttendanceDate<=today()&&selectedAttendanceDate>=emp.joinDate)pendingAttendanceSave=Triple(emp,selectedAttendanceDate,"उपस्थित") else android.widget.Toast.makeText(context,"नौकरी शुरू होने के बाद की सही पुरानी या आज की तारीख चुनें।",android.widget.Toast.LENGTH_LONG).show()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=3.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Text("✓ उपस्थित",fontSize=11.sp)}
                        OutlinedButton(onClick={if(validDate(selectedAttendanceDate)&&selectedAttendanceDate<=today()&&selectedAttendanceDate>=emp.joinDate)pendingAttendanceSave=Triple(emp,selectedAttendanceDate,"आधा दिन") else android.widget.Toast.makeText(context,"नौकरी शुरू होने के बाद की सही पुरानी या आज की तारीख चुनें।",android.widget.Toast.LENGTH_LONG).show()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=3.dp)){Text("½ आधा दिन",fontSize=11.sp)}
                        OutlinedButton(onClick={quickHoliday=emp;holidayNote=""},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=3.dp)){Text("भांजी",fontSize=11.sp)}
                        OutlinedButton(onClick={quickPayment=emp;paymentDate=selectedAttendanceDate;paymentAmount="";paymentNote=""},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp)){Text("₹ भुगतान",fontSize=12.sp)}
                    }
                    TextButton(onClick={onEmployeeDetail(emp.id)},modifier=Modifier.fillMaxWidth()){Text("${emp.name} की पूरी डिटेल खोलें")}
                }
            }
        }
        if (!attendanceOnly) item {
            Button(onClick={
                val lines=mutableListOf<String>()
                lines.add("हाजिरी चुनी तारीख: $selectedAttendanceDate • रिपोर्ट महीना: $activeMonth")
                lines.add("कुल कर्मचारी: ${employees.size}")
                lines.add("")
                lines.add("कर्मचारीवार वेतन सारांश")
                salaryRows.forEachIndexed { index, row ->
                    val emp=row.first; val rec=row.second; val earned=row.third.first; val paid=row.third.second; val balance=row.third.third
                    lines.add("${index+1}. ${emp.name} • मोबाइल ${emp.mobile.ifBlank{"—"}}")
                    lines.add("मासिक वेतन ₹${money(rec.salaryAtMonth.takeIf{it>0.0}?:emp.monthlySalary)} • बनी सैलरी ₹${money(earned)} • भुगतान ₹${money(paid)} • एडवांस ₹${money(rec.advance)} • बाकी ₹${money(balance)}")
                    rec.daily.toSortedMap().forEach { (date,day) -> lines.add("   $date • ${day.status}${if(day.note.isNotBlank())" • ${day.note}" else ""}") }
                    rec.payments.sortedBy{it.date}.forEach { payment -> lines.add("   भुगतान ${payment.date} • ₹${money(payment.amount)}${if(payment.note.isNotBlank())" • ${payment.note}" else ""}") }
                    lines.add("")
                }
                lines.add("कुल बनी सैलरी: ₹${money(totalEarned)}")
                lines.add("कुल भुगतान व एडवांस: ₹${money(totalPaid)}")
                lines.add("कुल बाकी सैलरी: ₹${money(totalBalance)}")
                exportReportPdf(context,"सभी कर्मचारियों की वेतन रिपोर्ट","महीना $activeMonth • ${employees.size} कर्मचारी • कुल बनी सैलरी ₹${money(totalEarned)} • कुल भुगतान/एडवांस ₹${money(totalPaid)} • कुल बाकी ₹${money(totalBalance)}",lines,hindiSafeWrap=true)
            },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E)),enabled=employees.isNotEmpty()) {
                Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(8.dp));Text("सभी कर्मचारियों की Salary PDF बनाएँ / शेयर करें")
            }
        }
        if (attendanceOnly) item {
            OutlinedButton(onClick={attendanceOnly=false},modifier=Modifier.fillMaxWidth()) { Text("कर्मचारी सूची पर वापस जाएँ") }
        }
    }
    protectedEdit?.let { emp -> DeviceCredentialGate("सैलरी कर्मचारी बदलें","कर्मचारी की सैलरी या जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{editing=emp;protectedEdit=null},{protectedEdit=null}) }
    if(showAdd||editing!=null){val old=editing;SalaryEmployeeDialog(initial=old,onDismiss={showAdd=false;editing=null},onSave={name,mobile,salary,date->
        val normalizedMobile=mobile.filter{ch->ch.isDigit()}
        val duplicate=normalizedMobile.isNotBlank() && employees.any{it.id!=old?.id && it.mobile.filter{ch->ch.isDigit()}==normalizedMobile}
        if(duplicate){android.widget.Toast.makeText(context,"इस मोबाइल नंबर का कर्मचारी पहले से मौजूद है।",android.widget.Toast.LENGTH_LONG).show()}
        else {val updated=if(old==null)employees+SalaryEmployee(UUID.randomUUID().toString(),name,mobile,"",salary,date) else employees.map{if(it.id==old.id)old.copy(name=name,mobile=mobile,monthlySalary=salary,joinDate=date)else it};val sorted=updated.sortedBy{it.name.lowercase(Locale.ROOT)};saveSalaryEmployees(context,sorted);employees=sorted;showAdd=false;editing=null}
    })}
    protectedDelete?.let { emp -> DeviceCredentialGate("कर्मचारी आर्काइव करें", "कर्मचारी को सक्रिय सूची से हटाकर सुरक्षित आर्काइव में रखने के लिए Android screen lock से पुष्टि करें।", {
        employees=employees.filterNot{it.id==emp.id};saveSalaryEmployees(context,employees)
        archivedEmployees=(archivedEmployees.filterNot{it.id==emp.id}+emp).sortedBy{it.name.lowercase(Locale.ROOT)}
        saveArchivedSalaryEmployees(context,archivedEmployees);protectedDelete=null
    }, { protectedDelete=null }) }
    pendingAttendanceSave?.let { (emp, date, requestedStatus) ->
        DeviceCredentialGate(
            "$date की हाजिरी सेव करें",
            "$date की हाजिरी दर्ज करने के लिए Android screen lock से पुष्टि करें।",
            {
                try {
                    if (!validDate(date) || date > today()) {
                        android.widget.Toast.makeText(context, "सही पुरानी या आज की तारीख चुनें। भविष्य की तारीख में हाजिरी नहीं लग सकती।", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        val targetMonth = date.take(7)
                        val previous = loadSalaryMonth(context, emp.id, targetMonth)
                        val alreadySame = previous.daily[date]?.status == requestedStatus
                        if (!alreadySame) {
                            saveSalaryMonth(context, emp.id, targetMonth, previous.copy(daily = previous.daily + (date to SalaryDay(requestedStatus, ""))))
                        }
                        val savedStatus = loadSalaryMonth(context, emp.id, targetMonth).daily[date]?.status
                        check(savedStatus == requestedStatus) { "हाजिरी रिकॉर्ड सेव नहीं हो पाया।" }
                        employees = loadSalaryEmployees(context)
                        android.widget.Toast.makeText(
                            context,
                            if (alreadySame) "${emp.name} की $date की $requestedStatus हाजिरी पहले से दर्ज है।" else "${emp.name} की $date की $requestedStatus हाजिरी सफलतापूर्वक दर्ज हो गई।",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (error: Exception) {
                    android.widget.Toast.makeText(context, "हाजिरी सेव नहीं हुई: ${error.localizedMessage ?: "कृपया दोबारा कोशिश करें।"}", android.widget.Toast.LENGTH_LONG).show()
                } finally {
                    pendingAttendanceSave = null
                }
            },
            { pendingAttendanceSave = null }
        )
    }
    pendingHolidaySave?.let { (emp, entry) -> DeviceCredentialGate("भांजी सेव करें", "चुनी हुई तारीख की भांजी दर्ज करने के लिए Android screen lock से पुष्टि करें।", { val (date,note)=entry;if(!validDate(date)||date>today()||date<emp.joinDate){android.widget.Toast.makeText(context,"नौकरी शुरू होने के बाद की सही पुरानी या आज की तारीख चुनें।",android.widget.Toast.LENGTH_LONG).show()}else{val m=date.take(7);val old=loadSalaryMonth(context,emp.id,m);saveSalaryMonth(context,emp.id,m,old.copy(daily=old.daily+(date to SalaryDay("भांजी",note))))};employees=loadSalaryEmployees(context);pendingHolidaySave=null }, { pendingHolidaySave=null }) }
    quickHoliday?.let{emp->AlertDialog(onDismissRequest={quickHoliday=null},title={Text("${emp.name} • $selectedAttendanceDate की भांजी")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("तारीख: $selectedAttendanceDate");AppTextField(holidayNote,{holidayNote=it},label={Text("कारण / नोट लिखें")},minLines=2)}},confirmButton={TextButton(onClick={val d=selectedAttendanceDate;pendingHolidaySave=emp to (d to holidayNote.trim());quickHoliday=null}){Text("सेव करें")}},dismissButton={TextButton(onClick={quickHoliday=null}){Text("रद्द करें")}})}
    quickPayment?.let { emp ->
        AlertDialog(onDismissRequest={quickPayment=null},title={Text("${emp.name} • भुगतान दर्ज करें")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            AppTextField(paymentDate,{paymentDate=it},label={Text("भुगतान की तारीख (YYYY-MM-DD)")},singleLine=true)
            AppTextField(paymentAmount,{paymentAmount=it},label={Text("भुगतान रकम ₹")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            AppTextField(paymentNote,{paymentNote=it},label={Text("नोट / विवरण (वैकल्पिक)")},minLines=2)
        }},confirmButton={TextButton(onClick={val amount=paymentAmount.toDoubleOrNull();if(!validDate(paymentDate)||paymentDate<emp.joinDate||amount==null||!amount.isFinite()||amount<=0){android.widget.Toast.makeText(context,"नौकरी शुरू होने के बाद की सही तारीख और रकम भरें।",android.widget.Toast.LENGTH_SHORT).show()}else{pendingPaymentSave=emp to SalaryPayment(paymentDate,amount,paymentNote.trim());quickPayment=null}}){Text("भुगतान सेव करें")}},dismissButton={TextButton(onClick={quickPayment=null}){Text("रद्द करें")}})
    }
    pendingPaymentSave?.let { (emp, payment) -> DeviceCredentialGate("कर्मचारी भुगतान सेव करें","भुगतान रिकॉर्ड जोड़ने के लिए Android screen lock से पुष्टि करें।",{val m=payment.date.take(7);val old=loadSalaryMonth(context,emp.id,m);saveSalaryMonth(context,emp.id,m,old.copy(payments=old.payments+payment));employees=loadSalaryEmployees(context);pendingPaymentSave=null},{pendingPaymentSave=null}) }
    selected?.let{emp->val old=loadSalaryMonth(context,emp.id,activeMonth);SalaryMonthDialog(employee=emp,month=activeMonth,initial=old,onDismiss={selected=null},onSave={record->pendingSalarySave=emp to record;selected=null})}
    pendingSalarySave?.let { (emp, record) -> DeviceCredentialGate("कर्मचारी का हिसाब बदलें","हाजिरी, आधा दिन, एडवांस और भुगतान का हिसाब बदलने के लिए Android screen lock से पुष्टि करें।",{saveSalaryMonth(context,emp.id,activeMonth,record);employees=loadSalaryEmployees(context);pendingSalarySave=null},{pendingSalarySave=null}) }
}

@Composable
private fun SalaryEmployeeDetailScreen(id:String,onBack:()->Unit){
    val context=LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val employee=remember(id,refresh){loadSalaryEmployees(context).firstOrNull{it.id==id}}
    var month by rememberSaveable(id){mutableStateOf(SimpleDateFormat("yyyy-MM",Locale.US).format(Date()))}
    var showPaymentEditor by rememberSaveable(id){mutableStateOf(false)}
    var pendingPaymentSave by remember(id){mutableStateOf<SalaryMonth?>(null)}
    val record=remember(id,month,refresh){loadSalaryMonth(context,id,month)}
    val days=monthDays(month).coerceAtLeast(1)
    val base=record.salaryAtMonth.takeIf{it.isFinite() && it>0.0}?:employee?.monthlySalary?:0.0
    val earned=employee?.let{salaryEarnedForRange(it,month,record)}?:0.0
    val paid=record.paid+record.payments.sumOf{it.amount}
    val totalSettled=record.advance+paid
    val netBalance=earned-totalSettled
    val balance=netBalance.coerceAtLeast(0.0)
    val overpaid=(-netBalance).coerceAtLeast(0.0)
    val presentDays=record.daily.values.count{it.status=="उपस्थित"}
    val halfDays=record.daily.values.count{it.status=="आधा दिन"}
    val absentDays=record.daily.values.count{it.status=="भांजी"||it.status=="अनुपस्थित"||it.status=="छुट्टी"}
    val leaveDays=0
    val eligibleDays=employee?.let{emp->
        val monthStart="$month-01"
        val monthEnd="$month-${days.toString().padStart(2,'0')}"
        val join=emp.joinDate.takeIf{validDate(it)}?:monthStart
        val start=maxOf(monthStart,join)
        if(start>monthEnd) 0 else runCatching {
            val f=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
            (((f.parse(monthEnd)!!.time-f.parse(start)!!.time)/86400000L)+1L).toInt().coerceAtLeast(0)
        }.getOrDefault(0)
    }?:0
    val unmarkedDays=(eligibleDays-presentDays-halfDays-absentDays-leaveDays).coerceAtLeast(0)
    if(employee==null){Column(Modifier.fillMaxSize().padding(20.dp)){Text("कर्मचारी रिकॉर्ड नहीं मिला");Button(onClick=onBack){Text("वापस जाएँ")}};return}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFE7F3EC))){Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(employee.name,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("मोबाइल: ${employee.mobile.ifBlank{"नहीं दिया"}}",color=Color.DarkGray);Text("जुड़ने की तारीख: ${employee.joinDate}",color=Color.DarkGray);Text("मासिक सैलरी: ₹${money(employee.monthlySalary)}",fontWeight=FontWeight.Bold,color=GreenDark)}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){SalaryDashboardMetric("बनी सैलरी","₹${money(earned)}",Color(0xFFDDF6E9),Modifier.weight(1f));SalaryDashboardMetric("भुगतान + एडवांस","₹${money(totalSettled)}",Color(0xFFFFEFD4),Modifier.weight(1f))};Spacer(Modifier.height(8.dp));SalaryDashboardMetric(if(overpaid>0.0)"अधिक भुगतान" else "बाकी सैलरी","₹${money(if(overpaid>0.0)overpaid else balance)}",Color(0xFFDCEEFF),Modifier.fillMaxWidth())}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("महीने का हिसाब",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton(onClick={month=SimpleDateFormat("yyyy-MM",Locale.US).format(Date());refresh++}){Text("आज")}};AppTextField(month,{v->if(v.matches(Regex("\\d{0,4}(-\\d{0,2})?"))&&(v.length<7||isValidSalaryMonth(v)))month=v},label={Text("महीना YYYY-MM")},singleLine=true)}
        item{Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("हाजिरी रिकॉर्ड",fontWeight=FontWeight.Bold,fontSize=17.sp);Text("उपस्थित: $presentDays  •  आधा दिन: $halfDays  •  भांजी: ${absentDays+leaveDays}  •  हाजिरी दर्ज नहीं: $unmarkedDays");record.daily.toSortedMap().forEach{(date,d)->Text("$date  •  ${d.status}${if(d.note.isNotBlank())"  •  ${d.note}" else ""}",fontSize=13.sp)}}}}
        item{Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("भुगतान इतिहास",fontWeight=FontWeight.Bold,fontSize=17.sp);Text("एडवांस: ₹${money(record.advance)} • पुराना भुगतान: ₹${money(record.paid)}");if(record.payments.isNotEmpty())Text("भुगतान बदलने या हटाने के लिए रिकॉर्ड पर टैप करें",fontSize=12.sp,color=Color.Gray);record.payments.sortedByDescending{it.date}.forEach{entry->Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${entry.date}  •  ₹${money(entry.amount)}",fontSize=13.sp,fontWeight=FontWeight.SemiBold);if(entry.note.isNotBlank())Text(entry.note,fontSize=12.sp,color=Color.Gray)};TextButton(onClick={showPaymentEditor=true}){Text("✏️ एडिट / हटाएँ",fontSize=12.sp,color=GreenDark,fontWeight=FontWeight.SemiBold)}}};if(record.payments.isEmpty()&&record.paid==0.0&&record.advance==0.0)Text("अभी भुगतान दर्ज नहीं है",color=Color.Gray)}}}
        item{Button(onClick={runCatching{shareSalaryEmployeePdf(context,employee,month,record,earned,paid,balance)}.onFailure{android.widget.Toast.makeText(context,"PDF नहीं बन सकी: ${it.message?:"त्रुटि"}",android.widget.Toast.LENGTH_LONG).show()}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E)),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(8.dp));Text("इस कर्मचारी की PDF रिपोर्ट बनाएँ / शेयर करें")}}
        item{OutlinedButton(onClick=onBack,modifier=Modifier.fillMaxWidth()){Text("वापस कर्मचारी सूची")}}
    }
    if(showPaymentEditor){
        SalaryMonthDialog(employee=employee,month=month,initial=record,onDismiss={showPaymentEditor=false},onSave={updated->
            pendingPaymentSave=updated
            showPaymentEditor=false
        })
    }
    pendingPaymentSave?.let { updated ->
        DeviceCredentialGate(
            "भुगतान इतिहास बदलें",
            "भुगतान की एंट्री बदलने या हटाने के लिए Android screen lock से पुष्टि करें।",
            {
                saveSalaryMonth(context,employee.id,month,updated)
                pendingPaymentSave=null
                refresh++
            },
            { pendingPaymentSave=null }
        )
    }
}

private fun shareSalaryEmployeePdf(context:Context,employee:SalaryEmployee,month:String,record:SalaryMonth,earned:Double,paid:Double,balance:Double){
    val hindiRegular=Typeface.createFromAsset(context.assets,"fonts/NotoSansDevanagari-Regular.ttf")
    val hindiBold=Typeface.createFromAsset(context.assets,"fonts/NotoSansDevanagari-Bold.ttf")
    val doc=PdfDocument(); val pageW=595; val pageH=842; val left=38f; val right=38f
    val title=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(25,75,48);textSize=20f;typeface=hindiBold}
    val heading=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(35,75,55);textSize=13f;typeface=hindiBold}
    val body=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.DKGRAY;textSize=11f;typeface=hindiRegular}
    val muted=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.GRAY;textSize=9f;typeface=hindiRegular}
    var pageNo=1; var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas; var y=48f
    fun newPage(){canvas.drawText("पृष्ठ $pageNo",pageW-right-45f,pageH-22f,muted);doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;y=48f}
    fun line(text:String,p:Paint=body,indent:Float=0f){
        val maxWidth=pageW-left-right-indent
        val words=text.split(Regex("\\s+")).filter{it.isNotEmpty()}
        var current=""
        fun flushLine(){if(y>pageH-55f)newPage();canvas.drawText(current,left+indent,y,p);y+=maxOf(17f,p.textSize*1.55f);current=""}
        words.forEach{word->
            val candidate=if(current.isEmpty()) word else "$current $word"
            if(current.isNotEmpty() && p.measureText(candidate)>maxWidth) flushLine()
            if(p.measureText(word)>maxWidth){
                val breaker=java.text.BreakIterator.getCharacterInstance(Locale("hi","IN")).apply{setText(word)}
                var part="";var start=breaker.first();var end=breaker.next()
                while(end!=java.text.BreakIterator.DONE){
                    val cluster=word.substring(start,end);val test=part+cluster
                    if(part.isNotEmpty()&&p.measureText(test)>maxWidth){current=part;flushLine();part=cluster}else part=test
                    start=end;end=breaker.next()
                }
                current=part
            }else current=if(current.isEmpty())word else "$current $word"
        }
        if(current.isNotEmpty())flushLine()
    }
    canvas.drawText("कर्मचारी वेतन रिपोर्ट",left,y,title);y+=30f
    line("महीना: $month",heading);line("कर्मचारी: ${employee.name}");line("मोबाइल: ${employee.mobile.ifBlank{"उपलब्ध नहीं"}}");line("जुड़ने की तारीख: ${employee.joinDate}");line("मासिक वेतन: ₹${money(employee.monthlySalary)}")
    y+=8f;canvas.drawLine(left,y,pageW-right,y,heading);y+=22f
    line("वेतन सारांश",heading);line("बनी हुई सैलरी: ₹${money(earned)}");line("कुल भुगतान: ₹${money(paid)}");line("एडवांस: ₹${money(record.advance)}");line("बाकी सैलरी: ₹${money(balance)}",heading)
    y+=8f;canvas.drawLine(left,y,pageW-right,y,heading);y+=22f
    line("हाजिरी विवरण",heading)
    val days=record.daily.toSortedMap(); if(days.isEmpty())line("इस महीने हाजिरी का अलग-अलग रिकॉर्ड उपलब्ध नहीं है") else days.forEach{(date,d)->line("$date   ${d.status}${if(d.note.isNotBlank())"   ${d.note}" else ""}")}
    y+=8f;canvas.drawLine(left,y,pageW-right,y,heading);y+=22f
    line("भुगतान / एडवांस विवरण",heading)
    if(record.advance>0)line("एडवांस   ₹${money(record.advance)}")
    if(record.paid>0)line("पुराना दर्ज भुगतान   ₹${money(record.paid)}")
    val payments=record.payments.sortedBy{it.date};if(payments.isEmpty()&&record.paid==0.0&&record.advance==0.0)line("इस महीने भुगतान रिकॉर्ड उपलब्ध नहीं है") else payments.forEach{line("${it.date}   ₹${money(it.amount)}${if(it.note.isNotBlank())"   ${it.note}" else ""}")}
    canvas.drawText("Majdoor Hisaab PRO • रिपोर्ट फोन के स्थानीय रिकॉर्ड से बनाई गई",left,pageH-22f,muted);canvas.drawText("पृष्ठ $pageNo",pageW-right-45f,pageH-22f,muted);doc.finishPage(page)
    val dir=File(context.cacheDir,"salary_reports").apply{mkdirs()};val file=File(dir,"Salary_${safeFileName(employee.name)}_${safeFileName(month)}.pdf")
    try{FileOutputStream(file).use{doc.writeTo(it)}}finally{doc.close()};shareFile(context,file,"application/pdf","Salary PDF रिपोर्ट शेयर करें")
}

@Composable private fun SalaryEmployeeDialog(initial:SalaryEmployee?,onDismiss:()->Unit,onSave:(String,String,Double,String)->Unit){
    var name by remember(initial?.id) { mutableStateOf(initial?.name?:"") };var mobile by remember(initial?.id) { mutableStateOf(initial?.mobile?:"") };var salary by remember(initial?.id) { mutableStateOf(initial?.monthlySalary?.toString()?:"") };var date by remember(initial?.id) { mutableStateOf(initial?.joinDate?:today()) };var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(initial==null)"नया कर्मचारी जोड़ें" else "कर्मचारी एडिट करें")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        AppTextField(name,{name=it},label={Text("कर्मचारी का नाम *")},singleLine=true)
        AppTextField(mobile,{mobile=it},label={Text("मोबाइल नंबर")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone))
        AppTextField(salary,{salary=it},label={Text("मासिक सैलरी ₹ *")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        AppTextField(date,{date=it},label={Text("नौकरी शुरू तारीख (YYYY-MM-DD)")},singleLine=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    }},confirmButton={TextButton(onClick={val amount=salary.toDoubleOrNull();if(name.isBlank()||amount==null||!amount.isFinite()||amount<=0||!validDate(date.trim()))error="नाम, सही मासिक सैलरी और सही तारीख भरें।" else onSave(name.trim(),mobile.trim(),amount,date.trim())}){Text("सेव करें")}},dismissButton={TextButton(onClick=onDismiss){Text("रद्द करें")}})
}

@Composable private fun SalaryMonthDialog(employee:SalaryEmployee,month:String,initial:SalaryMonth,onDismiss:()->Unit,onSave:(SalaryMonth)->Unit){
    var attendanceDate by remember { mutableStateOf(today().takeIf{it.startsWith(month)}?:"$month-01") }
    var status by remember { mutableStateOf(initial.daily[attendanceDate]?.status?:"उपस्थित") }
    var note by remember { mutableStateOf(initial.daily[attendanceDate]?.note?:"") }
    var daily by remember { mutableStateOf(initial.daily) }
    var payments by remember { mutableStateOf(initial.payments) }
    var paymentDate by remember { mutableStateOf(today().takeIf{it.startsWith(month)}?:"$month-01") }
    var paymentAmount by remember { mutableStateOf("") };var paymentNote by remember { mutableStateOf("") }
    var editingPaymentIndex by remember { mutableIntStateOf(-1) }
    val monthlySalary=initial.salaryAtMonth.takeIf{it>0.0} ?: employee.monthlySalary
    var advance by remember { mutableStateOf(initial.advance.toString()) };var paid by remember { mutableStateOf(initial.paid.toString()) };var error by remember { mutableStateOf("") }
    val days=monthDays(month);val absentNum=if(daily.isNotEmpty())daily.values.count{it.status=="भांजी"||it.status=="अनुपस्थित"||it.status=="छुट्टी"} else initial.absentDays.coerceIn(0,days);val previewRecord=initial.copy(daily=daily,salaryAtMonth=monthlySalary);val earned=salaryEarnedForRange(employee,month,previewRecord);val deduction=(monthlySalary-earned).coerceAtLeast(0.0);val totalPaid=(paid.toDoubleOrNull()?:0.0)+payments.sumOf{it.amount};val balance=(earned-(advance.toDoubleOrNull()?:0.0)-totalPaid).coerceAtLeast(0.0)
    AlertDialog(onDismissRequest=onDismiss,title={Text("${employee.name} • $month")},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("इस महीने लागू सैलरी ₹${money(monthlySalary)} • महीने में $days दिन",fontWeight=FontWeight.SemiBold)
        HorizontalDivider();Text("रोज की हाजिरी",fontWeight=FontWeight.Bold)
        AppTextField(attendanceDate,{attendanceDate=it;val d=daily[it];status=d?.status?:"उपस्थित";note=d?.note?:""},label={Text("तारीख (YYYY-MM-DD)")},singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("उपस्थित","आधा दिन","भांजी").forEach{v->TextButton(onClick={status=v}){Text(if(status==v)"✓ $v" else v)}}}
        AppTextField(note,{note=it},label={Text(if(status=="भांजी")"भांजी का कारण / नोट (वैकल्पिक)" else if(status=="आधा दिन")"आधा दिन का नोट (वैकल्पिक)" else "हाजिरी का नोट (वैकल्पिक)")},minLines=2)
        Button(onClick={if(!validDate(attendanceDate)||!attendanceDate.startsWith(month)||attendanceDate<employee.joinDate||status !in setOf("उपस्थित","आधा दिन","भांजी"))error="Joining Date के बाद की सही तारीख और हाजिरी चुनें।" else {daily=daily+(attendanceDate to SalaryDay(status,note.trim()));error=""}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Text("इस दिन की हाजिरी / नोट सेव करें")}
        if(daily.isNotEmpty()){Text("इस महीने दर्ज दिन (${daily.size})",fontWeight=FontWeight.Bold);daily.toSortedMap().forEach{(date,rec)->Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("$date • ${rec.status}",fontWeight=FontWeight.SemiBold);if(rec.note.isNotBlank())Text(rec.note,fontSize=12.sp,color=Color.Gray)};TextButton(onClick={attendanceDate=date;status=rec.status;note=rec.note}){Text("बदलें")};TextButton(onClick={daily=daily-date}){Text("हटाएँ",color=Color(0xFFB91C1C))}}}}
        HorizontalDivider();Text("अनुपस्थिति कटौती: ₹${money(deduction)}");Text("बनी हुई सैलरी: ₹${money(earned)}",fontWeight=FontWeight.Bold)
        AppTextField(advance,{advance=it},label={Text("इस महीने कुल एडवांस ₹")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        AppTextField(paid,{paid=it},label={Text("पहले दर्ज/पुराना भुगतान ₹")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        HorizontalDivider();Text("तारीखवार भुगतान दर्ज करें",fontWeight=FontWeight.Bold)
        AppTextField(paymentDate,{paymentDate=it},label={Text("भुगतान तारीख (YYYY-MM-DD)")},singleLine=true)
        AppTextField(paymentAmount,{paymentAmount=it},label={Text("भुगतान रकम ₹")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        AppTextField(paymentNote,{paymentNote=it},label={Text("भुगतान का नोट (वैकल्पिक)")},singleLine=true)
        OutlinedButton(onClick={
            val amount=paymentAmount.toDoubleOrNull()
            if(!validDate(paymentDate)||!paymentDate.startsWith(month)||paymentDate<employee.joinDate||amount==null||!amount.isFinite()||amount<=0)error="नौकरी शुरू होने के बाद की सही तारीख और रकम भरें।"
            else {
                val updated=SalaryPayment(paymentDate,amount,paymentNote.trim())
                payments=if(editingPaymentIndex in payments.indices)payments.toMutableList().also{it[editingPaymentIndex]=updated}else payments+updated
                editingPaymentIndex=-1;paymentAmount="";paymentNote="";error=""
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(editingPaymentIndex>=0)"भुगतान बदलाव सेव करें" else "+ भुगतान जोड़ें")}
        if(editingPaymentIndex>=0) TextButton(onClick={editingPaymentIndex=-1;paymentDate=today().takeIf{it.startsWith(month)}?:"$month-01";paymentAmount="";paymentNote=""}){Text("एडिट रद्द करें")}
        payments.forEachIndexed{index,entry->Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${entry.date} • ₹${money(entry.amount)}",fontWeight=FontWeight.SemiBold);if(entry.note.isNotBlank())Text(entry.note,fontSize=12.sp,color=Color.Gray)};TextButton(onClick={editingPaymentIndex=index;paymentDate=entry.date;paymentAmount=entry.amount.toString();paymentNote=entry.note}){Text("एडिट")};TextButton(onClick={payments=payments.filterIndexed{idx,_->idx!=index};if(editingPaymentIndex==index)editingPaymentIndex=-1}){Text("हटाएँ",color=Color(0xFFB91C1C))}}}
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF4EC))){Column(Modifier.padding(12.dp)){Text("कुल भुगतान: ₹${money(totalPaid)}",fontWeight=FontWeight.SemiBold);Text("बाकी सैलरी: ₹${money(balance)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)}}
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
    }},confirmButton={TextButton(onClick={val adv=advance.toDoubleOrNull();val pay=paid.toDoubleOrNull();if(adv==null||!adv.isFinite()||adv<0||pay==null||!pay.isFinite()||pay<0)error="एडवांस और भुगतान सही भरें।" else onSave(SalaryMonth(absentNum,adv,pay,daily,monthlySalary,payments))}){Text("पूरा हिसाब सेव करें")}},dismissButton={TextButton(onClick=onDismiss){Text("बंद करें")}})
}

private fun salaryPrefs(context:Context)=context.getSharedPreferences("mhpro_salary_employees_v1",Context.MODE_PRIVATE)
private fun salaryArchivePrefs(context:Context)=salaryPrefs(context)
private fun loadArchivedSalaryEmployees(context:Context):List<SalaryEmployee> = runCatching {
    val a=JSONArray(salaryArchivePrefs(context).getString("archived_employees","[]")?:"[]")
    (0 until a.length()).map{val o=a.getJSONObject(it);SalaryEmployee(o.optString("id"),o.optString("name"),o.optString("mobile"),o.optString("role"),o.optDouble("salary"),o.optString("joinDate"))}
}.getOrDefault(emptyList())
private fun saveArchivedSalaryEmployees(context:Context,list:List<SalaryEmployee>){
    val a=JSONArray();list.forEach{e->a.put(JSONObject().put("id",e.id).put("name",e.name).put("mobile",e.mobile).put("role",e.role).put("salary",e.monthlySalary).put("joinDate",e.joinDate))}
    salaryArchivePrefs(context).edit().putString("archived_employees",a.toString()).apply()
}
private fun loadSalaryEmployees(context:Context):List<SalaryEmployee> = runCatching { val a=JSONArray(salaryPrefs(context).getString("employees","[]")?:"[]");(0 until a.length()).map{val o=a.getJSONObject(it);SalaryEmployee(o.optString("id"),o.optString("name"),o.optString("mobile"),o.optString("role"),o.optDouble("salary"),o.optString("joinDate"))} }.getOrDefault(emptyList())
private fun saveSalaryEmployees(context:Context,list:List<SalaryEmployee>){val a=JSONArray();list.forEach{e->a.put(JSONObject().put("id",e.id).put("name",e.name).put("mobile",e.mobile).put("role",e.role).put("salary",e.monthlySalary).put("joinDate",e.joinDate))};salaryPrefs(context).edit().putString("employees",a.toString()).apply()}
private fun salaryMonthKey(id:String,month:String)="month_${id}_$month"
private fun loadSalaryMonth(context:Context,id:String,month:String):SalaryMonth=runCatching{val o=JSONObject(salaryPrefs(context).getString(salaryMonthKey(id,month),"{}")?:"{}");val d=o.optJSONObject("daily")?:JSONObject();val daily=buildMap{val it=d.keys();while(it.hasNext()){val k=it.next();val v=d.optJSONObject(k)?:JSONObject();val status=v.optString("status","हाजिरी नहीं");if(validDate(k)&&k.startsWith(month)&&status in setOf("उपस्थित","आधा दिन","अनुपस्थित","छुट्टी","भांजी"))put(k,SalaryDay(if(status=="अनुपस्थित"||status=="छुट्टी")"भांजी" else status,v.optString("note","")))}};val pa=o.optJSONArray("payments")?:JSONArray();val payments=(0 until pa.length()).mapNotNull{idx->val v=pa.optJSONObject(idx)?:return@mapNotNull null;val date=v.optString("date");val amount=v.optDouble("amount",0.0);if(validDate(date)&&date.startsWith(month)&&amount>0.0)SalaryPayment(date,amount,v.optString("note")) else null};SalaryMonth(o.optInt("absentDays",0),o.optDouble("advance",0.0),o.optDouble("paid",0.0),daily,o.optDouble("salaryAtMonth",0.0),payments)}.getOrDefault(SalaryMonth())
private fun saveSalaryMonth(context:Context,id:String,month:String,r:SalaryMonth){
    require(isValidSalaryMonth(month)) { "सही महीना चुनें।" }
    val d=JSONObject()
    r.daily.filter{(date,v)->validDate(date)&&date.startsWith(month)&&v.status in setOf("उपस्थित","आधा दिन","अनुपस्थित","छुट्टी","भांजी")}.forEach{(date,v)->d.put(date,JSONObject().put("status",v.status).put("note",v.note))}
    val payments=JSONArray()
    r.payments.filter{validDate(it.date)&&it.date.startsWith(month)&&it.amount.isFinite()&&it.amount>0.0}.forEach{payments.put(JSONObject().put("date",it.date).put("amount",it.amount).put("note",it.note))}
    require(r.advance.isFinite()&&r.advance>=0.0&&r.paid.isFinite()&&r.paid>=0.0&&r.salaryAtMonth.isFinite()&&r.salaryAtMonth>=0.0) { "सैलरी, एडवांस और भुगतान की रकम सही भरें।" }
    val saved = salaryPrefs(context).edit()
        .putString(salaryMonthKey(id, month), JSONObject().put("absentDays", r.absentDays.coerceAtLeast(0)).put("advance", r.advance).put("paid", r.paid).put("salaryAtMonth", r.salaryAtMonth).put("payments", payments).put("daily", d).toString())
        .commit()
    check(saved) { "Salary data could not be written to local storage." }
}
private fun isValidSalaryMonth(value:String):Boolean {
    if (!Regex("\\d{4}-(0[1-9]|1[0-2])").matches(value)) return false
    return runCatching {
        val parts=value.split("-")
        val calendar=Calendar.getInstance().apply {
            isLenient=false
            clear()
            set(Calendar.YEAR,parts[0].toInt())
            set(Calendar.MONTH,parts[1].toInt()-1)
            set(Calendar.DAY_OF_MONTH,1)
            timeInMillis
        }
        calendar.get(Calendar.YEAR).toString().padStart(4,'0') == parts[0] &&
            (calendar.get(Calendar.MONTH)+1).toString().padStart(2,'0') == parts[1]
    }.getOrDefault(false)
}
private fun monthDays(month:String):Int {
    if (!isValidSalaryMonth(month)) return 0
    return runCatching {
        val parts=month.split("-")
        Calendar.getInstance().apply {
            isLenient=false
            clear()
            set(Calendar.YEAR,parts[0].toInt())
            set(Calendar.MONTH,parts[1].toInt()-1)
            set(Calendar.DAY_OF_MONTH,1)
        }.getActualMaximum(Calendar.DAY_OF_MONTH)
    }.getOrDefault(0)
}

@Composable
private fun Dashboard(store:Store,onGo:(String)->Unit){
    val selectedDate = today()
    val dayAttendance = store.attendances.filter { it.date == selectedDate }
    val presentRows = dayAttendance.filter { it.fraction > 0.0 }
    val fullDays = presentRows.count { it.fraction >= 1.0 }
    val halfDays = presentRows.count { it.fraction > 0.0 && it.fraction < 1.0 }
    val absentCount = dayAttendance.count { it.fraction <= 0.0 }
    val wageTotal = dayAttendance.sumOf { it.fraction * it.rate }
    val paymentTotal = store.payments.filter { it.date == selectedDate }.sumOf { it.amount } +
        store.canePeelingPayments.filter { it.date == selectedDate }.sumOf { it.amount }
    val advanceTotal = store.labours.sumOf { worker -> store.balanceBreakdown(worker.id).advance }
    val expenseTotal = store.expenses.filter { it.date == selectedDate }.sumOf { it.amount }
    val saleTotal = store.sales.filter { it.date == selectedDate }.sumOf { it.total }
    // Outstanding uses the app's existing per-worker closure boundary: closed historical
    // accounting is not re-opened by the dashboard, and later payments remain included.
    val outstandingTotal = store.labours.sumOf { worker -> store.balanceBreakdown(worker.id).totalOutstanding }
    val recentAttendance = store.attendances.sortedByDescending { it.date }.take(3)
    val recentPayments = store.payments.sortedByDescending { it.date }.take(3)
    val todayText = displayDate(selectedDate)

    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("नमस्ते, किसान जी", fontSize = 13.sp, color = Green, fontWeight = FontWeight.SemiBold)
                Text("आज का हिसाब", fontSize = 27.sp, color = GreenDark, fontWeight = FontWeight.ExtraBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Green, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(todayText, color = Color(0xFF64736B), fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Surface(color = Color(0xFFE6F4EC), shape = RoundedCornerShape(20.dp)) {
                        Text("स्थानीय रिकॉर्ड", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = GreenDark, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = GreenDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("आज की मजदूरी", color = Color(0xFFD3EDE0), fontSize = 13.sp)
                            Text("₹${money(wageTotal)}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Groups, contentDescription = null, tint = Color.White, modifier = Modifier.size(29.dp))
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = .18f))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("उपस्थित", color = Color(0xFFD3EDE0), fontSize = 11.sp)
                            Text("${presentRows.size} मजदूर", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column {
                            Text("पूरा दिन", color = Color(0xFFD3EDE0), fontSize = 11.sp)
                            Text("$fullDays", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column {
                            Text("आधा दिन", color = Color(0xFFD3EDE0), fontSize = 11.sp)
                            Text("$halfDays", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column {
                            Text("अनुपस्थित", color = Color(0xFFD3EDE0), fontSize = 11.sp)
                            Text("$absentCount", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    Button(
                        onClick = { onGo("attendance_fields") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GreenDark)
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("आज की हाजरी", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }
            }
        }
        item {
            Text("आज का सारांश", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DashboardStat("₹", "मजदूरी", wageTotal, "आज की लेबर", Color(0xFFE4EEFF), Modifier.weight(1f))
                    DashboardStat("−", "खर्च", expenseTotal, "आज का खर्च", Color(0xFFFFF0DC), Modifier.weight(1f))
                    DashboardStat("+", "बिक्री", saleTotal, "आज की बिक्री", Color(0xFFE3F4E8), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DashboardStat("₹", "भुगतान/अग्रिम", paymentTotal, "आज भुगतान • एडवांस ₹${money(advanceTotal)}", Color(0xFFE6F1F4), Modifier.weight(1f))
                    DashboardStat("₹", "कुल बाकी", outstandingTotal, "मजदूरी का बाकी बकाया", Color(0xFFFFF0DC), Modifier.weight(1f))
                }
            }
        }
        item {
            ReorderableDashboardGrid(onGo = onGo)
        }
        item {
            Text("खेत और फसल का सारांश", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardCountStat("कुल खेत", store.fields.size, "सेव किए गए खेत", Color(0xFFF0F6EA), Modifier.weight(1f)) { onGo("field") }
                DashboardCountStat("कुल फसलें", store.crops.size, "सेव की गई फसलें", Color(0xFFEAF1F8), Modifier.weight(1f)) { onGo("crop") }
            }
        }
        item {
            Text("हाल की हाजिरी", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Spacer(Modifier.height(6.dp))
            if (recentAttendance.isEmpty()) {
                EmptyCard("अभी हाजिरी का कोई रिकॉर्ड नहीं है।")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    recentAttendance.forEach { row ->
                        val workerName = store.labours.firstOrNull { it.id == row.labourId }?.name ?: "मजदूर"
                        val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name.orEmpty()
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(workerName, fontWeight = FontWeight.Bold, color = GreenDark)
                                    Text(listOf(displayDate(row.date), fieldName).filter { it.isNotBlank() }.joinToString(" • "), fontSize = 11.sp, color = Color.Gray)
                                }
                                Text("₹${money(row.fraction * row.rate)}", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        item {
            Text("हाल के भुगतान", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GreenDark)
            Spacer(Modifier.height(6.dp))
            if (recentPayments.isEmpty()) {
                EmptyCard("अभी भुगतान का कोई रिकॉर्ड नहीं है।")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    recentPayments.forEach { row ->
                        val workerName = store.labours.firstOrNull { it.id == row.labourId }?.name ?: "मजदूर"
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(workerName, fontWeight = FontWeight.Bold, color = GreenDark)
                                    Text(displayDate(row.date), fontSize = 11.sp, color = Color.Gray)
                                }
                                Text("₹${money(row.amount)}", fontWeight = FontWeight.Bold, color = GreenDark)
                            }
                        }
                    }
                }
            }
        }
    }
}


internal data class DashboardShortcut(
    val id: String, val icon: String, val title: String, val subtitle: String,
    val detail: String, val color: Color, val route: String
)

private fun defaultDashboardShortcuts(): List<DashboardShortcut> = listOf(
    DashboardShortcut("field", "🌾", "खेत", "खेत प्रबंधन", "खेत • विवरण", Color(0xFFF0F6EA), "field"),
    DashboardShortcut("crop", "🌱", "फसल", "फसल प्रबंधन", "फसल • खर्च", Color(0xFFEAF1F8), "crop"),
    DashboardShortcut("expense", "₹", "खर्च", "खेती लागत", "खर्च • इतिहास", Color(0xFFF4F1E7), "expense"),
    DashboardShortcut("sale", "🧺", "बिक्री", "कमाई का हिसाब", "बिक्री • राशि", Color(0xFFF8ECE6), "sale"),
    DashboardShortcut("work_entry", "🧾", "काम दर्ज करें", "नई हाजिरी", "खेत • मजदूर • तारीख", Color(0xFFE8F4EC), "work_entry"),
    DashboardShortcut("work_list", "📋", "काम की सूची", "काम और मजदूरी", "रिकॉर्ड • विवरण", Color(0xFFEAF1F8), "work_list"),
    DashboardShortcut("rate_history", "📈", "मजदूरी-दर इतिहास", "दर में बदलाव", "लागू तारीख • रेट", Color(0xFFF4F1E7), "rate_history"),
    DashboardShortcut("profitability", "💹", "आय और मुनाफा", "खेतवार हिसाब", "बिक्री • लागत • लाभ", Color(0xFFF8ECE6), "profitability"),
    DashboardShortcut("cane", "🌾", "गन्ना पर्ची", "पर्ची जोड़ें/सूची", "सीजन • वजन • PDF", Color(0xFFF0F6EA), "cane"),
    DashboardShortcut("cane_peeling", "🌿", "गन्ना छिलाई", "फांदी/मजदूर", "रेट • भुगतान • बाकी", Color(0xFFE8F4EC), "cane_peeling"),
    DashboardShortcut("daily_labour", "👷", "दिहाड़ी मजदूर", "हाजिरी और हिसाब", "मजदूर • भुगतान • मासिक खाता", Color(0xFFE8F4EC), "daily_labour"),
    DashboardShortcut("salary_employees", "💼", "Salary Employee", "मासिक वेतन का अलग हिसाब", "कर्मचारी • हाजिरी • छुट्टी • भुगतान • बाकी", Color(0xFFE3F0FF), "salary_employees"),
    DashboardShortcut("reports", "📄", "रिपोर्ट सेंटर", "रिपोर्ट और PDF", "मजदूर • हाजिरी • खेत • मुनाफा", Color(0xFFEAF1F8), "reports"),
    DashboardShortcut("more", "⚙️", "सेटिंग व अन्य विकल्प", "सेटिंग और सुरक्षा", "Backup • Restore • अन्य सुविधाएँ", Color(0xFFEAF1F8), "more")
)

@Composable
private fun ReorderableDashboardGrid(onGo: (String) -> Unit) {
    val context = LocalContext.current
    val shortcuts = remember { defaultDashboardShortcuts() }
    val defaultIds = remember { shortcuts.map { it.id } }
    val savedIds = remember {
        settingString(context, "dashboard_shortcut_order_v1")
            .split(",").filter { it in defaultIds }.distinct()
            .let { it + defaultIds.filterNot(it::contains) }
    }
    val order = remember { mutableStateListOf<String>().apply { addAll(savedIds) } }
    val positions = remember { mutableStateMapOf<String, Rect>() }
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val moveThreshold = with(density) { 82.dp.toPx() }

    fun persistOrder() {
        saveSetting(context, "dashboard_shortcut_order_v1", order.joinToString(","))
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("होम स्क्रीन के विकल्प", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = GreenDark, modifier = Modifier.weight(1f))
            Text("लंबा दबाकर खींचें ↕", fontSize = 10.sp, color = Color(0xFF718078))
            TextButton(onClick = {
                order.clear()
                order.addAll(defaultIds)
                persistOrder()
            }) { Text("रीसेट", fontSize = 10.sp) }
        }
        order.toList().mapNotNull { id -> shortcuts.firstOrNull { it.id == id } }
            .chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    rowItems.forEach { shortcut ->
                        val isDragging = draggingId == shortcut.id
                        DashboardModule(
                            shortcut.icon, shortcut.title, shortcut.subtitle, shortcut.detail,
                            shortcut.color,
                            Modifier.weight(1f)
                                .graphicsLayer {
                                    translationX = if (isDragging) dragX else 0f
                                    translationY = if (isDragging) dragY else 0f
                                    shadowElevation = if (isDragging) 18f else 0f
                                    alpha = if (isDragging) 0.88f else 1f
                                }
                                .onGloballyPositioned { positions[shortcut.id] = it.boundsInRoot() }
                                .pointerInput(shortcut.id) {
                                    var startRect: Rect? = null
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = {
                                            draggingId = shortcut.id
                                            dragX = 0f; dragY = 0f
                                            startRect = positions[shortcut.id]
                                        },
                                        onDragCancel = {
                                            draggingId = null; dragX = 0f; dragY = 0f
                                        },
                                        onDragEnd = {
                                            draggingId = null; dragX = 0f; dragY = 0f
                                            persistOrder()
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragX += amount.x; dragY += amount.y
                                            val origin = startRect
                                            if (origin != null) {
                                                val centerX = origin.center.x + dragX
                                                val centerY = origin.center.y + dragY
                                                val target = positions.entries.filter { it.key != shortcut.id }
                                                    .minByOrNull { entry ->
                                                        val dx = entry.value.center.x - centerX
                                                        val dy = entry.value.center.y - centerY
                                                        dx * dx + dy * dy
                                                    }
                                                if (target != null) {
                                                    val dx = target.value.center.x - centerX
                                                    val dy = target.value.center.y - centerY
                                                    if (dx * dx + dy * dy <= moveThreshold * moveThreshold) {
                                                        val from = order.indexOf(shortcut.id)
                                                        val to = order.indexOf(target.key)
                                                        if (from >= 0 && to >= 0 && from != to) {
                                                            val moved = order.removeAt(from)
                                                            order.add(to, moved)
                                                            persistOrder()
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                        ) { onGo(shortcut.route) }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
    }
}

@Composable private fun DashboardStat(icon:String,label:String,value:Double,sub:String,bgColor:Color,modifier:Modifier=Modifier){Card(modifier=modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(icon,fontSize=21.sp);Text(label,fontSize=11.sp,color=GreenDark);Text("₹${money(value)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold);Text(sub,fontSize=9.sp,color=Color.Gray,maxLines=1)}}}

@Composable
private fun DashboardCountStat(label:String,value:Int,sub:String,bgColor:Color,modifier:Modifier=Modifier,onClick:()->Unit={}){
    Card(
        modifier.clickable(onClick=onClick),
        shape=RoundedCornerShape(18.dp),
        colors=CardDefaults.cardColors(containerColor=bgColor),
        elevation=CardDefaults.cardElevation(defaultElevation=0.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text("▦", fontSize=20.sp, color=Green)
            Text(label, fontSize=11.sp, color=GreenDark)
            Text(value.toString(), fontSize=22.sp, fontWeight=FontWeight.ExtraBold, color=GreenDark)
            Text(sub, fontSize=10.sp, color=Color.Gray, maxLines=1)
        }
    }
}

@Composable private fun DashboardModule(icon:String,title:String,subtitle:String,detail:String,bgColor:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.fillMaxWidth().padding(13.dp).heightIn(min=125.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.62f)),contentAlignment=Alignment.Center){Text(icon,fontSize=27.sp)};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=19.sp,fontWeight=FontWeight.ExtraBold);Text(subtitle,fontSize=10.sp,color=Color.DarkGray)};Icon(Icons.Default.ChevronRight,null,tint=GreenDark)};Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.72f)){Text(detail,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=9.sp,fontWeight=FontWeight.SemiBold,color=GreenDark,maxLines=1)}}}}

@Composable
private fun SummaryMoneyCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.heightIn(min = 82.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = accent, maxLines = 1)
        }
    }
}

@Composable private fun Stat(label:String,value:Double){
    val icon=when(label){"मजदूरी","Labour"->"👷";"खर्च","लागत","खेती खर्च"->"💰";"बिक्री","Sale"->"🧺";"भुगतान"->"💵";"बाकी"->"📌";"लाभ"->"📈";"कुल काम","कुल दिन","पूरा दिन","आधा दिन","मजदूर","कुल मजदूर","कुल खेत","कुल रिकॉर्ड","रिकॉर्ड","फांदी","कुल फांदी"->"📊";else->"📊"}
    val unit=when(label){"कुल काम","कुल दिन","पूरा दिन","आधा दिन"->" दिन";"मजदूर","कुल मजदूर"->" मजदूर";"कुल खेत"->" खेत";"कुल रिकॉर्ड","रिकॉर्ड"->" रिकॉर्ड";"फांदी","कुल फांदी"->" फांदी";else->null}
    val display=if(unit!=null) "${quantity(value)}$unit" else "₹${money(value)}"
    Card(Modifier.fillMaxWidth().heightIn(min=78.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=11.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=15.sp);Spacer(Modifier.width(5.dp));Text(label,fontSize=11.sp,color=Color.Gray,maxLines=1)}
            Text(display,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}
private fun money(v:Double)=String.format(Locale.US,"%.0f",v)
// Preserve fractional Fandi rates in inputs and rate labels; money() is intentionally whole-rupee for totals.
private fun formatFandiRate(v:Double)=String.format(Locale.US,"%.2f",v).trimEnd('0').trimEnd('.')
private fun quantity(v:Double)=String.format(Locale.US,"%.2f",v).trimEnd('0').trimEnd('.')
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
private fun validDate(v:String):Boolean{
    val value=v.trim()
    if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false
    return try{
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        f.isLenient=false
        val parsed=f.parse(value) ?: return false
        f.format(parsed)==value
    }catch(_:Exception){false}
}
private fun monthTitle(value:String):String{
    return try{
        val f=SimpleDateFormat("yyyy-MM",Locale.US).apply{isLenient=false}
        val d=f.parse(value) ?: return value
        SimpleDateFormat("MMMM yyyy",Locale("hi","IN")).format(d)
    }catch(_:Exception){value}
}
private fun displayDate(v:String):String{
    val value=v.trim()
    if(!validDate(value)) return value
    return try{
        val input=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
        val output=SimpleDateFormat("dd/MM/yyyy",Locale.US)
        output.format(input.parse(value)!!)
    }catch(_:Exception){value}
}

@Composable
private fun PhotoThumb(path:String,modifier:Modifier=Modifier.size(52.dp)){
    val bitmap=remember(path){if(path.isNotBlank()) runCatching{BitmapFactory.decodeFile(path)?.asImageBitmap()}.getOrNull() else null}
    if(bitmap!=null){
        Image(bitmap=bitmap,contentDescription=null,modifier=modifier.clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)
    }else{
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=22.sp)}
    }
}

@Composable
private fun RedesignMetric(label:String,value:String,modifier:Modifier=Modifier){
    Card(modifier,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=9.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(label,fontSize=10.sp,color=Color.Gray,maxLines=1)
            Text(value,fontSize=16.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark,maxLines=1)
        }
    }
}

@Composable
private fun LabourScreen(store:Store,onOpen:(String)->Unit,onAttendance:()->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    var edit by remember{mutableStateOf<Labour?>(null)}
    var delete by remember{mutableStateOf<Labour?>(null)}
    var protectedEdit by remember{mutableStateOf<Labour?>(null)}
    var protectedDelete by remember{mutableStateOf<Labour?>(null)}
    val workers = store.labours.asReversed().filter { l ->
        val q=normalizeSearch(query)
        q.isBlank() || searchMatches(q, l.name, l.address, l.mobile)
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp, vertical=12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("मजदूर",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                Text("मजदूरों की सूची और उनका हिसाब",fontSize=12.sp,color=Color.Gray)
            }
            FilledTonalButton(onClick={edit=Labour("","","",0.0,"","")}, shape=RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Add,contentDescription=null); Spacer(Modifier.width(5.dp)); Text("जोड़ें")
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            RedesignMetric("कुल मजदूर",store.labours.size.toString(),Modifier.weight(1f))
            RedesignMetric("आज काम पर",store.attendances.filter{it.date==today()&&it.fraction>0.0}.map{it.labourId}.distinct().size.toString(),Modifier.weight(1f))
            RedesignMetric("आज की मजदूरी","₹${money(store.attendances.filter{it.date==today()}.sumOf{it.fraction*it.rate})}",Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
            placeholder={Text("नाम, मोबाइल या पता खोजें")},leadingIcon={Icon(Icons.Default.Search,contentDescription="खोजें")},
            trailingIcon={if(query.isNotBlank()) IconButton(onClick={query=""}){Icon(Icons.Default.Close,contentDescription="खोज साफ करें")} },
            shape=RoundedCornerShape(16.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White))
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick=onAttendance,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.CalendarMonth,contentDescription=null); Spacer(Modifier.width(8.dp)); Text("हाजिरी दर्ज करें")
        }
        Spacer(Modifier.height(10.dp))
        if(workers.isEmpty()) {
            EmptyCard(if(query.isBlank()) "अभी कोई मजदूर दर्ज नहीं है। ‘जोड़ें’ से पहला मजदूर जोड़ें।" else "इस खोज से कोई मजदूर नहीं मिला।")
        } else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=16.dp)) {
            item { Text("मजदूर (${workers.size})",fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark) }
            items(workers,key={it.id}){l->
                val todayRows=store.attendances.filter{it.labourId==l.id&&it.date==today()}
                val todayWage=todayRows.sumOf{it.fraction*it.rate}
                Card(Modifier.fillMaxWidth().clickable{onOpen(l.id)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp)) {
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        PhotoThumb(l.photo,Modifier.size(54.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=15.sp,color=Color(0xFF18352A),maxLines=1)
                            Text(if(l.mobile.isNotBlank()) l.mobile else l.address.ifBlank{"मोबाइल/पता नहीं दिया"},fontSize=11.sp,color=Color.Gray,maxLines=1)
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Surface(color=Color(0xFFE8F5EC),shape=RoundedCornerShape(8.dp)){Text("₹${money(store.rateFor(l.id,today()))}/दिन",Modifier.padding(horizontal=7.dp,vertical=3.dp),fontSize=10.sp,color=GreenDark,fontWeight=FontWeight.SemiBold)}
                                if(todayRows.isNotEmpty()){Spacer(Modifier.width(5.dp));Text("आज ₹${money(todayWage)}",fontSize=10.sp,color=GreenDark)}
                            }
                        }
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            IconButton(onClick={protectedEdit=l},modifier=Modifier.size(36.dp)){Icon(Icons.Default.Edit,contentDescription="मजदूर बदलें",tint=Green)}
                            IconButton(onClick={protectedDelete=l},modifier=Modifier.size(36.dp)){Icon(Icons.Default.DeleteOutline,contentDescription="मजदूर हटाएँ",tint=Color(0xFFB3261E))}
                        }
                    }
                }
            }
        }
    }
    if(edit!=null) LabourDialog(store,edit!!.takeIf{it.id.isNotBlank()}){edit=null}
    protectedEdit?.let{item->DeviceCredentialGate("मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("मजदूर हटाएँ","मजदूर और उससे जुड़े attendance, payment तथा rate history हटाने के लिए Android screen lock से पुष्टि करें।",{delete=item;protectedDelete=null},{protectedDelete=null})}
    val deleteContext=LocalContext.current
    if(delete!=null) ConfirmDialog("मजदूर हटाएँ?","यदि इस मजदूर की हाजिरी, भुगतान, दिहाड़ी इतिहास या फांदी रिकॉर्ड है, तो रिकॉर्ड सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteLabour(delete!!.id);delete=null;if(!ok)android.widget.Toast.makeText(deleteContext,"इस मजदूर का पुराना हिसाब मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{delete=null})
}
@Composable private fun LabourDialog(store:Store,existing:Labour?,onClose:()->Unit){
    var name by rememberSaveable{mutableStateOf(existing?.name?:"")}
    var address by rememberSaveable{mutableStateOf(existing?.address?:"")}
    var rate by rememberSaveable{mutableStateOf(if(existing==null||existing.rate==0.0)"" else money(existing.rate))}
    var mobile by rememberSaveable{mutableStateOf(existing?.mobile?:"")}
    var photo by rememberSaveable{mutableStateOf(existing?.photo?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank()) photo=persisted}
    }
    SimpleDialog(if(existing==null)"मजदूर जोड़ें" else "मजदूर बदलें",onClose){
        AppTextField(value=name,onValueChange={name=it;error=""},label={Text("मजदूर का नाम *")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        AppTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true)
        AppTextField(value=rate,onValueChange={rate=it},label={Text("रुपये/दिन (Optional)")},singleLine=true)
        AppTextField(value=mobile,onValueChange={mobile=it},label={Text("मोबाइल (Optional)")},singleLine=true)
        OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")}
        Button(onClick={
            when {
                name.isBlank()->error="मजदूर का नाम लिखना जरूरी है।"
                store.labourNameExists(name,existing?.id)->error="इस नाम का मजदूर पहले से मौजूद है। नाम में फर्क करके ही सेव करें।"
                else->{
                    val x=Labour(ownerId,name.trim().replace(Regex("\\s+")," "),address,rate.toDoubleOrNull()?:0.0,mobile,photo)
                    val saved=if(existing==null)store.addLabour(x) else store.updateLabour(x)
                    if(saved) onClose() else error="मजदूर सेव नहीं हुआ। नाम जाँचें।"
                }
            }
        },modifier=Modifier.fillMaxWidth()){Text("मजदूर सेव करें")}
    }
}

@Composable
private fun FieldScreen(store:Store,onOpen:(String)->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    var add by rememberSaveable{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Field?>(null)}
    var del by remember{mutableStateOf<Field?>(null)}
    var protectedEdit by remember{mutableStateOf<Field?>(null)}
    var protectedDelete by remember{mutableStateOf<Field?>(null)}
    val fields=store.fields.filter{f->searchMatches(query, f.name, f.address, f.area)}
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=12.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("मेरे खेत",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("खेत, रकबा और खेती का हिसाब",fontSize=12.sp,color=Color.Gray)};FilledTonalButton(onClick={add=true},shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,contentDescription=null);Spacer(Modifier.width(4.dp));Text("खेत जोड़ें")}}
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){RedesignMetric("कुल खेत",store.fields.size.toString(),Modifier.weight(1f));RedesignMetric("फसलें",store.crops.size.toString(),Modifier.weight(1f));RedesignMetric("खेती खर्च","₹${money(store.expenses.sumOf{it.amount})}",Modifier.weight(1f))}
        Spacer(Modifier.height(12.dp))
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("खेत का नाम, स्थान या रकबा खोजें")},leadingIcon={Icon(Icons.Default.Search,contentDescription="खोजें")},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Close,contentDescription="खोज साफ करें")}},shape=RoundedCornerShape(16.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White))
        Spacer(Modifier.height(10.dp))
        if(fields.isEmpty()) EmptyCard(if(query.isBlank())"अभी कोई खेत दर्ज नहीं है। ‘खेत जोड़ें’ से शुरू करें।" else "इस खोज से कोई खेत नहीं मिला।")
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=16.dp)) {
            item{Text("खेत (${fields.size})",fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark)}
            items(fields,key={it.id}){f->
                val crops=store.crops.count{it.fieldId==f.id};val cost=store.attendances.filter{it.fieldId==f.id}.sumOf{it.fraction*it.rate}+store.expenses.filter{it.fieldId==f.id}.sumOf{it.amount};val revenue=store.sales.filter{it.fieldId==f.id}.sumOf{it.total}
                Card(Modifier.fillMaxWidth().clickable{onOpen(f.id)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp)) {
                    Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically){PhotoThumb(f.photo,Modifier.size(52.dp));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(f.name.ifBlank{"खेत का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark);Text(listOf(f.area.ifBlank{"रकबा नहीं दिया"},f.address).filter{it.isNotBlank()}.joinToString(" • "),fontSize=11.sp,color=Color.Gray,maxLines=2)};IconButton(onClick={protectedEdit=f}){Icon(Icons.Default.Edit,contentDescription="खेत बदलें",tint=Green)}}
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Surface(Modifier.weight(1f),color=Color(0xFFEAF6EF),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("फसलें",fontSize=10.sp,color=Color.Gray);Text(crops.toString(),fontWeight=FontWeight.Bold,color=GreenDark)}};Surface(Modifier.weight(1f),color=Color(0xFFF4F6F4),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("लागत",fontSize=10.sp,color=Color.Gray);Text("₹${money(cost)}",fontWeight=FontWeight.Bold,color=GreenDark,maxLines=1)}};Surface(Modifier.weight(1f),color=Color(0xFFF4F6F4),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("बिक्री",fontSize=10.sp,color=Color.Gray);Text("₹${money(revenue)}",fontWeight=FontWeight.Bold,color=GreenDark,maxLines=1)}}}
                        Row(verticalAlignment=Alignment.CenterVertically){Text("खेत का विवरण खोलें",Modifier.weight(1f),fontSize=11.sp,color=Color.Gray);IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,contentDescription="खेत ऊपर करें",tint=Green)};IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,contentDescription="खेत नीचे करें",tint=Green)};IconButton(onClick={protectedDelete=f}){Icon(Icons.Default.DeleteOutline,contentDescription="खेत हटाएँ",tint=Color(0xFFB3261E))}}
                    }
                }
            }
        }
    }
    if(add)FieldDialog(store,null){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("खेत बदलें","खेत की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खेत हटाएँ","खेत और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FieldDialog(store,edit!!){edit=null}
    val fieldContext=LocalContext.current
    if(del!=null)ConfirmDialog("खेत हटाएँ?","यदि इस खेत से फसल, खर्च, बिक्री, हाजिरी, भुगतान या फांदी रिकॉर्ड जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteField(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(fieldContext,"इस खेत का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun FieldDialog(store:Store,existing:Field?,onClose:()->Unit){
    var name by remember(existing?.id){mutableStateOf(existing?.name?:"")}
    var addr by remember(existing?.id){mutableStateOf(existing?.address?:"")}
    var area by remember(existing?.id){mutableStateOf(existing?.area?:"")}
    var photo by remember(existing?.id){mutableStateOf(existing?.photo?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank())photo=persisted}
    }
    SimpleDialog(if(existing==null)"खेत जोड़ें" else "खेत बदलें",onClose){
        AppTextField(value=name,onValueChange={name=it;error=""},label={Text("खेत का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        AppTextField(value=addr,onValueChange={addr=it},label={Text("पता/स्थान (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        AppTextField(value=area,onValueChange={area=it},label={Text("रकबा (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"खेत की फोटो (Optional)" else "✓ खेत की फोटो चुनी गई")}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={
            val normalized=name.trim().replace(Regex("\\s+")," ")
            when{
                normalized.isBlank()->error="खेत का नाम लिखना जरूरी है।"
                store.fields.any{it.id!=existing?.id && it.name.trim().replace(Regex("\\s+")," ").equals(normalized,ignoreCase=true)}->error="इस नाम का खेत पहले से मौजूद है। अलग नाम लिखें।"
                else->{val x=Field(ownerId,normalized,addr.trim(),area.trim(),photo);if(existing==null)store.addField(x) else store.updateField(x);onClose()}
            }
        },modifier=Modifier.fillMaxWidth()){Text("खेत सेव करें")}
    }
}

@Composable
private fun CropScreen(store:Store,preField:String?,onOpen:(String)->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    var add by rememberSaveable{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Crop?>(null)}
    var del by remember{mutableStateOf<Crop?>(null)}
    var protectedEdit by remember{mutableStateOf<Crop?>(null)}
    var protectedDelete by remember{mutableStateOf<Crop?>(null)}
    val crops=store.crops.filter{c->(preField==null||c.fieldId==preField)&&run{val f=store.fields.firstOrNull{it.id==c.fieldId};searchMatches(query, c.name, c.variety, c.season, f?.name)}}
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=12.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("फसलें",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("फसल, किस्म और सीजन",fontSize=12.sp,color=Color.Gray)};FilledTonalButton(onClick={add=true},shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,contentDescription=null);Spacer(Modifier.width(4.dp));Text("फसल जोड़ें")}}
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){RedesignMetric("कुल फसलें",store.crops.size.toString(),Modifier.weight(1f));RedesignMetric("खेत",store.fields.size.toString(),Modifier.weight(1f));RedesignMetric("कुल बिक्री","₹${money(store.sales.sumOf{it.total})}",Modifier.weight(1f))}
        Spacer(Modifier.height(12.dp))
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("फसल, किस्म, सीजन या खेत खोजें")},leadingIcon={Icon(Icons.Default.Search,contentDescription="खोजें")},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Close,contentDescription="खोज साफ करें")}},shape=RoundedCornerShape(16.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White))
        Spacer(Modifier.height(10.dp))
        if(crops.isEmpty()) EmptyCard(if(query.isBlank())"अभी कोई फसल दर्ज नहीं है। ‘फसल जोड़ें’ से शुरू करें।" else "इस खोज से कोई फसल नहीं मिली।")
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=16.dp)) {
            item{Text("फसल सूची (${crops.size})",fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark)}
            items(crops,key={it.id}){c->
                val f=store.fields.firstOrNull{it.id==c.fieldId};val expense=store.expenses.filter{it.cropId==c.id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==c.id}.sumOf{it.total};val wages=store.attendances.filter{it.cropId==c.id}.sumOf{it.fraction*it.rate}
                Card(Modifier.fillMaxWidth().clickable{onOpen(c.id)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp)){
                    Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F5EC)),contentAlignment=Alignment.Center){Text("🌱",fontSize=24.sp)};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(c.name.ifBlank{"फसल का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark);Text(f?.name?:"खेत नहीं चुना",fontSize=11.sp,color=Color.Gray);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=11.sp,color=Color.Gray)};IconButton(onClick={protectedEdit=c}){Icon(Icons.Default.Edit,contentDescription="फसल बदलें",tint=Green)};IconButton(onClick={protectedDelete=c}){Icon(Icons.Default.DeleteOutline,contentDescription="फसल हटाएँ",tint=Color(0xFFB3261E))}}
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Surface(Modifier.weight(1f),color=Color(0xFFF4F6F4),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("मजदूरी",fontSize=10.sp,color=Color.Gray);Text("₹${money(wages)}",fontWeight=FontWeight.Bold,fontSize=12.sp,color=GreenDark,maxLines=1)}};Surface(Modifier.weight(1f),color=Color(0xFFF4F6F4),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("खर्च",fontSize=10.sp,color=Color.Gray);Text("₹${money(expense)}",fontWeight=FontWeight.Bold,fontSize=12.sp,color=GreenDark,maxLines=1)}};Surface(Modifier.weight(1f),color=Color(0xFFEAF6EF),shape=RoundedCornerShape(10.dp)){Column(Modifier.padding(8.dp)){Text("बिक्री",fontSize=10.sp,color=Color.Gray);Text("₹${money(sale)}",fontWeight=FontWeight.Bold,fontSize=12.sp,color=GreenDark,maxLines=1)}}}
                    }
                }
            }
        }
    }
    if(add)CropDialog(store,null,preField){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("फसल बदलें","फसल की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("फसल हटाएँ","फसल और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)CropDialog(store,edit!!,null){edit=null}
    val cropContext=LocalContext.current
    if(del!=null)ConfirmDialog("फसल हटाएँ?","यदि इस फसल से खर्च, बिक्री, हाजिरी या भुगतान जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteCrop(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(cropContext,"इस फसल का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun CropDialog(store:Store,existing:Crop?,preField:String?,onClose:()->Unit){var name by rememberSaveable{mutableStateOf(existing?.name?:"")};var field by rememberSaveable{mutableStateOf(existing?.fieldId?:preField?:store.fields.firstOrNull()?.id?:"")};var variety by rememberSaveable{mutableStateOf(existing?.variety?:"")};var sow by rememberSaveable{mutableStateOf(existing?.sowingDate?:"")};var season by rememberSaveable{mutableStateOf(existing?.season?:SimpleDateFormat("yyyy",Locale.US).format(Date()))};var error by rememberSaveable{mutableStateOf("")};SimpleDialog(if(existing==null)"फसल जोड़ें" else "फसल बदलें",onClose){AppTextField(value=name,onValueChange={name=it;error=""},label={Text("फसल का नाम *")},singleLine=true);ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it};AppTextField(value=variety,onValueChange={variety=it},label={Text("किस्म (Optional)")},singleLine=true);AppTextField(value=sow,onValueChange={sow=it},label={Text("बुवाई तारीख YYYY-MM-DD (Optional)")},singleLine=true);AppTextField(value=season,onValueChange={season=it},label={Text("Season")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={when{ name.isBlank()->error="फसल का नाम डालें"; field.isBlank()->error="खेत चुनें"; store.crops.any{it.id!=existing?.id&&it.fieldId==field&&it.name.trim().equals(name.trim(),ignoreCase=true)}->error="इस खेत में इसी नाम की फसल पहले से है।"; !sow.isBlank()&&!validDate(sow)->error="सही बुवाई तारीख डालें: YYYY-MM-DD"; else->{error="";val x=Crop(existing?.id?:UUID.randomUUID().toString(),field,name.trim(),variety.trim(),sow.trim(),season.trim());val saved=if(existing==null)store.addCrop(x) else store.updateCrop(x);if(saved)onClose() else error="इस फसल के पुराने रिकॉर्ड हैं; खेत बदलना या डुप्लिकेट फसल बनाना संभव नहीं है।"}}},modifier=Modifier.fillMaxWidth()){Text("फसल सेव करें")}}}

@Composable
private fun ExpenseScreen(store:Store,preField:String?,preCrop:String?,onSaved:()->Unit){
    var edit by remember{mutableStateOf<Expense?>(null)}
    var add by rememberSaveable{mutableStateOf(false)}
    var del by remember{mutableStateOf<Expense?>(null)}
    var protectedEdit by remember{mutableStateOf<Expense?>(null)}
    var protectedDelete by remember{mutableStateOf<Expense?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    val all=store.expenses.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    val list=all.filter{e->val fieldName=store.fields.firstOrNull{it.id==e.fieldId}?.name.orEmpty();val cropName=store.crops.firstOrNull{it.id==e.cropId}?.name.orEmpty();searchMatches(query,e.type,e.item,e.date,displayDate(e.date),fieldName,cropName,e.qty,e.unit,money(e.amount),"₹${money(e.amount)}")}
    val visibleTotal=list.sumOf{it.amount}
    val scopeExpenses=all.sumOf{it.amount}
    val scopeWages=store.attendances.filter{it.fraction>0.0 && (preField==null || it.fieldId==preField) && (preCrop==null || it.cropId==preCrop)}.sumOf{attendanceWage(it.fraction,it.rate)}
    val scopeRevenue=store.sales.filter{(preField==null || it.fieldId==preField) && (preCrop==null || it.cropId==preCrop)}.sumOf{it.total}
    val scopeTotalCost=scopeExpenses+scopeWages
    val scopeProfit=fieldProfit(scopeRevenue,scopeExpenses,scopeWages)
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        SectionTitle("खर्च","खेत और फसल के खर्च का हिसाब"){add=true}
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
            Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("लागत और मुनाफा सारांश",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){RedesignMetric("खेती खर्च","₹${money(scopeExpenses)}",Modifier.fillMaxWidth())}
                    Box(Modifier.weight(1f)){RedesignMetric("मजदूरी लागत","₹${money(scopeWages)}",Modifier.fillMaxWidth())}
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){RedesignMetric("कुल लागत","₹${money(scopeTotalCost)}",Modifier.fillMaxWidth())}
                    Box(Modifier.weight(1f)){RedesignMetric("बिक्री","₹${money(scopeRevenue)}",Modifier.fillMaxWidth())}
                }
                Text("अनुमानित लाभ/हानि: ₹${money(scopeProfit)}",fontWeight=FontWeight.ExtraBold,color=if(scopeProfit>=0)GreenDark else Color(0xFFB3261E),fontSize=16.sp)
                Text("यह सारांश चुने हुए खेत/फसल के सभी सेव रिकॉर्ड पर आधारित है; खोज टेक्स्ट इसे नहीं बदलता।",fontSize=10.sp,color=Color.Gray)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Box(Modifier.weight(1f)){RedesignMetric("खोज परिणाम",list.size.toString())}
            Box(Modifier.weight(1f)){RedesignMetric("दिखाया गया खर्च","₹${money(visibleTotal)}")}
        }
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp),label={Text("खर्च, खेत, तारीख खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Close,"खोज साफ करें")}})
        if(list.isEmpty())EmptyCard(if(all.isEmpty())"अभी कोई खर्च दर्ज नहीं है। + बटन से पहला खर्च जोड़ें।" else "इस खोज से कोई खर्च नहीं मिला। खोज बदलें या साफ करें।")
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(list,key={it.id}){e->
                val f=store.fields.firstOrNull{it.id==e.fieldId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE5EEE8))){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF6EF)),contentAlignment=Alignment.Center){Icon(Icons.Default.ReceiptLong,null,tint=Green)}
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                            Text(e.type+if(e.item.isNotBlank())" • ${e.item}" else "",fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(e.date)}",fontSize=12.sp,color=Color.Gray)
                            Text("₹${money(e.amount)}",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
                        }
                        IconButton(onClick={protectedEdit=e},modifier=Modifier.size(40.dp)){Icon(Icons.Default.Edit,"खर्च बदलें",tint=Green)}
                        IconButton(onClick={protectedDelete=e},modifier=Modifier.size(40.dp)){Icon(Icons.Default.Delete,"खर्च हटाएँ",tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)ExpenseDialog(store,edit?:Expense(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),"बीज","","","",0.0,today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("खर्च बदलें","खर्च की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खर्च हटाएँ","खर्च रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)ExpenseDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("खर्च हटाएँ?","यह खर्च रिकॉर्ड हट जाएगा.",{store.deleteExpense(del!!.id);del=null},{del=null})
}
@Composable private fun ExpenseDialog(store:Store,existing:Expense,onClose:()->Unit,isEdit:Boolean){var field by rememberSaveable{mutableStateOf(existing.fieldId)};var crop by rememberSaveable{mutableStateOf(existing.cropId)};var type by rememberSaveable{mutableStateOf(existing.type)};var item by rememberSaveable{mutableStateOf(existing.item)};var qty by rememberSaveable{mutableStateOf(existing.qty)};var unit by rememberSaveable{mutableStateOf(existing.unit)};var amount by rememberSaveable{mutableStateOf(if(existing.amount==0.0)"" else money(existing.amount))};var date by rememberSaveable{mutableStateOf(existing.date)};var error by rememberSaveable{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"खर्च बदलें" else "खर्च जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};ChoiceField("खर्च का प्रकार",listOf("बीज" to "बीज","उर्वरक/खाद" to "उर्वरक/खाद","दवा/कीटनाशक" to "दवा/कीटनाशक","डीजल" to "डीजल","सिंचाई" to "सिंचाई","ट्रैक्टर/मशीन" to "ट्रैक्टर/मशीन","ढुलाई" to "ढुलाई","अन्य" to "अन्य"),type){type=it};AppTextField(value=item,onValueChange={item=it},label={Text("नाम (Optional)")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){AppTextField(value=qty,onValueChange={qty=it},modifier=Modifier.weight(1f),label={Text("मात्रा (Optional)")},singleLine=true);AppTextField(value=unit,onValueChange={unit=it},modifier=Modifier.weight(1f),label={Text("इकाई (Optional)")},singleLine=true)};AppTextField(value=amount,onValueChange={amount=it},label={Text("रकम")},singleLine=true);AppTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=amount.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";n==null||n<=0||!n.isFinite()->error="सही रकम दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,type=type,item=item,qty=qty,unit=unit,amount=n,date=date.trim());val saved=if(isEdit)store.updateExpense(x) else store.addExpense(x);if(saved)onClose() else error="खर्च सेव नहीं हुआ। खेत/फसल का मेल, तारीख और रकम जाँचें।"}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun WorkListScreen(store:Store,onBack:()->Unit,onAddWork:()->Unit,onWorker:(String)->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    var selected by rememberSaveable { mutableStateOf("") }
    val rows=store.attendances.sortedWith(compareByDescending<Attendance>{it.date}.thenBy{it.labourId}).filter { a ->
        val worker=store.labours.firstOrNull{it.id==a.labourId}?.name.orEmpty()
        val field=store.fields.firstOrNull{it.id==a.fieldId}?.name.orEmpty()
        val crop=store.crops.firstOrNull{it.id==a.cropId}?.name.orEmpty()
        val q=query.trim()
        q.isBlank() || listOf(worker,field,crop,a.date,displayDate(a.date),money(a.fraction*a.rate)).any{it.contains(q,ignoreCase=true)}
    }
    val total=rows.sumOf{it.fraction*it.rate}
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("काम और मजदूरी",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("हाजिरी में सेव हुए वास्तविक रिकॉर्ड",fontSize=12.sp,color=Color.Gray)};Button(onClick=onAddWork){Text("+ काम दर्ज")}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){RedesignMetric("रिकॉर्ड",rows.size.toString())};Box(Modifier.weight(1f)){RedesignMetric("कुल मजदूरी","₹${money(total)}")}}
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("मजदूर, खेत, फसल या तारीख खोजें")},leadingIcon={Icon(Icons.Default.Search,null)})
        if(rows.isEmpty()) EmptyCard(if(store.attendances.isEmpty())"अभी काम का कोई रिकॉर्ड नहीं है। काम दर्ज करें से हाजिरी जोड़ें।" else "इस खोज में कोई रिकॉर्ड नहीं मिला।")
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows,key={it.id}){a->
                val worker=store.labours.firstOrNull{it.id==a.labourId}
                val field=store.fields.firstOrNull{it.id==a.fieldId}
                val crop=store.crops.firstOrNull{it.id==a.cropId}
                val wage=a.fraction*a.rate
                Card(Modifier.fillMaxWidth().clickable{selected=if(selected==a.id)"" else a.id},shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE5EEE8))){
                    Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){Text(worker?.name?:"मजदूर रिकॉर्ड नहीं मिला",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("₹${money(wage)}",fontWeight=FontWeight.ExtraBold,color=Green)}
                        Text("${displayDate(a.date)} • ${field?.name?:"खेत नहीं चुना"}",fontSize=12.sp,color=Color.Gray)
                        Text("${crop?.name?.let{"फसल: $it • "}.orEmpty()}${when(a.fraction){1.0->"पूरा दिन";0.5->"आधा दिन";0.0->"भांजी / अनुपस्थित";else->"${quantity(a.fraction)} दिन"}} • दर ₹${money(a.rate)}",fontSize=12.sp,color=GreenDark)
                        if(selected==a.id){HorizontalDivider();Text("रिकॉर्ड विवरण",fontWeight=FontWeight.Bold);Text("मजदूर: ${worker?.name?:"हटाया गया"}");Text("खेत: ${field?.name?:"हटाया गया"}");Text("फसल: ${crop?.name?:"नहीं चुनी"}");Text("गणना: ${quantity(a.fraction)} दिन × ₹${money(a.rate)} = ₹${money(wage)}");if(worker!=null)TextButton(onClick={onWorker(worker.id)}){Text("मजदूर का पूरा लेजर देखें")}}
                    }
                }
            }
        }
    }
}

@Composable
private fun WageRateHistoryScreen(store:Store,onBack:()->Unit,onWorker:(String)->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    val rows=store.rates.sortedWith(compareByDescending<WageRate>{it.effectiveDate}.thenBy{it.labourId}).filter{r->val name=store.labours.firstOrNull{it.id==r.labourId}?.name.orEmpty();searchMatches(query,name,r.effectiveDate,displayDate(r.effectiveDate),money(r.rate))}
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("दिहाड़ी दर इतिहास",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Text("दर की लागू तारीख के अनुसार इतिहास। नई दर मजदूर के विवरण में ‘दिहाड़ी बदलें’ से जोड़ें।",fontSize=12.sp,color=Color.Gray)
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("मजदूर या तारीख खोजें")},leadingIcon={Icon(Icons.Default.Search,null)})
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){RedesignMetric("दर रिकॉर्ड",rows.size.toString())};Box(Modifier.weight(1f)){RedesignMetric("मजदूर",rows.map{it.labourId}.distinct().size.toString())}}
        if(rows.isEmpty())EmptyCard(if(store.rates.isEmpty())"अलग दर इतिहास अभी दर्ज नहीं है। मजदूर का वर्तमान रेट उसकी प्रोफाइल में उपलब्ध है; नई तारीख से रेट बदलने पर इतिहास बनेगा।" else "इस खोज में कोई दर नहीं मिली।")
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows,key={it.id}){r->val worker=store.labours.firstOrNull{it.id==r.labourId};Card(Modifier.fillMaxWidth().clickable{worker?.let{onWorker(it.id)}},shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE5EEE8))){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(worker?.name?:"मजदूर रिकॉर्ड नहीं मिला",fontWeight=FontWeight.Bold);Text("${displayDate(r.effectiveDate)} से लागू",fontSize=12.sp,color=Color.Gray)};Text("₹${money(r.rate)}/दिन",fontWeight=FontWeight.ExtraBold,color=Green)}}}
        }
    }
}

@Composable
private fun ProfitabilityScreen(store:Store,onBack:()->Unit,onField:(String)->Unit){
    var query by rememberSaveable { mutableStateOf("") }
    val rows=store.fields.map{f->
        val wage=store.attendances.filter{it.fieldId==f.id}.sumOf{it.fraction*it.rate}
        val expense=store.expenses.filter{it.fieldId==f.id}.sumOf{it.amount}
        val revenue=store.sales.filter{it.fieldId==f.id}.sumOf{it.total}
        Triple(f, revenue, Pair(wage+expense,revenue-(wage+expense)))
    }.filter{(f,_,_)->searchMatches(query,f.name,f.address)}
    val revenue=rows.sumOf{it.second};val cost=rows.sumOf{it.third.first};val profit=revenue-cost
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("आय और मुनाफा",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Text("सहेजे गए बिक्री, मजदूरी और खेती खर्च से गणना। गन्ना पर्ची/छिलाई का हिसाब इस सार में अलग से शामिल नहीं है।",fontSize=12.sp,color=Color.Gray)
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){RedesignMetric("बिक्री / आय","₹${money(revenue)}")};Box(Modifier.weight(1f)){RedesignMetric("लागत","₹${money(cost)}")}}
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=if(profit>=0)Color(0xFFE7F6EC) else Color(0xFFFFEDEA))){Column(Modifier.padding(14.dp)){Text("अनुमानित शुद्ध लाभ",fontSize=12.sp,color=Color.Gray);Text("₹${money(profit)}",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=if(profit>=0)GreenDark else Color(0xFFB3261E));Text("आय − (मजदूरी + खेती खर्च)",fontSize=11.sp,color=Color.Gray)}}
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("खेत खोजें")},leadingIcon={Icon(Icons.Default.Search,null)})
        if(rows.isEmpty())EmptyCard("इस खोज से कोई खेत नहीं मिला।")
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows,key={it.first.id}){(f,sale,costProfit)->
                val wage=store.attendances.filter{it.fieldId==f.id}.sumOf{it.fraction*it.rate};val expense=store.expenses.filter{it.fieldId==f.id}.sumOf{it.amount}
                Card(Modifier.fillMaxWidth().clickable{onField(f.id)},shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE5EEE8))){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(f.name,fontWeight=FontWeight.Bold,fontSize=16.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("आय",fontSize=12.sp,color=Color.Gray);Text("₹${money(sale)}",fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("मजदूरी",fontSize=12.sp,color=Color.Gray);Text("₹${money(wage)}")};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("अन्य खेती खर्च",fontSize=12.sp,color=Color.Gray);Text("₹${money(expense)}")};HorizontalDivider();Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("अनुमानित लाभ",fontWeight=FontWeight.Bold);Text("₹${money(costProfit.second)}",fontWeight=FontWeight.ExtraBold,color=if(costProfit.second>=0)Green else Color(0xFFB3261E))}}}
            }
        }
    }
}

@Composable
private fun SaleScreen(store:Store,preField:String?,preCrop:String?){
    var edit by remember{mutableStateOf<Sale?>(null)}
    var add by rememberSaveable{mutableStateOf(false)}
    var del by remember{mutableStateOf<Sale?>(null)}
    var protectedEdit by remember{mutableStateOf<Sale?>(null)}
    var protectedDelete by remember{mutableStateOf<Sale?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    val all=store.sales.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    val list=all.filter{s->val f=store.fields.firstOrNull{it.id==s.fieldId}?.name.orEmpty();val cropName=store.crops.firstOrNull{it.id==s.cropId}?.name.orEmpty();searchMatches(query,s.buyer,s.date,displayDate(s.date),s.unit,f,cropName,quantity(s.qty),quantity(s.rate),money(s.total),"₹${money(s.total)}")}
    val visibleTotal=list.sumOf{it.total}
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        SectionTitle("बिक्री","उपज और आय का रिकॉर्ड"){add=true}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Box(Modifier.weight(1f)){RedesignMetric("कुल रिकॉर्ड",list.size.toString())}
            Box(Modifier.weight(1f)){RedesignMetric("दिखाई गई आय","₹${money(visibleTotal)}")}
        }
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp),label={Text("खेत, खरीदार, तारीख खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Close,"खोज साफ करें")}})
        if(list.isEmpty())EmptyCard(if(all.isEmpty())"अभी कोई बिक्री दर्ज नहीं है। + बटन से पहली बिक्री जोड़ें।" else "इस खोज से कोई बिक्री नहीं मिली। खोज बदलें या साफ करें।")
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(list,key={it.id}){s->
                val f=store.fields.firstOrNull{it.id==s.fieldId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE5EEE8))){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF6EF)),contentAlignment=Alignment.Center){Icon(Icons.Default.TrendingUp,null,tint=Green)}
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                            Text("${quantity(s.qty)} ${s.unit} × ₹${money(s.rate)}",fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(s.date)}",fontSize=12.sp,color=Color.Gray)
                            if(s.buyer.isNotBlank())Text("खरीदार: ${s.buyer}",fontSize=12.sp,color=Color.Gray)
                            Text("₹${money(s.total)}",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=Green)
                        }
                        IconButton(onClick={protectedEdit=s},modifier=Modifier.size(40.dp)){Icon(Icons.Default.Edit,"बिक्री बदलें",tint=Green)}
                        IconButton(onClick={protectedDelete=s},modifier=Modifier.size(40.dp)){Icon(Icons.Default.Delete,"बिक्री हटाएँ",tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)SaleDialog(store,edit?:Sale(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),0.0,"क्विंटल",0.0,0.0,"",today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("बिक्री बदलें","बिक्री की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("बिक्री हटाएँ","बिक्री रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)SaleDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("बिक्री हटाएँ?","यह बिक्री रिकॉर्ड हट जाएगा.",{store.deleteSale(del!!.id);del=null},{del=null})
}
@Composable private fun SaleDialog(store:Store,existing:Sale,onClose:()->Unit,isEdit:Boolean){
    var field by rememberSaveable{mutableStateOf(existing.fieldId)}
    var crop by rememberSaveable{mutableStateOf(existing.cropId)}
    var qty by rememberSaveable{mutableStateOf(if(existing.qty==0.0)"" else quantity(existing.qty))}
    var unit by rememberSaveable{mutableStateOf(existing.unit)}
    var rate by rememberSaveable{mutableStateOf(if(existing.rate==0.0)"" else quantity(existing.rate))}
    var buyer by rememberSaveable{mutableStateOf(existing.buyer)}
    var date by rememberSaveable{mutableStateOf(existing.date)}
    var error by rememberSaveable{mutableStateOf("")}
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""}
    val q=qty.toDoubleOrNull(); val r=rate.toDoubleOrNull()
    val total=(q?:0.0)*(r?:0.0)
    fun saveSale(){
        when {
            field.isBlank()->error="खेत चुनें"
            q==null||q<=0||!q.isFinite()->error="सही मात्रा दर्ज करें"
            unit.isBlank()->error="इकाई दर्ज करें"
            r==null||r<=0||!r.isFinite()->error="सही दर दर्ज करें"
            !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
            else->{
                val x=existing.copy(fieldId=field,cropId=crop,qty=q,unit=unit.trim(),rate=r,total=q*r,buyer=buyer.trim(),date=date.trim())
                val saved=if(isEdit) store.updateSale(x) else store.addSale(x)
                if(saved){error="";onClose()}else error="बिक्री सेव नहीं हुई। खेत/फसल का मेल, तारीख, मात्रा और दर जाँचें।"
            }
        }
    }
    AlertDialog(
        onDismissRequest={},
        title={Text(if(isEdit)"बिक्री बदलें" else "बिक्री जोड़ें",fontWeight=FontWeight.Bold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
            ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""}
            ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it}
            AppTextField(value=qty,onValueChange={qty=it},label={Text("मात्रा")},singleLine=true,modifier=Modifier.fillMaxWidth())
            AppTextField(value=unit,onValueChange={unit=it},label={Text("इकाई (क्विंटल/किलो/टन आदि)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            AppTextField(value=rate,onValueChange={rate=it},label={Text("दर प्रति इकाई (₹)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            AppTextField(value=buyer,onValueChange={buyer=it},label={Text("खरीदार (वैकल्पिक)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            AppTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Text("कुल रकम: ₹${money(total)}",fontWeight=FontWeight.Bold,color=GreenDark)
            if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        }},
        confirmButton={Button(onClick={saveSale()},modifier=Modifier.fillMaxWidth()){Text(if(isEdit)"बिक्री सेव करें" else "बिक्री सेव करें",fontWeight=FontWeight.Bold)}},
        dismissButton={TextButton(onClick=onClose){Text("रद्द करें")}}
    )
}

@Composable
private fun DeviceCredentialGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
){
    val context=LocalContext.current
    var noLock by rememberSaveable{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        if(result.resultCode==Activity.RESULT_OK) onUnlocked() else onCancel()
    }
    LaunchedEffect(Unit){
        val host=context as? Activity
        val km=context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(!km.isKeyguardSecure){
            noLock=true
        }else{
            fun launchDeviceCredential(){
                val intent=km.createConfirmDeviceCredentialIntent(title,message)
                if(intent!=null) launcher.launch(intent) else onCancel()
            }
            if(settingBool(context, "biometric_enabled", true) && android.os.Build.VERSION.SDK_INT >= 28 && host != null){
                // Prefer biometric authentication where Android supports it; the negative action
                // and unavailable/error path safely fall back to the device PIN/pattern/password.
                runCatching {
                    PlatformBiometricPrompt.Builder(host)
                        .setTitle(title)
                        .setSubtitle(message)
                        .setNegativeButton("फोन का PIN / Pattern इस्तेमाल करें", host.mainExecutor) { _, _ ->
                            launchDeviceCredential()
                        }
                        .build()
                        .authenticate(CancellationSignal(), host.mainExecutor, object:PlatformBiometricPrompt.AuthenticationCallback(){
                            override fun onAuthenticationSucceeded(result:PlatformBiometricPrompt.AuthenticationResult){
                                onUnlocked()
                            }
                            override fun onAuthenticationError(errorCode:Int, errString:CharSequence){
                                if(errorCode != PlatformBiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED) launchDeviceCredential()
                                else onCancel()
                            }
                        })
                }.onFailure { launchDeviceCredential() }
            }else{
                launchDeviceCredential()
            }
        }
    }
    if(noLock){
        AlertDialog(
            onDismissRequest=onCancel,
            title={Text("Android Screen Lock जरूरी है")},
            text={Text("इस रिकॉर्ड को बदलने या हटाने के लिए फोन में PIN, Pattern या Password screen lock चालू होना चाहिए।")},
            confirmButton={Button(onClick=onCancel){Text("ठीक है")}}
        )
    }
}

@Composable
private fun DeviceCredentialDeleteGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
)=DeviceCredentialGate(title,message,onUnlocked,onCancel)

private fun isNotFutureDate(value:String):Boolean{
    return validDate(value) && value<=today()
}

@Composable
private fun AttendanceDateButton(value:String,onDateSelected:(String)->Unit){
    val context=LocalContext.current
    val parsed=try{
        SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value)
    }catch(_:Exception){Date()}
    OutlinedButton(
        onClick={
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(
                context,
                {_,year,month,day->
                    val selected=Calendar.getInstance().apply{
                        set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                    }
                    val formatted=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time)
                    if(formatted<=today()) onDateSelected(formatted)
                },
                cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)
            ).apply{
                datePicker.maxDate=System.currentTimeMillis()
            }.show()
        },
        modifier=Modifier.fillMaxWidth()
    ){
        Icon(Icons.Default.CalendarMonth,null)
        Spacer(Modifier.width(7.dp))
        Text("हाजिरी तारीख: ${displayDate(value)}")
    }
}

@Composable
private fun AttendanceSummaryPill(label:String,value:String,bg:Color,modifier:Modifier=Modifier){
    Surface(modifier=modifier, color=bg, shape=RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal=7.dp, vertical=9.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value, fontSize=17.sp, fontWeight=FontWeight.ExtraBold, color=GreenDark)
            Text(label, fontSize=9.sp, color=GreenDark, maxLines=1)
        }
    }
}

@Composable
private fun AttendanceScreen(store:Store,preField:String?,onBack:()->Unit){
    val context=LocalContext.current
    var selectedDate by rememberSaveable{mutableStateOf(today())}
    var activeField by rememberSaveable{mutableStateOf(preField?:store.fields.firstOrNull()?.id?:"")}
    var activeCrop by rememberSaveable{mutableStateOf("")}
    var attendanceQuery by rememberSaveable{mutableStateOf("")}
    var attendanceFilter by rememberSaveable{mutableStateOf("सभी")}
    var attendanceError by rememberSaveable{mutableStateOf("")}
    var addLabour by rememberSaveable{mutableStateOf(false)}
    var deleteAttendance by remember{mutableStateOf<Attendance?>(null)}
    var protectedAttendanceEdit by remember{mutableStateOf<Pair<Attendance,Double>?>(null)}
    var pendingBulkAttendanceAction by rememberSaveable{mutableStateOf("")}
    val field=store.fields.firstOrNull{it.id==activeField}
    val crops=store.crops.filter{it.fieldId==activeField}
    val attendanceWorkers = store.labours.asReversed().filter { worker ->
        val q = attendanceQuery.trim().lowercase(Locale.ROOT)
        val matchesQuery = q.isBlank() || worker.name.lowercase(Locale.ROOT).contains(q) || worker.mobile.contains(q) || worker.address.lowercase(Locale.ROOT).contains(q)
        val record = store.attendances.firstOrNull { it.labourId==worker.id && it.fieldId==activeField && it.date==selectedDate }
        val matchesStatus = when(attendanceFilter) {
            "दर्ज नहीं" -> record == null
            "पूरा दिन" -> record?.fraction == 1.0
            "आधा दिन" -> record?.fraction == 0.5
            "भांजी/Absent" -> record?.fraction == 0.0
            else -> true
        }
        matchesQuery && matchesStatus
    }
    val selectedFieldRows = store.attendances.filter { it.fieldId==activeField && it.date==selectedDate }
    val fullDayCount = selectedFieldRows.count { it.fraction==1.0 }
    val halfDayCount = selectedFieldRows.count { it.fraction==0.5 }
    val absentCount = selectedFieldRows.count { it.fraction==0.0 }
    val presentCount = selectedFieldRows.count { it.fraction>0.0 }
    LaunchedEffect(activeField){activeCrop=if(crops.size==1)crops.first().id else ""}

    val credentialDelete=deleteAttendance

    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📅 हाजिरी • ${displayDate(selectedDate)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.item{
                Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(15.dp)){
                        Text("🌾 ${field?.name ?: "खेत चुनें"}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Spacer(Modifier.height(8.dp))
                        AttendanceDateButton(selectedDate){selectedDate=it;attendanceError=""}
                        Spacer(Modifier.height(6.dp))
                        Text("आज या पिछली तारीख की हाजिरी लगाएँ। आगे की तारीख की हाजिरी नहीं लगेगी।",fontSize=11.sp,color=Color.Gray)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick={addLabour=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("+ मजदूर जोड़ें",fontWeight=FontWeight.Bold)}
                    }
                }
            }
            if(preField.isNullOrBlank()) this.item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.padding(14.dp)){
                        Text("🌾 खेत चुनें",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            store.fields.forEach{f->
                                val fieldName=f.name.ifBlank { "खेत" }
                                FilterChip(
                                    selected=f.id==activeField,
                                    onClick={activeField=f.id;attendanceError=""},
                                    label={Text("🌾 $fieldName")}
                                )
                            }
                        }
                        if(field!=null&&crops.size>1){
                            Spacer(Modifier.height(8.dp))
                            ChoiceField("फसल",crops.map{it.id to it.name},activeCrop){activeCrop=it;attendanceError=""}
                        }
                    }
                }
            }
            if(attendanceError.isNotBlank()) this.item{
                val isSuccess=attendanceError.contains("सफलतापूर्वक") || attendanceError.contains("सेव हो गई")
                Card(colors=CardDefaults.cardColors(containerColor=if(isSuccess)Color(0xFFE5F5EA) else Color(0xFFFFE8E6)),shape=RoundedCornerShape(14.dp)){
                    Text((if(isSuccess)"✓ " else "⚠ ")+attendanceError,Modifier.padding(12.dp),color=if(isSuccess)GreenDark else Color(0xFFB3261E),fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                }
            }
            if(field!=null){
                this.item{
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("मजदूरों की हाजिरी",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                        Text("${displayDate(selectedDate)}",fontSize=11.sp,color=Color.Gray)
                    }
                }
                this.item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        AttendanceSummaryPill("उपस्थित", presentCount.toString(), Color(0xFFE5F5EA), Modifier.weight(1f))
                        AttendanceSummaryPill("पूरा दिन", fullDayCount.toString(), Color(0xFFEAF2FF), Modifier.weight(1f))
                        AttendanceSummaryPill("आधा दिन", halfDayCount.toString(), Color(0xFFF0EAFE), Modifier.weight(1f))
                        AttendanceSummaryPill("Absent", absentCount.toString(), Color(0xFFFFE8E6), Modifier.weight(1f))
                    }
                }
                this.item {
                    Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Text("⚡ एक साथ हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=15.sp)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick={pendingBulkAttendanceAction="all_full"},modifier=Modifier.weight(1f)) {
                                Icon(Icons.Default.DoneAll,null); Spacer(Modifier.width(4.dp)); Text("सब पूरा दिन",maxLines=1,fontSize=11.sp)
                            }
                            OutlinedButton(onClick={pendingBulkAttendanceAction="previous_team"},modifier=Modifier.weight(1f)) {
                                Icon(Icons.Default.Groups,null); Spacer(Modifier.width(4.dp)); Text("पिछली टीम",maxLines=1,fontSize=11.sp)
                            }
                            OutlinedButton(onClick={pendingBulkAttendanceAction="clear_all"},modifier=Modifier.weight(1f),colors=ButtonDefaults.outlinedButtonColors(contentColor=Color(0xFFB3261E))) {
                                Icon(Icons.Default.DeleteSweep,null); Spacer(Modifier.width(4.dp)); Text("सब साफ",maxLines=1,fontSize=11.sp)
                            }
                        }
                        Text("ये कार्रवाई चुनी तारीख और खेत पर लागू होगी; आगे की तारीख, लॉक महीने और फाइनल हिसाब सुरक्षित रहेंगे।",fontSize=10.sp,color=Color.Gray)
                    }
                }
                this.item {
                    AppTextField(
                        value=attendanceQuery, onValueChange={attendanceQuery=it},
                        modifier=Modifier.fillMaxWidth(), singleLine=true,
                        placeholder={Text("मजदूर का नाम, मोबाइल या पता खोजें")},
                        leadingIcon={Icon(Icons.Default.Search, contentDescription="खोजें")},
                        trailingIcon={if(attendanceQuery.isNotBlank()) IconButton(onClick={attendanceQuery=""}) { Icon(Icons.Default.Close, contentDescription="खोज साफ करें") }},
                        shape=RoundedCornerShape(15.dp),
                        colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White, focusedContainerColor=Color.White)
                    )
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        listOf("सभी", "दर्ज नहीं", "पूरा दिन", "आधा दिन", "भांजी/Absent").forEach { status ->
                            FilterChip(selected=attendanceFilter==status, onClick={attendanceFilter=status}, label={Text(status)})
                        }
                    }
                    if(attendanceWorkers.isEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        EmptyCard(if(attendanceQuery.isBlank() && attendanceFilter=="सभी") "इस खेत में मजदूर दर्ज नहीं हैं।" else "इस खोज या फ़िल्टर से कोई मजदूर नहीं मिला।")
                    }
                }
                this.items(attendanceWorkers,key={it.id}){l->
                    val a=store.attendances.firstOrNull{it.labourId==l.id&&it.fieldId==activeField&&it.date==selectedDate}
                    val totalForLabour=store.attendances.filter{it.labourId==l.id&&it.date==selectedDate}.sumOf{it.fraction}
                    val remaining=(1.0-totalForLabour+(a?.fraction?:0.0)).coerceAtLeast(0.0)
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                        Column(Modifier.padding(13.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=24.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp)
                                    Text("दिहाड़ी ₹${money(store.rateFor(l.id,selectedDate))}/दिन",fontSize=11.sp,color=Color.Gray)
                                }
                                if(a!=null) Text(if(a.fraction==1.0)"✓ पूरा दिन" else if(a.fraction==0.5)"✓ आधा दिन" else if(a.fraction==0.0)"✓ भांजी (नहीं आया)" else "✓ ${money(a.fraction)} दिन",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                val fullSelected = a?.fraction == 1.0
                                val halfSelected = a?.fraction == 0.5
                                val bhanjiSelected = a?.fraction == 0.0
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.9999 || fullSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,1.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,1.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(fullSelected) Green else Color.White,
                                        contentColor=if(fullSelected) Color.White else Green
                                    ),
                                    border=if(fullSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Green)
                                ){Text(if(fullSelected)"✓ पूरा दिन" else "पूरा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.5 || halfSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.5)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.5,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(halfSelected) Color(0xFF6B4BC1) else Color.White,
                                        contentColor=if(halfSelected) Color.White else Color(0xFF6B4BC1)
                                    ),
                                    border=if(halfSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFF6B4BC1))
                                ){Text(if(halfSelected)"✓ आधा दिन" else "आधा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"भांजी दर्ज हो गई। इस दिन मजदूरी ₹0 रहेगी।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(bhanjiSelected) Color(0xFFB3261E) else Color.White,
                                        contentColor=if(bhanjiSelected) Color.White else Color(0xFFB3261E)
                                    ),
                                    border=if(bhanjiSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFFB3261E))
                                ){Text(if(bhanjiSelected)"✓ भांजी" else "भांजी",fontWeight=FontWeight.Bold)}
                                if(a!=null){
                                    IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                }
                            }
                        }
                    }
                }
            }
            if(store.fields.isEmpty()) this.item{Text("पहले Field में खेत जोड़ें।",color=Color.Gray)}
            if(store.labours.isEmpty()) this.item{Text("पहले Labour में मजदूर जोड़ें।",color=Color.Gray)}

            this.item{
                Text("इस तारीख की लगी हुई हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
            }
            this.items(store.attendances.filter{it.date==selectedDate&&it.fraction>0.0}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}),key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}",fontSize=11.sp,color=Color.Gray)
                        }
                        IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }

        if(addLabour) LabourDialog(store,null){addLabour=false}

    if(pendingBulkAttendanceAction.isNotBlank() && !pendingBulkAttendanceAction.startsWith("confirm:")) {
        val action = pendingBulkAttendanceAction
        val title = when(action){"all_full"->"सभी की पूरी हाजिरी";"clear_all"->"इस दिन की हाजिरी साफ करें";else->"पिछली टीम लगाएँ"}
        val message = when(action) {
            "all_full" -> "${displayDate(selectedDate)} को ${field?.name ?: "चुने खेत"} के सभी मजदूरों को पूरा दिन दर्ज किया जाएगा। मौजूदा रिकॉर्ड बदले जा सकते हैं।"
            "clear_all" -> "${displayDate(selectedDate)} को ${field?.name ?: "चुने खेत"} की सभी हाजिरी हटाई जाएगी। लॉक या फाइनल रिकॉर्ड नहीं हटेंगे।"
            else -> "पिछली तारीख की इसी खेत वाली उपस्थित टीम को ${displayDate(selectedDate)} पर लागू किया जाएगा। मौजूदा रिकॉर्ड बदल सकते हैं।"
        }
        AlertDialog(
            onDismissRequest={pendingBulkAttendanceAction=""},
            title={Text(title)},
            text={Text(message)},
            confirmButton={Button(onClick={
                pendingBulkAttendanceAction = "confirm:$action"
            }){Text("आगे बढ़ें")}},
            dismissButton={TextButton(onClick={pendingBulkAttendanceAction=""}){Text("रद्द करें")}}
        )
    }
    if(pendingBulkAttendanceAction.startsWith("confirm:")) {
        val action = pendingBulkAttendanceAction.removePrefix("confirm:")
        DeviceCredentialGate(
            when(action){"all_full"->"सभी की हाजिरी बदलें";"clear_all"->"हाजिरी साफ करें";else->"पिछली टीम लागू करें"},
            "एक साथ हाजिरी बदलने के लिए Android screen lock या biometric से पुष्टि करें।",
            {
                val rows = store.attendances.filter { it.fieldId==activeField && it.date==selectedDate }.toList()
                var changed=0
                var skipped=0
                when(action) {
                    "all_full" -> {
                        store.labours.forEach { worker ->
                            val existing=store.attendances.firstOrNull { it.labourId==worker.id && it.fieldId==activeField && it.date==selectedDate }
                            val cropId=activeCrop.ifBlank { existing?.cropId ?: crops.singleOrNull()?.id.orEmpty() }
                            if(crops.size>1 && cropId.isBlank()) { skipped++; return@forEach }
                            val result=store.upsertAttendance(Attendance(existing?.id ?: UUID.randomUUID().toString(),worker.id,activeField,cropId,selectedDate,1.0,store.rateFor(worker.id,selectedDate)))
                            if(result==null) changed++ else skipped++
                        }
                    }
                    "clear_all" -> {
                        rows.forEach { row -> if(store.deleteAttendance(row.id)) changed++ else skipped++ }
                    }
                    "previous_team" -> {
                        val previousDate=try {
                            val parsed=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(selectedDate)
                            Calendar.getInstance().apply { time=parsed ?: Date(); add(Calendar.DAY_OF_MONTH,-1) }
                                .let { SimpleDateFormat("yyyy-MM-dd",Locale.US).format(it.time) }
                        } catch(_:Exception) { "" }
                        val previousRows=store.attendances.filter { it.fieldId==activeField && it.date==previousDate && it.fraction>0.0 }
                        if(previousRows.isEmpty()) {
                            attendanceError="पिछली तारीख (${displayDate(previousDate)}) पर इस खेत में उपस्थित टीम का रिकॉर्ड नहीं मिला।"
                        } else {
                            previousRows.forEach { prior ->
                                val existing=store.attendances.firstOrNull { it.labourId==prior.labourId && it.fieldId==activeField && it.date==selectedDate }
                                val cropId=prior.cropId.takeIf { id -> crops.any { it.id==id } } ?: activeCrop.ifBlank { crops.singleOrNull()?.id.orEmpty() }
                                if(crops.size>1 && cropId.isBlank()) { skipped++; return@forEach }
                                val result=store.upsertAttendance(Attendance(existing?.id ?: UUID.randomUUID().toString(),prior.labourId,activeField,cropId,selectedDate,prior.fraction,store.rateFor(prior.labourId,selectedDate)))
                                if(result==null) changed++ else skipped++
                            }
                        }
                    }
                }
                if(action!="previous_team" || changed>0) attendanceError=when(action) {
                    "all_full" -> "एक साथ पूरी हाजिरी: $changed सेव, $skipped छोड़े गए।"
                    "clear_all" -> "हाजिरी साफ: $changed हटाए गए, $skipped सुरक्षित/लॉक रिकॉर्ड नहीं हटे।"
                    else -> "पिछली टीम: $changed रिकॉर्ड सेव, $skipped छोड़े गए।"
                }
                pendingBulkAttendanceAction=""
            },
            {pendingBulkAttendanceAction=""}
        )
    }
    protectedAttendanceEdit?.let{pending->
            DeviceCredentialGate(
                "हाजिरी बदलें",
                "हाजिरी का पूरा दिन, आधा दिन या भांजी बदलने के लिए Android screen lock से पुष्टि करें।",
                {
                    val a=pending.first
                    val result=store.upsertAttendance(a.copy(fraction=pending.second,rate=store.rateFor(a.labourId,a.date)))
                    attendanceError=result?:"हाजिरी सफलतापूर्वक बदली गई।"
                    protectedAttendanceEdit=null
                },
                {protectedAttendanceEdit=null}
            )
        }

        credentialDelete?.let{a->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                {val deleted=store.deleteAttendance(a.id);deleteAttendance=null;attendanceError=if(deleted)"हाजिरी सफलतापूर्वक हटाई गई।" else "इस मजदूर का हिसाब फाइनल है; पुरानी हाजिरी नहीं हटाई जा सकती।"},
                {deleteAttendance=null}
            )
        }
    }
}

@Composable private fun FieldDetail(store:Store,id:String,onBack:()->Unit,onCrop:(String)->Unit,onAttendance:(String)->Unit,onExpense:()->Unit,onSale:()->Unit,onAddCrop:()->Unit){val f=store.fields.firstOrNull{it.id==id}?:return;val crops=store.crops.filter{it.fieldId==id};val labourCost=store.attendances.filter{it.fieldId==id}.sumOf{it.fraction*it.rate};val exp=store.expenses.filter{it.fieldId==id}.sumOf{it.amount};val sale=store.sales.filter{it.fieldId==id}.sumOf{it.total};val total=labourCost+exp;val linkIssues=store.fieldCropIntegrityIssues(fieldId=id);Column(Modifier.fillMaxSize()){DetailTopBar("🌾 ${f.name.ifBlank{"खेत"}}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){if(linkIssues.isNotEmpty())item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF1D6))){Column(Modifier.padding(12.dp)){Text("खेत/फसल रिकॉर्ड मिलान चेतावनी",fontWeight=FontWeight.Bold,color=Color(0xFF8A4B00));Text("${linkIssues.size} पुराने रिकॉर्ड का लिंक जाँचने की जरूरत है। इन्हें चुपचाप किसी दूसरे खेत में नहीं जोड़ा गया।",fontSize=12.sp,color=Color(0xFF8A4B00))}}};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",total)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-total)}}};this.item{SmallAction("👷 Labour / हाजिरी",{onAttendance(id)})};this.item{SmallAction("💰 खेती का खर्च",onExpense)};this.item{SmallAction("🧺 Sale",onSale)};this.item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("🌱 फसल",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp);IconButton(onClick=onAddCrop){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}};this.items(crops,key={it.id}){c->Card(Modifier.fillMaxWidth().clickable{onCrop(c.id)},RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)}}};this.item{Text("कुल मजदूरी: ₹${money(labourCost)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल खेती खर्च: ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल लागत: ₹${money(total)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल बिक्री: ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{Text("लाभ: ₹${money(sale-total)}",fontWeight=FontWeight.Bold,color=Green)}}}}

@Composable
private fun TodayAttendanceScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val day=today()
    val rows=store.attendances.filter{it.date==day}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId})
    val total=rows.sumOf{it.fraction*it.rate}
    val workerCount=rows.filter{it.fraction>0.0}.map{it.labourId}.distinct().size
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 आज की हाजिरी • ${displayDate(day)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){Stat("कुल मजदूर",workerCount.toDouble())}
                    Box(Modifier.weight(1f)){Stat("कुल मजदूरी",total)}
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"})},
                    onPdf={exportReportPdf(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"},background=true)}
                )
            }
            items(rows.filter{it.fraction>0.0},key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}; val f=store.fields.firstOrNull{it.id==a.fieldId}; val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("👷",fontSize=24.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""}",fontSize=11.sp,color=Color.Gray)}
                        Surface(shape=RoundedCornerShape(10.dp),color=if(a.fraction==1.0) Color(0xFFE0F5E8) else Color(0xFFE9E0FF)){Text(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",Modifier.padding(horizontal=9.dp,vertical=6.dp),fontSize=11.sp,fontWeight=FontWeight.Bold,color=if(a.fraction==1.0)Green else Color(0xFF6B4BC1))}
                        Spacer(Modifier.width(8.dp));Text("₹${money(a.fraction*a.rate)}",fontWeight=FontWeight.Bold)
                    }
                }
            }
            if(rows.none{it.fraction>0.0}) item{Text("आज कोई मजदूर काम पर नहीं आया।",color=Color.Gray)}
        }
    }
}

@Composable
private fun AttendanceHistoryScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val todayMonth=today().take(7)
    val earliestMonth=store.attendances.minOfOrNull{it.date.take(7)} ?: todayMonth
    var month by rememberSaveable{mutableStateOf(todayMonth)}
    var selectedCalendarDate by rememberSaveable{mutableStateOf(today())}
    val monthCal=remember(month){
        Calendar.getInstance().apply{
            time=try{SimpleDateFormat("yyyy-MM",Locale.US).apply{isLenient=false}.parse(month)?:Date()}catch(_:Exception){Date()}
            set(Calendar.DAY_OF_MONTH,1)
        }
    }
    val daysInMonth=monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstOffset=monthCal.get(Calendar.DAY_OF_WEEK)-Calendar.SUNDAY
    val calendarCells=(List(firstOffset){0}+(1..daysInMonth).toList()).let{cells->cells+List((7-cells.size%7)%7){0}}
    val weeks=calendarCells.chunked(7)
    val allMonthRows=store.attendances.filter{it.date.startsWith(month)}.sortedByDescending{it.date}
    // Keep absent (fraction == 0) rows in calendar detail AND exported PDF.
    val rows=allMonthRows
    val total=allMonthRows.sumOf{it.fraction*it.rate}
    val dayGroups=allMonthRows.groupBy{it.date}.toList().sortedByDescending{it.first}
    val dayMap=allMonthRows.groupBy{it.date}
    val selectedRows=allMonthRows.filter{it.date==selectedCalendarDate}
    val selectedWage=selectedRows.sumOf{it.fraction*it.rate}
    fun shiftMonth(value:String,delta:Int):String{
        val cal=Calendar.getInstance().apply{
            time=try{SimpleDateFormat("yyyy-MM",Locale.US).parse(value)?:Date()}catch(_:Exception){Date()}
            set(Calendar.DAY_OF_MONTH,1);add(Calendar.MONTH,delta)
        }
        return SimpleDateFormat("yyyy-MM",Locale.US).format(cal.time)
    }
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 हाजिरी कैलेंडर",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            IconButton(enabled=month>earliestMonth,onClick={month=shiftMonth(month,-1);selectedCalendarDate="${month}-01"}){Icon(Icons.Default.ChevronLeft,null)}
                            Text(monthTitle(month),Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.ExtraBold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(enabled=month<todayMonth,onClick={month=shiftMonth(month,1);selectedCalendarDate="${month}-01"}){Icon(Icons.Default.ChevronRight,null)}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Box(Modifier.weight(1f)){Stat("रिकॉर्ड दिन",dayMap.keys.size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूर",rows.map{it.labourId}.distinct().size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूरी",total)}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){RedesignMetric("आधे दिन",allMonthRows.count{it.fraction==0.5}.toString(),Modifier.fillMaxWidth())}
                            Box(Modifier.weight(1f)){RedesignMetric("अनुपस्थित",allMonthRows.count{it.fraction==0.0}.toString(),Modifier.fillMaxWidth())}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(2.dp)){
                            listOf("रवि","सोम","मंगल","बुध","गुरु","शुक्र","शनि").forEach{day->
                                Box(Modifier.weight(1f).height(28.dp),contentAlignment=Alignment.Center){Text(day,fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray)}
                            }
                        }
                        weeks.forEach{week->
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(2.dp)){
                                week.forEach{day->
                                    if(day==0){
                                        Box(Modifier.weight(1f).height(48.dp))
                                    }else{
                                        val date=String.format(Locale.US,"%s-%02d",month,day)
                                        val records=dayMap[date].orEmpty()
                                        val hasPresent=records.any{it.fraction>0.0}
                                        val hasAbsent=records.any{it.fraction==0.0}
                                        val selected=date==selectedCalendarDate
                                        Surface(
                                            modifier=Modifier.weight(1f).height(48.dp).clickable{selectedCalendarDate=date},
                                            shape=RoundedCornerShape(10.dp),
                                            color=when{
                                                selected->Green
                                                records.isNotEmpty()->Color(0xFFE5F5EA)
                                                else->Color.Transparent
                                            },
                                            border=if(selected)null else androidx.compose.foundation.BorderStroke(0.7.dp,if(records.isNotEmpty())Color(0xFFB9DCC8) else Color(0xFFE6EBE8))
                                        ){
                                            Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
                                                Text(day.toString(),fontSize=13.sp,fontWeight=if(selected)FontWeight.ExtraBold else FontWeight.Medium,color=if(selected)Color.White else MaterialTheme.colorScheme.onSurface)
                                                if(records.isNotEmpty()){
                                                    Text("${records.size} ${if(hasAbsent)"•" else if(hasPresent)"●" else ""}",fontSize=8.sp,color=if(selected)Color.White else if(hasAbsent)Color(0xFFB3261E) else GreenDark,maxLines=1)
                                                }else{
                                                    Spacer(Modifier.height(10.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("● रिकॉर्ड वाला दिन",fontSize=10.sp,color=GreenDark)
                            Text("• अनुपस्थिति रिकॉर्ड",fontSize=10.sp,color=Color(0xFFB3261E))
                        }
                        Text("तारीख चुनें; नीचे उसी दिन के सेव किए गए वास्तविक रिकॉर्ड दिखेंगे।",fontSize=11.sp,color=Color.Gray)
                    }
                }
            }
            item{
                Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                        Text("📅 ${displayDate(selectedCalendarDate)}",fontSize=17.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Text("${selectedRows.size} रिकॉर्ड • ${selectedRows.count{it.fraction>0.0}} उपस्थित • ${selectedRows.count{it.fraction==0.0}} अनुपस्थित",fontSize=12.sp,color=Color.Gray)
                        Text("इस दिन की मजदूरी: ₹${money(selectedWage)}",fontWeight=FontWeight.Bold,color=GreenDark)
                    }
                }
            }
            if(selectedRows.isNotEmpty()){
                items(selectedRows,key={it.id}){a->
                    val labour=store.labours.firstOrNull{it.id==a.labourId}
                    val field=store.fields.firstOrNull{it.id==a.fieldId}
                    val crop=store.crops.firstOrNull{it.id==a.cropId}
                    val absent=a.fraction==0.0
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                                Text(labour?.name?:"मजदूर हटाया गया",fontWeight=FontWeight.Bold)
                                Text("${field?.name?:"खेत हटाया गया"}${crop?.name?.let{" • $it"}?:""}",fontSize=11.sp,color=Color.Gray)
                                Text(when(a.fraction){1.0->"पूरा दिन";0.5->"आधा दिन";0.0->"भांजी / अनुपस्थित";else->"${money(a.fraction)} दिन"},fontSize=12.sp,fontWeight=FontWeight.Bold,color=if(absent)Color(0xFFB3261E) else Green)
                            }
                            Text("₹${money(a.fraction*a.rate)}",fontWeight=FontWeight.ExtraBold,color=if(absent)Color.Gray else GreenDark)
                        }
                    }
                }
            }else{
                item{EmptyCard("इस तारीख का कोई हाजिरी रिकॉर्ड सेव नहीं है।")}
            }
            item{
                ExportButtons(
                    onPhoto={exportAttendanceHistoryPhoto(context,"हाजिरी_सूची_$month",month,dayGroups,store)},
                    onPdf={exportAttendanceHistoryPdf(context,"हाजिरी_सूची_$month",month,dayGroups,store)}
                )
            }
            if(rows.isEmpty()) item{Text("इस महीने कोई उपस्थित हाजिरी रिकॉर्ड नहीं है।",color=Color.Gray)}
        }
    }
}

@Composable
private fun LabourDetail(
    store: Store,
    id: String,
    onBack: () -> Unit
) {
    val l = store.labours.firstOrNull { it.id == id } ?: return
    val context=LocalContext.current

    var edit by remember { mutableStateOf(false) }
    var payment by remember { mutableStateOf(false) }
    var editPayment by remember { mutableStateOf<Payment?>(null) }
    var rate by remember { mutableStateOf(false) }
    var protectedRateEdit by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var delAttendance by remember { mutableStateOf<Attendance?>(null) }

    val lastClosedThrough=store.latestClosure(id)?.throughDate.orEmpty()
    val currentAttendance=store.attendances.filter{it.labourId==id&&it.date>lastClosedThrough}
    val currentPayments=store.payments.filter{it.labourId==id&&it.date>lastClosedThrough}
    val wage = currentAttendance.filter{it.fraction>0.0}.sumOf { it.fraction * it.rate }
    val paid = currentPayments.sumOf { it.amount }
    val balanceBreakdown=store.balanceBreakdown(id)
    var ledgerQuery by rememberSaveable(id) { mutableStateOf("") }
    var attendanceStatus by rememberSaveable(id) { mutableStateOf("सभी") }
    val filteredAttendance = currentAttendance.sortedByDescending { it.date }.filter { a ->
        val fieldName = store.fields.firstOrNull { it.id == a.fieldId }?.name.orEmpty()
        val cropName = store.crops.firstOrNull { it.id == a.cropId }?.name.orEmpty()
        val q = ledgerQuery.trim().lowercase(Locale.ROOT)
        val matchesQuery = q.isBlank() || displayDate(a.date).lowercase(Locale.ROOT).contains(q) || fieldName.lowercase(Locale.ROOT).contains(q) || cropName.lowercase(Locale.ROOT).contains(q)
        val matchesStatus = when (attendanceStatus) {
            "पूरा दिन" -> a.fraction == 1.0
            "आधा दिन" -> a.fraction == 0.5
            "भांजी/Absent" -> a.fraction == 0.0
            else -> true
        }
        matchesQuery && matchesStatus
    }
    val filteredPayments = currentPayments.sortedByDescending { it.date }.filter { p ->
        val fieldName = store.fields.firstOrNull { it.id == p.fieldId }?.name.orEmpty()
        val cropName = store.crops.firstOrNull { it.id == p.cropId }?.name.orEmpty()
        val q = ledgerQuery.trim().lowercase(Locale.ROOT)
        q.isBlank() || displayDate(p.date).lowercase(Locale.ROOT).contains(q) || fieldName.lowercase(Locale.ROOT).contains(q) || cropName.lowercase(Locale.ROOT).contains(q) || money(p.amount).contains(q)
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar(
            "👷 ${l.name.ifBlank { "मजदूर" }}",
            onBack
        )

        LazyColumn(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            this.item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(1f)) { Stat("पुराना बाकी", balanceBreakdown.oldDue) }
                    Box(Modifier.weight(1f)) { Stat("चालू बाकी", balanceBreakdown.currentDue) }
                    Box(Modifier.weight(1f)) { Stat("कुल बाकी", balanceBreakdown.totalOutstanding) }
                }
            }

            this.item {
                store.latestClosure(id)?.let { closed ->
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                            Text("पुराना हिसाब फाइनल",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                            Text("${displayDate(closed.throughDate)} तक • मजदूरी ₹${money(closed.wage)} • भुगतान ₹${money(closed.paid)} • शुरुआती बाकी ₹${money((closed.wage-closed.paid).coerceAtLeast(0.0))}",fontSize=12.sp)
                            Text("बाद के भुगतान पहले पुराने बाकी में समायोजित होंगे। चालू बाकी ₹${money(balanceBreakdown.currentDue)} • कुल बाकी ₹${money(balanceBreakdown.totalOutstanding)} • एडवांस ₹${money(balanceBreakdown.advance)}",fontSize=11.sp,color=Color.Gray)
                        }
                    }
                }
            }

            this.item {
                Button(
                    onClick = { payment = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("₹ Cash+ भुगतान जोड़ें")
                }
            }

            this.item {
                Button(
                    onClick = { protectedRateEdit = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
                ) {
                    Text("दिहाड़ी बदलें")
                }
            }

            this.item {
                val allAttendanceRows=store.attendances.filter{it.labourId==id}.sortedByDescending{it.date}
                val allPaymentRows=store.payments.filter{it.labourId==id}.sortedByDescending{it.date}
                val attendanceRows=allAttendanceRows.filter{it.date>lastClosedThrough}
                val paymentRows=allPaymentRows.filter{it.date>lastClosedThrough}
                val report=attendanceRows.filter{it.fraction>0.0}.map{a->val f=store.fields.firstOrNull{it.id==a.fieldId};"${displayDate(a.date)} • ${f?.name?:"खेत"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"} + listOf("","भुगतान") + paymentRows.map{p->"${displayDate(p.date)} • भुगतान • ₹${money(p.amount)}"}
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"${l.name}_हिसाब","कुल मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बाकी ₹${money(wage-paid)}",report)},
                    onPdf={exportWorkerLedgerPdf(context,l,store,attendanceRows,paymentRows,wage,paid,background=true)}
                )
            }

            this.item {
                Text(
                    "वर्तमान दिहाड़ी: ₹${money(store.rateFor(id, today()))}/दिन",
                    fontWeight = FontWeight.Bold,
                    color = Green
                )
            }

            this.item {
                Text(
                    "मजदूरी-दर इतिहास",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(store.rateHistoryFor(id), key = { it.id }) { r ->
                Text(
                    "${displayDate(r.effectiveDate)} से ₹${money(r.rate)}/दिन",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            this.item {
                val labourRows = currentAttendance
                val fullDays = labourRows.count { it.fraction == 1.0 }
                val halfDays = labourRows.count { it.fraction == 0.5 }
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(12.dp)){
                        Text("📊 काम का सार",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल काम",labourRows.sumOf{it.fraction})}
                            Box(Modifier.weight(1f)){Stat("पूरा दिन",fullDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("आधा दिन",halfDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("कुल मजदूरी",wage)}
                        }
                    }
                }
            }

            this.item {
                Text("पूरा लेजर खोजें", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = GreenDark)
                Spacer(Modifier.height(5.dp))
                AppTextField(
                    value = ledgerQuery, onValueChange = { ledgerQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("तारीख, खेत, फसल या भुगतान खोजें") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "लेजर खोजें") },
                    trailingIcon = { if (ledgerQuery.isNotBlank()) IconButton(onClick = { ledgerQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "खोज साफ करें") } },
                    shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White)
                )
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("सभी", "पूरा दिन", "आधा दिन", "भांजी/Absent").forEach { status ->
                        FilterChip(selected = attendanceStatus == status, onClick = { attendanceStatus = status }, label = { Text(status) })
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text("हाजिरी (${filteredAttendance.size}/${currentAttendance.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            this.items(
                filteredAttendance,
                key = { it.id }
            ) { a ->
                val f = store.fields.firstOrNull { it.id == a.fieldId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(
                            "${displayDate(a.date)} • ${f?.name ?: "खेत"} • " +
                                "${store.crops.firstOrNull { it.id == a.cropId }?.name?.let { "$it • " } ?: ""}" +
                                "${if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • " +
                                "₹${money(a.fraction * a.rate)}",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick={delAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }

            this.item {
                Text("भुगतान (${filteredPayments.size}/${currentPayments.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (filteredAttendance.isEmpty() && filteredPayments.isEmpty()) {
                    Spacer(Modifier.height(5.dp))
                    EmptyCard(if (ledgerQuery.isBlank() && attendanceStatus == "सभी") "इस अवधि में कोई हाजिरी या भुगतान दर्ज नहीं है।" else "इस खोज/फ़िल्टर में कोई रिकॉर्ड नहीं मिला।")
                }
            }

            this.items(
                filteredPayments,
                key = { it.id }
            ) { p ->
                val f = store.fields.firstOrNull { it.id == p.fieldId }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${displayDate(p.date)} • ${f?.name ?: "सामान्य"}" +
                            "${store.crops.firstOrNull { it.id == p.cropId }?.name?.let { " • $it" } ?: ""}" +
                            " • ₹${money(p.amount)}",
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { editPayment = p }) { Icon(Icons.Default.Edit,contentDescription="भुगतान बदलें",tint=Green) }
                    IconButton(onClick = { delPay = p }) {
                        Icon(imageVector = Icons.Default.Delete,contentDescription = "भुगतान हटाएँ",tint = Color(0xFFB3261E))
                    }
                }
            }
        }

        if (edit) {
            LabourDialog(store, l) {
                edit = false
            }
        }

        if (payment) {
            PaymentDialog(store, id, null, "", onClose={payment = false})
        }
        editPayment?.let { item ->
            PaymentDialog(store, id, item.fieldId, item.cropId, onClose={editPayment=null}, existing=item)
        }
        protectedRateEdit.takeIf{it}?.let{
            DeviceCredentialGate(
                "दिहाड़ी बदलें",
                "मजदूर की दिहाड़ी बदलने के लिए Android screen lock से पुष्टि करें।",
                {rate=true;protectedRateEdit=false},
                {protectedRateEdit=false}
            )
        }

        if (rate) {
            RateDialog(store, id) {
                rate = false
            }
        }

        delAttendance?.let { attendanceItem ->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deleteAttendance(attendanceItem.id); delAttendance = null; if(!deleted) android.widget.Toast.makeText(context,"यह हाजिरी फाइनल हिसाब में है, इसलिए नहीं हटाई गई।",android.widget.Toast.LENGTH_LONG).show() },
                { delAttendance = null }
            )
        }

        delPay?.let { paymentItem ->
            DeviceCredentialDeleteGate(
                "भुगतान हटाएँ",
                "गलत payment entry हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deletePayment(paymentItem.id); delPay = null; if(!deleted) android.widget.Toast.makeText(context,"यह भुगतान फाइनल हिसाब में है, इसलिए नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show() },
                { delPay = null }
            )
        }
        /*
        delPay?.let { paymentItem ->
            ConfirmDialog(
                "भुगतान हटाएँ?",
                "यह payment record हट जाएगा।",
                {
                    val deleted=store.deletePayment(paymentItem.id)
                    delPay = null
                    if(!deleted) android.widget.Toast.makeText(context,"यह भुगतान फाइनल हिसाब में है, इसलिए नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show()
                },
                {
                    delPay = null
                }
            )
        }
        */
    }
}


@Composable
private fun ExportButtons(onPhoto:()->Unit,onPdf:()->Unit){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
        Button(onClick=onPhoto,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4BC1))){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(6.dp));Text("Photo",fontWeight=FontWeight.Bold)}
        Button(onClick=onPdf,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(6.dp));Text("PDF",fontWeight=FontWeight.Bold)}
    }
}

private fun safeFileName(value:String):String=value.replace(Regex("[^A-Za-z0-9_-]+"),"_").trim('_').ifBlank{"report"}

private fun shareFile(context:Context,file:File,mime:String,title:String){
    require(file.exists() && file.isFile && file.length() > 0L) { "रिपोर्ट फ़ाइल खाली या उपलब्ध नहीं है" }
    val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file)
    val intent=Intent(Intent.ACTION_SEND).apply {
        type=mime
        putExtra(Intent.EXTRA_STREAM,uri)
        clipData=android.content.ClipData.newUri(context.contentResolver,title,uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser=Intent.createChooser(intent,title).apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    context.startActivity(chooser)
}

private fun wrapReportText(text:String, paint:Paint, maxWidth:Float):List<String>{
    val words=text.trim().split(Regex("\\s+"))
    if(words.isEmpty()) return listOf("")
    val out=mutableListOf<String>(); var line=""
    for(word in words){
        val candidate=if(line.isBlank()) word else "$line $word"
        if(paint.measureText(candidate)<=maxWidth){line=candidate}else{
            if(line.isNotBlank()) out.add(line)
            line=word
        }
    }
    if(line.isNotBlank()) out.add(line)
    return out.ifEmpty{listOf("")}
}

private fun exportReportPhoto(context:Context,title:String,summary:String,lines:List<String>){
    try{
        val width=1200; val side=45f; val contentW=width-side*2; val lineH=38f; val headerH=255f
        val textPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;typeface=Typeface.DEFAULT;textSize=27f}
        val wrapped=lines.flatMapIndexed{idx,line->wrapReportText("${idx+1}. $line",textPaint,contentW)}
        val height=(headerH+wrapped.size*lineH+70f).toInt().coerceAtLeast(500)
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=Typeface.DEFAULT_BOLD;textSize=46f}
        canvas.drawText("MAJDOOR HISAAB PRO",side,65f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=30f;paint.color=android.graphics.Color.DKGRAY
        canvas.drawText(title,side,115f,paint)
        paint.textSize=26f;paint.color=android.graphics.Color.rgb(11,107,74)
        wrapReportText(summary,paint,contentW).take(2).forEachIndexed{i,t->canvas.drawText(t,side,165f+i*32f,paint)}
        paint.color=android.graphics.Color.LTGRAY;canvas.drawRect(side,205f,width-side,207f,paint)
        paint.color=android.graphics.Color.BLACK;paint.textSize=27f;paint.typeface=Typeface.DEFAULT
        var y=250f
        wrapped.forEach{line->canvas.drawText(line,side,y,paint);y+=lineH}
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}; val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}; bitmap.recycle(); shareFile(context,file,"image/png","Photo साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Photo report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun exportAttendanceHistoryPhoto(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
) {
    try {
        val width = 1400
        val side = 50f
        val contentW = width - side * 2
        val lineH = 42f
        val days = dayGroups.sortedByDescending { it.first }
        val totalRecords = days.sumOf { it.second.size }
        val uniqueWorkers = days.flatMap { it.second.filter { a -> a.fraction > 0.0 }.map { a -> a.labourId } }.distinct().size
        val totalWage = days.sumOf { group -> group.second.sumOf { a -> a.fraction * a.rate } }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            typeface = Typeface.DEFAULT
            textSize = 28f
        }

        var height = 330f
        days.forEach { (_, rows) ->
            height += 110f + 72f + rows.size * lineH + 58f
        }
        height += 170f

        val bitmap = Bitmap.createBitmap(width, height.toInt().coerceAtLeast(700), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)

        val darkGreen = android.graphics.Color.rgb(6, 76, 54)
        val green = android.graphics.Color.rgb(11, 107, 74)
        val lightGreen = android.graphics.Color.rgb(234, 248, 241)
        val lightBlue = android.graphics.Color.rgb(235, 245, 255)
        val lightYellow = android.graphics.Color.rgb(255, 249, 225)

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkGreen
            typeface = Typeface.DEFAULT_BOLD
            textSize = 48f
        }
        canvas.drawRoundRect(side, 25f, width - side, 145f, 24f, 24f, headerPaint)

        headerPaint.color = android.graphics.Color.WHITE
        headerPaint.textSize = 44f
        canvas.drawText("MAJDOOR HISAAB PRO", side + 28f, 78f, headerPaint)
        headerPaint.textSize = 31f
        canvas.drawText("हाजिरी सूची • ${monthTitle(month)}", side + 28f, 120f, headerPaint)

        fun summaryCard(left: Float, top: Float, right: Float, label: String, value: String, bg: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
            canvas.drawRoundRect(left, top, right, top + 125f, 20f, 20f, p)
            p.color = darkGreen
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 25f
            canvas.drawText(label, left + 22f, top + 40f, p)
            p.textSize = 42f
            canvas.drawText(value, left + 22f, top + 94f, p)
        }

        val gap = 14f
        val cardW = (contentW - gap * 3) / 4f
        val sy = 170f
        summaryCard(side, sy, side + cardW, "कुल कार्य दिवस", days.size.toString(), lightBlue)
        summaryCard(side + cardW + gap, sy, side + cardW * 2 + gap, "अलग मजदूर", uniqueWorkers.toString(), lightYellow)
        summaryCard(side + cardW * 2 + gap * 2, sy, side + cardW * 3 + gap * 2, "कुल हाजिरी", totalRecords.toString(), lightGreen)
        summaryCard(side + cardW * 3 + gap * 3, sy, width - side, "कुल मजदूरी", "₹${money(totalWage)}", android.graphics.Color.rgb(255, 237, 237))

        var y = 325f

        days.forEachIndexed { dayIndex, pair ->
            val date = pair.first
            val rows = pair.second
            val dayTotal = rows.sumOf { it.fraction * it.rate }
            val workers = rows.filter { it.fraction > 0.0 }.map { it.labourId }.distinct().size
            val sectionBg = if (dayIndex % 2 == 0) lightGreen else lightYellow

            val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sectionBg }
            canvas.drawRoundRect(side, y, width - side, y + 82f + rows.size * lineH + 65f, 22f, 22f, sectionPaint)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = darkGreen
                typeface = Typeface.DEFAULT_BOLD
                textSize = 34f
            }
            canvas.drawText(displayDate(date), side + 25f, y + 43f, titlePaint)

            titlePaint.typeface = Typeface.DEFAULT
            titlePaint.textSize = 23f
            canvas.drawText("कुल मजदूर: $workers", side + 330f, y + 42f, titlePaint)
            canvas.drawText("कुल हाजिरी: ${rows.size}", side + 570f, y + 42f, titlePaint)
            titlePaint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}", side + 830f, y + 42f, titlePaint)

            val tableTop = y + 62f
            val headerH = 45f
            val col1 = side
            val col2 = side + 105f
            val col3 = side + 570f
            val col4 = side + 1080f
            val tableRight = width - side

            val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen }
            canvas.drawRect(col1, tableTop, tableRight, tableTop + headerH, hp)

            val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                typeface = Typeface.DEFAULT_BOLD
                textSize = 21f
            }
            canvas.drawText("क्रम", col1 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूर का नाम", col2 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("काम का प्रकार", col3 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूरी (₹)", col4 + 18f, tableTop + 30f, whitePaint)

            var rowY = tableTop + headerH
            rows.sortedWith(compareBy<Attendance> { it.labourId }.thenBy { it.fieldId }).forEachIndexed { index, a ->
                val l = store.labours.firstOrNull { it.id == a.labourId }
                val bg = if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(247, 250, 249)
                val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
                canvas.drawRect(col1, rowY, tableRight, rowY + lineH, rp)

                val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.rgb(25, 25, 25)
                    typeface = Typeface.DEFAULT
                    textSize = 21f
                }
                canvas.drawText("${index + 1}", col1 + 24f, rowY + 29f, tp)
                canvas.drawText(l?.name ?: "मजदूर", col2 + 18f, rowY + 29f, tp)
                canvas.drawText(if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (नहीं आया)" else "अन्य", col3 + 18f, rowY + 29f, tp)
                tp.typeface = Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction * a.rate)}", col4 + 18f, rowY + 29f, tp)
                rowY += lineH
            }

            val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(218, 246, 222)
                typeface = Typeface.DEFAULT_BOLD
                textSize = 24f
            }
            canvas.drawRect(col1, rowY, tableRight, rowY + 55f, totalPaint)
            totalPaint.color = darkGreen
            canvas.drawText("${displayDate(date)} का कुल", col1 + 25f, rowY + 36f, totalPaint)
            canvas.drawText("₹${money(dayTotal)}", col4 + 18f, rowY + 36f, totalPaint)

            y = rowY + 85f
        }

        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(235, 245, 255)
            typeface = Typeface.DEFAULT_BOLD
            textSize = 27f
        }
        canvas.drawRoundRect(side, y, width - side, y + 135f, 22f, 22f, totalPaint)
        totalPaint.color = darkGreen
        totalPaint.textSize = 32f
        canvas.drawText("${monthTitle(month)} — कुल योग", side + 25f, y + 45f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT
        totalPaint.textSize = 24f
        canvas.drawText("कार्य दिवस: ${days.size}   •   अलग मजदूर: $uniqueWorkers   •   कुल हाजिरी रिकॉर्ड: $totalRecords", side + 25f, y + 82f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT_BOLD
        totalPaint.textSize = 34f
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}", side + 25f, y + 119f, totalPaint)

        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        shareFile(context, file, "image/png", "Photo साझा करें")
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Photo report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportAttendanceHistoryPdf(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
){
    try{
        val doc=PdfDocument()
        val pageW=595
        val pageH=842
        val left=24f
        val right=24f
        val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        var pageNo=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
        var canvas=page.canvas

        val days=dayGroups.sortedByDescending{it.first}
        val totalRecords=days.sumOf{it.second.size}
        val uniqueWorkers=days.flatMap{it.second.map{a->a.labourId}}.distinct().size
        val totalWage=days.sumOf{g->g.second.sumOf{a->a.fraction*a.rate}}

        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=22f
            canvas.drawText("MAJDOOR HISAAB PRO",left,32f,paint)
            paint.color=android.graphics.Color.BLACK
            paint.textSize=14f
            paint.typeface=Typeface.DEFAULT
            canvas.drawText("हाजिरी सूची • ${monthTitle(month)}",left,53f,paint)
            paint.textSize=9.5f
            canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी: $totalRecords • कुल मजदूरी: ₹${money(totalWage)}",left,70f,paint)
            paint.color=android.graphics.Color.LTGRAY
            canvas.drawRect(left,80f,pageW-right,81.5f,paint)
        }

        fun newPage(){
            doc.finishPage(page)
            pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
            canvas=page.canvas
            header()
        }

        fun ensure(space:Float, currentY:Float):Float{
            if(currentY+space>810f){newPage();return 100f}
            return currentY
        }

        header()
        var y=102f

        days.forEach{(date,rows)->
            val dayTotal=rows.sumOf{it.fraction*it.rate}
            val workers=rows.map{it.labourId}.distinct().size

            y=ensure(60f,y)
            paint.color=android.graphics.Color.rgb(234,248,241)
            canvas.drawRoundRect(left,y-18f,pageW-right,y+22f,8f,8f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=12f
            canvas.drawText(displayDate(date),left+8f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT
            paint.textSize=9.5f
            canvas.drawText("कुल मजदूर: $workers",left+115f,y+3f,paint)
            canvas.drawText("कुल हाजिरी: ${rows.size}",left+225f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}",left+365f,y+3f,paint)
            y+=35f

            // Compact table columns
            val c1=left
            val c2=left+34f
            val c3=left+235f
            val c4=left+435f
            val tr=pageW-right
            paint.color=android.graphics.Color.rgb(6,76,54)
            canvas.drawRect(c1,y,c4+100f,y+24f,paint)
            paint.color=android.graphics.Color.WHITE
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=8.5f
            canvas.drawText("क्रम",c1+6f,y+16f,paint)
            canvas.drawText("मजदूर का नाम",c2+6f,y+16f,paint)
            canvas.drawText("काम का प्रकार",c3+6f,y+16f,paint)
            canvas.drawText("मजदूरी (₹)",c4+6f,y+16f,paint)
            y+=24f

            rows.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}).forEachIndexed{index,a->
                y=ensure(18f,y)
                paint.color=if(index%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(247,250,249)
                canvas.drawRect(c1,y,tr,y+18f,paint)
                val l=store.labours.firstOrNull{it.id==a.labourId}
                paint.color=android.graphics.Color.rgb(25,25,25)
                paint.typeface=Typeface.DEFAULT
                paint.textSize=8.5f
                canvas.drawText("${index+1}",c1+6f,y+13f,paint)
                canvas.drawText((l?.name?:"मजदूर").take(28),c2+6f,y+13f,paint)
                canvas.drawText(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",c3+6f,y+13f,paint)
                paint.typeface=Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction*a.rate)}",c4+6f,y+13f,paint)
                y+=18f
            }
            paint.color=android.graphics.Color.rgb(218,246,222)
            canvas.drawRect(c1,y,tr,y+22f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=9.5f
            canvas.drawText("${displayDate(date)} का कुल",c1+6f,y+15f,paint)
            canvas.drawText("₹${money(dayTotal)}",c4+6f,y+15f,paint)
            y+=34f
        }

        y=ensure(65f,y)
        paint.color=android.graphics.Color.rgb(235,245,255)
        canvas.drawRoundRect(left,y,pageW-right,y+58f,10f,10f,paint)
        paint.color=android.graphics.Color.rgb(6,76,54)
        paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=12f
        canvas.drawText("${monthTitle(month)} — कुल योग",left+8f,y+18f,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=9.5f
        canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी रिकॉर्ड: $totalRecords",left+8f,y+36f,paint)
        paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}",left+350f,y+36f,paint)

        doc.finishPage(page)
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use{doc.writeTo(it)}
        doc.close()
        shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){
        android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportWorkerLedgerPdf(
    context: Context,
    labour: Labour,
    store: Store,
    attendanceRows: List<Attendance>,
    paymentRows: List<Payment>,
    totalWage: Double,
    totalPaid: Double,
    background: Boolean = true
) {
    val showReportSummary = settingBool(context, "report_summary_enabled", true)
    val showReportWages = settingBool(context, "report_wages_enabled", true)
    val showReportPayments = settingBool(context, "report_payments_enabled", true)
    val generate = {
        try {
            val doc = PdfDocument()
            val pageW = 595
            val pageH = 842
            val left = 24f
            val right = 24f
            val contentRight = pageW - right
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val green = android.graphics.Color.rgb(6, 76, 54)
            val mint = android.graphics.Color.rgb(237, 248, 243)
            val dark = android.graphics.Color.rgb(25, 25, 25)
            val grid = android.graphics.Color.rgb(205, 216, 212)
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            var canvas = page.canvas

            fun text(value: String, x: Float, y: Float, size: Float, color: Int = dark, bold: Boolean = false) {
                paint.color = color
                paint.textSize = size
                paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                canvas.drawText(value, x, y, paint)
            }
            fun rect(l: Float, t: Float, r: Float, b: Float, color: Int) {
                paint.color = color
                canvas.drawRect(l, t, r, b, paint)
            }
            fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int = grid, stroke: Float = 0.7f) {
                paint.color = color
                paint.strokeWidth = stroke
                canvas.drawLine(x1, y1, x2, y2, paint)
            }
            fun rounded(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
                paint.color = color
                canvas.drawRoundRect(l, t, r, b, radius, radius, paint)
            }
            fun header() {
                rounded(left, 18f, contentRight, 92f, 12f, green)
                runCatching {
                    val logo = BitmapFactory.decodeResource(context.resources, R.drawable.majdoor_logo_small)
                    if (logo != null) {
                        canvas.drawBitmap(logo, null, android.graphics.RectF(left + 9f, 28f, left + 62f, 82f), Paint(Paint.ANTI_ALIAS_FLAG))
                        logo.recycle()
                    }
                }
                text("MAJDOOR HISAAB PRO", left + 72f, 49f, 22f, android.graphics.Color.WHITE, true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल", left + 72f, 73f, 12f, android.graphics.Color.rgb(224, 242, 234))
                text("मजदूर का हिसाब", contentRight - 142f, 48f, 13f, android.graphics.Color.WHITE, true)
                text("व्यक्तिगत विवरण", contentRight - 142f, 69f, 11f, android.graphics.Color.WHITE)
            }
            fun footer() {
                line(left, 806f, contentRight, 806f, green, 1.3f)
                text("तैयार करने की तारीख: ${displayDate(today())}", left + 8f, 825f, 9.5f)
                text("ऐप: MAJDOOR HISAAB PRO", left + 8f, 839f, 9f)
                text("पेज $pageNo", contentRight - 50f, 825f, 9.5f)
            }
            fun startNewPage() {
                footer()
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                canvas = page.canvas
                header()
            }

            header()
            rounded(left, 102f, contentRight, 198f, 10f, mint)
            text("मजदूर का नाम", left + 17f, 124f, 11f, dark, true)
            text(labour.name.ifBlank { "मजदूर" }.take(30), left + 17f, 153f, 21f, dark, true)
            text("मोबाइल: ${labour.mobile.ifBlank { "-" }}".take(36), left + 17f, 177f, 10.5f)
            if (showReportSummary) {
                line(316f, 113f, 316f, 187f, android.graphics.Color.rgb(190, 220, 207), 0.8f)
                text("कुल हाजिरी", 334f, 124f, 11f)
                text(":  ${quantity(attendanceRows.sumOf { it.fraction })} दिन", 428f, 124f, 11f, dark, true)
                if (showReportWages) { text("कुल मजदूरी", 334f, 147f, 11f); text(":  ₹${money(totalWage)}", 428f, 147f, 11f, dark, true) }
                if (showReportPayments) { text("कुल भुगतान", 334f, 169f, 11f); text(":  ₹${money(totalPaid)}", 428f, 169f, 11f, dark, true) }
                if (showReportWages || showReportPayments) { text("बकाया राशि", 334f, 190f, 11f); text(":  ₹${money(totalWage - totalPaid)}", 428f, 190f, 11f, green, true) }
            }

            // Work rows exclude absence/भांजी. Payments are shown only on their actual payment dates.
            data class LedgerRow(val date: String, val field: String, val attendance: String, val payment: Double?, val amount: Double?, val sortDate: String)
            val workRows = attendanceRows.filter { it.fraction > 0.0 }.map { a ->
                LedgerRow(a.date, store.fields.firstOrNull { it.id == a.fieldId }?.name ?: "खेत", if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else "${money(a.fraction)} दिन", null, a.fraction * a.rate, a.date)
            }
            val paymentsByDate = paymentRows.groupBy { it.date }.mapValues { (_, ps) -> ps.sumOf { it.amount } }
            val workDates = workRows.map { it.date }.toSet()
            val paymentOnlyRows = paymentsByDate.filterKeys { it !in workDates }.map { (date, amount) -> LedgerRow(date, "", "—", amount, null, date) }
            val rows = (workRows + paymentOnlyRows).sortedByDescending { it.sortDate }.toMutableList()
            val paidDates = paymentsByDate.keys
            val paidShown = mutableSetOf<String>()
            var y = 225f
            val cols = floatArrayOf(left, left + 43f, left + 145f, left + 332f, left + 418f, left + 500f, contentRight)
            val headers = listOf("क्रम सं.", "तारीख", "खेत / काम का नाम", "हाजिरी", if(showReportPayments) "भुगतान (₹)" else "", if(showReportWages) "रकम (₹)" else "")
            fun drawTableHeader() {
                rounded(left, y, contentRight, y + 28f, 5f, green)
                headers.forEachIndexed { i, label -> text(label, cols[i] + 5f, y + 18f, 8.8f, android.graphics.Color.WHITE, true) }
                y += 28f
            }
            drawTableHeader()
            rows.forEachIndexed { index, row ->
                if (y + 38f > 650f) {
                    startNewPage()
                    y = 112f
                    drawTableHeader()
                }
                rect(left, y, contentRight, y + 38f, if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(248, 251, 249))
                line(left, y + 38f, contentRight, y + 38f)
                for (x in cols.drop(1)) line(x, y, x, y + 38f)
                text("${index + 1}", cols[0] + 14f, y + 23f, 9.5f)
                text(displayDate(row.date), cols[1] + 5f, y + 23f, 8.6f)
                val fieldText = row.field.take(23)
                text(fieldText, cols[2] + 5f, y + 23f, 8.6f)
                text(row.attendance, cols[3] + 5f, y + 23f, 8.6f)
                val pay = if (row.date in paidDates && paidShown.add(row.date)) paymentsByDate[row.date] else null
                if (showReportPayments && pay != null) text("₹${money(pay)}", cols[4] + 7f, y + 23f, 8.6f)
                if (showReportWages && row.amount != null) text("₹${money(row.amount)}", cols[5] + 8f, y + 23f, 8.6f)
                y += 38f
            }

            // Compact green-and-white ledger summary includes finalized old debt and advance.
            if (showReportSummary) {
            if (y + 195f > 790f) {
                startNewPage()
                y = 112f
            } else {
                y = maxOf(y + 24f, 520f)
            }
            rounded(left, y, contentRight, y + 190f, 10f, mint)
            text("कुल सारांश", left + 15f, y + 25f, 17f, green, true)
            val workDays = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction }
            val balance = store.balanceBreakdown(labour.id)
            text("कुल कार्य दिवस", left + 20f, y + 51f, 10.5f)
            text(":  ${quantity(workDays)} दिन", left + 150f, y + 51f, 10.5f, dark, true)
            text("हाजिरी मजदूरी", left + 20f, y + 73f, 10.5f)
            text(":  ₹${money(totalWage)}", left + 150f, y + 73f, 10.5f, dark, true)
            text("चुने रिकॉर्ड भुगतान", left + 20f, y + 95f, 10.5f)
            text(":  ₹${money(totalPaid)}", left + 150f, y + 95f, 10.5f, dark, true)
            text("पुराना बाकी", left + 300f, y + 51f, 10.5f)
            text(":  ₹${money(balance.oldDue)}", left + 385f, y + 51f, 10.5f, dark, true)
            text("चालू बाकी", left + 300f, y + 73f, 10.5f)
            text(":  ₹${money(balance.currentDue)}", left + 385f, y + 73f, 10.5f, dark, true)
            text("कुल बाकी", left + 300f, y + 95f, 10.5f)
            text(":  ₹${money(balance.totalOutstanding)}", left + 385f, y + 95f, 10.5f, android.graphics.Color.rgb(185, 35, 35), true)
            text("एडवांस", left + 20f, y + 120f, 10.5f)
            text(":  ₹${money(balance.advance)}", left + 150f, y + 120f, 10.5f, dark, true)
            text("पुराने भुगतान पहले पुराने बाकी में समायोजित", left + 20f, y + 158f, 9f, green, true)
            }
            footer()
            doc.finishPage(page)
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "${safeFileName(labour.name + "_हिसाब")}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            if (background) reportMainHandler.post {
                runCatching { shareFile(context, file, "application/pdf", "PDF साझा करें") }.onFailure {
                    android.widget.Toast.makeText(context, "PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            } else shareFile(context, file, "application/pdf", "PDF साझा करें")
        } catch (e: Exception) {
            if (background) reportMainHandler.post { android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            else android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    if (background) reportPdfExecutor.execute { generate() } else generate()
}

private val reportPdfExecutor = Executors.newSingleThreadExecutor()
private val reportMainHandler = android.os.Handler(android.os.Looper.getMainLooper())

private fun exportAllWorkersLedgerPdf(
    context:Context,
    title:String,
    dateLabel:String,
    fieldLabel:String,
    rows:List<LabourReportRow>,
    totalWage:Double,
    totalPaid:Double,
    background:Boolean=false
){
    val showReportSummary = settingBool(context, "report_summary_enabled", true)
    val showReportWages = settingBool(context, "report_wages_enabled", true)
    val showReportPayments = settingBool(context, "report_payments_enabled", true)
    val generate={
        try{
            val doc=PdfDocument(); val pageW=595; val pageH=842; val left=24f; val right=24f; val contentRight=pageW-right
            val green=android.graphics.Color.rgb(6,76,54); val mint=android.graphics.Color.rgb(237,248,243); val dark=android.graphics.Color.rgb(25,35,31); val red=android.graphics.Color.rgb(196,35,35)
            val paint=Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo=1
            var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
            fun text(t:String,x:Float,y:Float,size:Float=10f,color:Int=dark,bold:Boolean=false){paint.color=color;paint.textSize=size;paint.typeface=if(bold)Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL);canvas.drawText(t,x,y,paint)}
            fun line(x1:Float,y1:Float,x2:Float,y2:Float,color:Int=android.graphics.Color.LTGRAY,width:Float=0.6f){paint.color=color;paint.strokeWidth=width;canvas.drawLine(x1,y1,x2,y2,paint)}
            fun rect(l:Float,t:Float,r:Float,b:Float,color:Int){paint.color=color;canvas.drawRect(l,t,r,b,paint)}
            fun rounded(l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int){paint.color=color;canvas.drawRoundRect(l,t,r,b,rad,rad,paint)}
            fun footer(){line(left,806f,contentRight,806f,green,1.2f);text("तैयार करने की तारीख: ${displayDate(today())}",left+7f,824f,9f);text("ऐप: MAJDOOR HISAAB PRO",left+7f,838f,8.5f);text("पेज $pageNo",contentRight-48f,824f,9f)}
            fun header(){
                rounded(left,20f,contentRight,82f,9f,green)
                val logo=runCatching{BitmapFactory.decodeResource(context.resources,R.drawable.majdoor_logo_small)}.getOrNull()
                if(logo!=null){paint.isFilterBitmap=true;canvas.drawBitmap(logo,null,android.graphics.RectF(left+10f,29f,left+68f,73f),paint);logo.recycle()}
                text("MAJDOOR HISAAB PRO",left+78f,49f,21f,android.graphics.Color.WHITE,true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल",left+78f,68f,10f,android.graphics.Color.WHITE)
                text("चुने हुए मजदूरों का हिसाब",left,112f,20f,green,true)
                text("अवधि: $dateLabel",left,134f,10f,dark)
                text("खेत: ${fieldLabel.take(64)}",left,151f,10f,dark)
            }
            fun startNewPage(){footer();doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header()}
            header()
            val workerCount=rows.size
            val summaryCols=floatArrayOf(left,left+137f,left+274f,left+411f,contentRight)
            if(showReportSummary){
                rounded(left,166f,contentRight,229f,9f,mint)
                val summaryLabels=listOf("कुल मजदूर",if(showReportWages)"कुल मजदूरी" else "",if(showReportPayments)"कुल भुगतान" else "",if(showReportWages||showReportPayments)"कुल बकाया" else "")
                val summaryValues=listOf("$workerCount मजदूर",if(showReportWages)"₹${money(totalWage)}" else "",if(showReportPayments)"₹${money(totalPaid)}" else "",if(showReportWages||showReportPayments)"₹${money(totalWage-totalPaid)}" else "")
                for(i in 0..3){
                    if(i>0) line(summaryCols[i],174f,summaryCols[i],220f,android.graphics.Color.rgb(190,220,207),0.8f)
                    text(summaryLabels[i],summaryCols[i]+9f,188f,8.5f,green,true)
                    text(summaryValues[i],summaryCols[i]+9f,214f,if(i==0)14f else 12f,if(i==3)red else green,true)
                }
            }
            var y=if(showReportSummary)245f else 166f
            val cols=floatArrayOf(left,left+31f,left+195f,left+265f,left+355f,left+435f,contentRight)
            val headers=listOf("क्र.","मजदूर का नाम","काम के दिन",if(showReportWages)"कुल मजदूरी (₹)" else "",if(showReportPayments)"भुगतान (₹)" else "",if(showReportWages||showReportPayments)"बाकी रकम (₹)" else "")
            fun drawTableHeader(){rounded(left,y,contentRight,y+27f,4f,green);headers.forEachIndexed{i,h->text(h,cols[i]+4f,y+17f,7.5f,android.graphics.Color.WHITE,true)};y+=27f}
            drawTableHeader()
            rows.forEachIndexed{idx,r->
                if(y+29f>790f){startNewPage();y=170f;drawTableHeader()}
                rect(left,y,contentRight,y+29f,if(idx%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(248,251,249))
                for(x in cols.drop(1))line(x,y,x,y+29f)
                line(left,y+29f,contentRight,y+29f)
                val balance=r.wage-r.paid
                text("${idx+1}",cols[0]+9f,y+18f,8.5f)
                text(r.labour.name.take(26),cols[1]+4f,y+18f,8.2f)
                text(quantity(r.workDays),cols[2]+10f,y+18f,8.5f)
                if(showReportWages) text("₹${money(r.wage)}",cols[3]+5f,y+18f,8.2f)
                if(showReportPayments) text("₹${money(r.paid)}",cols[4]+5f,y+18f,8.2f)
                if(showReportWages||showReportPayments) text("₹${money(balance)}",cols[5]+5f,y+18f,8.2f,if(balance>0)red else green,true)
                y+=29f
            }
            if(showReportSummary){
                if(y+34f>790f){startNewPage();y=170f}
                rounded(left,y,contentRight,y+34f,5f,mint)
                text("कुल योग",left+12f,y+21f,10f,green,true)
                text("${quantity(rows.sumOf{it.workDays})}",cols[2]+10f,y+21f,9f,green,true)
                if(showReportWages) text("₹${money(totalWage)}",cols[3]+5f,y+21f,9f,green,true)
                if(showReportPayments) text("₹${money(totalPaid)}",cols[4]+5f,y+21f,9f,green,true)
                if(showReportWages||showReportPayments) text("₹${money(totalWage-totalPaid)}",cols[5]+5f,y+21f,9f,red,true)
            }
            footer();doc.finishPage(page)
            val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close()
            if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}",android.widget.Toast.LENGTH_LONG).show()}} else shareFile(context,file,"application/pdf","PDF साझा करें")
        }catch(e:Exception){if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()} else android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
    }
    if(background)reportPdfExecutor.execute{generate()}else generate()
}


private fun exportDateFieldReportPdf(
    context: Context,
    title: String,
    summary: String,
    attendanceRows: List<Attendance>,
    paymentRows: List<Payment>,
    store: Store,
    aggregateWorkerView: Boolean,
    background: Boolean = false
) {
    val generate = {
        try {
            val doc = PdfDocument()
            val pageW = 842
            val pageH = 595
            val left = 28f
            val right = 28f
            val rightEdge = pageW - right
            val green = android.graphics.Color.rgb(6, 76, 54)
            val paleGreen = android.graphics.Color.rgb(230, 243, 236)
            val dark = android.graphics.Color.rgb(35, 45, 40)
            val muted = android.graphics.Color.rgb(95, 105, 100)
            val grid = android.graphics.Color.rgb(196, 213, 204)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo = 0
            var page: PdfDocument.Page? = null
            var canvas: Canvas? = null
            var y = 0f
            // Five useful columns only: deliberately no wage-rate column.
            val colX = floatArrayOf(left, 100f, 195f, 325f, 405f, 505f, 605f, rightEdge)
            val headers = listOf("तारीख / अवधि", "खेत / समूह", "मजदूर का नाम", "हाजिरी", "मजदूरी (₹)", "भुगतान (₹)", "बकाया (₹)")
            fun fit(value: String, maxWidth: Float, size: Float, bold: Boolean = false): String {
                paint.textSize = size
                paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                val clean = value.replace('\n', ' ').replace('\r', ' ')
                var out = clean
                while (out.isNotEmpty() && paint.measureText(out) > maxWidth - 12f) out = out.dropLast(1)
                return if (out != clean) out.trimEnd() + "…" else out
            }
            fun drawTableHeader() {
                val c = canvas ?: return
                paint.color = green
                c.drawRoundRect(android.graphics.RectF(left, y, rightEdge, y + 29f), 4f, 4f, paint)
                headers.forEachIndexed { i, h ->
                    paint.color = android.graphics.Color.WHITE
                    paint.textSize = 10.5f
                    paint.typeface = Typeface.DEFAULT_BOLD
                    c.drawText(fit(h, colX[i + 1] - colX[i], 10.5f, true), colX[i] + 6f, y + 19f, paint)
                }
                y += 29f
            }
            fun startPage(first: Boolean) {
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                canvas = page!!.canvas
                val c = canvas!!
                c.drawColor(android.graphics.Color.WHITE)
                y = 18f
                paint.color = green
                c.drawRoundRect(android.graphics.RectF(left, y, rightEdge, y + 45f), 8f, 8f, paint)
                paint.color = android.graphics.Color.WHITE
                paint.textSize = 20f
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("MAJDOOR HISAAB PRO", left + 14f, y + 21f, paint)
                paint.textSize = 11f
                paint.typeface = Typeface.DEFAULT
                c.drawText(if (first) "तारीख और खेत के अनुसार मजदूर हिसाब" else "तारीख और खेत के अनुसार हिसाब — जारी", left + 14f, y + 37f, paint)
                y += 55f
                if (first) {
                    paint.color = muted
                    paint.textSize = 9.5f
                    paint.typeface = Typeface.DEFAULT
                    c.drawText(fit(summary, rightEdge - left, 9.5f), left + 2f, y + 1f, paint)
                    val wage = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction * it.rate }
                    val paid = paymentRows.sumOf { it.amount }
                    val days = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction }
                    val cardsTop = y + 11f
                    val cardsBottom = cardsTop + 43f
                    val cardW = (rightEdge - left) / 4f
                    // Keep the on-screen preview unchanged; this fix is limited to the PDF row list.
                    val labels = listOf("कुल हाजिरी", "कुल मजदूरी", "कुल भुगतान", "अवधि का बाकी")
                    val values = listOf("${quantity(days)} दिन", "₹${money(wage)}", "₹${money(paid)}", "₹${money(wage - paid)}")
                    for (i in 0..3) {
                        val x1 = left + i * cardW
                        paint.color = paleGreen
                        c.drawRoundRect(android.graphics.RectF(x1 + 2f, cardsTop, x1 + cardW - 4f, cardsBottom), 6f, 6f, paint)
                        paint.color = green
                        paint.textSize = 9f
                        paint.typeface = Typeface.DEFAULT_BOLD
                        c.drawText(labels[i], x1 + 10f, cardsTop + 15f, paint)
                        paint.textSize = 13f
                        c.drawText(values[i], x1 + 10f, cardsTop + 34f, paint)
                    }
                    y = cardsBottom + 13f
                } else {
                    y += 7f
                }
                drawTableHeader()
            }
            fun finishPage() {
                val c = canvas ?: return
                paint.color = muted
                paint.textSize = 8.5f
                paint.typeface = Typeface.DEFAULT
                c.drawLine(left, pageH - 24f, rightEdge, pageH - 24f, paint)
                c.drawText("MAJDOOR HISAAB PRO • मजदूर हिसाब रिपोर्ट", left, pageH - 10f, paint)
                c.drawText("पेज $pageNo", rightEdge - 42f, pageH - 10f, paint)
                page?.let { doc.finishPage(it) }
            }
            fun drawRow(date: String, field: String, worker: String, attendance: String, wage: String, paid: String, balance: String, index: Int) {
                if (y + 25f > pageH - 32f) {
                    finishPage()
                    startPage(false)
                }
                val c = canvas ?: return
                val bottom = y + 25f
                paint.color = if (index % 2 == 0) android.graphics.Color.WHITE else paleGreen
                c.drawRect(left, y, rightEdge, bottom, paint)
                paint.color = grid
                paint.strokeWidth = 0.6f
                c.drawRect(left, y, rightEdge, bottom, paint)
                for (x in colX.drop(1).dropLast(1)) c.drawLine(x, y, x, bottom, paint)
                val vals = listOf(date, field, worker, attendance, wage, paid, balance)
                vals.forEachIndexed { i, value ->
                    paint.color = dark
                    paint.textSize = 9f
                    paint.typeface = if (i >= 4) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    c.drawText(fit(value, colX[i + 1] - colX[i], 9f, i >= 4), colX[i] + 4f, y + 16f, paint)
                }
                y = bottom
            }
            startPage(true)
            data class ReportLine(val date: String, val field: String, val worker: String, val workerId: String, val attendance: Double, val wage: Double, val paid: Double, val kind: Int)
            val allRows = mutableListOf<ReportLine>()
            attendanceRows.forEach { a ->
                val worker = store.labours.firstOrNull { it.id == a.labourId }?.name ?: "मजदूर हटाया गया"
                val field = store.fields.firstOrNull { it.id == a.fieldId }?.name ?: "—"
                allRows.add(ReportLine(a.date, field, worker, a.labourId, a.fraction, a.fraction * a.rate, 0.0, 0))
            }
            paymentRows.forEach { p ->
                val worker = store.labours.firstOrNull { it.id == p.labourId }?.name ?: "मजदूर हटाया गया"
                // A payment is not field work. Show a field only if its stored ID still resolves; never print a fake deleted-field label.
                val field = store.fields.firstOrNull { it.id == p.fieldId }?.name ?: "—"
                allRows.add(ReportLine(p.date, field, worker, p.labourId, 0.0, 0.0, p.amount, 1))
            }
            // When the user selects all dates and all fields, show one combined row per worker.
            // For a date range or a specific field, retain the detailed date/field rows.
            // Aggregate only when the caller explicitly selected all dates and all fields.
            // Do not infer report mode from translated/display summary text.
            val aggregateFieldLabel = if (summary.contains("खेत: सभी खेत")) "सभी खेत" else "चुने खेत"
            // Aggregate into one row only for the all-workers report. When a single worker
            // is selected, preserve each attendance/payment date in the PDF, matching the
            // date-by-date detail shown in the on-screen preview.
            val shouldAggregateWorkerView = aggregateWorkerView && summary.contains("मजदूर: सभी मजदूर")
            val reportRows = if (shouldAggregateWorkerView) {
                // Include only workers with actual positive attendance or a recorded payment,
                // then produce exactly one combined row per worker for the selected date range.
                (attendanceRows.filter { it.fraction > 0.0 }.map { it.labourId } + paymentRows.map { it.labourId })
                    .distinct()
                    .mapNotNull { workerId ->
                        val worker = store.labours.firstOrNull { it.id == workerId }?.name ?: "मजदूर हटाया गया"
                        val workerAttendance = attendanceRows.filter { it.labourId == workerId && it.fraction > 0.0 }
                        val workerPayments = paymentRows.filter { it.labourId == workerId }
                        val days = workerAttendance.sumOf { it.fraction }
                        val wages = workerAttendance.sumOf { it.fraction * it.rate }
                        val paid = workerPayments.sumOf { it.amount }
                        ReportLine("चयनित अवधि", aggregateFieldLabel, worker, workerId, days, wages, paid, 0)
                    }
                    .sortedBy { it.worker.lowercase(Locale.ROOT) }
            } else {
                allRows.sortWith(compareBy<ReportLine> { it.date }.thenBy { it.field }.thenBy { it.worker }.thenBy { it.kind })
                allRows
            }
            // In the all-workers summary, each row is already the worker's selected-period
            // aggregate, so show that worker's period balance once. In date-wise detail mode,
            // show the running balance for that worker after each dated attendance/payment row.
            // The neutral “बकाया” column label works for both report modes.
            val runningBalanceByWorker = mutableMapOf<String, Double>()
            reportRows.forEachIndexed { i, row ->
                val rowBalance = if (shouldAggregateWorkerView) {
                    row.wage - row.paid
                } else {
                    val previous = runningBalanceByWorker[row.workerId] ?: 0.0
                    val updated = previous + row.wage - row.paid
                    runningBalanceByWorker[row.workerId] = updated
                    updated
                }
                drawRow(if (shouldAggregateWorkerView) row.date else displayDate(row.date), row.field, row.worker,
                    if (row.attendance == 0.0) "—" else quantity(row.attendance),
                    if (row.wage == 0.0) "—" else money(row.wage),
                    if (row.paid == 0.0) "—" else money(row.paid),
                    money(rowBalance), i)
            }
            if (reportRows.isEmpty()) drawRow("—", "—", "कोई रिकॉर्ड नहीं", "—", "0", "0", "0", 0)
            val totalWage = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction * it.rate }
            val totalPaid = paymentRows.sumOf { it.amount }
            val periodOutstanding = totalWage - totalPaid
            if (y + 31f > pageH - 32f) {
                finishPage()
                startPage(false)
            }
            paint.color = paleGreen
            canvas!!.drawRoundRect(android.graphics.RectF(left, y + 4f, rightEdge, y + 32f), 5f, 5f, paint)
            paint.color = green
            paint.textSize = 10f
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas!!.drawText("कुल मजदूरी: ₹${money(totalWage)}", left + 10f, y + 22f, paint)
            canvas!!.drawText("कुल भुगतान: ₹${money(totalPaid)}", left + 275f, y + 22f, paint)
            canvas!!.drawText("अवधि का बाकी: ₹${money(periodOutstanding)}", left + 545f, y + 22f, paint)
            finishPage()
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            if (background) reportMainHandler.post {
                runCatching { shareFile(context, file, "application/pdf", "PDF साझा करें") }
                    .onFailure { e -> android.widget.Toast.makeText(context, "PDF तैयार है, लेकिन शेयर नहीं खुला: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            } else shareFile(context, file, "application/pdf", "PDF साझा करें")
        } catch (e: Exception) {
            if (background) reportMainHandler.post { android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            else android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    if (background) reportPdfExecutor.execute { generate() } else generate()
}

private fun exportReportPdf(context:Context,title:String,summary:String,lines:List<String>,background:Boolean=false,hindiSafeWrap:Boolean=false){
    val generate = {
    try{
        // Bundled Noto Sans Devanagari fonts ensure Hindi glyphs and conjuncts do not
        // depend on the Android device's fallback font installation.
        val hindiRegular=Typeface.createFromAsset(context.assets,"fonts/NotoSansDevanagari-Regular.ttf")
        val hindiBold=Typeface.createFromAsset(context.assets,"fonts/NotoSansDevanagari-Bold.ttf")
        val doc=PdfDocument(); val pageW=595; val pageH=842; val left=28f; val right=28f; val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;typeface=hindiRegular;textSize=11f;letterSpacing=0f}
        val titlePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=hindiBold;textSize=21f}
        val brandPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=Typeface.create("sans-serif",Typeface.BOLD);textSize=16f}
        val footerPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.DKGRAY;typeface=hindiRegular;textSize=8f}
        var pageNo=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
        var canvas=page.canvas
        fun header(){
            canvas.drawText("MAJDOOR HISAAB PRO",left,34f,brandPaint)
            canvas.drawText(title.take(45),left,70f,titlePaint)
            paint.textSize=10f;paint.typeface=hindiRegular
            wrapReportText(summary,paint,maxW).take(3).forEachIndexed{i,t->canvas.drawText(t,left,94f+i*17f,paint)}
        }
        header(); var y=150f
        fun wrapHindiPdfLine(value:String):List<String>{
            val out=mutableListOf<String>()
            val breaker=java.text.BreakIterator.getCharacterInstance(Locale("hi","IN")).apply{setText(value)}
            val clusters=mutableListOf<String>();var start=breaker.first();var end=breaker.next()
            while(end!=java.text.BreakIterator.DONE){clusters.add(value.substring(start,end));start=end;end=breaker.next()}
            var current=""
            clusters.forEach{cluster->
                val candidate=current+cluster
                if(current.isNotEmpty()&&paint.measureText(candidate)>maxW){out.add(current);current=cluster}else current=candidate
            }
            if(current.isNotEmpty())out.add(current)
            return out.ifEmpty{listOf("")}
        }
        lines.forEachIndexed{idx,line->
            val wrapped=if(hindiSafeWrap)wrapHindiPdfLine(line) else wrapReportText(line,paint,maxW)
            for(part in wrapped){
                if(y>805f){
                    canvas.drawText("पृष्ठ $pageNo",pageW-right-42f,pageH-15f,footerPaint)
                    doc.finishPage(page)
                    pageNo++
                    page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
                    canvas=page.canvas
                    header()
                    y=150f
                }
                canvas.drawText(part,left,y,paint)
                y+=19f
            }
            y+=4f
        }
        canvas.drawText("पृष्ठ $pageNo",pageW-right-42f,pageH-15f,footerPaint)
        doc.finishPage(page)
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
        try{FileOutputStream(file).use{doc.writeTo(it)}}finally{doc.close()}
        if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{shareError->android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${shareError.message}",android.widget.Toast.LENGTH_LONG).show()}}
        else shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){
        if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"Hindi PDF नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
        else android.widget.Toast.makeText(context,"Hindi PDF नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()
    }
    }
    if(background)reportPdfExecutor.execute{generate()} else generate()
}

private fun caneSeason(date:String=today()):String{
    return try{
        val y=date.take(4).toInt(); val m=date.substring(5,7).toInt()
        if(m>=4) "$y-${(y+1).toString().takeLast(2)}" else "${y-1}-${y.toString().takeLast(2)}"
    }catch(_:Exception){"2026-27"}
}


@Composable
private fun CanePeelingScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    var tab by rememberSaveable{mutableStateOf(0)}
    var showEntry by rememberSaveable{mutableStateOf(false)}
    var showPayment by rememberSaveable{mutableStateOf(false)}
    var showLabours by rememberSaveable{mutableStateOf(false)}
    var quickAddFandi by rememberSaveable{mutableStateOf(false)}
    var quickAddDate by rememberSaveable{mutableStateOf(today())}
    var quickAddField by rememberSaveable{mutableStateOf("")}
    var selectedLabour by remember{mutableStateOf<String?>(null)}
    var selectedField by remember{mutableStateOf<String?>(null)}
    var editEntry by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedEdit by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedDelete by remember{mutableStateOf<CanePeeling?>(null)}
    var editPayment by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentEdit by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentDelete by remember{mutableStateOf<CanePeelingPayment?>(null)}

    if(showLabours){
        CanePeelingLabourScreen(store,{showLabours=false;quickAddFandi=false},quickAddDate,quickAddField,quickAddFandi)
        return
    }
    if(selectedLabour!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingLabourDetail(store,selectedLabour!!,{selectedLabour=null},{showPayment=true})
        }
        if(showPayment){CanePeelingPaymentDialog(store,null,selectedLabour!!){showPayment=false}}
        return
    }
    if(selectedField!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingFieldDetail(store,selectedField!!,{selectedField=null},{showEntry=true})
        }
        if(showEntry){CanePeelingSingleEntryDialog(store,selectedField!!,quickAddDate){showEntry=false;selectedField=null}}
        return
    }
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌿 गन्ना छिलाई • फांदी हिसाब",onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=12.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
            listOf("मुख्य","Search / Filter","भुगतान").forEachIndexed{index,label->FilterChip(selected=tab==index,onClick={tab=index},label={Text(label)})}
        }
        when(tab){
            0->CanePeelingHome(store,{quickAddDate=today();quickAddField="";showEntry=true},{tab=1},{tab=2},{quickAddDate=today();quickAddField="";quickAddFandi=false;showLabours=true})
            1->CanePeelingSearch(store,{selectedLabour=it},{selectedField=it},{editEntry=it;showEntry=true},{protectedDelete=it})
            else->CanePeelingPayments(store,{protectedPaymentEdit=it},{protectedPaymentDelete=it},{selectedLabour=it.labourId})
        }
    }
    if(showEntry){if(editEntry!=null) CanePeelingEntryDialog(store,editEntry,""){showEntry=false;editEntry=null} else CanePeelingSingleEntryDialog(store,quickAddField,quickAddDate){showEntry=false}}
    protectedDelete?.let{row->DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ","यदि इस मजदूर का भुगतान इतिहास है, तो हिसाब सुरक्षित रखने के लिए हटाना रोका जाएगा।",{val deleted=store.deleteCanePeeling(row.id);if(!deleted)android.widget.Toast.makeText(context,"इस मजदूर का भुगतान इतिहास मौजूद है। हिसाब सुरक्षित रखने के लिए रिकॉर्ड हटाना रोका गया; रिकॉर्ड Edit करें।",android.widget.Toast.LENGTH_LONG).show();protectedDelete=null},{protectedDelete=null})}
    if(showPayment){CanePeelingPaymentDialog(store,null,"",{showPayment=false})}
    protectedPaymentEdit?.let{DeviceCredentialGate("छिलाई भुगतान बदलें","भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।",{editPayment=it;protectedPaymentEdit=null},{protectedPaymentEdit=null})}
    protectedPaymentDelete?.let{DeviceCredentialDeleteGate("छिलाई भुगतान हटाएँ","यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।",{store.deleteCanePeelingPayment(it.id);protectedPaymentDelete=null},{protectedPaymentDelete=null})}
    editPayment?.let{CanePeelingPaymentDialog(store,it,"",{editPayment=null})}
}

@Composable
private fun CanePeelingHome(store:Store,onAdd:()->Unit,onSearch:()->Unit,onPayments:()->Unit,onLabours:()->Unit){
    var rateText by remember(store.fandiRate){mutableStateOf(formatFandiRate(store.fandiRate))}
    var rateMessage by rememberSaveable{mutableStateOf("")}
    var showRateDialog by rememberSaveable{mutableStateOf(false)}
    val day=today()
    val todayRows=store.canePeelings.filter{it.date==day}
    val todayFandi=todayRows.sumOf{it.fandi}
    val todayAmount=todayRows.sumOf{it.total}
    val paidToday=store.canePeelingPayments.filter{it.date==day}.sumOf{it.amount}
    val todayWorkers=todayRows.map{it.labourId}.distinct().size
    val recentDates=store.canePeelings.map{it.date}.distinct().sortedDescending().take(10)
    var detailDate by rememberSaveable { mutableStateOf("") }
    if(showRateDialog) AlertDialog(
        onDismissRequest={showRateDialog=false},
        title={Text("फांदी का रेट बदलें",fontWeight=FontWeight.Bold)},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("वर्तमान रेट: ₹${formatFandiRate(store.fandiRate)} प्रति फांदी")
            AppTextField(value=rateText,onValueChange={input->val normalized=input.replace(',','.').filter{c->c.isDigit()||c=='.'};val dot=normalized.indexOf('.');rateText=if(dot<0) normalized else normalized.substring(0,dot+1)+normalized.substring(dot+1).replace(".","")},singleLine=true,label={Text("नया रेट (₹ प्रति फांदी)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
            Text("नया रेट केवल आगे की एंट्री पर लागू होगा। पुराने रिकॉर्ड नहीं बदलेंगे।",fontSize=12.sp,color=Color.Gray)
            if(rateMessage.isNotBlank()) Text(rateMessage,fontSize=12.sp,color=if(rateMessage.contains("सेव")) Green else Color(0xFFB3261E))
        }},
        confirmButton={Button(onClick={val r=rateText.trim().replace(',','.').toDoubleOrNull();if(r!=null&&r>0&&r.isFinite()){if(store.updateFandiRate(r)){rateMessage="नया रेट सेव हो गया।";showRateDialog=false}else rateMessage="रेट सेव नहीं हुआ। दोबारा कोशिश करें।"}else rateMessage="सही रेट दर्ज करें।"},colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("रेट सेव करें")}},
        dismissButton={TextButton(onClick={showRateDialog=false}){Text("रद्द करें")}}
    )
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){
                Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("गन्ना छिलाई",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
                            Text("दैनिक फांदी और मजदूरी का हिसाब",color=Color.White.copy(alpha=.82f),fontSize=12.sp)
                        }
                        Column(horizontalAlignment=Alignment.End,verticalArrangement=Arrangement.spacedBy(5.dp)){
                            Surface(shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.14f)){
                                Column(Modifier.padding(horizontal=10.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally){
                                    Icon(Icons.Default.DateRange,null,tint=Color.White)
                                    Text(displayDate(day),fontSize=10.sp,color=Color.White,fontWeight=FontWeight.Bold)
                                }
                            }
                            TextButton(onClick={rateText=formatFandiRate(store.fandiRate);rateMessage="";showRateDialog=true},contentPadding=PaddingValues(horizontal=8.dp,vertical=0.dp)){
                                Icon(Icons.Default.Settings,null,tint=Color.White,modifier=Modifier.size(15.dp));Spacer(Modifier.width(3.dp));Text("रेट बदलें",fontSize=11.sp,color=Color.White,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की फांदी",money(todayFandi),Color(0xFFE4F6EA))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की राशि","₹${formatFandiRate(todayAmount)}",Color(0xFFE5F0FF))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज भुगतान","₹${formatFandiRate(paidToday)}",Color(0xFFFFF0D9))}
                    }
                    Text("आज $todayWorkers मजदूरों की एंट्री",color=Color.White.copy(alpha=.9f),fontSize=12.sp)
                }
            }
        }
        item{
            Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("आज की छिलाई दर्ज करें",fontWeight=FontWeight.Bold,fontSize=16.sp)
            }
        }
        item{
            Button(onClick=onLabours,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){
                Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("फांदी मजदूर सूची / नया मजदूर",fontWeight=FontWeight.Bold,fontSize=14.sp)
            }
        }
        item{Text("पहले मजदूर जोड़ें, फिर ‘आज की छिलाई दर्ज करें’ से एक-एक मजदूर की फांदी सेव करें।",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(horizontal=3.dp))}
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
                OutlinedButton(onClick=onSearch,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Search,null);Spacer(Modifier.width(5.dp));Text("खोजें / रिकॉर्ड")
                }
                OutlinedButton(onClick=onPayments,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Payments,null);Spacer(Modifier.width(5.dp));Text("भुगतान")
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("हाल की छिलाई",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,color=GreenDark)
                    Text("तारीख के अनुसार रिकॉर्ड और कुल राशि",fontSize=11.sp,color=Color.Gray)
                }
                Surface(shape=RoundedCornerShape(50),color=Color(0xFFE6F5EC)){
                    Text("${store.canePeelings.size} रिकॉर्ड",Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=11.sp,color=GreenDark,fontWeight=FontWeight.Bold)
                }
            }
        }
        if(recentDates.isEmpty()) item{EmptyCard("अभी कोई गन्ना छिलाई रिकॉर्ड नहीं है। शुरू करने के लिए ‘आज की छिलाई दर्ज करें’ दबाएँ।")}
        recentDates.forEach{d->
            item(key="cane_day_$d"){
                val rows=store.canePeelings.filter{it.date==d}
                val fieldNames=rows.map{it.fieldId}.filter{it.isNotBlank()}.distinct().mapNotNull{id->store.fields.firstOrNull{it.id==id}?.name}
                Card(Modifier.fillMaxWidth().clickable { detailDate=d },RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFFE8F5ED)){
                                Icon(Icons.Default.DateRange,null,Modifier.padding(10.dp),tint=GreenDark)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)){
                                Text(displayDate(d),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                                Text(if(fieldNames.isEmpty())"खेत नहीं चुना गया" else fieldNames.joinToString(", "),fontSize=11.sp,color=Color.Gray,maxLines=2)
                            }
                            Text("₹${formatFandiRate(rows.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=Green)
                        }
                        Divider(color=Color(0xFFE8ECE9))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                            Text("${rows.map{it.labourId}.distinct().size} मजदूर",fontSize=12.sp,color=Color.DarkGray)
                            Text("${money(rows.sumOf{it.fandi})} फांदी",fontSize=13.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("${rows.size} एंट्री",fontSize=11.sp,color=Color.Gray)
                        }
                    }
                }
            }
        }
    }
    if(detailDate.isNotBlank()) CanePeelingDayDetail(store,detailDate){detailDate=""}
}

@Composable private fun CanePeelingDayDetail(store:Store,date:String,onClose:()->Unit){
    val rows=store.canePeelings.filter{it.date==date}.sortedBy{store.fandiLabours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()}
    SimpleDialog("${displayDate(date)} • छिलाई मजदूर",onClose){
        Text("${rows.size} एंट्री • ${rows.map{it.labourId}.distinct().size} मजदूर",fontWeight=FontWeight.Bold,color=GreenDark)
        Text("कुल ${money(rows.sumOf{it.fandi})} फांदी • मजदूरी ₹${formatFandiRate(rows.sumOf{it.total})}",fontWeight=FontWeight.Bold)
        androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxWidth().heightIn(max=440.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows,key={it.id}){row->
                val worker=store.fandiLabours.firstOrNull{it.id==row.labourId}
                val field=store.fields.firstOrNull{it.id==row.fieldId}?.name ?: "खेत नहीं चुना"
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(12.dp)){
                    Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                        Text(worker?.name ?: "मजदूर रिकॉर्ड नहीं मिला",fontWeight=FontWeight.Bold,color=GreenDark)
                        Text("खेत: $field",fontSize=12.sp,color=Color.Gray)
                        Text("${money(row.fandi)} फांदी × ₹${formatFandiRate(row.rate)} = ₹${formatFandiRate(row.total)}",fontWeight=FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
@Composable private fun CaneMiniStat(label:String,value:String,bg:Color){Card(colors=CardDefaults.cardColors(containerColor=bg),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(8.dp)){Text(label,fontSize=9.sp,color=GreenDark);Text(value,fontWeight=FontWeight.ExtraBold,fontSize=15.sp,color=GreenDark)}}}
@Composable private fun EmptyCard(text:String){SharedStatePanel("कोई रिकॉर्ड नहीं",text,"empty")}

@Composable
private fun CanePeelingSingleEntryDialog(store:Store,presetField:String,initialDate:String=today(),onClose:()->Unit){
    var date by remember{mutableStateOf(initialDate)}
    var field by remember{mutableStateOf(presetField)}
    var labour by rememberSaveable{mutableStateOf(store.fandiLabours.firstOrNull()?.id.orEmpty())}
    var fandi by rememberSaveable{mutableStateOf("")}
    var error by rememberSaveable{mutableStateOf("")}
    val rate=store.fandiRate
    SimpleDialog("एक मजदूर की फांदी दर्ज करें",onClose){
        Text("एक बार में केवल एक मजदूर की एंट्री सेव होगी।",fontSize=12.sp,color=Color.Gray)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("मजदूर *",store.fandiLabours.map{it.id to it.name},labour){labour=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        AppTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},modifier=Modifier.fillMaxWidth(),label={Text("फांदी की संख्या *")},singleLine=true)
        Text("रेट: ₹${formatFandiRate(rate)} प्रति फांदी",fontWeight=FontWeight.Bold,color=GreenDark)
        val amount=(fandi.toDoubleOrNull()?:0.0)*rate
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल मजदूरी",fontWeight=FontWeight.Bold);Text("₹${formatFandiRate(amount)}",fontWeight=FontWeight.ExtraBold,color=Green)}}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={val f=fandi.toDoubleOrNull()?:0.0;when{labour.isBlank()->error="पहले मजदूर जोड़ें।";!validDate(date)->error="सही तारीख चुनें।";f<=0||!f.isFinite()->error="फांदी की संख्या सही डालें।";rate<=0||!rate.isFinite()->error="पहले सही फांदी रेट सेव करें।";store.canePeelings.any{it.labourId==labour&&it.fieldId==field&&it.date==date}->error="इस मजदूर की इस तारीख और खेत की एंट्री पहले से है।";else->{val saved=store.addCanePeeling(CanePeeling(UUID.randomUUID().toString(),labour,field,date,f,rate,amount));if(saved)onClose() else error="फांदी सेव नहीं हुई। मजदूर/खेत या डुप्लिकेट रिकॉर्ड जाँचें।"}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("✓ फांदी सेव करें")}
    }
}

@Composable
private fun CanePeelingEntryDialog(store:Store,existing:CanePeeling?,presetField:String,onClose:()->Unit){
    var date by rememberSaveable{mutableStateOf(existing?.date?:today())}; var field by remember{mutableStateOf(existing?.fieldId?:presetField)}; var labour by rememberSaveable{mutableStateOf(existing?.labourId?:store.fandiLabours.firstOrNull()?.id.orEmpty())}; var fandi by rememberSaveable{mutableStateOf(if(existing!=null) money(existing.fandi) else "")}; var error by rememberSaveable{mutableStateOf("")}
    val r=existing?.rate ?: store.fandiRate
    SimpleDialog(if(existing==null) "आज की छिलाई दर्ज करें" else "छिलाई रिकॉर्ड बदलें",onClose){
        Text("फांदी रेट Settings में एक बार सेट करें। नई एंट्री में वही रेट अपने-आप लगेगा। पुराने रिकॉर्ड का सेव किया हुआ रेट बदलता नहीं है।",fontSize=11.sp,color=Color.Gray)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        ChoiceField("मजदूर *",store.fandiLabours.map{it.id to it.name},labour){labour=it}
        AppTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},label={Text("फांदी")},singleLine=true)
        Text("फांदी रेट: ₹${formatFandiRate(r)} / फांदी",fontWeight=FontWeight.Bold,color=GreenDark)
        val f=fandi.toDoubleOrNull()?:0.0
        val total=f*r
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${formatFandiRate(total)}",fontWeight=FontWeight.ExtraBold,color=Green)}}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={when{labour.isBlank()->error="मजदूर चुनें।";!validDate(date)->error="सही तारीख चुनें।";f<=0||!f.isFinite()->error="फांदी सही डालें।";r<=0||!r.isFinite()->error="Settings में फांदी रेट सेट करें।";else->{val duplicate=store.canePeelings.any{it.id!=existing?.id&&it.labourId==labour&&it.fieldId==field&&it.date==date};if(duplicate){error="इस मजदूर की इस तारीख और खेत की फांदी पहले से दर्ज है। पुराने रिकॉर्ड को खोलकर बदलें।"}else{val x=(existing ?: CanePeeling(UUID.randomUUID().toString(),labour,field,date,f,r,total)).copy(labourId=labour,fieldId=field,date=date,fandi=f,rate=r,total=total);val saved=if(existing==null)store.addCanePeeling(x) else store.updateCanePeeling(x);if(saved)onClose() else error="रिकॉर्ड सेव नहीं हुआ। मजदूर, खेत, तारीख और डुप्लिकेट एंट्री जाँचें।"}}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("✓ फांदी सेव करें")}
    }
}

@Composable
private fun CanePeelingSearch(store:Store,onLabour:(String)->Unit,onField:(String)->Unit,onEdit:(CanePeeling)->Unit,onDelete:(CanePeeling)->Unit){
    var query by rememberSaveable{mutableStateOf("")}
    var from by rememberSaveable{mutableStateOf("")}
    var to by rememberSaveable{mutableStateOf("")}
    var labourId by rememberSaveable{mutableStateOf("")}
    var fieldId by rememberSaveable{mutableStateOf("")}
    var rate by rememberSaveable{mutableStateOf("")}
    var paymentStatus by rememberSaveable{mutableStateOf("")}
    var showExport by rememberSaveable{mutableStateOf(false)}

    val base=store.canePeelings.filter{row->
        val l=store.fandiLabours.firstOrNull{it.id==row.labourId}
        val f=store.fields.firstOrNull{it.id==row.fieldId}
        val q=normalizeSearch(query)
        val earned=store.canePeelings.filter{it.labourId==row.labourId}.sumOf{it.total}
        val paid=store.canePeelingPayments.filter{it.labourId==row.labourId}.sumOf{it.amount}
        val bal=earned-paid
        (q.isBlank()||searchMatches(q,l?.name,l?.mobile,f?.name,row.date,row.fandi.toString(),row.rate.toString(),row.total.toString())) &&
        (from.isBlank()||row.date>=from)&&(to.isBlank()||row.date<=to) &&
        (labourId.isBlank()||row.labourId==labourId)&&(fieldId.isBlank()||row.fieldId==fieldId) &&
        (rate.isBlank()||row.rate==rate.toDoubleOrNull()) &&
        (paymentStatus.isBlank() || when(paymentStatus){"paid"->bal<=0.009;"partial"->paid>0.009&&bal>0.009;"pending"->paid<=0.009&&bal>0.009;else->true})
    }.sortedWith(compareByDescending<CanePeeling>{it.date}.thenBy{store.fandiLabours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})

    val totalFandi=base.sumOf{it.fandi}
    val totalAmount=base.sumOf{it.total}
    val workers=base.map{it.labourId}.distinct().size
    val fields=base.map{it.fieldId}.filter{it.isNotBlank()}.distinct().size
    val days=base.map{it.date}.distinct().size
    val context=LocalContext.current

    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item{
            AppTextField(
                value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                label={Text("नाम, मोबाइल, खेत, तारीख या राशि खोजें")},
                leadingIcon={Icon(Icons.Default.Search,null)},
                trailingIcon={if(query.isNotBlank()){IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}}}
            )
        }
        item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("फिल्टर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark,modifier=Modifier.weight(1f));TextButton(onClick={query="";from="";to="";labourId="";fieldId="";rate="";paymentStatus=""}){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("रीसेट")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){DateFilterField("से",from){from=it}};Box(Modifier.weight(1f)){DateFilterField("तक",to){to=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("मजदूर",listOf("" to "सभी मजदूर")+store.fandiLabours.map{it.id to it.name},labourId){labourId=it}};Box(Modifier.weight(1f)){ChoiceField("खेत",listOf("" to "सभी खेत")+store.fields.map{it.id to it.name},fieldId){fieldId=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("रेट",listOf("" to "सभी रेट")+store.canePeelings.map{it.rate}.distinct().sorted().map{it.toString() to "₹${formatFandiRate(it)} / फांदी"},rate){rate=it}};Box(Modifier.weight(1f)){ChoiceField("भुगतान",listOf("" to "सभी","paid" to "पूरा भुगतान","partial" to "आंशिक भुगतान","pending" to "पूरा बाकी"),paymentStatus){paymentStatus=it}}}}

        item{
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(16.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${base.size} रिकॉर्ड");Text("$workers मजदूर");Text("$fields खेत");Text("$days दिन")}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल फांदी",fontWeight=FontWeight.Bold);Text(money(totalFandi),fontWeight=FontWeight.ExtraBold,color=Green);Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${money(totalAmount)}",fontWeight=FontWeight.ExtraBold,color=Green)}
                }
            }
        }

        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF3FF)),elevation=CardDefaults.cardElevation(1.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Landscape,null,tint=Color(0xFF315B8A),modifier=Modifier.size(25.dp));Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("खेतवार छिलाई विवरण",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark);Text("खेत चुनें → उस खेत का पूरा हिसाब और PDF",fontSize=11.sp,color=Color.Gray)}}
                    if(store.fields.isEmpty())Text("पहले खेत जोड़ें।",fontSize=12.sp,color=Color.Gray)
                    else store.fields.sortedBy{it.name.lowercase(Locale.getDefault())}.forEach{field->
                        val fieldRows=store.canePeelings.filter{it.fieldId==field.id}
                        Card(Modifier.fillMaxWidth().clickable{onField(field.id)},RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                            Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(field.name,fontWeight=FontWeight.Bold,color=GreenDark);Text("${fieldRows.size} एंट्री • ${fieldRows.map{it.labourId}.distinct().size} मजदूर • ${money(fieldRows.sumOf{it.fandi})} फांदी",fontSize=11.sp,color=Color.Gray)};Column(horizontalAlignment=Alignment.End){Text("₹${money(fieldRows.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,color=Green);Icon(Icons.Default.ChevronRight,null,tint=Green)}}
                        }
                    }
                    val unassigned=store.canePeelings.filter{it.fieldId.isBlank()}
                    if(unassigned.isNotEmpty())Text("खेत नहीं चुने गए रिकॉर्ड: ${unassigned.size} • ₹${money(unassigned.sumOf{it.total})} (ये किसी खेत के कुल में शामिल नहीं हैं)",fontSize=11.sp,color=Color(0xFF7A5A16))
                }
            }
        }

        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Groups,null,tint=Green,modifier=Modifier.size(26.dp));Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("सभी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark);Text("नाम पर टैप करें → पूरा हिसाब",fontSize=11.sp,color=Color.Gray)}}
                    if(store.fandiLabours.isEmpty()) Text("अभी कोई फांदी मजदूर नहीं है।",color=Color.Gray)
                    else store.fandiLabours.sortedBy{it.name.lowercase(Locale.getDefault())}.forEach{l->
                        val rr=store.canePeelings.filter{it.labourId==l.id}
                        val earned=rr.sumOf{it.total}
                        val paid=store.canePeelingPayments.filter{it.labourId==l.id}.sumOf{it.amount}
                        Card(Modifier.fillMaxWidth().clickable{onLabour(l.id)},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF4FAF7))){
                            Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                                val outstanding=(earned-paid).coerceAtLeast(0.0);val advance=(paid-earned).coerceAtLeast(0.0)
                                PhotoThumb(l.photo);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी • ₹${money(earned)}",fontSize=11.sp,color=Green);if(paid>0)Text("भुगतान ₹${money(paid)} • बाकी ₹${money(outstanding)}${if(advance>0.009)" • एडवांस ₹${money(advance)}" else ""}",fontSize=10.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null,tint=Green)}
                        }
                    }
                }
            }
        }

        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                Button(onClick={showExport=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4FB3))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF / Excel")}
            }
        }

        if(base.isEmpty()) item{EmptyCard("इस Filter से कोई रिकॉर्ड नहीं मिला।")}
        base.forEach{row->
            item(key=row.id){
                val l=store.fandiLabours.firstOrNull{it.id==row.labourId}; val f=store.fields.firstOrNull{it.id==row.fieldId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp)){
                    Column(Modifier.padding(11.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f).clickable{onLabour(row.labourId)}){Text(l?.name?:"मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text(displayDate(row.date),fontSize=11.sp,color=Color.Gray);Text("🌾 ${f?.name?:"खेत नहीं चुना"}",fontSize=11.sp,color=Green,modifier=Modifier.clickable{if(f!=null)onField(f.id)})}
                            Text("₹${formatFandiRate(row.total)}",fontWeight=FontWeight.ExtraBold,color=Green)
                            IconButton(onClick={onEdit(row)}){Icon(Icons.Default.Edit,null,tint=Green)}
                            IconButton(onClick={onDelete(row)}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${money(row.fandi)} फांदी");Text("₹${formatFandiRate(row.rate)} / फांदी",color=Color.Gray);Text("₹${formatFandiRate(row.total)}",fontWeight=FontWeight.Bold)}
                    }
                }
            }
        }
    }
    if(showExport) CanePeelingExportDialog(store,base){showExport=false}
}

@Composable
private fun CanePeelingExportDialog(store:Store,rows:List<CanePeeling>,onClose:()->Unit){
    val allIds=remember(rows){rows.map{it.labourId}.distinct()}
    var selected by remember(rows){mutableStateOf(allIds.toSet())}
    val context=LocalContext.current
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("रिपोर्ट बनाएं",fontWeight=FontWeight.ExtraBold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp)){
            Text("सभी मजदूर या अपनी पसंद के मजदूर चुनें।",fontSize=12.sp,color=Color.Gray)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={selected=allIds.toSet()},modifier=Modifier.weight(1f)){Text("✓ Mark All")}
                OutlinedButton(onClick={selected=emptySet()},modifier=Modifier.weight(1f)){Text("सब हटाएं")}
            }
            if(allIds.isEmpty()) Text("कोई रिकॉर्ड उपलब्ध नहीं है।",color=Color.Gray)
            else LazyColumn(Modifier.weight(1f,false),verticalArrangement=Arrangement.spacedBy(2.dp)){
                items(allIds){id->
                    val l=store.fandiLabours.firstOrNull{it.id==id}
                    Row(Modifier.fillMaxWidth().clickable{selected=if(selected.contains(id))selected-id else selected+id},verticalAlignment=Alignment.CenterVertically){Checkbox(checked=selected.contains(id),onCheckedChange={checked->selected=if(checked)selected+id else selected-id});Text(l?.name?:"मजदूर",fontWeight=FontWeight.SemiBold)}
                }
            }
            Text("${selected.size} मजदूर चुने गए",fontWeight=FontWeight.Bold,color=Green)
        }},
        confirmButton={Button(onClick={
            if(selected.isEmpty()) return@Button
            val chosen=rows.filter{selected.contains(it.labourId)}
            val lines=chosen.map{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId};val f=store.fields.firstOrNull{it.id==r.fieldId};"${displayDate(r.date)} • ${l?.name?:"मजदूर"} • ${f?.name?:"खेत नहीं चुना"} • ${money(r.fandi)} फांदी × ₹${formatFandiRate(r.rate)} = ₹${formatFandiRate(r.total)}"}
            exportReportPdf(context,"गन्ना_छिलाई_रिपोर्ट","${selected.size} मजदूर • ${chosen.map{it.fieldId}.distinct().size} खेत • ${chosen.map{it.date}.distinct().size} दिन • ${money(chosen.sumOf{it.fandi})} फांदी • ₹${money(chosen.sumOf{it.total})}",lines);onClose()
        },enabled=selected.isNotEmpty()){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF बनाएं")}},
        dismissButton={OutlinedButton(onClick={
            if(selected.isEmpty()) return@OutlinedButton
            exportCanePeelingCsv(context,rows.filter{selected.contains(it.labourId)},store);onClose()
        }){Text("CSV / Excel")}}
    )
}

private fun csvCell(value:String):String = "\"${value.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ")}\""

private fun exportCanePeelingCsv(context:Context,rows:List<CanePeeling>,store:Store){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Chhilai_${System.currentTimeMillis()}.csv")
        file.writeText(buildString{
            append("तारीख,मजदूर,खेत,फांदी,रेट,राशि\n")
            rows.forEach{r->
                val l=store.fandiLabours.firstOrNull{it.id==r.labourId}
                val f=store.fields.firstOrNull{it.id==r.fieldId}
                append(listOf(csvCell(r.date),csvCell(l?.name.orEmpty()),csvCell(f?.name?:"खेत नहीं चुना"),r.fandi.toString(),r.rate.toString(),r.total.toString()).joinToString(","))
                append("\n")
            }
        },Charsets.UTF_8)
        shareFile(context,file,"text/csv","CSV साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"CSV report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable
private fun DateFilterField(label:String,value:String,onSelected:(String)->Unit){
    val context=LocalContext.current
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        OutlinedButton(onClick={
            val parsed=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value.ifBlank{today()})}catch(_:Exception){Date()}
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(context,{_,year,month,day->
                val selected=Calendar.getInstance().apply{set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)}
                onSelected(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time))
            },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=System.currentTimeMillis()}.show()
        },modifier=Modifier.weight(1f)){Text(if(value.isBlank()) "$label: कोई सीमा" else "$label: ${displayDate(value)}",maxLines=1);Spacer(Modifier.width(4.dp));Icon(Icons.Default.DateRange,null)}
        if(value.isNotBlank()) IconButton(onClick={onSelected("")}){Icon(Icons.Default.Clear,null)}
    }
}

@Composable
private fun CanePeelingLabourScreen(store:Store,onBack:()->Unit,initialDate:String=today(),initialField:String="",autoOpenAdd:Boolean=false){
    var add by remember{mutableStateOf(autoOpenAdd)}
    var edit by remember{mutableStateOf<FandiLabour?>(null)}
    var delete by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedEdit by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedDelete by remember{mutableStateOf<FandiLabour?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    val context=LocalContext.current
    val visibleWorkers=store.fandiLabours.filter{searchMatches(query,it.name,it.mobile,it.address)}.sortedBy{it.name.lowercase(Locale.ROOT)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("👷 फांदी मजदूर",onBack)
        Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
            Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("फांदी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=22.sp,color=Color.White)
                    Text("${store.fandiLabours.size} सेव मजदूर • नाम दोबारा सेव नहीं होगा",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                }
                Button(onClick={add=true},shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("नया मजदूर")}
            }
        }
        AppTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=7.dp),singleLine=true,label={Text("मजदूर का नाम / मोबाइल खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}},shape=RoundedCornerShape(15.dp))
        if(visibleWorkers.isEmpty()){
            Box(Modifier.weight(1f).fillMaxWidth().padding(14.dp),contentAlignment=Alignment.TopCenter){EmptyCard(if(query.isBlank())"अभी कोई फांदी मजदूर नहीं है। ‘नया मजदूर’ दबाकर जोड़ें।" else "इस नाम से कोई मजदूर नहीं मिला।")}
        }else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=14.dp)){
            items(visibleWorkers,key={it.id}){l->
                val workRows=store.canePeelings.filter{it.labourId==l.id}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo);Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                            Text(l.mobile.ifBlank{"मोबाइल नहीं दिया"},fontSize=11.sp,color=Color.Gray)
                            Text("${workRows.size} रिकॉर्ड • ${money(workRows.sumOf{it.fandi})} फांदी • ₹${money(workRows.sumOf{it.total})}",fontSize=11.sp,color=Green,fontWeight=FontWeight.SemiBold)
                        }
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FandiLabourDialog(store,null,initialDate,initialField){add=false;if(autoOpenAdd)onBack()}
    protectedEdit?.let{worker->DeviceCredentialGate("फांदी मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=worker;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{worker->DeviceCredentialDeleteGate("फांदी मजदूर हटाएँ","पुराना हिसाब सुरक्षित रखने के लिए रिकॉर्ड वाले मजदूर को हटाया नहीं जा सकेगा।",{delete=worker;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FandiLabourDialog(store,edit){edit=null}
    delete?.let{worker->ConfirmDialog("फांदी मजदूर हटाएँ?","इस मजदूर का कोई छिलाई या भुगतान रिकॉर्ड नहीं होना चाहिए। पुराने रिकॉर्ड सुरक्षित रखे जाएंगे।",{
        val deleted=store.deleteFandiLabour(worker.id)
        if(!deleted) android.widget.Toast.makeText(context,"इस मजदूर का पुराना छिलाई/भुगतान हिसाब मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()
        delete=null
    },{delete=null})}
}
@Composable
private fun FandiLabourDialog(store:Store,existing:FandiLabour?,initialDate:String=today(),initialField:String="",onClose:()->Unit){
    var name by rememberSaveable{mutableStateOf(existing?.name.orEmpty())}
    var address by rememberSaveable{mutableStateOf(existing?.address.orEmpty())}
    var mobile by rememberSaveable{mutableStateOf(existing?.mobile.orEmpty())}
    var photo by rememberSaveable{mutableStateOf(existing?.photo.orEmpty())}
    var showExtra by remember{mutableStateOf(existing!=null)}
    var saveTodayFandi by rememberSaveable{mutableStateOf(false)}
    var date by remember{mutableStateOf(initialDate)}
    var field by remember{mutableStateOf(initialField)}
    var fandi by rememberSaveable{mutableStateOf("")}
    var error by rememberSaveable{mutableStateOf("")}
    var saving by rememberSaveable{mutableStateOf(false)}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank())photo=persisted}}
    SimpleDialog(if(existing==null)"फांदी मजदूर जोड़ें" else "फांदी मजदूर बदलें",onClose){
        Text("नाम सेव करते समय ही आज की फांदी भी दर्ज कर सकते हैं।",fontSize=12.sp,color=Color.Gray)
        AppTextField(value=name,onValueChange={name=it},label={Text("मजदूर का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        TextButton(onClick={showExtra=!showExtra}){Text(if(showExtra)"− अतिरिक्त जानकारी छिपाएँ" else "+ पता / मोबाइल / फोटो (वैकल्पिक)")}
        if(showExtra){
            AppTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            AppTextField(value=mobile,onValueChange={mobile=it.filter{c->c.isDigit()||c=='+'}},label={Text("मोबाइल (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")}
        }
        if(existing==null){
            Row(Modifier.fillMaxWidth().clickable{saveTodayFandi=!saveTodayFandi}.padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=saveTodayFandi,onCheckedChange={saveTodayFandi=it});Spacer(Modifier.width(5.dp));Column{Text("आज की फांदी भी साथ में सेव करें",fontWeight=FontWeight.Bold);Text("मजदूर का नाम और फांदी एक ही बार में सेव होंगे।",fontSize=11.sp,color=Color.Gray)}}
            if(saveTodayFandi){
                Text("दिनांक",fontWeight=FontWeight.SemiBold)
                AttendanceDateButton(date){date=it}
                ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
                AppTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},label={Text("आज की फांदी *")},singleLine=true,modifier=Modifier.fillMaxWidth())
                val amount=(fandi.toDoubleOrNull()?:0.0)*store.fandiRate
                Text("रेट ₹${formatFandiRate(store.fandiRate)} / फांदी • कुल ₹${formatFandiRate(amount)}",fontWeight=FontWeight.Bold,color=GreenDark)
            }
        }
        if(error.isNotBlank())Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE8E6)),shape=RoundedCornerShape(12.dp)){Text(error,Modifier.padding(10.dp),color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)}
        Button(enabled=!saving,onClick={
            if(!saving){
                val f=fandi.toDoubleOrNull()?:0.0
                val normalizedName=name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
                val sameNameAlreadySaved=store.fandiLabours.any{old->
                    old.id!=existing?.id && old.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)==normalizedName
                }
                when{
                    name.isBlank()->error="मजदूर का नाम लिखें।"
                    sameNameAlreadySaved->error="यह नाम पहले से सेव है। उसी मजदूर को सूची से चुनें; नाम दोबारा सेव नहीं होगा।"
                    existing==null && saveTodayFandi && field.isNotBlank() && store.fields.none{it.id==field}->error="चुना हुआ खेत उपलब्ध नहीं है। खेत हटाएँ या दूसरा चुनें।"
                    existing==null && saveTodayFandi && !validDate(date)->error="सही तारीख चुनें।"
                    existing==null && saveTodayFandi && (f<=0||!f.isFinite())->error="आज की फांदी सही डालें।"
                    existing==null && saveTodayFandi && (store.fandiRate<=0||!store.fandiRate.isFinite())->error="पहले सही फांदी रेट सेट करें।"
                    else->{
                        val phoneKey=mobile.filter{it.isDigit()}
                        val duplicatePhone=existing==null && phoneKey.length>=7 && store.fandiLabours.any{old->old.mobile.filter{it.isDigit()}.let{it.length>=7&&it==phoneKey}}
                        if(duplicatePhone){error="यह मोबाइल नंबर पहले से सेव है। मौजूदा मजदूर की जानकारी देखें।"}
                        else{
                            saving=true
                            val resolvedId=existing?.id?:ownerId
                            val x=FandiLabour(resolvedId,name.trim(),address.trim(),existing?.rate?:0.0,mobile.trim(),photo)
                            if(existing!=null){
                                if(store.updateFandiLabour(x)) onClose() else {error="मजदूर की जानकारी सेव नहीं हुई। नाम/मोबाइल दोबारा जाँचें।";saving=false}
                            }else{
                                val workerSaved=store.addFandiLabour(x)
                                if(!workerSaved){error="यह नाम या मोबाइल पहले से मौजूद है। कोई नया रिकॉर्ड सेव नहीं हुआ।";saving=false}
                                else if(saveTodayFandi){
                                    val r=store.fandiRate
                                    val fandiSaved=store.addCanePeeling(CanePeeling(UUID.randomUUID().toString(),resolvedId,field,date,f,r,f*r))
                                    if(!fandiSaved){store.deleteFandiLabour(resolvedId);error="इस मजदूर की इस तारीख और खेत की फांदी पहले से दर्ज है। कोई नया हिसाब सेव नहीं हुआ। पुरानी एंट्री खोलकर जाँचें।";saving=false}
                                    else onClose()
                                }else onClose()
                            }
                        }
                    }
                }
            }
        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(saving)"सेव हो रहा है…" else if(existing==null && saveTodayFandi)"✓ मजदूर + आज की फांदी सेव करें" else "✓ फांदी मजदूर सेव करें")}
    }
}

@Composable
private fun CanePeelingLabourDetail(
    store: Store,
    labourId: String,
    onBack: () -> Unit,
    onPay: () -> Unit
) {
    val labour = store.fandiLabours.firstOrNull { it.id == labourId }
    if (labour == null) { onBack(); return }
    val context = LocalContext.current

    val rows = store.canePeelings.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val paid = store.canePeelingPayments.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val earned = rows.sumOf { it.total }
    val paidTotal = paid.sumOf { it.amount }
    val balance = (earned - paidTotal).coerceAtLeast(0.0)
    val advance = (paidTotal - earned).coerceAtLeast(0.0)
    val fields = rows.map { it.fieldId }.distinct()
    val days = rows.map { it.date }.distinct().size

    var selectedFieldId by remember { mutableStateOf<String?>(null) }
    var selectedRow by remember { mutableStateOf<CanePeeling?>(null) }
    var selectedPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedEdit by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedDelete by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedPaymentEdit by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedPaymentDelete by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var editRow by remember { mutableStateOf<CanePeeling?>(null) }
    var editPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("👷 ${labour.name} • पूरा हिसाब", onBack)
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF8F1))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoThumb(labour.photo); Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(labour.name, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = GreenDark)
                            if (labour.mobile.isNotBlank()) Text(labour.mobile, fontSize = 11.sp, color = Color.Gray)
                            Text("गन्ना छिलाई / फांदी मजदूर", fontSize = 11.sp, color = Green)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.weight(1f)) { Stat("कुल दिन", days.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल खेत", fields.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल रिकॉर्ड", rows.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("फांदी", rows.sumOf { it.fandi }) }
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            SummaryMoneyCard("कुल छिलाई राशि", "₹${money(earned)}", Green, Modifier.weight(1f))
                            SummaryMoneyCard("कुल भुगतान", "₹${money(paidTotal)}", Color(0xFF276B8A), Modifier.weight(1f))
                            SummaryMoneyCard("बाकी", "₹${money(balance)}", if (balance > 0) Color(0xFFB3261E) else Green, Modifier.weight(1f))
                        }
                        if(advance>0.009) Text("एडवांस / अधिक भुगतान: ₹${money(advance)}",fontWeight=FontWeight.Bold,color=Color(0xFF276B8A),fontSize=12.sp)
                    }
                }
            }
            item {
                Button(onClick = onPay, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Icon(Icons.Default.Payments, null); Spacer(Modifier.width(7.dp)); Text("इस मजदूर को भुगतान दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            item { SectionTitle("🌾 खेतवार हिसाब", "हर खेत में कितने दिन, फांदी और राशि • कार्ड पर टैप करें") }
            if (fields.isEmpty()) item { EmptyCard("इस मजदूर का अभी कोई छिलाई रिकॉर्ड नहीं है।") }
            fields.forEach { fieldId ->
                item(key = "field_$fieldId") {
                    val fieldRows = rows.filter { it.fieldId == fieldId }
                    val fieldName = store.fields.firstOrNull { it.id == fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedFieldId = fieldId },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🌾", fontSize = 27.sp); Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(fieldName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = GreenDark)
                                Text("${fieldRows.map { it.date }.distinct().size} दिन • ${money(fieldRows.sumOf { it.fandi })} फांदी", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹${money(fieldRows.sumOf { it.total })}", fontWeight = FontWeight.ExtraBold, color = Green)
                                Text("विवरण देखें ›", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
            item { SectionTitle("📅 तारीखवार पूरा हिसाब", "हर काम का पूरा रिकॉर्ड • रिकॉर्ड पर टैप करें") }
            rows.forEach { row ->
                item(key = "day_${row.id}") {
                    val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedRow = row },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(104.dp)) {
                                Text(displayDate(row.date), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = GreenDark)
                                Text(try { SimpleDateFormat("EEEE", Locale("hi", "IN")).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(row.date) ?: Date()) } catch (_: Exception) { "" }, fontSize = 10.sp, color = Color.Gray)
                            }
                            Column(Modifier.weight(1f)) {
                                Text("🌾 $fieldName", fontWeight = FontWeight.SemiBold)
                                Text("${money(row.fandi)} फांदी × ₹${formatFandiRate(row.rate)}", fontSize = 12.sp, color = Color.Gray)
                                Text("₹${formatFandiRate(row.total)}", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                            }
                            Text("›", fontSize = 26.sp, color = Green)
                        }
                    }
                }
            }
            item { SectionTitle("💳 भुगतान इतिहास", "किस दिन कितने रुपये दिए गए • भुगतान पर टैप करें") }
            if (paid.isEmpty()) item { EmptyCard("अभी कोई भुगतान दर्ज नहीं है।") }
            paid.forEach { payment ->
                item(key = "payment_${payment.id}") {
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedPayment = payment },
                        RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(displayDate(payment.date), fontWeight = FontWeight.Bold)
                                Text(payment.method.ifBlank { "नकद" }, fontSize = 11.sp, color = Color.Gray)
                                if (payment.note.isNotBlank()) Text(payment.note, fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("₹${formatFandiRate(payment.amount)}  ›", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                        }
                    }
                }
            }
        }
    }

    selectedFieldId?.let { fid ->
        val field = store.fields.firstOrNull { it.id == fid }
        val fr = rows.filter { it.fieldId == fid }
        SimpleDialog("🌾 ${field?.name ?: "खेत"} • पूरा हिसाब", { selectedFieldId = null }) {
            Text("कुल दिन: ${fr.map { it.date }.distinct().size}")
            Text("कुल फांदी: ${money(fr.sumOf { it.fandi })}")
            Text("कुल राशि: ₹${money(fr.sumOf { it.total })}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(6.dp))
            fr.forEach { r ->
                Text("${displayDate(r.date)} • ${money(r.fandi)} फांदी × ₹${formatFandiRate(r.rate)} = ₹${formatFandiRate(r.total)}", fontSize = 12.sp)
            }
        }
    }

    selectedRow?.let { row ->
        SimpleDialog("📅 छिलाई रिकॉर्ड", { selectedRow = null }) {
            val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
            Text("दिनांक: ${displayDate(row.date)}")
            Text("खेत: $fieldName")
            Text("फांदी: ${money(row.fandi)}")
            Text("दर: ₹${formatFandiRate(row.rate)}")
            Text("कुल राशि: ₹${formatFandiRate(row.total)}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedEdit = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedDelete = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    selectedPayment?.let { payment ->
        SimpleDialog("💳 भुगतान विवरण", { selectedPayment = null }) {
            Text("दिनांक: ${displayDate(payment.date)}")
            Text("राशि: ₹${formatFandiRate(payment.amount)}", fontWeight = FontWeight.Bold, color = Green)
            Text("तरीका: ${payment.method.ifBlank { "नकद" }}")
            if (payment.note.isNotBlank()) Text("टिप्पणी: ${payment.note}")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedPaymentEdit = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedPaymentDelete = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    protectedEdit?.let { row ->
        DeviceCredentialGate("छिलाई रिकॉर्ड बदलें", "इस रिकॉर्ड की तारीख, खेत या फांदी बदलने के लिए Android screen lock से पुष्टि करें।", { editRow = row; protectedEdit = null }, { protectedEdit = null })
    }
    protectedDelete?.let { row ->
        DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ", "यदि इस मजदूर का भुगतान इतिहास है, तो हिसाब सुरक्षित रखने के लिए हटाना रोका जाएगा।", { val deleted=store.deleteCanePeeling(row.id); if(!deleted) android.widget.Toast.makeText(context, "इस मजदूर का भुगतान इतिहास मौजूद है। हिसाब सुरक्षित रखने के लिए रिकॉर्ड हटाना रोका गया; रिकॉर्ड Edit करें।", android.widget.Toast.LENGTH_LONG).show(); protectedDelete = null }, { protectedDelete = null })
    }
    protectedPaymentEdit?.let { payment ->
        DeviceCredentialGate("भुगतान बदलें", "भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।", { editPayment = payment; protectedPaymentEdit = null }, { protectedPaymentEdit = null })
    }
    protectedPaymentDelete?.let { payment ->
        DeviceCredentialDeleteGate("भुगतान हटाएँ", "यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।", { store.deleteCanePeelingPayment(payment.id); protectedPaymentDelete = null }, { protectedPaymentDelete = null })
    }
    editRow?.let { row -> CanePeelingEntryDialog(store, row, row.fieldId) { editRow = null } }
    editPayment?.let { payment -> CanePeelingPaymentDialog(store, payment, labourId) { editPayment = null } }
}

@Composable
private fun CanePeelingFieldDetail(store:Store,fieldId:String,onBack:()->Unit,onAdd:()->Unit){
    val f=store.fields.firstOrNull{it.id==fieldId}?:run{onBack();return}
    var from by rememberSaveable(fieldId){mutableStateOf("")}
    var to by rememberSaveable(fieldId){mutableStateOf("")}
    var workerFilter by rememberSaveable(fieldId){mutableStateOf("")}
    val context=LocalContext.current
    val allRows=store.canePeelings.filter{it.fieldId==fieldId}.sortedWith(compareByDescending<CanePeeling>{it.date}.thenBy{store.fandiLabours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
    val rows=allRows.filter{(from.isBlank()||it.date>=from)&&(to.isBlank()||it.date<=to)&&(workerFilter.isBlank()||it.labourId==workerFilter)}
    val workers=rows.map{it.labourId}.distinct()
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌾 ${f.name} • छिलाई हिसाब",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
            item{
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                        Text(f.name,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
                        Text("इस खेत के सेव किए गए फांदी रिकॉर्ड • फ़िल्टर के अनुसार सार",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){CaneMiniStat("मजदूर",workers.size.toString(),Color(0xFFE5F6EA))}
                            Box(Modifier.weight(1f)){CaneMiniStat("फांदी",money(rows.sumOf{it.fandi}),Color(0xFFE5F0FF))}
                            Box(Modifier.weight(1f)){CaneMiniStat("कुल राशि","₹${formatFandiRate(rows.sumOf{it.total})}",Color(0xFFFFF0D9))}
                        }
                        Text("${rows.size} एंट्री • ${rows.map{it.date}.distinct().size} दिन",fontSize=12.sp,color=Color.White)
                    }
                }
            }
            item{Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("इस खेत में छिलाई दर्ज करें",fontWeight=FontWeight.Bold)}}
            item{Text("रिकॉर्ड फ़िल्टर",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=GreenDark)}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){DateFilterField("तारीख से",from){from=it}};Box(Modifier.weight(1f)){DateFilterField("तारीख तक",to){to=it}}}}
            item{ChoiceField("मजदूर",listOf("" to "सभी मजदूर")+store.fandiLabours.filter{l->allRows.any{it.labourId==l.id}}.sortedBy{it.name.lowercase(Locale.getDefault())}.map{it.id to it.name},workerFilter){workerFilter=it}}
            if(from.isNotBlank()&&to.isNotBlank()&&from>to)item{Text("तारीख सीमा सही नहीं है: ‘से’ तारीख ‘तक’ तारीख से बाद की है।",color=Color(0xFFB3261E),fontSize=12.sp)}
            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={from="";to="";workerFilter=""},modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("फ़िल्टर हटाएँ")};Button(onClick={if(rows.isNotEmpty()&&!(from.isNotBlank()&&to.isNotBlank()&&from>to)){val lines=buildList{add("खेत: ${f.name}");add("अवधि: ${if(from.isBlank())"सभी तारीखें" else displayDate(from)} से ${if(to.isBlank())"आज तक" else displayDate(to)}");add("कुल फांदी: ${money(rows.sumOf{it.fandi})}");add("कुल मजदूरी: ₹${formatFandiRate(rows.sumOf{it.total})}");add("");rows.forEach{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId};add("${displayDate(r.date)} • ${l?.name?:"मजदूर"} • ${money(r.fandi)} फांदी × ₹${formatFandiRate(r.rate)} = ₹${formatFandiRate(r.total)}")}};exportReportPdf(context,"Ganna_Chhilai_Field_${safeFileName(f.name)}","${f.name} • ${rows.size} एंट्री • ${money(rows.sumOf{it.fandi})} फांदी • ₹${formatFandiRate(rows.sumOf{it.total})}",lines)}},modifier=Modifier.weight(1f),enabled=rows.isNotEmpty()&&!(from.isNotBlank()&&to.isNotBlank()&&from>to),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF रिपोर्ट")}}}
            item{Text("मजदूरवार हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark)}
            if(rows.isEmpty())item{EmptyCard(if(allRows.isEmpty())"इस खेत में अभी कोई छिलाई रिकॉर्ड नहीं है। ‘इस खेत में छिलाई दर्ज करें’ से शुरुआत करें।" else "इस फ़िल्टर में कोई रिकॉर्ड नहीं मिला। तारीख या मजदूर का फ़िल्टर बदलें।")}
            workers.forEach{lid->item(key="field_worker_$lid"){
                val rr=rows.filter{it.labourId==lid};val l=store.fandiLabours.firstOrNull{it.id==lid}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){PhotoThumb(l?.photo.orEmpty());Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold,color=GreenDark);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी",fontSize=12.sp,color=Color.Gray)};Text("₹${money(rr.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
            item{Text("तारीखवार रिकॉर्ड",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark)}
            rows.forEach{r->item(key="field_entry_${r.id}"){
                val l=store.fandiLabours.firstOrNull{it.id==r.labourId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(r.date),fontWeight=FontWeight.Bold,color=GreenDark);Text(l?.name?:"मजदूर",fontSize=12.sp);Text("${money(r.fandi)} फांदी × ₹${formatFandiRate(r.rate)}",fontSize=11.sp,color=Color.Gray)};Text("₹${formatFandiRate(r.total)}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
        }
    }
}
@Composable
private fun CanePeelingPayments(
    store: Store,
    onEdit: (CanePeelingPayment) -> Unit,
    onDelete: (CanePeelingPayment) -> Unit,
    onOpenLabour: (CanePeelingPayment) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }

    val rows = store.canePeelingPayments
        .filter { payment ->
            val labour = store.fandiLabours.firstOrNull { worker ->
                worker.id == payment.labourId
            }
            searchMatches(query, labour?.name, payment.date)
        }
        .sortedByDescending { payment -> payment.date }

    val total = rows.sumOf { payment -> payment.amount }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            AppTextField(
                value = query,
                onValueChange = { value -> query = value },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("भुगतान में नाम / तारीख खोजें") },
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )
        }

        item {
            val earned = store.canePeelings.sumOf { it.total }
            val allPaid = store.canePeelingPayments.sumOf { it.amount }
            val balance = (earned - allPaid).coerceAtLeast(0.0)
            val advance = (allPaid - earned).coerceAtLeast(0.0)
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenDark), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("छिलाई भुगतान", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("${rows.size} भुगतान रिकॉर्ड • इस सूची में ₹${formatFandiRate(total)}", color = Color.White.copy(alpha = .82f), fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल मजदूरी", "₹${money(earned)}", Color(0xFFE5F6EA)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल भुगतान", "₹${money(allPaid)}", Color(0xFFE5F0FF)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("बाकी", "₹${money(balance)}", Color(0xFFFFF0D9)) }
                    }
                    if(advance>0.009) Text("कुल एडवांस / अधिक भुगतान: ₹${money(advance)}",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)
                }
            }
        }

        rows.forEach { payment ->
            item(key = payment.id) {
                val labour = store.fandiLabours.firstOrNull { worker ->
                    worker.id == payment.labourId
                }

                Card(
                    Modifier.fillMaxWidth(),
                    RoundedCornerShape(15.dp)
                ) {
                    Row(
                        Modifier.padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable { onOpenLabour(payment) }
                        ) {
                            Text(
                                labour?.name ?: "मजदूर",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                displayDate(payment.date),
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            Text(
                                payment.method.ifBlank { "नकद" },
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            if (payment.note.isNotBlank()) {
                                Text(
                                    payment.note,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Text(
                            "₹${formatFandiRate(payment.amount)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = Green
                        )

                        IconButton(onClick = { onEdit(payment) }) {
                            Icon(Icons.Default.Edit, null, tint = Green)
                        }

                        IconButton(onClick = { onDelete(payment) }) {
                            Icon(
                                Icons.Default.Delete,
                                null,
                                tint = Color(0xFFB3261E)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CanePeelingPaymentDialog(
    store: Store,
    existing: CanePeelingPayment?,
    presetLabour: String,
    onClose: () -> Unit
) {
    var labour by remember {
        mutableStateOf(
            existing?.labourId
                ?: presetLabour.ifBlank {
                    store.fandiLabours.firstOrNull()?.id.orEmpty()
                }
        )
    }

    var date by remember {
        mutableStateOf(existing?.date ?: today())
    }

    var amount by remember {
        mutableStateOf(
            if (existing != null) money(existing.amount) else ""
        )
    }

    var method by remember {
        mutableStateOf(existing?.method ?: "नकद")
    }

    var note by remember {
        mutableStateOf(existing?.note ?: "")
    }
    var error by remember { mutableStateOf("") }

    SimpleDialog(
        if (existing == null) "छिलाई भुगतान दर्ज करें" else "छिलाई भुगतान बदलें",
        onClose
    ) {
        if (presetLabour.isNotBlank()) {
            val selectedLabour = store.fandiLabours.firstOrNull { worker ->
                worker.id == labour
            }

            Text(
                "मजदूर: ${selectedLabour?.name ?: "मजदूर"}",
                fontWeight = FontWeight.Bold,
                color = Green
            )
        } else {
            ChoiceField(
                "मजदूर *",
                store.fandiLabours.map { worker ->
                    worker.id to worker.name
                },
                labour
            ) { selectedId ->
                labour = selectedId
            }
        }

        Text(
            "भुगतान तारीख",
            fontWeight = FontWeight.SemiBold
        )

        AttendanceDateButton(date) { selectedDate ->
            date = selectedDate
        }

        AppTextField(
            value = amount,
            onValueChange = { value ->
                amount = value.filter { character ->
                    character.isDigit() || character == '.'
                }
            },
            label = { Text("कितने रुपये दिए? *") },
            singleLine = true
        )

        ChoiceField(
            "भुगतान तरीका",
            listOf(
                "नकद" to "नकद",
                "बैंक" to "बैंक",
                "UPI" to "UPI",
                "अन्य" to "अन्य"
            ),
            method
        ) { selectedMethod ->
            method = selectedMethod
        }

        AppTextField(
            value = note,
            onValueChange = { value ->
                note = value
            },
            label = { Text("टिप्पणी (Optional)") },
            singleLine = true
        )

        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
        Button(
            onClick = {
                error=""
                val parsedAmount = amount.toDoubleOrNull()

                when {
                    labour.isBlank() || store.fandiLabours.none{it.id==labour} -> { error="मजदूर चुनें।"; return@Button }
                    parsedAmount == null || parsedAmount <= 0 || !parsedAmount.isFinite() -> { error="भुगतान की राशि शून्य से अधिक और सही होनी चाहिए।"; return@Button }
                    !validDate(date) -> { error="भुगतान की तारीख सही चुनें।"; return@Button }
                }

                val payment = (
                    existing
                        ?: CanePeelingPayment(
                            UUID.randomUUID().toString(),
                            labour,
                            date,
                            parsedAmount,
                            method,
                            note.trim()
                        )
                    ).copy(
                        labourId = labour,
                        date = date,
                        amount = parsedAmount,
                        method = method,
                        note = note.trim()
                    )

                val saved=if(existing==null) store.addCanePeelingPayment(payment) else store.updateCanePeelingPayment(payment)
                if(saved) onClose() else error="भुगतान सेव नहीं हुआ। मजदूर, तारीख, राशि या रिकॉर्ड ID जाँचें।"
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Text("✓ सेव करें")
        }
    }
}

private fun exportCaneCsv(context:Context,store:Store,list:List<CaneParchi>,season:String){
    try{
        if(list.isEmpty()){
            android.widget.Toast.makeText(context,"चुने हुए सीजन/खोज में कोई पर्ची नहीं है।",android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val totalWeight=list.sumOf{it.weight}
        val totalAmount=list.sumOf{it.weight*it.rate}
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Parchi_${safeFileName(season)}_${System.currentTimeMillis()}.csv")
        FileOutputStream(file).use{out->
            out.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()))
            out.bufferedWriter(Charsets.UTF_8).use{w->
                fun q(raw:String):String{
                    // Guard against spreadsheet formula injection in user-provided text.
                    val first=raw.firstOrNull()
                    val safe=if(first!=null && first in listOf('=','+','-','@','\t','\r')) "'"+raw else raw
                    return "\"" + safe.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ") + "\""
                }
                w.append(listOf("सीजन","नाम","पिता का नाम","पर्ची कोड","दिनांक","खेत","वजन (क्विंटल)","भाव/क्विंटल","कुल राशि","टिप्पणी").joinToString(","){q(it)}).append('\n')
                list.forEach{p->
                    val amount=p.weight*p.rate
                    w.append(listOf(q(p.season),q(p.name),q(p.fatherName),q(p.code),q(p.date),q(store.fields.firstOrNull{it.id==p.fieldId}?.name ?: if(p.fieldId.isBlank()) "खेत नहीं चुना" else "खेत रिकॉर्ड नहीं मिला"),q(String.format(Locale.US,"%.2f",p.weight)),q(String.format(Locale.US,"%.2f",p.rate)),q(String.format(Locale.US,"%.2f",amount)),q(p.remark)).joinToString(",")).append('\n')
                }
                w.append(listOf(q("कुल (${list.size} पर्चियां)"),q(""),q(""),q(""),q("TOTAL"),q(""),q(String.format(Locale.US,"%.2f",totalWeight)),q(""),q(String.format(Locale.US,"%.2f",totalAmount)),q("चुने हुए रिकॉर्ड")).joinToString(",")).append('\n')
            }
        }
        shareFile(context,file,"text/csv","Excel साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Excel रिपोर्ट नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable private fun SummaryMini(label:String,value:Double,unit:String,modifier:Modifier){Card(modifier,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(9.dp)){Text(label,fontSize=10.sp,color=Color.Gray);Text(if(label=="कुल राशि")"₹${money(value)}" else money(value),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark);if(unit.isNotBlank())Text(unit,fontSize=9.sp,color=Color.Gray)}}}


@Composable
private fun CaneParchiDashboardScreen(store:Store){
    var showForm by rememberSaveable { mutableStateOf(false) }
    var edit by remember { mutableStateOf<CaneParchi?>(null) }
    var detail by remember { mutableStateOf<CaneParchi?>(null) }
    var delete by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedEdit by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedDelete by remember { mutableStateOf<CaneParchi?>(null) }
    var showPriceHistory by rememberSaveable { mutableStateOf(false) }
    var season by rememberSaveable { mutableStateOf(caneSeason()) }
    var query by rememberSaveable { mutableStateOf("") }
    val selectedParchiIds = remember { mutableStateListOf<String>() }
    val context = LocalContext.current

    val seasons = remember(store.caneParchis) {
        (store.caneParchis.map { it.season }.filter { it.isNotBlank() } + caneSeason()).distinct().sortedDescending()
    }
    // ALL is a valid explicit filter, even though it is not a concrete season value.
    if (season != "ALL" && season !in seasons) season = seasons.firstOrNull() ?: caneSeason()
    val allRows = if (season == "ALL") store.caneParchis else store.caneParchis.filter { it.season == season }
    val rows = allRows.filter {
        searchMatches(query, it.name, it.fatherName, it.code, it.remark)
    }.sortedWith(compareByDescending<CaneParchi> { it.date }.thenBy { it.name })
    val exportRows = if (selectedParchiIds.isNotEmpty()) store.caneParchis.filter { it.id in selectedParchiIds } else rows
    val totalWeight = allRows.sumOf { it.weight }
    val totalAmount = allRows.sumOf { it.weight * it.rate }
    val avgRate = if (allRows.isEmpty()) 0.0 else allRows.sumOf { it.rate } / allRows.size

    if (showForm) {
        CaneParchiFormScreen(store, edit) {
            showForm = false
            edit = null
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🌾 गन्ना पर्ची", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = GreenDark)
                    Text("पर्ची का पूरा हिसाब • पुराना सीजन • रिपोर्ट", fontSize = 11.sp, color = Color.Gray)
                }
                Button(
                    onClick = { edit = null; showForm = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("नई पर्ची") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = GreenDark)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("पर्ची डैशबोर्ड", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("कुल पर्ची", allRows.size.toDouble(), "", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल वजन", totalWeight, "क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल राशि", totalAmount, "", Modifier.fillMaxWidth()) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("औसत भाव", avgRate, "/ क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल सीजन", seasons.size.toDouble(), "सीजन", Modifier.fillMaxWidth()) }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceField(
                        "सीजन / पुरानी पर्चियां",
                        listOf("ALL" to "सभी सीजन") + seasons.map { it to "सीजन $it" },
                        season
                    ) { season = it }
                    AppTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("पर्ची खोजें — नाम / पिता / कोड") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = { if(query.isNotBlank()) IconButton(onClick={query=""}) { Icon(Icons.Default.Close,"खोज साफ करें") } }
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { showPriceHistory = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.History, null); Spacer(Modifier.width(4.dp)); Text("भाव इतिहास")
                }
                OutlinedButton(onClick = {
                    exportCaneCsv(context, store, exportRows, if (season == "ALL") "ALL" else season)
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.TableChart, null); Spacer(Modifier.width(4.dp)); Text(if(selectedParchiIds.isEmpty()) "Excel / CSV" else "चुनी (${selectedParchiIds.size}) CSV")
                }
                OutlinedButton(onClick = {
                    if(exportRows.isEmpty()){
                        android.widget.Toast.makeText(context,"चुने हुए सीजन/खोज में कोई पर्ची नहीं है।",android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        val lines = exportRows.map { p ->
                            "सीजन ${p.season} • ${p.name} • पिता: ${p.fatherName} • कोड: ${p.code} • ${displayDate(p.date)} • खेत: ${store.fields.firstOrNull{it.id==p.fieldId}?.name ?: if(p.fieldId.isBlank()) "नहीं चुना" else "रिकॉर्ड नहीं मिला"} • ${String.format(Locale.US, "%.2f", p.weight)} क्विंटल • ₹${money(p.rate)}/क्विंटल • कुल ₹${money(p.weight * p.rate)}${if (p.remark.isNotBlank()) " • ${p.remark}" else ""}"
                        }
                        val filterLabel=if(query.isBlank()) "" else " • खोज: ${query.trim()}"
                        val weightTotal=String.format(Locale.US,"%.2f",exportRows.sumOf{it.weight})
                        exportReportPdf(context, "गन्ना_पर्ची_${safeFileName(season)}", "${if(selectedParchiIds.isNotEmpty()) "चुनी हुई पर्चियां" else if(season=="ALL")"सभी सीजन" else "सीजन $season"}${filterLabel} • ${exportRows.size} पर्चियां • ${weightTotal} क्विंटल • कुल ₹${money(exportRows.sumOf{it.weight*it.rate})}", lines)
                    }
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(4.dp)); Text("PDF")
                }
            }
        }
        item { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("${if (season == "ALL") "सभी सीजन" else "सीजन $season"} की पर्चियां (${rows.size})",Modifier.weight(1f),fontSize=17.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);TextButton(onClick={if(selectedParchiIds.size==rows.size)selectedParchiIds.clear() else {selectedParchiIds.clear();selectedParchiIds.addAll(rows.map{it.id})}}){Text(if(rows.isNotEmpty()&&selectedParchiIds.size==rows.size)"चयन हटाएँ" else "सभी चुनें")}};if(selectedParchiIds.isNotEmpty())Text("${selectedParchiIds.size} पर्चियां चुनी गईं — PDF/CSV में केवल यही जाएँगी",fontSize=12.sp,color=GreenDark) }
        if (rows.isEmpty()) {
            item { EmptyCard(if(query.isBlank()) "इस सीजन में अभी कोई पर्ची नहीं है। ऊपर 'नई पर्ची' दबाकर जोड़ें।" else "इस खोज से कोई पर्ची नहीं मिली। नाम, पिता का नाम या कोड बदलकर देखें।") }
        }
        items(rows, key = { it.id }) { p ->
            Card(
                Modifier.fillMaxWidth().clickable { detail = p },
                RoundedCornerShape(17.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked=p.id in selectedParchiIds,onCheckedChange={checked->if(checked){if(p.id !in selectedParchiIds)selectedParchiIds.add(p.id)}else selectedParchiIds.remove(p.id)})
                        if (p.photo.isNotBlank()) PhotoThumb(p.photo, Modifier.size(58.dp)) else Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8F3ED)), contentAlignment = Alignment.Center) { Text("🌾", fontSize = 25.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = GreenDark)
                            Text("पिता: ${p.fatherName.ifBlank { "—" }}", fontSize = 11.sp, color = Color.Gray)
                            Text("कोड: ${p.code} • ${displayDate(p.date)}", fontSize = 11.sp, color = Color.Gray)
                            Text("खेत: ${store.fields.firstOrNull{it.id==p.fieldId}?.name ?: if(p.fieldId.isBlank()) "नहीं चुना" else "रिकॉर्ड नहीं मिला"}",fontSize=10.sp,color=Color.Gray,maxLines=1)
                        }
                        IconButton(onClick = { protectedEdit = p }) { Icon(Icons.Default.Edit, "पर्ची बदलें", tint = Green) }
                        IconButton(onClick = { protectedDelete = p }) { Icon(Icons.Default.Delete, "पर्ची हटाएं", tint = Color(0xFFB3261E)) }
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${String.format(Locale.US, "%.2f", p.weight)} क्विंटल", fontWeight = FontWeight.Bold)
                        Text("₹${money(p.rate)} / क्विंटल", color = Green)
                        Text("₹${money(p.weight * p.rate)}", fontWeight = FontWeight.ExtraBold, color = GreenDark)
                    }
                }
            }
        }
    }

    detail?.let { p -> CaneParchiDetail(store,p) { detail = null } }
    protectedEdit?.let { p ->
        DeviceCredentialGate("गन्ना पर्ची बदलें", "पर्ची की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।", {
            edit = p; protectedEdit = null; showForm = true
        }, { protectedEdit = null })
    }
    protectedDelete?.let { p ->
        DeviceCredentialDeleteGate("गन्ना पर्ची हटाएं", "यह पर्ची स्थायी रूप से हट जाएगी।", {
            store.deleteCaneParchi(p.id); protectedDelete = null
        }, { protectedDelete = null })
    }
    if (showPriceHistory) {
        val selectedSeason = if (season == "ALL") caneSeason() else season
        CanePriceDialog(store, selectedSeason) { showPriceHistory = false }
    }
}

@Composable
private fun CaneParchiFormScreen(store:Store,existing:CaneParchi?=null,onClose:()->Unit){
    var name by rememberSaveable(existing?.id){mutableStateOf(existing?.name?:"")}
    var father by rememberSaveable(existing?.id){mutableStateOf(existing?.fatherName?:"")}
    var code by rememberSaveable(existing?.id){mutableStateOf(existing?.code?:"")}
    var date by rememberSaveable(existing?.id){mutableStateOf(existing?.date?:today())}
    var weight by rememberSaveable(existing?.id){mutableStateOf(if(existing==null)"" else existing.weight.toString())}
    var remark by rememberSaveable(existing?.id){mutableStateOf(existing?.remark?:"")}
    var photo by rememberSaveable(existing?.id){mutableStateOf(existing?.photo?:"")}
    var fieldId by rememberSaveable(existing?.id){mutableStateOf(existing?.fieldId?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val season=caneSeason(date)
    // Keep a saved ticket rate stable when its date has not changed.
    val rate=if(existing!=null && existing.date==date.trim()) existing.rate else store.caneRateFor(season,date)
    val amount=(weight.toDoubleOrNull()?:0.0)*rate
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)photo=store.persistPhoto(uri.toString(),"cane")}
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){bitmap->if(bitmap!=null)photo=store.persistBitmapPhoto(bitmap,"cane")}
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onClose){Icon(Icons.Default.ArrowBack,"वापस")}
            Text(if(existing==null)"नई गन्ना पर्ची जोड़ें" else "गन्ना पर्ची बदलें",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        }
        AppTextField(value=name,onValueChange={name=it},label={Text("नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        AppTextField(value=father,onValueChange={father=it},label={Text("पिता का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            AppTextField(value=code,onValueChange={code=it.filter(Char::isDigit).take(7)},label={Text("पर्ची कोड * (6–7 अंक)")},singleLine=true,modifier=Modifier.weight(1f))
            AppTextField(value=date,onValueChange={date=it},label={Text("दिनांक *")},singleLine=true,modifier=Modifier.weight(1f))
        }
        AppTextField(value=weight,onValueChange={weight=it.filter{c->c.isDigit()||c=='.'}},label={Text("वजन (क्विंटल) *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},fieldId){fieldId=it}
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFF1F4F2)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){
                Text("भाव/क्विंटल (इस तारीख का)",fontSize=12.sp,color=Color.Gray)
                Text("₹${money(rate)}",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
            }
        }
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){Text("कुल अनुमानित राशि",fontSize=12.sp,color=Color.Gray);Text("₹${formatFandiRate(amount)}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)}
        }
        AppTextField(value=remark,onValueChange={remark=it},label={Text("टिप्पणी (वैकल्पिक)")},minLines=2,maxLines=3,modifier=Modifier.fillMaxWidth())
        Text("पर्ची की फोटो",fontWeight=FontWeight.Bold,color=GreenDark)
        if(photo.isNotBlank())PhotoThumb(photo,Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={camera.launch(null)},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(5.dp));Text("कैमरा से लें")}
            OutlinedButton(onClick={picker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoLibrary,null);Spacer(Modifier.width(5.dp));Text("गैलरी से चुनें")}
        }
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
        Button(onClick={
            val w=weight.toDoubleOrNull()
            when{
                name.isBlank()->error="नाम दर्ज करें"
                father.isBlank()->error="पिता का नाम दर्ज करें"
                !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
                date>today()->error="भविष्य की तारीख नहीं हो सकती"
                !Regex("\\d{6,7}").matches(code.trim())->error="पर्ची कोड 6–7 अंक का होना चाहिए"
                store.caneParchis.any{it.id!=existing?.id && it.code.trim().filter(Char::isDigit)==code.trim().filter(Char::isDigit) && it.season==caneSeason(date)}->error="इस सीजन में यह पर्ची कोड पहले से मौजूद है। कोड जाँचें।"
                w==null||w<=0||!w.isFinite()->error="सही वजन दर्ज करें"
                else->{
                    val x=(existing?:CaneParchi(UUID.randomUUID().toString(),name.trim(),father.trim(),code.trim(),date.trim(),w,rate,photo,remark.trim(),season,fieldId)).copy(name=name.trim(),fatherName=father.trim(),code=code.trim(),date=date.trim(),weight=w,rate=rate,photo=photo,remark=remark.trim(),season=season,fieldId=fieldId)
                    val saved=if(existing==null) store.addCaneParchi(x) else store.updateCaneParchi(x)
                    if(saved) onClose() else error="पर्ची सेव नहीं हुई। सीजन, पर्ची कोड, तारीख और डुप्लिकेट रिकॉर्ड जाँचें।"
                }
            }
        },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(existing==null)"पर्ची सेव करें" else "पर्ची अपडेट करें",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun CanePriceDialog(store:Store,season:String,onClose:()->Unit){
    var date by rememberSaveable{mutableStateOf(today())};var rate by rememberSaveable{mutableStateOf("")};var error by rememberSaveable{mutableStateOf("")};
    SimpleDialog("गन्ना भाव इतिहास",onClose){Text("सीजन: $season",fontWeight=FontWeight.Bold,color=GreenDark);Text("नया भाव जिस तारीख से लागू हो, वही तारीख डालें। उसी सीजन और तारीख पर पहले से भाव है तो वही रिकॉर्ड अपडेट होगा। पुरानी पर्चियों का सेव किया हुआ भाव नहीं बदलेगा।",fontSize=11.sp,color=Color.Gray);AppTextField(value=rate,onValueChange={rate=it.filter{c->c.isDigit()||c=='.'}},label={Text("भाव / क्विंटल")},singleLine=true);AppTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val r=rate.toDoubleOrNull();when{r==null||r<=0->error="सही भाव दर्ज करें";!validDate(date)->error="सही तारीख डालें";date>today()->error="भविष्य की तारीख नहीं";else->{store.addCanePrice(CanePrice(UUID.randomUUID().toString(),season,date,r));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("नया भाव सेव करें")};Spacer(Modifier.height(8.dp));Text("भाव इतिहास",fontWeight=FontWeight.ExtraBold);store.canePricesFor(season).forEach{p->Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(displayDate(p.effectiveDate),Modifier.weight(1f));Text("₹${money(p.rate)} / क्विंटल",fontWeight=FontWeight.Bold,color=GreenDark)}}}
}

@Composable private fun CaneParchiDetail(store:Store,p:CaneParchi,onClose:()->Unit){SimpleDialog("पर्ची विवरण",onClose){Text("नाम: ${p.name}",fontWeight=FontWeight.Bold);Text("पिता का नाम: ${p.fatherName.ifBlank{"—"}}");Text("पर्ची कोड: ${p.code}");Text("दिनांक: ${displayDate(p.date)}");Text("खेत: ${store.fields.firstOrNull{it.id==p.fieldId}?.name ?: if(p.fieldId.isBlank()) "नहीं चुना" else "खेत रिकॉर्ड नहीं मिला"}");Text("वजन: ${String.format(Locale.US,"%.2f",p.weight)} क्विंटल");Text("भाव: ₹${money(p.rate)} / क्विंटल");Text("कुल राशि: ₹${money(p.weight*p.rate)}",fontWeight=FontWeight.ExtraBold,color=GreenDark);if(p.remark.isNotBlank())Text("Remark: ${p.remark}");if(p.photo.isNotBlank())PhotoThumb(p.photo,Modifier.fillMaxWidth().height(220.dp))}}

@Composable
private fun ProfileScreen(onBackup:()->Unit,themeMode:String,onThemeModeChange:(String)->Unit,onNavigate:(String)->Unit){
    val context = LocalContext.current
    var profileName by remember { mutableStateOf(settingString(context, "profile_name", "")) }
    var appLock by remember { mutableStateOf(settingBool(context, "app_lock_enabled", true)) }
    var biometric by remember { mutableStateOf(settingBool(context, "biometric_enabled", true)) }
    var timeout by remember { mutableStateOf(settingString(context, "auto_lock_timeout", "immediate")) }
    var notifications by remember { mutableStateOf(settingBool(context, "notifications_enabled", true)) }
    var reportSummary by remember { mutableStateOf(settingBool(context, "report_summary_enabled", true)) }
    var reportWages by remember { mutableStateOf(settingBool(context, "report_wages_enabled", true)) }
    var reportPayments by remember { mutableStateOf(settingBool(context, "report_payments_enabled", true)) }
    var backupReminder by remember { mutableStateOf(settingBool(context, "backup_reminder_enabled", true)) }
    var showAbout by remember { mutableStateOf(false) }
    var showPinManager by rememberSaveable { mutableStateOf(false) }
    var showPinResetCredentialGate by remember { mutableStateOf(false) }
    // One-time authorization must not survive Activity recreation via saved state.
    var pinResetAuthorized by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.AccountCircle,null,tint=Color.White,modifier=Modifier.size(52.dp)); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text(profileName.ifBlank { "Majdoor Hisaab PRO" },color=Color.White,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)
                        Text("प्रोफाइल और ऐप सेटिंग्स",color=Color.White.copy(alpha=.85f),fontSize=12.sp)
                    }
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("👤 प्रोफाइल",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    AppTextField(value=profileName,onValueChange={profileName=it;saveSetting(context,"profile_name",it)},modifier=Modifier.fillMaxWidth(),label={Text("खाता / खेत का नाम (वैकल्पिक)")},singleLine=true)
                    Text("यह नाम इसी फोन में सेव होगा।",fontSize=11.sp,color=Color.Gray)
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("🎨  थीम चुनें",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    Text("Light, Dark या फोन की System Theme",fontSize=12.sp,color=Color.Gray)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
                        listOf("light" to "Light","dark" to "Dark","system" to "System").forEach { (value,label) ->
                            FilterChip(selected=themeMode==value,onClick={onThemeModeChange(value)},label={Text(label)},leadingIcon=if(themeMode==value) {{Icon(Icons.Default.Check,null)}} else null)
                        }
                    }
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("🔐 ऐप लॉक और सुरक्षा",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    SettingsSwitch("ऐप खोलते समय लॉक", "बंद करने पर लॉन्च पर PIN/बायोमेट्रिक नहीं पूछा जाएगा; संवेदनशील Edit/Delete और Restore पर सुरक्षा फिर भी लागू रहेगी।",appLock){appLock=it;saveSetting(context,"app_lock_enabled",it)}
                    SettingsSwitch("बायोमेट्रिक प्राथमिकता", "चालू होने पर उपलब्ध Android biometric prompt पहले दिखेगा; जरूरत पर फोन PIN/Pattern fallback रहेगा।",biometric){biometric=it;saveSetting(context,"biometric_enabled",it)}
                    OutlinedButton(onClick={showPinManager=true},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Lock,null); Spacer(Modifier.width(8.dp)); Text(if(hasCustomPin(context)) "ऐप PIN बदलें / हटाएँ" else "कस्टम ऐप PIN सेट करें") }
                    if(hasCustomPin(context)) OutlinedButton(onClick={showPinResetCredentialGate=true},modifier=Modifier.fillMaxWidth()) { Text("PIN भूल गए? फोन लॉक से रीसेट करें") }
                    Text(if(hasCustomPin(context)) "कस्टम PIN सेट है। लॉन्च लॉक पर PIN या फोन लॉक विकल्प उपलब्ध होगा." else "कस्टम PIN वैकल्पिक है; PIN सेट नहीं करने पर फोन का PIN/Pattern/biometric gate रहेगा।",fontSize=11.sp,color=Color.Gray)
                    Text("ऑटो-लॉक टाइमआउट",fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onSurface)
                    listOf("immediate" to "तुरंत","1m" to "1 मिनट","5m" to "5 मिनट","15m" to "15 मिनट","30m" to "30 मिनट","never" to "कभी नहीं").forEach{(value,label)->
                        Row(Modifier.fillMaxWidth().clickable{timeout=value;saveSetting(context,"auto_lock_timeout",value)}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=timeout==value,onClick={timeout=value;saveSetting(context,"auto_lock_timeout",value)});Text(label,color=MaterialTheme.colorScheme.onSurface)}
                    }
                    Text("चयनित समय तक ऐप background में रहने पर अगली बार खोलते समय लॉक लगेगा।",fontSize=11.sp,color=Color.Gray)
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("🔔 सूचना सेटिंग्स",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    SettingsSwitch("ऐप सूचनाएँ सक्षम", "सूचना सुविधा द्वारा समर्थित संदेशों के लिए प्राथमिकता।",notifications){notifications=it;saveSetting(context,"notifications_enabled",it)}
                    Text("इस build में scheduled/push reminders उपलब्ध नहीं हैं; यह preference सेव होती है, लेकिन स्वयं नई notification service शुरू नहीं करती।",fontSize=11.sp,color=Color.Gray)
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("📄 रिपोर्ट सेटिंग्स",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    SettingsSwitch("रिपोर्ट में सारांश", "रिपोर्ट प्राथमिकता सेव करें।",reportSummary){reportSummary=it;saveSetting(context,"report_summary_enabled",it)}
                    SettingsSwitch("मजदूरी कॉलम", "रिपोर्ट प्राथमिकता सेव करें।",reportWages){reportWages=it;saveSetting(context,"report_wages_enabled",it)}
                    SettingsSwitch("भुगतान कॉलम", "रिपोर्ट प्राथमिकता सेव करें।",reportPayments){reportPayments=it;saveSetting(context,"report_payments_enabled",it)}
                    Text("ये विकल्प मजदूर लेजर PDF में सारांश, मजदूरी और भुगतान कॉलम दिखाने/छिपाने पर लागू होते हैं।",fontSize=11.sp,color=Color.Gray)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(2.dp)){
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("☁️ बैकअप सेटिंग्स",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)
                    SettingsSwitch("बैकअप याद दिलाने की प्राथमिकता", "7 दिन से बैकअप न हुआ हो तो Home खोलने पर याद दिलाएगा।",backupReminder){backupReminder=it;saveSetting(context,"backup_reminder_enabled",it)}
                    OutlinedButton(onClick=onBackup,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(8.dp));Text("Backup & Restore खोलें")}
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().clickable{showAbout=true},shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.Info,null,tint=GreenDark,modifier=Modifier.size(32.dp));Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){Text("About / Version",fontSize=17.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface);Text("Majdoor Hisaab PRO • v${BuildConfig.VERSION_NAME}",fontSize=12.sp,color=Color.Gray)}
                    Icon(Icons.Default.ChevronRight,null,tint=GreenDark)
                }
            }
        }
        item {
            Text("मॉड्यूल",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                SmallAction("👷 मजदूरों की सूची",{onNavigate("workers")});SmallAction("📅 हाजिरी",{onNavigate("attendance")});SmallAction("🌾 खेत प्रबंधन",{onNavigate("field")});SmallAction("🌱 फसल प्रबंधन",{onNavigate("crop")});SmallAction("💰 खर्च और लागत",{onNavigate("expense")});SmallAction("🧺 बिक्री और कमाई",{onNavigate("sale")});SmallAction("🌿 गन्ना छिलाई",{onNavigate("cane_peeling")});SmallAction("🌾 गन्ना पर्ची",{onNavigate("cane")});SmallAction("📄  रिपोर्ट सेंटर",{onNavigate("reports")})
            }
        }
    }
    if(showAbout) AlertDialog(onDismissRequest={showAbout=false},title={Text("Majdoor Hisaab PRO")},text={Text("Version: ${BuildConfig.VERSION_NAME}\nVersion code: ${BuildConfig.VERSION_CODE}\nPackage: ${context.packageName}\nOffline-first labour and farm accounting app.")},confirmButton={TextButton(onClick={showAbout=false}){Text("ठीक है")}})
    if(showPinManager) PinManagementDialog(onClose={showPinManager=false;pinResetAuthorized=false},requireCurrentPin=!pinResetAuthorized)
    if(showPinResetCredentialGate) DeviceCredentialGate("कस्टम PIN रीसेट करें","फोन का PIN/Pattern या biometric सत्यापित करने के बाद ही कस्टम ऐप PIN रीसेट होगा।",{showPinResetCredentialGate=false;pinResetAuthorized=true;showPinManager=true},{showPinResetCredentialGate=false;pinResetAuthorized=false})
}

@Composable private fun SettingsSwitch(title:String,description:String,checked:Boolean,onChange:(Boolean)->Unit){
    Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onSurface);Text(description,fontSize=11.sp,color=Color.Gray)}
        Switch(checked=checked,onCheckedChange=onChange)
    }
}

private fun recordBackupHistory(context:Context,name:String,sizeBytes:Long,location:String){
    runCatching {
        val prefs=context.getSharedPreferences("mhpro_backup_history",Context.MODE_PRIVATE)
        val history=JSONArray(prefs.getString("items","[]") ?: "[]")
        val item=JSONObject().apply {
            put("name",name.substringAfterLast('/').take(180))
            put("sizeBytes",sizeBytes.coerceAtLeast(0L))
            put("location",location)
            put("createdAt",System.currentTimeMillis())
        }
        val updated=JSONArray().put(item)
        for(i in 0 until minOf(history.length(),9)) updated.put(history.getJSONObject(i))
        prefs.edit().putString("items",updated.toString()).commit()
    }
}

private fun readBackupHistory(context:Context):List<String> = runCatching {
    val items=JSONArray(context.getSharedPreferences("mhpro_backup_history",Context.MODE_PRIVATE).getString("items","[]") ?: "[]")
    (0 until items.length()).mapNotNull { i ->
        val item=items.optJSONObject(i) ?: return@mapNotNull null
        val date=java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a",java.util.Locale("hi","IN")).format(java.util.Date(item.optLong("createdAt",0L)))
        val mb=String.format(java.util.Locale.US,"%.2f",item.optLong("sizeBytes",0L)/1048576.0)
        "${item.optString("name","Backup")} · ${item.optString("location")} · $mb MB · $date"
    }
}.getOrDefault(emptyList())

@Composable
private fun BackupScreen(store:Store,status:String,onStatus:(String)->Unit,onBackup:()->Unit,onRestore:()->Unit,driveEmail:String,driveBusy:Boolean,onDriveSignIn:()->Unit,onDriveBackup:()->Unit,onDriveRestore:()->Unit,onAutoRestore:(File)->Unit){
    val backupHistoryContext = LocalContext.current
    var refreshKey by remember { mutableIntStateOf(0) }
    val history=remember(status, backupHistoryContext){readBackupHistory(backupHistoryContext)}
    val autoStatus=remember(refreshKey,status){readDailyBackupStatus(backupHistoryContext)}
    val autoFiles=remember(refreshKey,status){listDailyAutoBackups(backupHistoryContext)}
    var showOtherOptions by rememberSaveable { mutableStateOf(false) }
    var showAutoFiles by rememberSaveable { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Backup और Restore",fontSize=22.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
            Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                Text("रोज़ाना Automatic Backup",fontSize=18.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                Text("हर दिन लगभग रात 10 बजे फोन में Backup बनेगा। Battery Saver / Android Doze के कारण समय थोड़ा आगे हो सकता है।",fontSize=12.sp,color=Color.Gray)
                val lastText=if(autoStatus.lastSuccessAt>0L) SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale("hi","IN")).format(Date(autoStatus.lastSuccessAt)) else "अभी तक कोई सफल Auto Backup नहीं"
                Text("आखिरी सफल Backup: $lastText",fontWeight=FontWeight.SemiBold,color=GreenDark)
                if(autoStatus.fileName.isNotBlank()) Text("फाइल: ${autoStatus.fileName}",fontSize=11.sp,color=Color.Gray)
                if(autoStatus.sizeBytes>0L) Text("आकार: ${String.format(Locale.US,"%.2f",autoStatus.sizeBytes/1048576.0)} MB",fontSize=11.sp,color=Color.Gray)
                Text("स्थिति: ${when(autoStatus.status){"SUCCESS"->"सफल";"FAILED"->"असफल";else->"अभी चलना बाकी है"}}",fontWeight=FontWeight.Bold,color=if(autoStatus.status=="SUCCESS") Green else if(autoStatus.status=="FAILED") Color(0xFFB3261E) else Color.Gray)
                if(autoStatus.error.isNotBlank()) Text("त्रुटि: ${autoStatus.error}",fontSize=11.sp,color=Color(0xFFB3261E))
                Text("Google Drive: ${autoStatus.driveStatus}",fontSize=11.sp,color=Color.Gray)
                Button(onClick={runDailyAutoBackupNow(backupHistoryContext);onStatus("Automatic Backup अभी शुरू किया गया है। कुछ देर बाद Refresh दबाएँ।")},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                    Icon(Icons.Default.Backup,null);Spacer(Modifier.width(8.dp));Text("अभी Auto Backup बनाएँ")
                }
                OutlinedButton(onClick={refreshKey++},modifier=Modifier.fillMaxWidth()){Text("स्थिति Refresh करें")}
            }
        }
        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
            Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("फोन के Automatic Backup",Modifier.weight(1f),fontSize=16.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                    TextButton(onClick={showAutoFiles=!showAutoFiles}){Text(if(showAutoFiles)"छिपाएँ" else "दिखाएँ")}
                }
                if(showAutoFiles){
                    if(autoFiles.isEmpty()) Text("अभी कोई Automatic Backup फ़ाइल नहीं मिली।",fontSize=12.sp,color=Color.Gray)
                    autoFiles.forEach { file ->
                        Column(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                            Text(file.name,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                            Text("${String.format(Locale.US,"%.2f",file.length()/1048576.0)} MB • ${SimpleDateFormat("dd/MM/yyyy hh:mm a",Locale.getDefault()).format(Date(file.lastModified()))}",fontSize=11.sp,color=Color.Gray)
                            OutlinedButton(onClick={onAutoRestore(file)},modifier=Modifier.fillMaxWidth(),enabled=!driveBusy){Text("इस Backup से Restore करें")}
                        }
                        HorizontalDivider()
                    }
                }
                Text("ध्यान दें: फोन का Auto Backup ऐप के निजी storage में रहता है। App uninstall या app data clear होने पर यह मिट सकता है। इसलिए समय-समय पर Google Drive या फोन की दूसरी जगह भी Backup रखें।",fontSize=11.sp,color=Color(0xFF8A4B00))
            }
        }
        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
            Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){
                    Icon(imageVector=Icons.Default.Cloud,contentDescription=null,tint=GreenDark)
                    Spacer(Modifier.width(8.dp))
                    Text("Google Drive",fontSize=18.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                }
                Text(if(driveEmail=="Google Account नहीं जुड़ा") "Google Account जुड़ा नहीं है" else driveEmail,fontSize=13.sp,color=if(driveEmail=="Google Account नहीं जुड़ा") Color(0xFFB45309) else GreenDark,fontWeight=FontWeight.SemiBold)
                OutlinedButton(onClick=onDriveSignIn,enabled=!driveBusy,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp)){
                    Text(if(driveEmail=="Google Account नहीं जुड़ा") "Google Account जोड़ें" else "Account बदलें",fontWeight=FontWeight.Bold)
                }
                Button(onClick=onDriveBackup,enabled=!driveBusy,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                    Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(8.dp));Text(if(driveBusy) "कृपया प्रतीक्षा करें…" else "Drive Backup करें",fontWeight=FontWeight.Bold)
                }
                OutlinedButton(onClick=onDriveRestore,enabled=!driveBusy,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp)){
                    Icon(Icons.Default.CloudDownload,null);Spacer(Modifier.width(8.dp));Text("Drive से Restore करें")
                }
                if(history.isNotEmpty()) Text("हाल के बैकअप • आखिरी: ${history.first()}",fontSize=11.sp,color=Color.Gray) else Text("हाल के बैकअप: अभी कोई Backup दर्ज नहीं",fontSize=11.sp,color=Color.Gray)
            }
        }
        if(status.isNotBlank()){
            val statusKind=when {
                status.contains("सफल",true) || status.contains("upload हो गया",true) || status.contains("जुड़ गया",true) -> "success"
                status.contains("असफल",true) || status.contains("विफल",true) || status.contains("नहीं हो सका",true) || status.contains("रद्द",true) || status.contains("failed",true) -> "error"
                else -> "info"
            }
            SharedStatePanel("Backup / Restore स्थिति",status,statusKind)
        }
        TextButton(onClick={showOtherOptions=!showOtherOptions},modifier=Modifier.align(Alignment.Start)){
            Text(if(showOtherOptions) "अन्य Backup विकल्प छिपाएँ" else "फोन में Backup / Restore विकल्प")
        }
        if(showOtherOptions){
            OutlinedButton(onClick=onBackup,enabled=!driveBusy,modifier=Modifier.fillMaxWidth()){Text("फोन / File Picker में Backup सेव करें")}
            OutlinedButton(onClick=onRestore,enabled=!driveBusy,modifier=Modifier.fillMaxWidth()){Text("फोन से Backup Restore करें")}
        }
    }
}

@Composable private fun PaymentDialog(store:Store,labourId:String,preField:String?,preCrop:String?,onClose:()->Unit,existing:Payment?=null){
    var field by rememberSaveable{mutableStateOf(existing?.fieldId ?: preField?:"")}
    var crop by rememberSaveable{mutableStateOf(existing?.cropId ?: preCrop?:"")}
    var amount by rememberSaveable{mutableStateOf(existing?.amount?.let{money(it)} ?: "")}
    var date by rememberSaveable{mutableStateOf(existing?.date ?: today())}
    var error by rememberSaveable{mutableStateOf("")}
    var saving by rememberSaveable{mutableStateOf(false)}
    val lockedField=preField?.isNotBlank()==true
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){
        if(crop.isNotBlank() && crops.none{it.id==crop}) crop=""
        if(crop.isBlank() && crops.size==1) crop=crops.first().id
    }
    SimpleDialog(if(existing==null)"भुगतान दर्ज करें" else "भुगतान बदलें",onClose){
        if(lockedField){
            val name=store.fields.firstOrNull{it.id==field}?.name?:"खेत"
            Text("खेत: $name",fontWeight=FontWeight.Bold,color=Green)
        } else {
            ChoiceField("खेत (Optional)",listOf("" to "खेत नहीं चुनना")+store.fields.map{it.id to it.name},field){field=it}
        }
        if(field.isNotBlank() && crops.size>1){
            ChoiceField("फसल (Optional)",listOf("" to "फसल नहीं चुनना")+crops.map{it.id to it.name},crop){crop=it}
        }
        AttendanceDateButton(date){date=it}
        AppTextField(value=amount,onValueChange={amount=it;error=""},label={Text("भुगतान की रकम (₹)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(enabled=!saving,onClick={
            if(saving) return@Button
            val n=amount.toDoubleOrNull()
            when {
                n==null||n<=0||!n.isFinite()->error="सही भुगतान रकम दर्ज करें।"
                !validDate(date)->error="सही भुगतान तारीख चुनें।"
                (existing!=null && (store.isClosedDate(labourId,existing.date) || store.isMonthLocked(existing.date))) || store.isClosedDate(labourId,date) || store.isMonthLocked(date)->error="इस तारीख का महीना लॉक है या हिसाब फाइनल है। बाद की खुली तारीख चुनें।"
                else->{saving=true;val row=Payment(existing?.id?:UUID.randomUUID().toString(),labourId,field,crop,date,n);val saved=if(existing==null)store.addPayment(row) else store.updatePayment(row);if(saved)onClose() else {saving=false;error="भुगतान सेव नहीं हुआ। तारीख या फाइनल हिसाब जाँचें।"}}
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(existing==null)"भुगतान सेव करें" else "बदलाव सेव करें")}
    }
}

@Composable private fun RateDialog(store:Store,labourId:String,onClose:()->Unit){var rate by rememberSaveable{mutableStateOf("")};var date by rememberSaveable{mutableStateOf(today())};var error by rememberSaveable{mutableStateOf("")};val current=store.rateFor(labourId,today());SimpleDialog("दिहाड़ी बदलें",onClose){Text("अभी की प्रभावी दिहाड़ी: ₹${money(current)}/दिन",fontWeight=FontWeight.SemiBold,color=Green);AppTextField(value=rate,onValueChange={rate=it},label={Text("नई दिहाड़ी")},singleLine=true);AppTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=rate.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही दिहाड़ी दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";store.setRate(WageRate(UUID.randomUUID().toString(),labourId,date.trim(),n));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save नई दर")}}}

@Composable private fun CropDetail(store:Store,id:String,onBack:()->Unit,onExpense:()->Unit,onSale:()->Unit){val c=store.crops.firstOrNull{it.id==id}?:return;val f=store.fields.firstOrNull{it.id==c.fieldId};val exp=store.expenses.filter{it.cropId==id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==id}.sumOf{it.total};val wage=store.attendances.filter{it.cropId==id}.sumOf{it.fraction*it.rate};val linkIssues=store.fieldCropIntegrityIssues(cropId=id);Column(Modifier.fillMaxSize()){DetailTopBar("🌱 ${c.name}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){if(linkIssues.isNotEmpty())item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF1D6))){Column(Modifier.padding(12.dp)){Text("फसल रिकॉर्ड मिलान चेतावनी",fontWeight=FontWeight.Bold,color=Color(0xFF8A4B00));Text("${linkIssues.size} पुराने रिकॉर्ड में खेत/फसल का लिंक मेल नहीं खाता। रिपोर्ट में जाँचें।",fontSize=12.sp,color=Color(0xFF8A4B00))}}};this.item{Text("खेत: ${f?.name?:"नहीं चुना"}",fontWeight=FontWeight.Bold)};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",exp+wage)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-exp-wage)}}};this.item{Text("मजदूरी ₹${money(wage)}",fontWeight=FontWeight.Bold)};this.item{Text("खेती खर्च ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("बिक्री ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{SmallAction("💰 इस फसल के खर्च",onExpense)};this.item{SmallAction("🧺 इस फसल की बिक्री",onSale)}}}}

@Composable private fun DetailTopBar(title:String,onBack:()->Unit){
    Surface(color=GreenDark,tonalElevation=0.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"वापस",tint=Color.White)}
            Text(title,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}

@Composable private fun SectionTitle(title:String,sub:String,onAdd:(()->Unit)?=null){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
            Text(title,fontWeight=FontWeight.ExtraBold,fontSize=22.sp,color=GreenDark)
            Text(sub,fontSize=12.sp,color=Color(0xFF64746B))
        }
        if(onAdd!=null){FilledTonalIconButton(onClick=onAdd,colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=Color(0xFFDDF2E5),contentColor=GreenDark)){Icon(imageVector=Icons.Default.Add,contentDescription="जोड़ें")}}
    }
}
@Composable private fun SmallAction(text:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(0.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFE3ECE6))){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(text,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=GreenDark);Icon(Icons.Default.ChevronRight,null,tint=Green)}}}
@Composable private fun SimpleDialog(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){BackHandler{onClose()};AlertDialog(onDismissRequest={onClose()},shape=RoundedCornerShape(24.dp),containerColor=CardBg,title={Text(title,fontWeight=FontWeight.ExtraBold,color=GreenDark)},text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)},confirmButton={},dismissButton={TextButton(onClick=onClose){Text("बंद")}})}
@Composable private fun ConfirmDialog(title:String,message:String,onYes:()->Unit,onNo:()->Unit){BackHandler(enabled=true){onNo()};AlertDialog(onDismissRequest=onNo,shape=RoundedCornerShape(22.dp),containerColor=CardBg,title={Text(title,fontWeight=FontWeight.ExtraBold,color=GreenDark)},text={Text(message,color=Color(0xFF46564D))},confirmButton={Button(onClick=onYes,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Text("हटाएँ")}},dismissButton={TextButton(onClick=onNo){Text("रद्द करें")}})}
@Composable
private fun ChoiceField(label:String,options:List<Pair<String,String>>,selected:String,onSelected:(String)->Unit){
    var open by rememberSaveable{mutableStateOf(false)}
    Column{
        Text(label,fontSize=12.sp,color=Color.Gray)
        Box{
            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){
                Text(options.firstOrNull{it.first==selected}?.second?.ifBlank{"नहीं चुना"} ?: "चुनें")
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                options.forEach{(id,name)->
                    DropdownMenuItem(text={Text(name.ifBlank{"नहीं चुना"})},onClick={onSelected(id);open=false})
                }
            }
        }
    }
}
