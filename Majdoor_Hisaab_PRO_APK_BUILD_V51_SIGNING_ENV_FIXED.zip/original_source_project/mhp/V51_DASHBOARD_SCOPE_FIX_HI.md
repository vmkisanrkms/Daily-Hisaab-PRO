# V51 — Dashboard Scope / Kotlin Compilation Fix

## Confirmed from GitHub Actions run 41594817715 / job 125779590510
The job environment requested `Majdoor_Hisaab_PRO_APK_BUILD_V50_KOTLIN_COMPILE_FIX.zip`, but the workflow fallback selected the only root ZIP available:
`Majdoor_Hisaab_PRO_APK_BUILD_V49_FINAL.zip`.
Thus the build did not compile V50.

## Root source defect found in the actually selected V49 source
`MainActivity.kt` `Dashboard()` opened a `LazyColumn` and closed that list, but did not close the outer `Dashboard()` function. As a result, declarations from `DashboardShortcut` onward were parsed as local declarations inside Dashboard. This caused cascaded errors including local `private` modifier errors, `@Composable` context errors, and unresolved references such as `SimpleDialog`, `ChoiceField`, `CaneParchiFormScreen`, and `CaneParchiDetail`.

## Fix
Inserted the missing closing brace immediately after the Dashboard LazyColumn, restoring top-level scope for the subsequent declarations. No feature logic or data model was changed.

## Workflow hardening
- Source ZIP is now strictly required by exact name; no automatic fallback to a different ZIP.
- `ZIP_NAME` is `Majdoor_Hisaab_PRO_APK_BUILD_V51_DASHBOARD_SCOPE_FIX.zip`.
- APK artifact name is `Majdoor-Hisaab-PRO-V51-RELEASE.apk`.

## Verification limits
ZIP integrity is checked. Static source audits can be run, but this environment does not have Gradle wrapper JAR, Gradle, or kotlinc cached. Kotlin compilation, signing, and APK creation must be confirmed by the next GitHub Actions run.
