from pathlib import Path
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'quick payment dialog has date amount and note': all(x in s for x in ['भुगतान की तारीख (YYYY-MM-DD)','भुगतान रकम ₹','नोट / विवरण (वैकल्पिक)']),
 'quick payment accepts historical date and stores by that month': 'val m=payment.date.take(7)' in s and 'old.copy(payments=old.payments+payment)' in s,
 'quick payment requires positive finite amount and valid date': '!validDate(paymentDate)||amount==null||!amount.isFinite()||amount<=0' in s,
 'salary edit opens Android device credential gate': 'protectedEdit?.let { emp -> DeviceCredentialGate("सैलरी कर्मचारी बदलें"' in s,
 'salary ledger save opens Android device credential gate': 'pendingSalarySave?.let { (emp, record) -> DeviceCredentialGate("कर्मचारी का हिसाब बदलें"' in s,
 'payment save opens Android device credential gate': 'pendingPaymentSave?.let { (emp, payment) -> DeviceCredentialGate("कर्मचारी भुगतान सेव करें"' in s,
 'attendance quick action remains one tap': 'Text("✓ उपस्थित"' in s and 'saveSalaryMonth(context,emp.id,m,updated)' in s,
 'holiday reason note remains available': 'कारण / नोट लिखें' in s,
 'employee detail ledger retains dated attendance and payment': 'तारीखवार भुगतान दर्ज करें' in s and 'रोज की हाजिरी' in s,
 'Google account change clears prior selection and forces fresh sign-in': 'driveAccount=null;backupStatus="Google Account चुनें…";drive.prepareFreshSignIn' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
