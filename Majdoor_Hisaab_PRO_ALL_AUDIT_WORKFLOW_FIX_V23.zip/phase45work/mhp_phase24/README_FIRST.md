# Majdoor Hisaab PRO — Redesign Master Package

## Contents
- `original_source_project/mhp/` — Android source project with Phase 1 UI/navigation changes.
- `MASTER_SCREEN_PLAN_HI_EN.md` — full A-to-Z scope and implementation phases.
- `FEATURE_PRESERVATION_MATRIX_TEMPLATE.md` — preservation matrix template.
- `SCREEN_PROGRESS_TRACKER.csv` — updated only for the source changes made in this phase.
- `original_source_project/mhp/REDESIGN_PHASE1_IMPLEMENTATION_REPORT.md` — changes, test status, and remaining work.

## Current status
This is a **partial implementation**, not a completed A-to-Z redesign or verified release APK.

## Phase 1 source changes
- Consistent Material 3 green/white palette at app root.
- Refined top app bar and four-destination bottom navigation.
- “और” module shortcuts for existing modules.
- Redesigned data-driven dashboard based on existing local records.
- Existing package, local store, business data classes, and module implementations retained.

## Verification limits
ZIP integrity and source-level structure checks were performed. Android compilation, Release signing, real-device testing, and end-to-end regression were not run in this environment.


## Phase 2 additions (2026-10-11)
- Screen-specific global app-bar titles/subtitles.
- Dashboard outstanding wage balance, recent attendance/payment rows, and saved field/crop counts.
- Updated tracker and preservation matrix for the newly changed items.
- See `original_source_project/mhp/REDESIGN_PHASE2_SOURCE_CHANGES_20261011.md`.
- These additions remain NOT TESTED on Android runtime and do not complete the full A-to-Z redesign.


## Phase 3 additions (2026-10-11)
- Worker list, Field list and Crop list UI layouts redesigned with search, real-data summary metrics and empty states.
- Existing store APIs and protected edit/delete behavior retained.
- Design implementation tracker: 12/135 (was 9/135); runtime tests remain NOT TESTED.
- See `REDESIGN_PHASE3_WORKER_FIELD_CROP_LISTS_20261011.md`.

## Phase 4 UI increment (2026-10-11)
- Expense and Sales lists updated with live search, saved-record count, visible subtotal/revenue, consistent cards and empty/no-results states.
- Shared detail header, section title/add action, action rows, common dialogs and destructive confirmation styling improved.
- Added `FEATURE_PRESERVATION_MATRIX_PHASE4.csv` and `original_source_project/mhp/scripts_redesign_phase4_ui_audit.py`.
- Current tracker: 16/135 design points marked IMPLEMENTED; 3 IN PROGRESS; 116 NOT STARTED. All 135 remain NOT TESTED on Android runtime.
- Kotlin compilation and Release APK were not verified because Android SDK/Gradle executable and `gradle-wrapper.jar` are unavailable in this environment. Do not treat this ZIP as the final completed redesign.


## Phase 7 data safety fixes (2026-10-11)
- Backup/restore now preserves locked-month accounting and field ordering.
- Restore validates collection structure, stages photos, and attempts rollback if photo replacement or preference commit fails.
- App lock is re-confirmed after Activity recreation.
- Phase 7 GitHub Actions ZIP/APK names updated.
- Static source audits: 82/82 assertions pass; see `PHASE7_STATIC_AUDIT_RESULTS.txt`.
- This is still a partial redesign. 102 design points remain not started, and all 135 Android runtime tests remain not tested.

## Phase 8 batch fixes (2026-10-11)
See `REDESIGN_PHASE8_BATCH_FIXES_20261011.md` and `PHASE8_STATIC_AUDIT_RESULTS.txt`. The batch adds field/crop duplicate validation, broader expense/sale search, season-scoped cane-parchi code validation, filtered PDF summary correction, attendance history counts, and GitHub Actions source-audit/build workflow updates. Static checks pass; Android build/runtime remain untested.


## Latest continuation: Phase 10 (2026-10-11)
Requested fixes K03 Report Date Range and K04 Worker/Field/Crop Selection are implemented in source. See `REDESIGN_PHASE10_REPORT_FILTERS_20261011.md` and `PHASE10_STATIC_AUDIT_RESULTS.txt`. Static source checks pass; Android runtime and APK build are not certified.

## Phase 13 — Work/Wages/Profitability (2026-10-11)
See `original_source_project/mhp/REDESIGN_PHASE13_WORK_WAGES_PROFITABILITY_20261011.md`. F01 routes to the existing protected attendance-entry flow; F02 adds a searchable saved-work list/detail; F03 adds wage-rate history; J04 adds field-wise revenue/cost/profit summary. Source/static audits passed, but Android runtime/build remains untested.


Phase 14 (2026-10-11): Report Centre, report type selection, report date/filter retention, and filtered-record PDF preview added. See `original_source_project/mhp/REDESIGN_PHASE14_REPORTS_PDF_20261011.md`. Android runtime/build tests remain pending.

## Phase 15 — L07 Ganna Chhilai Field-wise Detail (2026-10-11)
- Added a direct field-wise list in Ganna Chhilai Search / Filter; tapping a field opens its detail.
- Field detail now has date range and worker filters, filtered totals, reset action, and PDF export of the visible filtered rows.
- Field-less records are disclosed separately and are not attributed to any field total.
- Static audit script: `original_source_project/mhp/scripts_redesign_phase15_l07_field_detail_audit.py`.
- Android compile/APK/device UI test remain unverified.

## Phase 16 — Settings & Security (2026-10-11)
O01–O09 settings/profile/theme/app-lock/biometric/auto-lock/notification/report/backup/about controls were added or wired in MainActivity.kt. Static audit script: `scripts_redesign_phase16_settings_security_audit.py`. See `REDESIGN_PHASE16_SETTINGS_SECURITY_20261011.md`. Known incomplete wiring: notification service, report PDF column preferences, and scheduled backup reminders.


Phase 17 (2026-10-11): Store-level field/crop validation, payment lock integrity, old balance/advance allocation, worker-ledger PDF summary, and absent-inclusive attendance PDF. See `original_source_project/mhp/REDESIGN_PHASE17_ACCOUNTING_INTEGRITY_20261011.md`. Static assertions pass; Android build/runtime remains untested.

## Phase 18 — Ganna Chhilai Fandi / Rate / Worker Ledger / Payments
See `original_source_project/mhp/REDESIGN_PHASE18_GANNA_CHHILAI_FANDI_PAYMENTS_20261011.md` and `PHASE18_STATIC_AUDIT_RESULTS.txt`.
- Rate persistence uses synchronous preference commit with validation and save feedback.
- Store-level validation protects Fandi workers, duplicate work rows, payment CRUD and historical worker ledgers.
- Worker outstanding and advance are shown separately; workers with history cannot be deleted.
- Static audit: 22/22 PASS. Android compile/runtime and PDF/device testing remain NOT TESTED.


## Phase 19 — Ganna Parchi Season / Duplicate / PDF / CSV (2026-10-11)
- Fixed ALL season selector reset; season derives from ticket date using the existing April–March season rule.
- Added Store-level synchronized validation and season-scoped duplicate code checks for add/update, and missing-ID validation for delete.
- Preserved saved rate for edits that do not change the ticket date.
- PDF/CSV totals use the same filtered rows; CSV adds season, ISO date, totals, UTF-8 BOM and formula-injection guards. Empty exports are blocked.
- Focused audit: 34/34 PASS. Android build/device/PDF/CSV runtime remain NOT TESTED. See `original_source_project/mhp/REDESIGN_PHASE19_GANNA_PARCHI_SEASON_DUPLICATES_EXPORTS_20261011.md`.


## Phase 20 Backup / Restore hardening (2026-10-11)
- Hardened ZIP creation/validation, local export read-back verification, restore pre-validation, Drive file selection and rollback behavior.
- Static audits: canonical 27/27, V99 24/24; Android runtime and live Google Drive remain NOT TESTED. See Phase 20 audit report.

## Phase 21 — Shared UI / Back Navigation / Search / Rotation (2026-10-11)
- Navigation stack now serializes screen route and IDs through a saveable state saver, restoring the current route after Activity recreation.
- Startup readiness is no longer restored independently from the in-memory Store; the Store is reinitialized after recreation. App-lock state and in-flight Drive busy state are deliberately not restored as unlocked/busy.
- Pending local/Drive restore confirmation preserves the temporary backup file path across recreation.
- Shared SimpleDialog and ConfirmDialog handle system Back consistently; destructive confirmation Back maps to cancel.
- Shared search normalizer handles case, punctuation/spacing, and Devanagari digits across worker, field, crop, expense, sale, wage-rate, profitability, Fandi, payment and cane-parchi searches.
- Common primitive/string form state changed to saveable state where safe. Rotation and dialog interaction remain NOT TESTED on a physical Android device.
- Focused static audit: 24/24 PASS. The selected regression scripts were run; Android compilation/APK and runtime tests remain unverified because the wrapper JAR is missing and no Gradle executable is installed.

## Phase 24 — Five Remaining Points (2026-10-11)
- A02: optional custom 4–8 digit PIN with salted digest, attempt delay, phone credential fallback and credential-authorized reset.
- P03: standardized shared AppTextField wrapper across the canonical UI source.
- P06: shared loading/empty/error/success/info state component used by launch, empty cards, PIN feedback and backup status.
- Q01: action-level feature preservation matrix includes 291 scenarios for all 97 requested point IDs.
- Q09: release workflow points to Phase 24 source and validates signed package; actual signed APK remains blocked until permanent GitHub Actions signing secrets are configured and CI succeeds.
- See `PHASE24_FIVE_REMAINING_POINTS_FIX_REPORT_20261011.md` and `PHASE24_STATIC_AUDIT_RESULTS.txt`.


## Phase 25 — Gradle Wrapper JAR bootstrap hardening (2026-10-11)

The source ZIP still does not embed the binary gradle-wrapper.jar because this environment could not resolve external download hosts. Instead, both Android source trees now include `scripts/bootstrap-gradle-wrapper.sh`, and both workflows invoke it before any `./gradlew` task. The script downloads Gradle 8.11.1 from one of two official distribution hosts, verifies the SHA-256 pinned in `gradle-wrapper.properties`, generates the official wrapper JAR using that distribution, validates that `GradleWrapperMain` exists, and re-pins the distribution URL/checksum. This removes reliance on downloading the wrapper JAR directly from raw.githubusercontent.com; first-time Gradle distribution download still needs network access. Android build/runtime is not claimed verified here.

The Phase 25 workflow expects `Majdoor_Hisaab_PRO_REDESIGN_PHASE25_GRADLE_WRAPPER_BOOTSTRAP_FIX_20261011.zip` at the repository root.


## Phase 29 — Fandi Labour Quick Entry (2026-10-12)
See `PHASE29_FANDI_LABOUR_OPTIONAL_QUICK_ENTRY_20261012.md`. New labour form now has an optional checkbox to save today's fandi at the same time.
