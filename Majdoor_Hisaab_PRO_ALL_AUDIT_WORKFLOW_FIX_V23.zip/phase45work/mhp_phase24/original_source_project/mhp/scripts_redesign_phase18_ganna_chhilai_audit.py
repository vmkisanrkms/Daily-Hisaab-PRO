#!/usr/bin/env python3
"""Static source audit for Phase 18 Ganna Chhilai Fandi/rate/ledger/payments."""
from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER = ROOT.parents[1] / 'SCREEN_PROGRESS_TRACKER.csv'
s = SRC.read_text(encoding='utf-8')
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

store = s[s.index('private class Store'):s.index('@Composable private fun MajdoorApp')]
check('Fandi rate accepts only positive finite values', 'if(!value.isFinite() || value<=0.0) return false' in store)
check('Fandi rate uses synchronous preference commit before updating UI state', 'putString("fandiRate",value.toString()).commit()' in store)
check('Fandi worker creation rejects duplicate normalized names', 'fun addFandiLabour' in store and 'it.name.trim().replace(Regex("\\\\s+")," ").lowercase(Locale.ROOT)==key' in store)
check('Fandi worker creation rejects duplicate phone numbers', 'phone.length>=7' in store and 'old==phone' in store)
check('Fandi worker update rejects missing IDs and duplicates', 'fun updateFandiLabour' in store and 'if(fandiLabours.none{it.id==x.id}) return false' in store)
check('Fandi worker deletion preserves historical work/payment records', 'if(canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}) return false' in store)
check('Chhilai entry validates worker, optional field, date, quantity and rate', 'fandiLabours.none{it.id==x.labourId}' in store and '!validDate(x.date)' in store and '!x.fandi.isFinite()' in store and '!x.rate.isFinite()' in store)
check('Chhilai duplicate protection is enforced at Store layer', 'it.id==x.id || (it.labourId==x.labourId&&it.fieldId==x.fieldId&&it.date==x.date)' in store)
check('Chhilai amount is recalculated from saved quantity × historical rate', 'val normalized=x.copy(total=x.fandi*x.rate)' in store)
check('Chhilai deletion is blocked when worker has payment history', 'if(canePeelingPayments.any{it.labourId==row.labourId}) return false' in store and 'भुगतान इतिहास मौजूद है। हिसाब सुरक्षित रखने के लिए रिकॉर्ड हटाना रोका गया' in s)
check('Chhilai edit validates record ID and duplicate key', 'fun updateCanePeeling(x:CanePeeling):Boolean' in store and 'canePeelings.none{it.id==x.id}' in store and 'it.id!=x.id && it.labourId==x.labourId' in store)
check('Payment creation validates ID, worker, date and positive finite amount', 'fun addCanePeelingPayment' in store and 'x.id.isBlank()' in store and 'canePeelingPayments.any{it.id==x.id}' in store and '!x.amount.isFinite()' in store)
check('Payment edit rejects missing payment ID', 'fun updateCanePeelingPayment' in store and 'canePeelingPayments.none{it.id==x.id}' in store)
check('Payment delete rejects unknown ID and persists successful change', 'fun deleteCanePeelingPayment' in store and 'if(canePeelingPayments.none{it.id==id}) return false' in store)
check('Payment UI shows validation/save errors instead of silently closing', 'भुगतान सेव नहीं हुआ। मजदूर, तारीख, राशि या रिकॉर्ड ID जाँचें।' in s and 'if(saved) onClose()' in s)
check('Worker ledger separates outstanding balance and advance', 'val balance = (earned - paidTotal).coerceAtLeast(0.0)' in s and 'val advance = (paidTotal - earned).coerceAtLeast(0.0)' in s)
check('Payment summary separates overall outstanding and advance', 'val balance = (earned - allPaid).coerceAtLeast(0.0)' in s and 'val advance = (allPaid - earned).coerceAtLeast(0.0)' in s)
check('Worker list never displays a negative outstanding balance', 'val outstanding=(earned-paid).coerceAtLeast(0.0);val advance=(paid-earned).coerceAtLeast(0.0)' in s)
check('Existing entries retain their saved historical rate while new entries use current rate', 'val r=existing?.rate ?: store.fandiRate' in s)
check('Fandi workers, work and payments are included in backup collections', '"fandiLabour"' in s and '"canePeeling"' in s and '"canePeelingPayment"' in s)
check('All sensitive Fandi Store CRUD paths are synchronized against rapid duplicate calls', all(f'@Synchronized fun {name}' in store for name in ['addCanePeeling','updateCanePeeling','deleteCanePeeling','addCanePeelingPayment','updateCanePeelingPayment','deleteCanePeelingPayment','addFandiLabour','updateFandiLabour','deleteFandiLabour','updateFandiRate']))
check('Payment dialog reports invalid amount and invalid date', 'भुगतान की राशि शून्य से अधिक और सही होनी चाहिए।' in s and 'भुगतान की तारीख सही चुनें।' in s)

for label, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'RESULT: {sum(ok for _,ok in checks)}/{len(checks)} PASS, {sum(not ok for _,ok in checks)} FAIL')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
