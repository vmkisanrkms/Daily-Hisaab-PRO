#!/usr/bin/env python3
"""Phase 12 static audit for attendance bulk actions and record calendar."""
from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parent
SRC=(ROOT/"app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt").read_text(encoding="utf-8")
TRACKER=ROOT.parent.parent/"SCREEN_PROGRESS_TRACKER.csv"
checks={
 "E05 all-full action control exists": 'pendingBulkAttendanceAction="all_full"' in SRC and 'सब पूरा दिन' in SRC,
 "E05 clear-all action control exists": 'pendingBulkAttendanceAction="clear_all"' in SRC and 'सब साफ' in SRC,
 "E05 previous-team action control exists": 'pendingBulkAttendanceAction="previous_team"' in SRC and 'पिछली टीम' in SRC,
 "E05 actions require confirmation dialog": 'एक साथ हाजिरी' in SRC and 'onDismissRequest={pendingBulkAttendanceAction=""}' in SRC,
 "E05 actions require Android credential gate": 'एक साथ हाजिरी बदलने के लिए Android screen lock या biometric से पुष्टि करें।' in SRC,
 "E05 all-full writes through Store validation": 'store.upsertAttendance(Attendance(existing?.id ?: UUID.randomUUID().toString(),worker.id,activeField,cropId,selectedDate,1.0' in SRC,
 "E05 clear-all uses Store delete validation": 'rows.forEach { row -> if(store.deleteAttendance(row.id)) changed++ else skipped++ }' in SRC,
 "E05 previous team copies saved prior-day attendance": 'store.attendances.filter { it.fieldId==activeField && it.date==previousDate && it.fraction>0.0 }' in SRC,
 "E05 skipped locked/conflicting rows reported": 'सुरक्षित/लॉक रिकॉर्ड नहीं हटे' in SRC and 'छोड़े गए' in SRC,
 "E07 calendar derives markers from real saved rows": 'val dayMap=allMonthRows.groupBy{it.date}' in SRC and 'records=dayMap[date].orEmpty()' in SRC,
 "E07 calendar dates are selectable": 'clickable{selectedCalendarDate=date}' in SRC,
 "E07 previous/next month navigation exists": 'shiftMonth(month,-1)' in SRC and 'shiftMonth(month,1)' in SRC,
 "E07 selected day details come from stored records": 'val selectedRows=allMonthRows.filter{it.date==selectedCalendarDate}' in SRC,
 "E07 selected day shows absent records": 'selectedRows.count{it.fraction==0.0}' in SRC and 'भांजी / अनुपस्थित' in SRC,
 "E07 empty-day state exists": 'इस तारीख का कोई हाजिरी रिकॉर्ड सेव नहीं है।' in SRC,
}
try:
 with TRACKER.open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
 ids={r["ID"]:r for r in rows}
 checks["tracker contains 135 unique IDs"]=len(rows)==135 and len(ids)==135
 checks["tracker E05 source implementation and honest test status"]=ids["E05"]["Implementation_Status"]=="IMPLEMENTED" and ids["E05"]["Test_Status"]=="NOT TESTED"
 checks["tracker E07 source fix status honest"]=ids["E07"]["Implementation_Status"]=="IMPLEMENTED" and ids["E07"]["Test_Status"]=="NOT TESTED"
except Exception:
 checks["tracker valid"]=False
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" | "+name)
print(f"SUMMARY {sum(checks.values())}/{len(checks)} PASS")
sys.exit(0 if all(checks.values()) else 1)
