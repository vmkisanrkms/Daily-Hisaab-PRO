from pathlib import Path
import csv, zipfile, tempfile
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
tracker=root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
s=src.read_text(encoding='utf-8')
checks={
 'backup contains locked-month accounting state':'"lockedLabourMonths"' in s and 'private val backupKeys = listOf("labour","fandiLabour","field","crop","expense","sale","attendance","payment","labourClosure","lockedLabourMonths"' in s,
 'backup captures field ordering':'put("fieldOrder",prefs.getString("fieldOrder", "").orEmpty())' in s,
 'restore reapplies field ordering or clears stale ordering':'if(savedFieldOrder.isNotBlank()) editor.putString("fieldOrder",savedFieldOrder) else editor.remove("fieldOrder")' in s,
 'restore reloads locked-month state into live Store':'lockedLabourMonths=loadLockedLabourMonths()' in s,
 'backup arrays validated before restore writes':'validateBackupArrays(root)' in s,
 'backup collection types validated':'if(value !is JSONArray)' in s,
 'backup records validated as JSON objects':'value.opt(i) !is JSONObject' in s,
 'fandi rate metadata validated':'Backup में फांदी रेट गलत है।' in s,
 'field-order metadata validated':'Backup में खेतों का क्रम गलत है।' in s,
 'app lock is not restored from saved-state bundle':'var appUnlocked by remember{mutableStateOf(false)}' in s,
 'screen lock credential gate retained':'createConfirmDeviceCredentialIntent(title,message)' in s,
 'restore confirmation remains protected':'DeviceCredentialGate("Backup Restore करें"' in s,
 'photo files are staged before replacing existing data':'photos_restore_${UUID.randomUUID()}' in s and 'photoEntries.forEach{(name,bytes)->' in s,
 'preference snapshot supports rollback':'val oldValues=backupKeys.associateWith{prefs.getString(it,null)}' in s and 'rollback.commit()' in s,
 'old photo folder is restored on preference failure':'if(previousMoved && previousDir.exists()) previousDir.renameTo(photoDir)' in s,
 'existing local store retained':'private class Store(private val context:Context)' in s,
 'Ganna Chhilayi and Parchi remain wired':'Screen.CaneParchi->CaneParchiDashboardScreen(store)' in s and 'Screen.CanePeeling->CanePeelingScreen(store,{back()})' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'SUMMARY {sum(checks.values())}/{len(checks)} PASS')
rows=list(csv.DictReader(open(tracker,encoding='utf-8-sig')))
assert len(rows)==135 and len({r['ID'] for r in rows})==135
print('PASS | tracker has exactly 135 unique screen IDs')
if not all(checks.values()): raise SystemExit(1)
