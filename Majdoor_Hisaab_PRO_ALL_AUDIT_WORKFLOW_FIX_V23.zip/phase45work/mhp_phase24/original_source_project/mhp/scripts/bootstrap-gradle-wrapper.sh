#!/usr/bin/env bash
set -euo pipefail
EXPECTED_GRADLE_VERSION="8.11.1"
WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"

version_of() {
  gradle --version | awk '/^Gradle [0-9]/{ sub(/^Gradle /, ""); print; exit }'
}

# A pre-existing JAR is accepted only if it is a readable ZIP/JAR and contains
# the official wrapper entry point. Otherwise remove it and regenerate it.
if [[ -s "$WRAPPER_JAR" ]]; then
  if jar tf "$WRAPPER_JAR" >/dev/null 2>&1 && jar tf "$WRAPPER_JAR" | grep -qx 'org/gradle/wrapper/GradleWrapperMain.class'; then
    echo "Valid Gradle Wrapper JAR already present"
    [[ -x ./gradlew ]] || chmod +x ./gradlew
    exit 0
  fi
  echo "Invalid Gradle Wrapper JAR detected; regenerating"
  rm -f "$WRAPPER_JAR"
fi

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle $EXPECTED_GRADLE_VERSION must be provisioned on CI before wrapper bootstrap." >&2
  exit 2
fi
ACTUAL_VERSION="$(version_of)"
if [[ "$ACTUAL_VERSION" != "$EXPECTED_GRADLE_VERSION" ]]; then
  echo "ERROR: expected Gradle $EXPECTED_GRADLE_VERSION, found ${ACTUAL_VERSION:-unknown}" >&2
  exit 3
fi

gradle wrapper --gradle-version "$EXPECTED_GRADLE_VERSION" --distribution-type bin
[[ -s "$WRAPPER_JAR" ]]
jar tf "$WRAPPER_JAR" | grep -qx 'org/gradle/wrapper/GradleWrapperMain.class'
[[ -x ./gradlew ]] || chmod +x ./gradlew
./gradlew --version
echo "Gradle Wrapper generated and verified"
