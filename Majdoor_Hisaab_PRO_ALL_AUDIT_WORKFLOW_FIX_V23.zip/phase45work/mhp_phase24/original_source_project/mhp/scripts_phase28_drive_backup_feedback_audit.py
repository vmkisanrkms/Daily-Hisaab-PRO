#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
s=(root/"app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt").read_text(encoding="utf-8")
w=(root/".github/workflows/majdoor-hisaab.yml").read_text(encoding="utf-8")
checks={
 "direct Drive action reports immediate progress":"Backup शुरू हुआ है:" in s,
 "backup creation stage is visible":"Backup फ़ाइल बनाई जा रही है…" in s,
 "Drive upload stage is visible":"Google Drive पर upload हो रहा है…" in s,
 "success confirms uploaded file and timestamp":"Google Drive Backup सफल! फ़ाइल:" in s,
 "busy duplicate taps show feedback":"पिछला Google Drive काम अभी चल रहा है" in s,
 "manual backup clearly described as local file":"फोन / File Picker में Backup" in s,
 "Drive backup button has explicit busy label":"कृपया प्रतीक्षा करें…" in s and 'if(driveBusy)' in s,
 "Phase 27 audit is called as a shell command":"python scripts_phase27_requested_ui_fixes_audit.py" in w or "python3 scripts_phase27_requested_ui_fixes_audit.py" in w,
 "Phase 28 backup feedback audit is in workflow":"scripts_phase28_drive_backup_feedback_audit.py" in w,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+": "+name)
print(f"RESULT: {sum(checks.values())}/{len(checks)} PASS, {sum(not v for v in checks.values())} FAIL")
sys.exit(0 if all(checks.values()) else 1)
