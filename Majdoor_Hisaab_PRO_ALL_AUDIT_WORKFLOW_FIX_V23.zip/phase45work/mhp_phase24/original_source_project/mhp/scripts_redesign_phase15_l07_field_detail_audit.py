#!/usr/bin/env python3
"""Static audit for Phase 15 L07 field-wise Ganna Chhilai details."""
from pathlib import Path
p=Path(__file__).resolve().parent / "app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt"
s=p.read_text(encoding="utf-8")
checks={
 "field detail composable exists": "private fun CanePeelingFieldDetail" in s,
 "field detail is routed from selected field": "CanePeelingFieldDetail(store,selectedField!!" in s,
 "field-wise list entry point exists": "खेतवार छिलाई विवरण" in s,
 "field cards open matching field": "clickable{onField(field.id)}" in s,
 "field records filtered by field id": "store.canePeelings.filter{it.fieldId==fieldId}" in s,
 "field date-from filter": "(from.isBlank()||it.date>=from)" in s,
 "field date-to filter": "(to.isBlank()||it.date<=to)" in s,
 "field worker filter": "(workerFilter.isBlank()||it.labourId==workerFilter)" in s,
 "filtered fandi summary": 'CaneMiniStat("फांदी",money(rows.sumOf{it.fandi})' in s,
 "filtered wage summary": 'CaneMiniStat("कुल राशि","₹${formatFandiRate(rows.sumOf{it.total})}"' in s,
 "field PDF action": 'Text("PDF रिपोर्ट")' in s and 'Ganna_Chhilai_Field_' in s,
 "PDF uses filtered rows": 'rows.forEach{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId}' in s,
 "unassigned entries are not silently included": "ये किसी खेत के कुल में शामिल नहीं हैं" in s,
 "Ganna Parchi route still present": 'onNavigate("cane")' in s,
 "normal labour module still present": 'Screen.Labour' in s,
}
failed=[]
for label,ok in checks.items():
 print(("PASS" if ok else "FAIL")+" | "+label)
 if not ok: failed.append(label)
print(f"RESULT: {len(checks)-len(failed)} PASS / {len(failed)} FAIL")
raise SystemExit(bool(failed))
