package com.majdoor.hisaabpro

import kotlin.math.max

/** Pure accounting calculations shared by the app and JVM regression tests. */
internal data class AccountingBalance(
    val oldDue: Double,
    val currentDue: Double,
    val advance: Double,
    val totalOutstanding: Double,
    val currentWages: Double,
    val currentPayments: Double
)

private fun nonNegativeFinite(value: Double): Double = if (value.isFinite()) max(0.0, value) else 0.0

internal fun attendanceWage(fraction: Double, rate: Double): Double {
    if (!fraction.isFinite() || !rate.isFinite() || fraction <= 0.0 || rate <= 0.0) return 0.0
    return fraction * rate
}

internal fun fieldProfit(revenue: Double, expenses: Double, wages: Double): Double =
    nonNegativeFinite(revenue) - nonNegativeFinite(expenses) - nonNegativeFinite(wages)

/** Payments from an open period first settle finalized/locked old debt. */
internal fun calculateAccountingBalance(
    closureWage: Double,
    closurePaid: Double,
    lockedWages: Double,
    lockedPayments: Double,
    currentWages: Double,
    currentPayments: Double
): AccountingBalance {
    val safeClosureWage = nonNegativeFinite(closureWage)
    val safeClosurePaid = nonNegativeFinite(closurePaid)
    val safeLockedWages = nonNegativeFinite(lockedWages)
    val safeLockedPayments = nonNegativeFinite(lockedPayments)
    val safeCurrentWages = nonNegativeFinite(currentWages)
    val safeCurrentPayments = nonNegativeFinite(currentPayments)

    val oldNet = safeClosureWage - safeClosurePaid + safeLockedWages - safeLockedPayments
    val oldDue = max(0.0, oldNet)
    val oldCredit = max(0.0, -oldNet)
    val paymentsToOld = minOf(oldDue, safeCurrentPayments)
    val oldRemaining = max(0.0, oldDue - paymentsToOld)
    val paymentsForCurrent = max(0.0, safeCurrentPayments - paymentsToOld)
    val creditAdjustedWages = max(0.0, safeCurrentWages - oldCredit)
    val currentDue = max(0.0, creditAdjustedWages - paymentsForCurrent)
    val creditRemaining = max(0.0, oldCredit - safeCurrentWages)
    val advance = creditRemaining + max(0.0, paymentsForCurrent - creditAdjustedWages)
    return AccountingBalance(
        oldDue = oldRemaining, currentDue = currentDue, advance = advance,
        totalOutstanding = oldRemaining + currentDue, currentWages = safeCurrentWages,
        currentPayments = safeCurrentPayments
    )
}
