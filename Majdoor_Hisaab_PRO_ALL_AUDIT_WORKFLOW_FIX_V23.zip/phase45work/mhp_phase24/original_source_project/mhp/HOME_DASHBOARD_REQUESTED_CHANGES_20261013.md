# Majdoor Hisaab PRO — Home Dashboard Changes (2026-10-13)

## Requested changes applied
- Renamed the main Home dashboard attendance button to **आज की हाजरी**.
- That button now navigates directly to the existing **हाजिरी के लिए खेत चुने** field picker, skipping the intermediate **दिहाड़ी मजदूर** two-button screen.
- The five **आज का सारांश** metric cards are display-only; their click handlers and clickable card modifiers were removed. They continue to display the existing computed values for today's wages, expenses, sales, today's payments/advances, and labour outstanding.
- Replaced the **कुल खेत** and **कुल फसलें** tiles in **खेत और फसल** with **गन्ना पर्ची** and **गन्ना छिलाई** shortcuts.
- Removed the full **हाल के रिकॉर्ड** section from Home.
- Kept the separate existing Ganna Parchi, Ganna Chhilai, Daily Labour accounts, and other modules intact.

## Validation
- Source-level assertions checked for the renamed label, direct attendance-field route, non-clickable summary cards, replacement shortcuts, and removal of the Home recent-records block.
- ZIP archive integrity checked after packaging.
- Gradle compile could not be completed in this environment because the Gradle wrapper attempted to download its distribution from `raw.githubusercontent.com` and network DNS access was unavailable. Build/runtime verification is therefore still pending; no successful build is claimed.
