#!/usr/bin/env python3
from pathlib import Path
import sys
s=(Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'salary data included in backup': 'put("salaryData",salaryData)' in s,
 'salary data restored with rollback': 'restoredSalaryData!=null' in s and 'oldSalaryValues.forEach' in s,
 'salary month snapshot stored': 'salaryAtMonth' in s and 'put("salaryAtMonth",r.salaryAtMonth)' in s,
 'dated salary payment ledger stored': 'data class SalaryPayment' in s and 'put("payments",payments)' in s,
 'salary payment date validated': 'validDate(paymentDate)' in s,
 'salary attendance date validated': 'validDate(attendanceDate)' in s,
 'salary employee join date validated': 'validDate(date.trim())' in s,
 'daily labour landing actions': 'DailyLabourHomeScreen' in s and 'Text("हाजिरी लगाएँ"' in s and 'Text("हिसाब देखें"' in s,
 'salary module independent preference store': 'getSharedPreferences("mhpro_salary_employees_v1"' in s,
}
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' | '+name)
 if not ok: failed.append(name)
print(f'SUMMARY {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
