# Salary Employee Daily Actions / Backup Account Picker Patch

- Reworked Salary Employee list into compact worker cards with one-tap today's Present action, a Bhānji/leave action with a required note field, and a direct route into employee details/payment ledger.
- Employee name opens the detailed monthly attendance/payment editor; salary remains editable from the worker card. Historical attendance and payment dates remain editable by selecting the relevant month and date in the detail view.
- Leave entries now count toward salary deduction consistently with absent days.
- Backup Google Account change action now explicitly clears the displayed account and starts the fresh sign-in flow with a visible prompt.
- Salary data remains in the dedicated local SharedPreferences store and existing backup/restore integration remains intact.

Verification: salary employee static audit 14/14 PASS. Gradle compile could not be run here because the wrapper bootstrap needs network access to raw.githubusercontent.com, which was unavailable. GitHub Actions compile and on-device Google account selection still need verification.
