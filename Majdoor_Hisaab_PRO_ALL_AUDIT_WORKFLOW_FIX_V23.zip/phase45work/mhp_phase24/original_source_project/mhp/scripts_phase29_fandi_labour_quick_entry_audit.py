#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
a=s.index('@Composable\nprivate fun FandiLabourDialog(')
b=s.index('\n@Composable\nprivate fun CanePeelingLabourDetail(',a)
d=s[a:b]
checks={
 'optional checkbox exists':'आज की फांदी भी साथ में सेव करें' in d,
 'unchecked by default':'mutableStateOf(false)' in d and 'saveTodayFandi' in d,
 'date input available':'AttendanceDateButton(date)' in d,
 'optional field selector':'खेत (वैकल्पिक)' in d,
 'fandi quantity input':'आज की फांदी *' in d,
 'rate from persistent store':'store.fandiRate' in d,
 'amount preview':'amount=(fandi.toDoubleOrNull()?:0.0)*store.fandiRate' in d,
 'validates positive quantity':'f<=0||!f.isFinite()' in d,
 'validates date':'!validDate(date)' in d,
 'saves worker first':'val workerSaved=store.addFandiLabour(x)' in d,
 'saves same-day entry linked to new worker':'CanePeeling(UUID.randomUUID().toString(),resolvedId,field,date,f,r,f*r)' in d,
 'rolls back worker if fandi save fails':'store.deleteFandiLabour(resolvedId)' in d,
 'clear user feedback on failure':'फांदी पहले से दर्ज है' in d,
 'only adds fandi when opted in':'else if(saveTodayFandi)' in d,
}
failed=[]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name); failed += [] if ok else [name]
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(bool(failed))
