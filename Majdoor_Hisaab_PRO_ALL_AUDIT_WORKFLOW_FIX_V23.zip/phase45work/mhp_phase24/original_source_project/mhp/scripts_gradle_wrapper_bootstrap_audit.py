#!/usr/bin/env python3
"""Static consistency audit for the Gradle Wrapper bootstrap workflow."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
workflow_path = ROOT / ".github/workflows/majdoor-hisaab.yml"
bootstrap_path = ROOT / "scripts/bootstrap-gradle-wrapper.sh"
props_path = ROOT / "gradle/wrapper/gradle-wrapper.properties"

workflow = workflow_path.read_text(encoding="utf-8")
bootstrap = bootstrap_path.read_text(encoding="utf-8")
props = props_path.read_text(encoding="utf-8")

def property_value(key):
    prefix = key + "="
    for line in props.splitlines():
        if line.startswith(prefix):
            return line.split("=", 1)[1].replace(r"\\:", ":")
    return ""

checks = {
    "wrapper bootstrap script exists": bootstrap_path.is_file(),
    "wrapper properties exist": props_path.is_file(),
    "Gradle distribution pinned to 8.11.1": "gradle-8.11.1-bin.zip" in property_value("distributionUrl"),
    "distribution checksum is a 64-character SHA-256": len(property_value("distributionSha256Sum")) == 64 and all(c in "0123456789abcdefABCDEF" for c in property_value("distributionSha256Sum")),
    "bootstrap expects Gradle 8.11.1": 'EXPECTED_GRADLE_VERSION="8.11.1"' in bootstrap,
    "bootstrap rejects missing system Gradle with actionable error": 'command -v gradle' in bootstrap and "must be provisioned on CI" in bootstrap,
    "bootstrap checks actual Gradle version before generation": 'gradle --version' in bootstrap and 'ACTUAL_VERSION' in bootstrap,
    "bootstrap regenerates wrapper using pinned version": 'gradle wrapper --gradle-version "$EXPECTED_GRADLE_VERSION" --distribution-type bin' in bootstrap,
    "bootstrap verifies wrapper entry point": "org/gradle/wrapper/GradleWrapperMain.class" in bootstrap,
    "workflow provisions Gradle 8.11.1 before bootstrap": workflow.find("gradle-version: 8.11.1") >= 0 and workflow.find("gradle-version: 8.11.1") < workflow.find("bash scripts/bootstrap-gradle-wrapper.sh"),
    "workflow invokes bootstrap before compile": workflow.find("bash scripts/bootstrap-gradle-wrapper.sh") >= 0 and workflow.find("bash scripts/bootstrap-gradle-wrapper.sh") < workflow.find("./gradlew :app:compileReleaseKotlin"),
    "workflow validates wrapper version before compile": workflow.find("./gradlew --version") >= 0 and workflow.find("./gradlew --version") < workflow.find("./gradlew :app:compileReleaseKotlin"),
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"SUMMARY: {len(checks)-failed}/{len(checks)} PASS, {failed} FAIL")
sys.exit(0 if failed == 0 else 1)
