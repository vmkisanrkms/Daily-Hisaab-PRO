# Phase 12 — Attendance Bulk Actions & Real Record Calendar

Date: 2026-10-11

## E05 — Bulk Actions
- Added All Full, Clear All, and Previous Team controls for the selected field/date.
- Actions show a confirmation dialog and use the existing Android credential gate before applying changes.
- All Full and Previous Team use Store.upsertAttendance, so existing month-lock, finalized-account and cross-field conflict rules continue to apply.
- Clear All uses Store.deleteAttendance, preserving locked/finalized attendance.
- Previous Team uses the prior calendar date's saved present attendance rows for the same field, carrying forward their full/half fraction and applicable crop when available.
- UI reports how many rows were changed or skipped.

## E07 — Actual Attendance Calendar
- Replaced the month-list-only navigation with a selectable calendar grid.
- Calendar markers/counts are derived from stored attendance records for each exact date.
- Month navigation is limited to available historical months and the current month.
- Selecting a date displays the real saved rows for that date, including absent (fraction=0) rows, and a wage summary.

## Static verification
- `scripts_redesign_phase12_attendance_bulk_calendar_audit.py` checks 18 source/tracker assertions.
- Existing audits for phases 2, 4–9, K03/K04 and phase 11 should be rerun after changes.
- Android/Kotlin compilation, biometric confirmation on device, bulk-action behavior with locked months, and calendar visual/rotation tests remain NOT TESTED. The source ZIP currently does not contain `gradle-wrapper.jar`.
