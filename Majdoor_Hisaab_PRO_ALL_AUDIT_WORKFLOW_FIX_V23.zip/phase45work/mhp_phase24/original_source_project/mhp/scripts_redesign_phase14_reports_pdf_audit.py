from pathlib import Path
import csv, sys
root=Path(__file__).resolve().parent
source=root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
text=source.read_text(encoding='utf-8')
checks={
 'K01 ReportCentre screen registered':'data object ReportCentre:Screen()' in text and 'Screen.ReportCentre->ReportCentreScreen' in text,
 'K01 dashboard shortcut':'DashboardModule("📄", "रिपोर्ट सेंटर"' in text and '"reports"->Screen.ReportCentre' in text,
 'K01 profile shortcut':'SmallAction("📄  रिपोर्ट सेंटर"' in text,
 'K02 report type screen registered':'data object ReportType:Screen()' in text and 'Screen.ReportType->ReportTypeSelectionScreen' in text,
 'K02 worker/payment type':'"मजदूर और भुगतान"' in text,
 'K02 attendance type':'"हाजिरी"' in text,
 'K02 work type':'"काम और मजदूरी"' in text,
 'K02 expense and sales types':'"खर्च रिपोर्ट"' in text and '"बिक्री रिपोर्ट"' in text,
 'K02 profitability type':'"मुनाफा रिपोर्ट"' in text,
 'K03 inclusive date range retained':'startDate <= endDate' in text and 'date >= startDate && date <= endDate' in text,
 'K04 worker selection retained':'selectedReportWorkers.toSet()' in text,
 'K04 field selection retained':'selectedFields.toSet()' in text,
 'K04 crop selection retained':'selectedCrops.toSet()' in text,
 'K05 preview state':'var showPdfPreview by rememberSaveable' in text,
 'K05 preview screen':'DetailTopBar("K05 • PDF पूर्वावलोकन"' in text,
 'K05 preview attendance rows':'items(selectedAttendanceForReport' in text,
 'K05 preview payment rows':'items(selectedPaymentsForReport' in text,
 'K05 PDF action after preview':'PDF बनाएं और साझा करें' in text,
 'K05 export uses filtered records':'selectedAttendanceForReport,selectedPaymentsForReport,store,aggregateWorkerView=true,background=true' in text and 'val selectedAttendanceForReport=matchingAttendance' in text and 'val selectedPaymentsForReport=matchingPayments' in text,
 'Existing modules remain registered':'Screen.WorkList->WorkListScreen' in text and 'Screen.Profitability->ProfitabilityScreen' in text,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'RESULT {sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): sys.exit(1)
tracker=root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
if tracker.exists():
    with tracker.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    ids={r['ID'] for r in rows}
    print(f'TRACKER unique IDs: {len(ids)}')
    for k in ['K01','K02','K03','K04','K05']:
        print(('PASS' if k in ids else 'FAIL')+' tracker '+k)
