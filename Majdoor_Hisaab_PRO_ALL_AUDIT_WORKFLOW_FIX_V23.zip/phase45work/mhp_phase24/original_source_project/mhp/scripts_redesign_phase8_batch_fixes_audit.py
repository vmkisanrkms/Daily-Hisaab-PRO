from pathlib import Path
import csv
ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
text = SRC.read_text(encoding='utf-8')
checks = {
    'field form requires a name': 'खेत का नाम लिखना जरूरी है।' in text,
    'field form blocks duplicate names case-insensitively': 'it.name.trim().replace(Regex("\\\\s+")," ").equals(normalized,ignoreCase=true)' in text,
    'field address remains optional': 'पता/स्थान (Optional)' in text,
    'field form shows validation errors': 'if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)' in text,
    'crop form requires a name': 'फसल का नाम डालें' in text,
    'crop form blocks duplicate crop within field': 'it.fieldId==field&&it.name.trim().equals(name.trim(),ignoreCase=true)' in text,
    'crop sowing date validation retained': 'सही बुवाई तारीख डालें: YYYY-MM-DD' in text,
    'expense search includes crop name': 'val cropName=store.crops.firstOrNull{it.id==e.cropId}?.name.orEmpty()' in text,
    'expense search includes display date': 'displayDate(e.date)' in text,
    'expense search includes formatted amount': '"₹${money(e.amount)}"' in text,
    'expense list keeps no-result state': 'इस खोज से कोई खर्च नहीं मिला।' in text,
    'sale search includes crop name': 'val cropName=store.crops.firstOrNull{it.id==s.cropId}?.name.orEmpty()' in text,
    'sale search includes display date': 'displayDate(s.date)' in text,
    'sale search includes formatted total': '"₹${money(s.total)}"' in text,
    'sale list keeps no-result state': 'इस खोज से कोई बिक्री नहीं मिली।' in text,
    'parchi duplicate code is season-scoped at Store boundary': 'it.season==normalized.season && normalizedParchiCode(it.code)==normalized.code' in text and 'it.season==caneSeason(date)' in text,
    'parchi duplicate code error is user-readable': 'इस सीजन में यह पर्ची कोड पहले से मौजूद है।' in text,
    'parchi search can be cleared': 'IconButton(onClick={query=""}) { Icon(Icons.Default.Close,"खोज साफ करें") }' in text,
    'parchi search empty state distinguishes query': 'इस खोज से कोई पर्ची नहीं मिली। नाम, पिता का नाम या कोड बदलकर देखें。' in text or 'इस खोज से कोई पर्ची नहीं मिली。' in text or 'इस खोज से कोई पर्ची नहीं मिली। नाम, पिता का नाम या कोड बदलकर देखें।' in text,
    'parchi PDF summary uses exported filtered rows': 'exportRows.sumOf{it.weight}' in text and 'exportRows.sumOf{it.weight*it.rate}' in text and 'exportCaneCsv(context, store, exportRows' in text,
    'attendance history exposes half-day count': 'RedesignMetric("आधे दिन",allMonthRows.count{it.fraction==0.5}.toString()' in text,
    'attendance history exposes absent count without names': 'RedesignMetric("अनुपस्थित",allMonthRows.count{it.fraction==0.0}.toString()' in text,
    'existing Ganna Chhilayi store logic retained': 'private fun CanePeelingScreen' in text,
    'existing Ganna Parchi module retained': 'private fun CaneParchiDashboardScreen' in text,
}
wf=(ROOT/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
checks.update({
    'workflow uses setup-android v4': 'android-actions/setup-android@v4' in wf,
    'workflow installs platform-tools via setup action': "packages: 'platform-tools'" in wf,
    'workflow no longer cancels active release builds': 'cancel-in-progress: false' in wf,
    'workflow runs phase8 static audit': 'scripts_redesign_phase8_batch_fixes_audit.py' in wf,
    'workflow builds release APK directly after Kotlin compile': ':app:compileReleaseKotlin' in wf and ':app:assembleRelease' in wf,
    'workflow validates package and signature': 'verify --verbose' in wf and 'Expected package' in wf,
})
tracker=ROOT.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
if tracker.exists():
    rows=list(csv.DictReader(tracker.open(encoding='utf-8-sig',newline='')))
    checks['tracker retains 135 unique screen IDs']=len(rows)==135 and len({r['ID'] for r in rows})==135
else:
    checks['tracker retains 135 unique screen IDs']=False
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
