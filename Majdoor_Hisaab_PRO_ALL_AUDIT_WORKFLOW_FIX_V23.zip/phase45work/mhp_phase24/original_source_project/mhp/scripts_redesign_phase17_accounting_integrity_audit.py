from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER = ROOT.parent.parent / 'SCREEN_PROGRESS_TRACKER.csv'
s = SOURCE.read_text(encoding='utf-8')
checks = {
    'crop field reassignment blocked if any linked history exists': 'if(hasHistory && old.fieldId!=x.fieldId) return false' in s,
    'crop add/update validates parent field and duplicate identity': 'fields.none{it.id==x.fieldId}' in s and 'crops.any{it.id!=x.id && it.fieldId==x.fieldId' in s,
    'field/crop consistency checked in Store': 'private fun validFieldCrop(fieldId:String,cropId:String):Boolean' in s,
    'legacy relational mismatch detector exists': 'fun fieldCropIntegrityIssues(fieldId:String?=null,cropId:String?=null):List<String>' in s,
    'field detail warns about mismatched legacy records': 'खेत/फसल रिकॉर्ड मिलान चेतावनी' in s,
    'crop detail warns about mismatched legacy records': 'फसल रिकॉर्ड मिलान चेतावनी' in s,
    'expense create validates row and unique ID': 'if(!validExpense(x) || expenses.any{it.id==x.id}) return false' in s,
    'expense update rejects unknown ID': 'if(expenses.none{it.id==x.id} || !validExpense(x)) return false' in s,
    'expense delete rejects unknown ID': 'if(expenses.none{it.id==id}) return false' in s,
    'sale create validates and recalculates total': 'if(!validSale(x) || sales.any{it.id==x.id}) return false' in s and 'val safe=x.copy(total=x.qty*x.rate)' in s,
    'sale update rejects unknown ID and recalculates total': 'if(sales.none{it.id==x.id} || !validSale(x)) return false' in s,
    'payment create rejects locked and finalized dates': 'isClosedDate(x.labourId,x.date) || isMonthLocked(x.date)' in s,
    'payment update requires existing ID': 'val old=payments.firstOrNull{it.id==x.id}?:return false' in s,
    'payment update preserves original worker ID': 'if(x.labourId!=old.labourId' in s,
    'payment update checks both old and new dates for lock/finalization': 'isClosedDate(old.labourId,old.date) || isClosedDate(x.labourId,x.date) || isMonthLocked(old.date) || isMonthLocked(x.date)' in s,
    'payment delete checks lock and finalization': 'isClosedDate(row.labourId,row.date) || isMonthLocked(row.date)' in s,
    'locked month wage/payment records roll into finalized old balance': 'val lockedWages=attendances.filter' in s and 'val lockedPayments=payments.filter' in s and 'calculateAccountingBalance(' in s,
    'balance breakdown allocates later payments to old debt first': 'paymentsToOld = minOf(oldDue, safeCurrentPayments)' in (ROOT / 'app/src/main/java/com/majdoor/hisaabpro/AccountingMath.kt').read_text(encoding='utf-8'),
    'balance breakdown retains old credit as advance': 'creditRemaining = max(0.0, oldCredit - safeCurrentWages)' in (ROOT / 'app/src/main/java/com/majdoor/hisaabpro/AccountingMath.kt').read_text(encoding='utf-8'),
    'worker profile shows old/current/total due and advance': 'balanceBreakdown.oldDue' in s and 'balanceBreakdown.currentDue' in s and 'balanceBreakdown.totalOutstanding' in s and 'balanceBreakdown.advance' in s,
    'worker ledger PDF shows old/current/total due and advance': 'balance.totalOutstanding' in s and 'पुराना बाकी' in s and 'चालू बाकी' in s and 'एडवांस' in s,
    'attendance calendar PDF uses all monthly rows including absences': 'val dayGroups=allMonthRows.groupBy{it.date}' in s,
    'attendance PDF marks absent rows explicitly': 'भांजी (नहीं आया)' in s,
    'attendance PDF worker count includes all recorded rows': 'days.flatMap{it.second.map{a->a.labourId}}.distinct().size' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
print(f'RESULT {sum(checks.values())}/{len(checks)} PASS')
assert all(checks.values())

# Verify the allocation math for common old-debt, old-credit, and overpayment scenarios.
def calc(old_wage, old_paid, current_wages, current_payments):
    closed_net = old_wage - old_paid
    old_due = max(0, closed_net)
    old_credit = max(0, -closed_net)
    to_old = min(old_due, current_payments)
    old_remaining = max(0, old_due - to_old)
    for_current = max(0, current_payments - to_old)
    wage_after_credit = max(0, current_wages - old_credit)
    current_due = max(0, wage_after_credit - for_current)
    credit_remaining = max(0, old_credit - current_wages)
    advance = credit_remaining + max(0, for_current - wage_after_credit)
    return old_remaining, current_due, advance, old_remaining + current_due

math_cases = [
    ((1000, 0, 500, 700), (300, 500, 0, 800)),
    ((1000, 0, 500, 1200), (0, 300, 0, 300)),
    ((1000, 0, 500, 1700), (0, 0, 200, 0)),
    ((0, 1000, 500, 0), (0, 0, 500, 0)),
    ((0, 1000, 500, 100), (0, 0, 600, 0)),
    ((0, 0, 500, 700), (0, 0, 200, 0)),
]
for i, (args, expected) in enumerate(math_cases, 1):
    actual = calc(*args)
    ok = actual == expected
    print(('PASS' if ok else 'FAIL') + f' | balance calculation case {i}: {actual}')
    assert ok
# Locked-month debt is combined with prior closure debt before applying later open-month payments.
locked_old_net = (800 - 200)
locked_case = calc(locked_old_net, 0, 500, 700)
assert locked_case == (0, 400, 0, 400), locked_case
print(f'PASS | locked-month debt settlement case: {locked_case}')
print(f'MATH RESULT {len(math_cases)+1}/{len(math_cases)+1} PASS')

if TRACKER.exists():
    with TRACKER.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    ids = [r['ID'] for r in rows]
    assert len(ids) == 135 and len(set(ids)) == 135
    print('PASS | tracker retains 135 unique screen IDs')
