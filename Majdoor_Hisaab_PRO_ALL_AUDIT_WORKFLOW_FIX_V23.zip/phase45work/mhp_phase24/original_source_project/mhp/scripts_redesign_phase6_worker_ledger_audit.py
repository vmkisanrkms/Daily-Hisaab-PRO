from pathlib import Path
import csv
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
tracker=root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
s=src.read_text(encoding='utf-8')
checks={
 'worker detail query state survives recreation':'rememberSaveable(id) { mutableStateOf("") }' in s,
 'worker ledger query searches date/field/crop':'displayDate(a.date).lowercase(Locale.ROOT).contains(q) || fieldName.lowercase(Locale.ROOT).contains(q) || cropName.lowercase(Locale.ROOT).contains(q)' in s,
 'worker ledger status filter supports full day':'"पूरा दिन" -> a.fraction == 1.0' in s,
 'worker ledger status filter supports half day':'"आधा दिन" -> a.fraction == 0.5' in s,
 'worker ledger status filter supports absent':'"भांजी/Absent" -> a.fraction == 0.0' in s,
 'worker payments filter searches amount':'money(p.amount).contains(q)' in s,
 'worker ledger empty state exists':'इस खोज/फ़िल्टर में कोई रिकॉर्ड नहीं मिला।' in s,
 'monthly account query state exists':'var monthWorkerQuery by rememberSaveable' in s,
 'monthly account searches worker name/mobile/address':'r.labour.name.contains(monthWorkerQuery.trim(), ignoreCase=true) || r.labour.mobile.contains(monthWorkerQuery.trim(), ignoreCase=true) || r.labour.address.contains(monthWorkerQuery.trim(), ignoreCase=true)' in s,
 'monthly account summary includes full/half/absent':'monthFullDays = monthAttendance.count { it.fraction == 1.0 }' in s and 'monthHalfDays = monthAttendance.count { it.fraction == 0.5 }' in s and 'monthAbsents = monthAttendance.count { it.fraction == 0.0 }' in s,
 'month lock/unlock controls retained':'store.setLabourMonthLocked(month,month !in store.lockedLabourMonths)' in s,
 'worker PDF ledger export retained':'exportWorkerLedgerPdf(context,l,store,attendanceRows,paymentRows,wage,paid,background=true)' in s,
 'worker payment edit/delete actions retained':'PaymentDialog(store, id, item.fieldId, item.cropId' in s and 'delPay = p' in s,
 'attendance delete action retained':'delAttendance=a' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'SUMMARY {sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
rows=list(csv.DictReader(open(tracker,encoding='utf-8-sig')))
assert len(rows)==135 and len({r['ID'] for r in rows})==135
print('PASS | tracker has exactly 135 unique screen IDs')
