# Phase 17 — Accounting Integrity and Reconciliation Fixes

**Date:** 11 October 2026  
**Base:** Phase 16 Settings & Security source ZIP  
**Scope:** Fields/Crops relational integrity, expense/sale Store validation, payment edit/delete and month locks, old debt/advance allocation, attendance calendar/PDF reconciliation.

## Fixes applied

1. **Crop/field consistency:** changing a crop's parent field is rejected when attendance, expense, sale or payment history references that crop. Crop create/update also checks field existence and duplicate names.
2. **Store-level expense and sale validation:** add/update/delete methods validate record IDs; dates; field/crop ownership; positive, finite amounts, quantities and rates. Sale totals are recomputed in Store as `quantity × rate`, not trusted from a caller.
3. **Payment integrity and lock protection:** create/edit/delete validate the worker, ID, amount/date and field/crop relation. Editing cannot transfer a payment to another worker. Both the existing and destination payment dates are checked against closed-through dates and locked months. Later payments on an open date remain allowed to settle old debt.
4. **Old balance and advance allocation:** a shared balance breakdown calculates old outstanding, current outstanding, total outstanding and advance. Locked-month records are treated as finalized old debt/credit, excluding dates already covered by a later closure. Later open-month payments are applied to old outstanding first; old credit/overpayment is carried forward instead of hidden as a negative balance.
5. **Worker ledger PDF:** the green-and-white ledger summary now includes old due, current due, total due and advance in addition to current-period wage/payment totals.
6. **Attendance calendar/PDF parity:** the calendar's monthly PDF now receives all saved rows, including `fraction == 0` absent records, so PDF record count/details can reconcile with the calendar. Absences contribute zero wages.
7. **Legacy relational warnings:** field and crop detail screens now warn if existing records contain a missing or mismatched crop/field link. Such records are not silently migrated or dropped.
8. **Progress tracker:** affected screen IDs updated; device and Android PDF tests remain honestly marked `NOT TESTED`.

## Verification

- Phase 17 static source assertions: **24/24 PASS**.
- Balance allocation math cases: **7/7 PASS** (old due, partial settlement, full settlement, overpayment, old credit and advance).
- Existing regression audits: Phase 5 **14/14**, Phase 6 **14/14 + tracker**, Phase 7 **17/17 + tracker**, Phase 12 **18/18**, Phase 13 **20/20**, Phase 14 **20/20**, Phase 15 **15/15**, Phase 16 **21/21**, report filters **16/16**. Phase 2 audit assertions were updated to reflect the new shared balance helper and then rerun separately.
- Android build/runtime: **NOT TESTED**. The source ZIP lacks `gradle-wrapper.jar`; a device build, payment edit/delete workflow, backup/restore, and PDF rendering/share still require a successful Android build and phone test.

## Important behavior

- A payment dated inside a locked month cannot be created, edited or deleted.
- A later payment dated in an open month can be recorded and allocated against historical debt without editing locked month rows.
- If existing legacy records have inconsistent field/crop IDs, a warning is shown for inspection; records are preserved, not guessed into another field.
