# Salary Module V21 Audit / Fix Report

## Scope
Home -> Salary Dashboard -> Employee List -> Employee Detail -> Attendance -> Leave/Bhanji -> Payment/Advance -> Salary Editor -> Date Range Report/PDF -> Backup/Restore.

## Changes in V21
- Fixed an undefined `$absent` interpolation in `SalaryEmployeeDetailScreen` which would prevent Kotlin compilation.
- Added explicit present, absent, leave, and unmarked day counters to Employee Detail.
- Unmarked days are counted only within the employee's eligible month window (from joining date through month end).
- Employee Detail now displays overpayment separately instead of silently showing only a zero balance when payments exceed earned wages.
- Added a dedicated regression audit script and wired it into GitHub Actions.
- No Ganna Chhilayi or Ganna Parchi source was changed.

## Verified checks
- Salary full module static audit: 21/21
- Salary data integrity static audit: 9/9
- Salary V10 static audit: 14/14
- Salary quick actions static audit: 10/10
- V21 detail regression audit: 5/5
- Workflow YAML parses successfully.

## Not verified
- Android Gradle/Kotlin compilation was not completed in this environment.
- Signed Release APK build and install were not run.
- Real-device Salary flows, PDF rendering, and Backup/Restore were not runtime-tested.

Static checks do not replace compilation or real-device testing.
