#!/usr/bin/env python3
"""Static audit for Phase 16 O01-O09 settings and security controls."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER=ROOT.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
s=SRC.read_text(encoding='utf-8')
checks={
 'settings preferences namespace exists':'mhpro_settings_v1' in s,
 'profile name persists':'profile_name' in s and 'खाता / खेत का नाम' in s,
 'theme selection persists': 'onThemeModeChange(value)' in s and 'THEME_KEY' in s,
 'app lock preference defaults secure':'settingBool(context, "app_lock_enabled", true)' in s,
 'app lock can be controlled from settings':'saveSetting(context,"app_lock_enabled",it)' in s,
 'sensitive device credential gate remains present':'DeviceCredentialGate("इस रिकॉर्ड' in s or 'DeviceCredentialGate(title,message,onUnlocked,onCancel)' in s,
 'biometric preference persisted':'saveSetting(context,"biometric_enabled",it)' in s,
 'biometric gate respects preference':'settingBool(context, "biometric_enabled", true) && android.os.Build.VERSION.SDK_INT >= 28' in s,
 'timeout choices include immediate and durations':'"immediate" to "तुरंत"' in s and '"1m" to "1 मिनट"' in s and '"5m" to "5 मिनट"' in s and '"15m" to "15 मिनट"' in s and '"30m" to "30 मिनट"' in s and '"never" to "कभी नहीं"' in s,
 'background auto-lock lifecycle observer':'LifecycleEventObserver' in s and 'Lifecycle.Event.ON_STOP' in s and 'Lifecycle.Event.ON_START' in s,
 'notification preference persisted':'saveSetting(context,"notifications_enabled",it)' in s,
 'report summary preference persisted':'saveSetting(context,"report_summary_enabled",it)' in s,
 'report wage preference persisted':'saveSetting(context,"report_wages_enabled",it)' in s,
 'report payment preference persisted':'saveSetting(context,"report_payments_enabled",it)' in s,
 'backup settings links to existing backup screen':'onClick=onBackup' in s and 'Backup & Restore खोलें' in s,
 'backup preference persisted':'saveSetting(context,"backup_reminder_enabled",it)' in s,
 'about screen shows app version':'BuildConfig.VERSION_NAME' in s and 'BuildConfig.VERSION_CODE' in s and 'context.packageName' in s,
 'settings switch is interactive':'Switch(checked=checked,onCheckedChange=onChange)' in s,
 'existing report centre route preserved':'onNavigate("reports")' in s,
 'existing cane peeling route preserved':'onNavigate("cane_peeling")' in s,
 'existing cane parchi route preserved':'onNavigate("cane")' in s,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
rows=list(csv.DictReader(TRACKER.open(encoding='utf-8-sig',newline='')))
expected={f'O{i:02d}' for i in range(1,10)}
ids={r['ID'] for r in rows}
if not expected <= ids: raise SystemExit('FAIL | O01-O09 tracker rows missing')
print('PASS | O01-O09 tracker rows exist')
