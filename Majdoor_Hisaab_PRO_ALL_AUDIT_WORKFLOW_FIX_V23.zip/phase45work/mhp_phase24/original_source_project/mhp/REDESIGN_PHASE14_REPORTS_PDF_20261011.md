# Phase 14 — Reports and PDF screens (2026-10-11)

## Scope
- K01 Report Centre: added a dedicated report centre entry on the dashboard and profile, with navigation to labour reports, attendance, work/wages, and profitability.
- K02 Report Type Selection: added selectable report categories for labour/payments, attendance, work/wages, expenses, sales, and profitability.
- K03 Date Range: retained inclusive start/end date filters and reversed/invalid date guard.
- K04 Worker/Field/Crop Selection: retained independent filters and applied them to both attendance and payment records; fixed the all-workers toggle to clear the correct selected-worker list.
- K05 PDF Preview: added an in-app pre-export preview of the selected date range, worker/field/crop scope, summary totals, attendance rows and payment rows. PDF generation uses the same filtered record lists displayed in the preview.

## Static verification
- Phase 14 report/PDF audit: 20/20 checks passed.
- Existing Phase 2, 4, 5, 6, 7, 8, 9, 11, 12, 13 audits and K03/K04 report audit run after changes.
- Android compilation, APK build, installation, and device-level visual/PDF-share tests are not verified in this environment.
