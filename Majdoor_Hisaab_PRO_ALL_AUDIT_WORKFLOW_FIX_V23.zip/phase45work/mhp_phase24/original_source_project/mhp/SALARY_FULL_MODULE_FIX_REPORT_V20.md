# Salary Full Module Fix Report — V20

Scope: Salary Employee module only. Ganna Chhilayi and Ganna Parchi source logic was not intentionally changed.

## Changes
- Added one canonical salary-earned calculation used by Dashboard, Employee List, Employee Detail, salary editor preview, and date-range report.
- Salary accrues only for explicitly marked `उपस्थित` days; absent, leave, and unmarked days accrue zero.
- Salary is prorated by calendar days in the month and attendance before Joining Date is excluded.
- Quick attendance, holiday/leave, and payment entries reject dates before Joining Date.
- Duplicate nonblank mobile-number check added; same-name employees remain allowed.
- Employee `role` is preserved when editing and serialized to preferences (previous save omitted it).
- Updated the existing quick-action audit and added a focused Salary full-module static audit.
- Updated workflow to select this V20 ZIP and run the new audit; app version is 1.84.0 / 84.

## Validation limits
Static source audits are not a substitute for Kotlin compilation, APK signing, or real-device UI/backup/restore tests. Those must be confirmed by GitHub Actions and a phone test before release.
