# Salary Employee Module V7 — Changes

- Added employee create, edit, and delete actions in the separate Salary Employee module.
- Removed role/designation field from the employee form and visible employee cards.
- Added monthly salary editing while retaining employee ID and month-specific accounting records.
- Added date-wise attendance entry for Present, Absent, and Leave.
- Added optional note for every date; leave note can capture why/where the employee went.
- Added date-wise record edit/delete within the selected month.
- Monthly salary deduction is calculated from recorded absent days divided by calendar days in the selected month. If no daily records exist for a legacy month, the previous absent-day count remains supported.
- Advance, paid amount, salary earned, deduction and remaining balance remain in the salary-only preferences store, separate from labour/cane modules.
- No changes intentionally made to Daily Labour, Ganna Chhilai, or Ganna Parchi source sections.

Build note: Kotlin compile was attempted but could not run because the environment could not download the Gradle wrapper from the network. Please validate via GitHub Actions before installing the APK.
