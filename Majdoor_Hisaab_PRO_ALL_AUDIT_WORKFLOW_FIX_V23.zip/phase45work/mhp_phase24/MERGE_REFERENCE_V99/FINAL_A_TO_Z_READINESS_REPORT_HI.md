# Majdoor Hisaab PRO — Final A-to-Z Package Status (V83)

Date: 11 October 2026

## Included in this package
- Existing Kotlin/Jetpack Compose Android project and package ID `com.majdoor.hisaabpro`.
- UI polish on Dashboard and Labour list: Hindi-first labels, compact daily summary, primary attendance action, module cards, worker search, empty state, worker counts, and clearer worker rows.
- Four-tab bottom navigation (Home, Labour, Fields, More) and a secondary More screen for reports, attendance history, expenses, sales, crops, Ganna Chhilai, Ganna Parchi, backup and settings.
- Existing local-first data model and business logic retained; no Supabase/Firebase/cloud sync added.
- Existing Google Drive Backup/Restore and its consent retry handling retained. Internet permission remains because Drive is an explicit user-selected feature.
- Existing monthly labour locks, payment ledger/reporting, selected date/field report filtering, Fandi/Ganna Chhilai and Ganna Parchi modules retained.
- Release workflow bumped to version 1.83.0 / versionCode 83; checks package ID, release signature and APK alignment; attempts to bootstrap a missing Gradle wrapper JAR.
- Four targeted audit scripts and the project documentation.

## Verification performed in this environment
- Daily Labour / navigation source audit: **27/27 PASS**.
- Date/field report audit: **11/11 PASS**.
- Google Drive NeedRemoteConsent static audit: **11/11 PASS**.
- Selected report / sale persistence audit: **16/16 PASS**.
- Kotlin source parser scan: no Kotlin syntax/`expecting` errors found; full compilation was not possible because Android/Compose dependencies are unavailable here.
- ZIP integrity check: performed when package was assembled.

## Not verified — do not treat these as passed
- Android Gradle compile and Release APK assembly were **not run successfully** in this environment. The source checkout lacks `gradle-wrapper.jar` and the environment cannot reach the Gradle download host.
- Real Android installation, upgrade from the previous APK, Google sign-in/Drive backup and restore, PDF rendering/share, and device-specific navigation were **not runtime-tested here**.
- The GitHub Actions workflow is included to run those build checks in GitHub. It requires the repository secrets `RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD` for a signed Release APK.

## Critical preservation rules
- Do not replace or migrate the user's existing local app data as part of this UI update.
- Do not alter Ganna Chhilai / Fandi calculations, single-worker entry behavior, rate persistence, or Ganna Parchi records while applying visual changes.
- Do not add mandatory login, Supabase, Firebase, or automatic cloud sync.
- Locked months remain readable and must not have finalized attendance recalculated by later entries.

This is the complete source/workflow package prepared in this session, not a claim that a signed APK was built or device-tested in this environment.


## V84 navigation fixes
- Dashboard worker shortcut routes to the worker list; attendance shortcut routes to Daily Labour home.
- Unknown Dashboard route keys now fall back to More rather than Crop List.
- Daily Labour Accounts field-wise report shortcut now opens the report centre.
- More includes worker list, monthly accounts/locks, date-field report and field management shortcuts.
- Added `scripts_v84_navigation_regression.py`; these are static checks only.
- Android Gradle build and device runtime remain unverified in this environment.


## V85 follow-up (11 Oct 2026)
Dashboard quick actions, grouped More menu, bottom navigation selected state, Android instrumentation smoke test and API 35 emulator CI wiring were added. These are incremental UI/runtime-test improvements, not proof that all screens are fully redesigned. CI must run successfully before marking emulator or Release APK as PASS. See `V85_REDESIGN_AND_RUNTIME_TEST_AUDIT_HI.md`.
