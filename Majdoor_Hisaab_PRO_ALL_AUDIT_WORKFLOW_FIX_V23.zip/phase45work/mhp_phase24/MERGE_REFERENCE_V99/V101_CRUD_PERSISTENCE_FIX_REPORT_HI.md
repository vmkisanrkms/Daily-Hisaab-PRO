# V101 — CRUD persistence hardening (11 अक्टूबर 2026)

## इस pass में वास्तविक source बदलाव

SharedPreferences में candidate data पहले synchronous `commit()` से persist होता है; commit विफल हो तो method `false` लौटाता है और नया candidate in-memory state में publish नहीं होता।

- Worker add/edit: worker record और changed wage-rate history एक editor commit में persist.
- Worker active/deactivate status: persist-first.
- Fandi labour add/edit/delete: persist-first.
- Field add/edit: persist-first; field add में field data और ordering metadata एक atomic editor commit में.
- Crop add/edit/delete: persist-first.
- Expense add/edit: persist-first (delete पहले से commit-first था).
- Sale add/edit: persist-first (delete पहले से commit-first था).
- Payment add/edit/delete: persist-first; existing locked-month/closed-account guards बरकरार.
- नया `scripts_v101_crud_persist_first_audit.py`: 19/19 PASS.

## Regression

- सभी existing static audit scripts (release-package gate को छोड़कर) project root से चलाए गए; वे पास हुए। Release-package gate ने सही रूप से block किया क्योंकि 96 points के लिए runtime evidence उपलब्ध नहीं है।
- Python audit scripts compile हुए।
- ZIP integrity और source tree की मौजूदगी अलग से verify की गई।

## ईमानदार सीमा

यह incremental source fix है; यह दावा नहीं है कि A–N या सभी 96 points पूरे हो गए हैं। Gradle wrapper JAR मौजूद नहीं है, इसलिए इस environment में Kotlin/Android Release build नहीं चलाया गया। Android emulator/physical-device runtime, Google Drive round-trip, PDF visual verification और Ganna Chhilayi/Parchi regression अभी आवश्यक हैं।
