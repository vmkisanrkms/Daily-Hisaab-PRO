# गन्ना छिलाई UI re-audit — V94 source pass

## Source changes
- गन्ना छिलाई Home पर केवल एक rate-change dialog/control रखा; फांदी मजदूर सूची का दूसरा editable rate panel हटाया।
- मजदूर जोड़ने वाले profile form से `आज की फांदी भी साथ में सेव करें` combined workflow हटाया।
- अब मजदूर profile save और एक मजदूर की दैनिक फांदी entry अलग-अलग actions हैं।
- नाम required; normalized duplicate name रोकना जारी है। मोबाइल, पता और फोटो वैकल्पिक हैं।
- खेत optional रहता है; single-entry form में duplicate worker + date + field record रोका जाता है।
- Existing Fandi workers, rates, peeling rows, payment rows, and backup logic were not deleted or migrated by this UI-only patch.

## Verification
- `scripts_v94_fandi_ui_regression.py`: static source regression gate added to GitHub Actions.
- Android compile, emulator, physical device, and actual backup/restore round-trip have **not** been run in this local environment; those gates remain pending.
