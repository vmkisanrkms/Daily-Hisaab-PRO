# K10 CSV Unicode-prefix hardening — 2026-10-11

## Source change
- Shared `csvCell()` sanitizer now checks past leading whitespace, BOM (`U+FEFF`), and zero-width format characters (`U+200B`–`U+200D`) when detecting formula-like prefixes (`=`, `+`, `-`, `@`).
- Explicitly handles a leading line-feed in addition to tab and carriage return.
- Original cell content remains preserved after adding a leading apostrophe text marker; normal CSV quote escaping remains in place.
- Runtime core-store regression assertions now cover BOM, zero-width-space, newline, common formula prefixes, quoting, and ordinary numeric values.

## Verification
- CSV sanitizer static audit: 13/13 PASS.
- Other static source audit scripts: PASS (release-packaging gate intentionally excluded because it must fail until all 96 points have runtime evidence).
- GitHub Actions YAML parse: PASS.
- Android compile/emulator/device verification: NOT RUN in this environment; do not mark runtime as verified.
