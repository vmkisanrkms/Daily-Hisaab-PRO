# Majdoor Hisaab PRO — V95 Security Lifecycle Fix Audit

## Source fix
- `appUnlocked` now uses non-saveable Compose state initialized to `false`.
- The previously saveable state could be restored from Activity saved state; a recreated Activity/process might otherwise expose accounting screens without repeating the device credential gate.
- Navigation route state remains saveable, but the security-unlocked flag is not.

## Verification run
- `scripts_v95_security_lifecycle_audit.py`: 4/4 PASS
- `scripts_v92_selected_audit_fixes.py`: 73/73 PASS
- `scripts_v93_96_point_source_trace.py`: 96/96 source traces found
- `scripts_v93_locked_month_payment_audit.py`: 42/42 PASS
- `scripts_v94_fandi_ui_regression.py`: 11/11 PASS
- All Python audit scripts compile; Android XML resources parse.

## Not claimed as complete
- The Gradle build could not run in this workspace: the wrapper JAR is absent and network access to `raw.githubusercontent.com` is unavailable.
- Emulator instrumentation, physical-device lock/auto-lock tests, real Google Drive account backup/restore, PDF visual review, offline restart/rotation, and signed APK verification remain pending.
- The final packaging gate must remain closed until all 96 checklist items and required runtime evidence are verified.
