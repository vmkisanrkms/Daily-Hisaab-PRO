# Majdoor Hisaab PRO V94 — Recheck Report (2026-10-11)

## Changes made in this pass
- Removed the second editable Fandi-rate panel from the Fandi worker list; the rate editor remains on the Ganna Chhilayi home screen.
- Removed the optional “आज की फांदी भी साथ में सेव करें” combined workflow from the Fandi worker profile form. Worker profile save and one-worker daily Fandi entry are now separate actions.
- Kept worker name required, duplicate normalized name/mobile checks, optional address/mobile/photo, optional field on daily entry, and duplicate worker/date/field protection.
- Bumped Android app version to 1.94.0 (versionCode 94), aligned the Release APK name/workflow and fail-closed package gate to V94.
- Added `scripts_v94_fandi_ui_regression.py` to the GitHub Actions audit sequence and updated the 96-point tracker copy to V94.
- Corrected a stale dashboard audit assertion that expected “आज का भुगतान” while the UI correctly says “आज का भुगतान/अग्रिम”.

## Source/static verification results
- 96/96 requested point source traces found. This verifies source markers, not full feature behavior.
- 73/73 source assertions passed in the selected audit suite.
- 42/42 locked-month/payment and adjacent data-integrity assertions passed.
- 11/11 new Fandi UI regression assertions passed.
- Other focused suites passed: Daily Labour 30/30; date/field report 11/11; report selection 16/16; navigation 10/10; data integrity 62/62; restore atomicity 23/23; CRUD feedback 14/14.
- All 7 Android XML files parse, and all 12 workflow-referenced audit scripts exist.

## Not yet verified — do not mark these as fully fixed
- Local Gradle build could not start because `gradle/wrapper/gradle-wrapper.jar` is absent and this environment cannot resolve/download `raw.githubusercontent.com`.
- No Android SDK/emulator/ADB is available in this workspace; no real emulator/physical-device UI test was run.
- Google Drive live backup/restore round-trip and visual PDF inspection were not run.
- The 96-point checklist intentionally retains all 96 `Fully fixed + Android runtime verified` boxes unchecked. The final-package script therefore correctly refuses to create a final ZIP.

## Release decision
**NOT FINAL / NOT READY TO SHIP.** Source/static audit is improved, but release is blocked until GitHub Actions builds and signs V94, emulator tests pass, and remaining device/Drive/PDF gates have evidence. Existing data and Ganna modules were not intentionally reset or migrated by this UI-only patch.
