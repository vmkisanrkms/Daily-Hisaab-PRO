# Majdoor Hisaab PRO V85 — UI redesign और Android runtime test audit

## V85 में किए गए source changes
1. Dashboard पर त्वरित काम की अलग पंक्ति: मजदूर, हाजिरी और बैकअप। सभी बटन मौजूदा routes पर जाते हैं।
2. More स्क्रीन को मजदूरी/हिसाब, खेत/फसल, गन्ना मॉड्यूल और डेटा/सेटिंग्स समूहों में बाँटा।
3. Bottom navigation में selected tab का स्पष्ट background और बड़ा tap target।
4. सभी shared top bars में एक जैसा green gradient, consistent spacing और bold title hierarchy।
5. Shared section headers और action cards को समान padding, icon और elevation styling दी।
6. Android instrumentation tests जोड़े: unsecured emulator पर Android Screen Lock requirement और isolated local-store regression scenarios (worker duplicate, attendance upsert/month lock, locked-month settlement payment, cane-peeling duplicate, persistence, backup ZIP validation)।
7. GitHub Actions में API 35 emulator पर `connectedDebugAndroidTest` चलाने का चरण जोड़ा।
8. Version 1.85.0 / versionCode 85।

## क्या प्रमाणित है
- Source audit script के PASS परिणाम केवल आवश्यक wiring और UI structure की मौजूदगी बताते हैं।
- Emulator test और Release build CI में configured हैं, पर workflow run हुए बिना इन्हें PASS नहीं कहा जा सकता।
- Runtime suite app launch/security gate और local-store regression scenarios जाँचती है; Google Drive account, PDF share UI और सभी screens की पूर्ण end-to-end testing का विकल्प नहीं है।

## अभी बाकी वास्तविक सत्यापन
- GitHub Actions में सफल emulator test और signed Release build।
- असली Android फोन पर मजदूर जोड़ना, हाजिरी, भुगतान, monthly lock/settlement, PDF/CSV export, Google Drive upload/download/restore, offline/restart/rotation/Back navigation।
- पूरे app की हर screen का visual review और feature-preservation regression।

पुराने डेटा, Google Drive integration, monthly lock, Ganna Chhilai/Fandi और Ganna Parchi के business logic को बदलने का उद्देश्य नहीं था। इस package को पूर्ण production-ready न माना जाए जब तक CI और device regression pass न हों।

## Screen coverage tracker
`SCREEN_PROGRESS_TRACKER.csv` को V85 के touched navigation/quick-action rows के लिए अपडेट किया गया है। बाकी screens को complete नहीं माना गया; वे अपने पुराने status पर ही हैं।
