# Majdoor Hisaab PRO — V101 source patch

यह ZIP नवीनतम V100 source patch पर आधारित incremental patch है। मुख्य बदलाव और सीमा `V101_CRUD_PERSISTENCE_FIX_REPORT_HI.md` में हैं।

- Worker, Fandi, Field, Crop, Expense, Sale और Payment के कई add/edit/delete flows अब पहले candidate state persist करते हैं और सफल commit के बाद ही in-memory state बदलते हैं।
- Month lock, old outstanding balance protections, backup/restore code और Ganna modules को हटाया या redesign नहीं किया गया।
- सभी 96 features को fixed या runtime-verified न मानें। Release package gate के लिए actual Android runtime evidence जरूरी है।
