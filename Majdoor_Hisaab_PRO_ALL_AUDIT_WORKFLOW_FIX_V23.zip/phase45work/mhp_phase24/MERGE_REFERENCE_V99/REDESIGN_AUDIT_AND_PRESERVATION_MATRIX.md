# Majdoor Hisaab PRO — UI/UX Redesign Audit & Preservation Matrix

## Source baseline
- Package: `com.majdoor.hisaabpro`
- Version at baseline: `1.82.0` / versionCode `82`
- UI implementation currently concentrated in `MainActivity.kt`.
- Local persistence uses Android `SharedPreferences` with JSON-backed records and local photo files.
- Google Drive integration uses Google Sign-In + `drive.file` scope and direct Drive API calls.
- Existing GitHub workflow referenced a separately named ZIP that does not match this uploaded project. Workflow updated to build the checked-out project directly.

## Explicit preservation rules
- Keep all existing record models and stable IDs unless a separately audited migration is proven necessary.
- Do not change wage, attendance, payment, closure/locked-month, crop costing, sale, cane peeling or cane parchi business logic as a side effect of visual changes.
- Daily Labour may use shared UI components; Ganna Chhilayi and Ganna Parchi workflows/calculations must not be altered without a separate, explicit module audit.
- Daily local operations remain offline-capable. Preserve existing Google Drive backup/restore; no new Supabase, Firebase or cloud-sync dependency.
- No claim of device/runtime verification unless it is actually performed.

## Feature preservation matrix
| Existing feature | Required preservation | Current verification status |
|---|---|---|
| Dashboard and quick navigation | Use real saved records; no dummy metrics | Static source review only |
| Workers, unique IDs, worker detail | CRUD, identity, history and ledger stay connected | Not fully tested |
| Daily Labour attendance | Present/Absent/Half-day rules, bulk actions, saved history | Existing targeted script available; runtime not tested |
| Locked/closed labour periods | Prevent attendance from changing finalized accounting; allow later settlement payments | Static review only |
| Payments, advances and balances | Keep payment history separate from attendance/work records | Not fully tested |
| Fields and crops | Preserve field/crop relations and optional-field workflows where applicable | Not fully tested |
| Expenses and crop sales | Preserve amounts, totals, dates, and profitability inputs | Targeted report/sale checks available |
| Reports, worker selection, PDF/CSV | Selected rows only; accurate totals and payment/date fields | Existing report scripts require rerun and review |
| Backup/restore | Validate archive before restore; confirmation; retain Google Drive account/consent flow | Static source review only |
| PIN/device credential gate | Preserve existing security gate | Not runtime tested |
| Ganna Chhilai | Keep fandi rate, single-entry and payment workflows intact | No business-logic changes made in this pass |
| Ganna Parchi | Keep parchi, weight, rate, season and worker selection intact | No business-logic changes made in this pass |
| Android release workflow | Compile, sign, package, align and verify APK | Workflow source updated; GitHub run not yet executed |

## Screen inventory from current navigation model
Home Dashboard; Daily Labour Home; Daily Labour Accounts; All Labour Report; Worker List; Worker Detail; Attendance Field Picker; Attendance Entry; Attendance History; Today Attendance; Field List; Field Detail; Crop List; Crop Detail; Expense List; Sale List; Backup/Restore; Profile/Settings; Ganna Parchi; Ganna Chhilai.

## Changes in this pass
1. Shared top app bar now shows a context-specific title and subtitle instead of repeating the app name on every screen.
2. Release workflow now builds the repository project directly rather than requiring an unrelated ZIP filename in the repository root.
3. Added this preservation matrix so future UI changes can be reviewed against existing modules.

## Known gaps — do not mark as PASS
- Full per-control end-to-end test matrix remains to be executed.
- Report-selection audit script and date/field report checks need investigation where they fail.
- Build has not been run in GitHub Actions after workflow changes.
- No physical Android device test has been performed for restart, rotation, font scaling, offline use, backup/restore, or navigation/back behavior.
- This is an incremental redesign pass, not a claim that every screen has already been redesigned.
