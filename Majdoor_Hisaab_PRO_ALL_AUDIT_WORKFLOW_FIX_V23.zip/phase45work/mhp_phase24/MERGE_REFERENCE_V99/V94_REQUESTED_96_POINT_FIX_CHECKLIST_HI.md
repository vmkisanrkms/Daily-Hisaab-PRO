# Majdoor Hisaab PRO — 96-point audit checklist (V96 calendar pass)

**नियम:** Source fix/static PASS को Android runtime verification न मानें। Runtime evidence मिलने तक सभी “Fully fixed + Android runtime verified” खाने unchecked रहेंगे।

| ID | Point | Source trace | Static check | Source fix | Runtime verified | Status | Evidence / next action |
|---|---|---:|---:|---:|---:|---|---|
| A01 | App Launch / Loading | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added branded Android splash theme and installSplashScreen call; cold-start runtime check pending. |
| A04 | Existing Data Initialization | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added guarded JSON loading and raw recovery-copy preservation. |
| A05 | Offline / Error State | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Local-first indicator and data/Drive error messages exist; airplane-mode device test pending. |
| A06 | Theme Selection | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added persistent Light/Dark/System theme selection. |
| B01 | Main Dashboard | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Dashboard source exists; visual/device review pending. |
| B02 | Today's Attendance Summary | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Today attendance summary is calculated from local records. |
| B03 | Today's Wages and Payments | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added today payment total beside wage/expense/sales. |
| B04 | Outstanding Balance | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Dashboard now includes reconciled total outstanding balance; runtime reconciliation pending. |
| B05 | Recent Work/Payment Records | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Dashboard recent payments “सभी देखें” now opens a searchable global payment history with worker/date/amount filters and opens worker ledger on tap. Emulator navigation test pending. |
| B06 | Quick Actions | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Dashboard quick actions exist; destination runtime test pending. |
| B07 | Field/Crop Summary | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added crop count beside worker/field counts. |
| C01 | Worker List | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Worker list screen exists; full CRUD runtime audit pending. |
| C04 | Worker Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Worker detail screen exists; runtime audit pending. |
| C05 | Attendance History | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Attendance history screen exists. |
| C06 | Work History | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Worker work history source exists; runtime audit pending. |
| C07 | Payment/Advance History | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Worker payment history source exists; runtime audit pending. V93 distinguishes payment vs advance, persists kind with legacy default, validates type, and shows type in history/reports. Android runtime pending. |
| C08 | Full Ledger | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Worker ledger PDF now shows reconciled total balance including carried closed balance; visual/runtime test pending. |
| C09 | Deactivate/Delete Safety | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Worker can be deactivated/reactivated without deleting history; inactive workers are hidden from attendance by default; hard-delete is allowed only without accounting history and removes unused rate metadata. Android UI test pending. |
| D01 | Daily Labour Home | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Daily Labour home source exists. |
| D02 | Monthly Account List | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V94 re-check: updatePayment now protects both the stored payment date/worker closure and proposed date; regressions added for moving locked/closed payments forward. Emulator execution pending. |
| D03 | Monthly Account Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Monthly details/closures source exists; runtime audit pending. |
| D07 | Daily Labour PDF | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | PDF balance summary updated to use reconciled current balance; visual/runtime test pending. |
| E02 | Date Selection | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Date change now clears bulk selection to prevent applying it to another date. |
| E04 | Present/Absent/Half-day | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Zero-fraction absence is now persisted and hidden from the default roster/list; device test pending. |
| E05 | Bulk Attendance Actions | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added select-workers bulk full-day attendance with confirmation and skip protection; runtime test pending. |
| E06 | Attendance Save/Edit | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V93: attendance supports blank field selection; V97 additionally rejects future attendance dates at Store boundary. Android runtime pending. |
| E07 | Calendar | ☑ | ☑ | ☑ | ☐ | Calendar source fix added; Android runtime pending | V96: Added Monday-first six-week calendar with bounded month navigation, per-day distinct-worker counts, selected-date worker/wage detail, and saveable calendar state. Static assertions 12/12 pass. Android UI runtime verification pending. |
| E08 | History | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Attendance history excludes zero-wage absence markers from the worked-attendance list. |
| E10 | Conflict Handling | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Conflict guard now rejects marking absent when same worker already has positive attendance on another field that day. |
| F01 | Work Entry | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Attendance-based work entry exists. |
| F02 | Work List/Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Work history/detail source exists. |
| F03 | Wage Rate History | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Wage rate history functions exist. |
| F08 | Outstanding Balance | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added balance reconciliation that carries latest closed balance and subtracts later payments; runtime test pending. |
| G03 | Field Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Field detail source exists. |
| G05 | Field Reports | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Field report/export source exists. |
| H03 | Crop Detail | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Crop field cannot be reassigned after expenses/sales/attendance/payments are linked; regression assertion added. Verify crop edit on emulator. |
| H04 | Crop Expenses | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Crop/field expense screens exist. |
| H05 | Crop Sales | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Crop/field sales screens exist. |
| I01 | Expense List | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V93: expense form now offers optional field/crop and storage/runtime regression covers blank field. Runtime pending. |
| I04 | Expense Detail/History | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Expense edit/history source exists. |
| I05 | Cost Summary | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Cost summary calculations exist. |
| J01 | Sales List | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V93: sale form now offers optional field/crop and storage/runtime regression covers blank field. Runtime pending. |
| J03 | Sale Detail/Delete | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Sale edit/delete source exists. |
| J04 | Revenue/Profitability | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Profitability calculations exist. |
| K01 | Report Centre | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Report centre source exists. |
| K02 | Report Type | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Report choices exist; all report-type routing needs runtime audit. |
| K03 | Date Range | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added report default-range behavior and retained manual date selection; runtime scenarios pending. |
| K04 | Worker/Field/Crop Selection | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Date/field/worker selections are now saveable across recreation; runtime tests pending. |
| K05 | Preview | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Selected report summary/preview exists; new default-range selection affects its input; runtime preview pending. |
| K06 | PDF Ledger | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | PDF ledger balance now includes carried closed balance; visual/runtime test pending. |
| K07 | CSV Export | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added selected-date/field general report CSV export; output verification pending. |
| K08 | Attendance PDF | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Attendance PDF exporter exists. |
| K09 | Worker Ledger PDF | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Worker ledger PDF exporter exists. |
| K10 | Export Result | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | File sharing/export flow exists. |
| K11 | Empty Result | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Empty-state text exists; screen coverage pending. |
| L01 | Ganna Chhilayi Dashboard | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V94 source pass: one Chhilai-home rate editor; worker-profile save separated from daily single-worker entry. Run emulator and real-device regressions. |
| L08 | Worker-wise Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Worker-wise detail source exists. |
| L11 | PDF/CSV | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Cane Chhilayi CSV now escapes quotes/commas through csvCell and writes UTF-8 BOM; runtime regression assertion added. Verify exported file on Android. |
| M01 | Parchi Dashboard | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Parchi dashboard exists. |
| M02 | Season Filter | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Fixed season validation so selecting ALL stays selected; added pure filter regression for all seasons and a single-season filter. Emulator UI test pending. |
| M04 | Parchi Detail | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Parchi detail exists. |
| M05 | Delete Safety | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Delete confirmation/guard requires runtime audit. |
| M06 | PDF/CSV | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | CSV export source exists; PDF coverage pending. |
| N01 | Backup Centre | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Backup centre exists. |
| N02 | Google Sign-in/Consent | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Consent flow exists; real-account test pending. |
| N03 | Google Drive Backup | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Drive backup/restore source exists; real account test pending. |
| N04 | Restore Selection | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Restore file selection exists. |
| N05 | Local Backup | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Local backup source exists; round-trip test pending. |
| N07 | Restore Confirmation | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Restore confirmation gate exists. |
| N09 | Import Validation | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Backup validation now rejects impossible dates and malformed locked-month keys before restore mutation; regression case added. Execute on Android emulator. |
| N10 | Backup Metadata/History | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Backup now carries recovery and backup-history metadata; runtime round-trip pending. |
| O01 | Settings/Profile | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Profile/settings screen exists. |
| O02 | Theme | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Added persistent theme settings. |
| O03 | App Lock | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V95 hardening: unlocked state uses non-saveable remember(false), so Activity/process recreation cannot restore an unlocked state. Emulator/device lock-gate test remains required. |
| O04 | Biometric | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Biometric prompt source exists; device testing pending. |
| O05 | Auto-lock | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Auto-lock settings/logic exists; lifecycle test pending. |
| O06 | Notification Settings | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added a daily attendance reminder setting; Android permission/schedule behavior still needs device testing. |
| O07 | Report Settings | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added persistent default report range: all dates or current month; runtime behavior pending. |
| O08 | Backup Settings | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Backup settings entry exists. |
| O09 | About/Version | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added About/version section showing app version and package; runtime pending. |
| P01 | Header/Back Navigation | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Navigation/back source exists; stack/lifecycle runtime test pending. |
| P02 | Buttons/Icons/Menus | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Controls/menu source exists; interaction audit pending. |
| P03 | Reusable Forms | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Reusable form dialogs exist. |
| P05 | Dialogs/Bottom Sheets | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Dialogs exist. |
| P06 | Loading/Empty/Error/Success | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added data-recovery warning; broader screen state coverage pending. |
| P07 | Delete/Replace Confirmation | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Confirmation patterns exist; every delete path audit pending. |
| P08 | Duplicate Operation Protection | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Duplicate guards exist; double-tap runtime test pending. |
| P09 | Responsive/Font Scaling | ☑ | ☑ | ☐ | ☐ | Source exists; full audit/runtime pending | Responsive Compose layouts exist; real font-scaling test pending. |
| P10 | Rotation/Lifecycle | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Lifecycle and some saveable state exist; rotation test pending. |
| Q01 | Feature Preservation Matrix | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V92 feature preservation matrix added with modules, boundaries and release gates; runtime evidence still pending. |
| Q03 | Ganna Regression Testing | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V93: runtime regression cases added for locked-month payment immutability, optional-field attendance/expense/sale, Fandi duplicate mobile and Store/backup attendance identity; emulator execution pending. V93 adds worker deactivate/reactivate, inactive attendance rejection and safe-delete regression checks. V93 adds payment-history route serialization/source trace. |
| Q05 | Offline Test | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Local storage/offline-first source exists; airplane-mode device test pending. |
| Q06 | Restart/Rotation Tests | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | Added Store recreation and route serialization regression assertions; Android runtime/rotation execution pending. V93 adds Android instrumentation test that recreates Activity and verifies lock gate survives; emulator execution pending. |
| Q08 | GitHub Actions Build | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V94: workflow includes locked-month payment and Fandi UI regression suites plus 96-point source trace. Actual CI build/test run still required. |
| Q09 | Signed Release APK | ☑ | ☑ | ☑ | ☐ | Source fix added; runtime pending | V93: Gradle version and workflow artifact agree on V93; signed Release APK must still be built and verified. |
| Q10 | Final ZIP/Audit Report | ☑ | ☑ | ☐ | ☐ | Final packaging gate implemented; evidence pending | Fail-closed package script now requires all 96 runtime ticks, signed APK SHA-256 and explicit runtime evidence; do not package until every gate passes. |

## Current conclusion

- 96 requested points remain tracked individually.
- E07 now has a calendar source fix and 12 static assertions.
- Runtime ticks stay unchecked until actual emulator/device evidence is recorded.
- Final package remains blocked until all required release gates pass.


## V98 — Backup Settings source fix (runtime pending)
- Profile में “Backup Settings” के तहत Restore से पहले safety backup का persisted toggle जोड़ा; default ON है।
- Restore से पहले मौजूदा app data का ZIP safety snapshot बनता है। Snapshot नहीं बनता/खाली है तो restore रोका जाता है और मौजूदा data नहीं बदला जाता।
- Backup & Restore स्क्रीन में safety copy को दोबारा restore करने का विकल्प जोड़ा; safety file स्वयं restore करते समय overwrite/delete नहीं होती।
- Static source checks और Android runtime checks अलग रखे गए हैं; emulator/Google Drive test अभी बाकी है।


## V99 अतिरिक्त source fix — CSV formula injection
- CSV में मजदूर/खेत/टिप्पणी जैसे user-controlled text यदि `=`, `+`, `-`, `@`, tab या carriage-return से शुरू हो, तो spreadsheet formula के रूप में execute होने से रोकने के लिए safe cell escaping जोड़ी।
- Date/field report, गन्ना छिलाई और गन्ना पर्ची CSV में shared sanitizer लागू।
- `scripts_v99_csv_formula_injection_audit.py` static audit और core-store runtime regression assertion जोड़े।
- यह source-level fix है; Android APK build/device export test अभी बाकी है।

- **K11 Empty Result (V99):** गन्ना पर्ची में खाली सीजन/सर्च रिजल्ट पर CSV/PDF export buttons disabled रहते हैं; खाली फाइल बनने से रोकता है। Runtime UI test बाकी।
