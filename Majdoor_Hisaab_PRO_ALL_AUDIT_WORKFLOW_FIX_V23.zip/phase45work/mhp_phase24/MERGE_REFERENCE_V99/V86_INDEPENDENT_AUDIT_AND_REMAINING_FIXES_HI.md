# Majdoor Hisaab PRO V86 — Independent Audit & Remaining Fix Board

**तारीख:** 11 अक्टूबर 2026  
**Package:** `com.majdoor.hisaabpro`  
**Version:** `1.86.0` / `versionCode 86`

## User-requested checklist summary

आपकी 1000 में 800 सही और 200 बाकी वाली मिसाल के अनुसार, हमने source project में मौजूद असली checklist गिनी है—मन से 1000 नहीं बनाया:

- **कुल checklist:** 135
- **PASS दर्ज:** 5 (केवल tracker में दर्ज source-level checks; real-device PASS नहीं)
- **बाकी / NOT TESTED:** 130

**ध्यान दें:** 130 का अर्थ यह नहीं कि 130 निश्चित bugs मिले। इसका अर्थ है कि इन items के लिए पूरा implementation + runtime/device evidence अभी दर्ज नहीं है। इन्हें बिना जाँच PASS नहीं किया जा सकता।

## इस V86 batch में किए गए बदलाव

1. Android runtime regression harness अब API 24+ पर Device Protected Storage में चलता है; यह test preferences और test photos को सामान्य app data से अलग रखता है।
2. API 24 से नीचे unsafe fallback लेने के बजाय harness fail-fast करता है।
3. Fandi rate के local preferences से load और Store reinitialization के बाद persistence की जाँच जोड़ी।
4. Backup test अब create/validate तक सीमित नहीं: backup लेने के बाद temporary worker जोड़ा जाता है, restore किया जाता है, फिर मूल worker/attendance और Fandi rate की वापसी तथा temporary worker हटने की जाँच की जाती है।
5. Version / artifact नाम V86 (`1.86.0`, code 86) पर अपडेट किए।
6. नया static audit script `scripts_v86_remaining_fix_audit.py` जोड़ा; workflow इसे बाकी पाँच source audit scripts के साथ चलाता है।
7. 135 checklist items के लिए priority, current evidence/status और next action वाली `A_TO_Z_REMAINING_FIX_LIST_V86.csv` बनाई।

## चलाए गए source-level checks

| Audit | परिणाम |
|---|---:|
| Daily Labour / navigation | 30/30 PASS |
| Date/field report | 11/11 PASS |
| Google Drive consent | 11/11 PASS |
| Report selection / sale | 16/16 PASS |
| Navigation regression | 10/10 PASS |
| V86 test/CI wiring | 18/18 PASS |
| **कुल targeted checks** | **96/96 PASS** |

ये checks source patterns और test/CI wiring देखते हैं। ये Kotlin/Compose compilation, emulator test execution, वास्तविक Google Drive login, PDF output या physical device behavior का प्रमाण नहीं हैं।

## Remaining work — priority order

### P0 — data और हिसाब सुरक्षित करना
- मासिक लॉक/अनलॉक, बंद तारीख पर बदलाव रोकना, पुराने बकाये का settlement।
- हाजिरी: present/absent/half-day, conflict, edit/save, restart persistence।
- Google Drive: वास्तविक consent, upload/download/restore, photos, corrupted backup recovery।
- गन्ना छिलाई/फांदी: rate persistence, same-name handling, duplicate worker-field-date, payment ledger।
- गन्ना पर्ची: add/edit/delete, season/rate, search और पुराने रिकॉर्ड।

### P1 — मुख्य workflows
- मजदूर CRUD, duplicate names, worker detail और पूरा ledger।
- PDF/CSV: selected date/field/worker, totals, layout और share।
- PIN/device lock, biometric, auto-lock, theme/settings।
- सफल GitHub build, emulator tests, signing, package ID, alignment और install/upgrade।

### P2 — UI/UX और secondary modules
- Dashboard totals और हर shortcut का सही destination।
- Fields/crops/expenses/sales CRUD, empty/error states और persistence।
- छोटे/बड़े स्क्रीन, font scaling, rotation और accessibility review।

## Release verdict

**V86 भी अभी production-ready नहीं है।** इस वातावरण में Release APK build या Android emulator execution नहीं हुआ। GitHub Actions में सभी jobs सफल होने और असली फोन पर P0/P1 flows की जाँच के बाद ही संबंधित items को PASS करें। पुराने local data, Google Drive backup, monthly lock, Ganna Chhilayi/Fandi और Ganna Parchi को सुरक्षित रखना अनिवार्य है।
