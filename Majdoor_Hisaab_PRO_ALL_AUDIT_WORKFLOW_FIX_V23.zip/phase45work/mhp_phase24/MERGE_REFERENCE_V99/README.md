# Majdoor Hisaab PRO — V85 UI and Runtime Smoke-Test Package

- Package: `com.majdoor.hisaabpro`
- Version: `1.85.0` / versionCode `85`
- Existing local data, Google Drive Backup/Restore, monthly lock behavior, Ganna Chhilai/Fandi and Ganna Parchi modules are retained.

## V85 changes
- Dashboard has a dedicated quick-action row for worker list, attendance, and backup.
- More screen is organized into labour/accounts, field/crop, cane, and data/settings sections.
- Bottom navigation has a clearer selected state and larger tap target.
- Added an Android instrumentation smoke test for app launch and the device-lock requirement.
- GitHub Actions runs the smoke test on an Android API 35 emulator before attempting the signed Release APK build.

## Verification status
The source/static audits can be run locally with the Python scripts. Android instrumentation and Release compilation are configured in GitHub Actions but are **not marked PASS until that workflow actually completes**. The smoke test verifies launch/security-gate behavior only; it does not substitute for full field testing of Drive, PDF, monthly lock, or Ganna workflows.

Release signing secrets required: `RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`.
