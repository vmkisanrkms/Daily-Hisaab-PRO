# Phase 29 — Ganna Chhilai: optional fandi while adding a new labourer

- Added an unchecked-by-default checkbox in the new Fandi Labour form: “आज की फांदी भी साथ में सेव करें”.
- When enabled, the form shows date, optional field, fandi quantity, saved current rate, and calculated wage amount.
- Save validates worker name/duplicate identity, date, selected field, positive finite fandi quantity, and positive finite saved rate.
- The new worker is saved first; if the same-day fandi record cannot be saved (including duplicate date/field), the new worker is rolled back and the form reports the failure.
- When the checkbox is off, only the worker is saved, preserving the previous workflow.
- Applied to both canonical redesign and V99 Android source trees so the active workflow does not miss the UI change.

Static audit script: `scripts_phase29_fandi_labour_quick_entry_audit.py` (14 assertions).
Android compilation and on-device test remain NOT TESTED in this environment.
