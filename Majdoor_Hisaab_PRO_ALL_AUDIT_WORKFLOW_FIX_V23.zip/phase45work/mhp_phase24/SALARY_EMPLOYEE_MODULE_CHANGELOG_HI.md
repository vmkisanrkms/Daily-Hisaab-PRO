# Salary Employee Module — Change Log

- Added a separate `सैलरी कर्मचारी` dashboard module and screen.
- Employee records are stored in a dedicated SharedPreferences namespace (`mhpro_salary_employees_v1`), separate from daily labour and cane modules.
- Monthly salary is fixed per employee. Absence deduction is calculated as monthly salary / calendar days in the selected month × absent days.
- Monthly record stores absent days, total advance, and salary paid; the screen shows earned salary and remaining balance.
- Existing Daily Labour, Ganna Chhilai, and Ganna Parchi code paths were not intentionally changed.
- Build verification could not run in this environment because Gradle wrapper distribution download requires network access (`raw.githubusercontent.com` DNS unavailable). Please run the repository GitHub Actions workflow to compile and produce the APK.
