# Majdoor Hisaab PRO — Phase 45 Source Audit & Fix Report
Date: 2026-10-12

## Input archive integrity
- Input: `Majdoor_Hisaab_PRO_PHASE45_FINAL_KOTLIN_WORKFLOW_FIXED_20261012-1.zip`
- ZIP integrity: PASS (`ZipFile.testzip()` returned no corrupt member)
- Input SHA-256: `8d2fcc48f7db85f51275b5074bc1ab83ec03e7c428dcc4f0184403c8a973ce5b`
- Canonical Android project found at `original_source_project/mhp/`.
- One Gradle settings file and one canonical `MainActivity.kt` build tree were found; audit notes/reference snapshots are retained separately.

## Fixes made in this pass

### NAV-01 — Dashboard “दिहाड़ी इतिहास” label was misleading
- Original: route `rate_history` opened `Screen.WageRateHistory`; screen content showed each worker's effective date and ₹/day rate.
- Change: renamed visible dashboard and worker-detail heading to `मजदूरी-दर इतिहास`.
- Test: source audit checks the explicit label; PASS.

### NAV-02 — Dashboard “सभी विकल्प” label did not clearly describe its destination
- Original: `onGo("more")` maps to `Screen.Profile`, which is the existing profile/settings/backup hub.
- Assessment: route itself is not demonstrably broken; label was broader/ambiguous.
- Change: renamed the shortcut to `सेटिंग व अन्य विकल्प`; destination preserved to avoid breaking existing navigation.
- Test: source mapping and label check; PASS.

### FANDI-01 — Duplicate inline Fandi rate control on Cane Peeling home
- Original: `CanePeelingHome` displayed a “रेट बदलें” dialog control in the green header and a second inline “फांदी रेट” input/save card immediately below the header/date card.
- Change: removed only the duplicate inline card. The header's “रेट बदलें” control and its validated Save action remain.
- Data behavior retained: `toDoubleOrNull()` parses decimal values; Store rejects non-finite/non-positive rates and synchronously commits `value.toString()` to preferences before updating UI state. Existing work rows retain their saved rate.
- Test: focused source audit 12/12 PASS; no Android runtime decimal entry/restart test was possible here.

### AUDIT-01 — Stale source audit expectations
- Original: `scripts_daily_labour_audit_check.py` expected an obsolete Phase 25 ZIP name and obsolete wrapper-bootstrap implementation markers, so it failed against the Phase 45 workflow even though the current workflow uses the Gradle setup action and pinned Gradle 8.11.1.
- Change: updated those two assertions to check the current Phase 45 ZIP name and actual wrapper bootstrap flow.
- Test: daily-labour static audit 26/26 PASS.

## Confirmed source-level checks
- Daily Labour audit: 26/26 PASS.
- Phase 45 handover audit: 12/12 PASS.
- Existing focused audit scripts in the archive cover Ganna Chhilai (22 assertions), Ganna Parchi (34 assertions), Backup/Restore (27 assertions), requested UI fixes (15 assertions), and Gradle wrapper bootstrap. Some broad multi-script command attempts timed out in this environment; do not interpret a timed-out batch as a pass.
- Ganna Parchi screen/model and existing Ganna Chhilai source were retained; no redesign was made to those modules in this pass.

## Navigation items deliberately NOT changed without a real destination

### NAV-03 — Monthly account “भुगतान दर्ज करें” currently opens `Screen.LabourList`
- Source: `MainActivity.kt`, `DailyLabourAccountsScreen` wiring.
- Finding: this archive does not declare a `Screen.PaymentHistory` route. Payment records/history appear within existing worker/ledger flows. Creating a new global payment-history screen or changing this callback without defining the intended entry/edit flow risks changing accounting behavior.
- Status: NOT FIXED / needs functional decision and a destination-level implementation audit.

### NAV-04 — Monthly account “खेतवार हिसाब” currently opens `Screen.FieldList`
- Finding: `FieldList` opens field details with labour cost and related farming totals, but is not a dedicated date-filtered labour field report.
- Status: NOT FIXED / field report screen and intended filters must be defined before rerouting.

## Audit scope and counts
- `MainActivity.kt`: 6,239 lines at inspection time.
- Screen model variants: 25.
- Composable function declarations: 78.
- Named `onClick` occurrences: 164.
- `.clickable {}` occurrences: 32.
- UI/button-like call occurrences: 193 (includes reusable components; not a count of unique user-visible buttons).
- These counts are inventory indicators only. A complete per-button destination matrix and physical-device traversal of every screen were NOT completed in this pass. Do not mark the whole application audit complete.

## Build / runtime status
- Local Java available: OpenJDK 21, not the workflow's required JDK 17.
- System Gradle: unavailable.
- `gradle/wrapper/gradle-wrapper.jar`: absent in input archive.
- Attempted `./gradlew :app:compileReleaseKotlin --no-daemon`: blocked before compilation because the wrapper bootstrap attempted to fetch from `raw.githubusercontent.com`, which is unreachable in this environment.
- Kotlin compile: NOT TESTED (no compiler task was reached).
- Release APK build/signature: NOT TESTED.
- APK install / physical phone runtime: NOT TESTED.
- The workflow provisions JDK 17, Android API 36 / Build Tools 36.0.0, Gradle 8.11.1, bootstraps the wrapper, runs static tests and Kotlin compilation, checks required permanent signing secrets, then assembles and validates a signed APK. CI success still needs to be observed.

## Remaining work
1. Build a true per-screen/per-button callback → destination matrix and identify same-destination shortcuts by intent, not label alone.
2. Decide and implement a proper monthly labour payment entry/history destination and dedicated field-wise labour report if required.
3. Run the full CI workflow to obtain Kotlin compiler output; fix any actual errors and rerun to green.
4. Run decimal-rate persistence, attendance/payment/locked-month, PDF/CSV, Backup/Restore and Google Drive consent tests on an Android device/emulator.
5. Verify APK install and Back navigation on the phone.

This archive is a corrected source/audit handover, not a verified final Release APK.
