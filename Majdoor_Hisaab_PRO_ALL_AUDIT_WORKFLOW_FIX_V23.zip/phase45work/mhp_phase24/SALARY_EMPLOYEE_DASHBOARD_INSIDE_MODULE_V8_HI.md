# Salary Employee Dashboard Placement — V8

## Requested UI behavior
- Keep only the Salary Employee entry button on the Home screen; do not show Salary Employee-specific totals on Home.
- Move the Salary Employee entry button near the top of Home, immediately below the greeting/date header.
- Remove the duplicate Salary Employee button from the Farm/Crop section.
- Show Salary Employee dashboard totals only after opening the Salary Employee button: total employees, total monthly salary, and current month's remaining salary balance.
- Keep the existing labour, cane peeling, and cane receipt modules unchanged.

## Verification
- Source-level edit applied to MainActivity.kt.
- Kotlin/Gradle compilation and Android runtime have not been verified in this environment.
