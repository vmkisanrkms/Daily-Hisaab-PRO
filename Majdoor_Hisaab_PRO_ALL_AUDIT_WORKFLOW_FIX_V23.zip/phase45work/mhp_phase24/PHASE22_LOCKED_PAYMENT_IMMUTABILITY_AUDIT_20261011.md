# Phase 22 — Locked Month Payment Immutability

## Scope
Fix and verify Daily Labour payment protection for locked months. No unrelated feature redesign is included.

## Source changes
- Store-level guard rejects new payments dated in a locked month.
- Store-level guard rejects edits when either the stored date or proposed date is locked/finalized.
- Store-level guard rejects deletion of payments in locked/finalized periods.
- Payment edit cannot transfer an existing payment to a different worker.
- Payment dialog explains locked-month rejection and advises using a later unlocked date for old-balance settlement.
- Regression assertions cover locked payment edit/delete, moving a locked payment forward, rejected backdating, worker transfer, and allowed later unlocked settlement.

## Verification
The Phase 22 script checks source guards and regression assertions. This is a static source audit, not proof of Android runtime behavior. APK compilation, installation, and interaction tests remain NOT TESTED.
