# Majdoor Hisaab PRO — Phase 24 Five Remaining Points

Date: 2026-10-11
Base: Phase 23 source ZIP

## Changes

### A02 — Custom in-app PIN / Device Lock
- Added optional 4–8 digit custom PIN setup, change and removal flow in Settings/Profile.
- Raw PIN is never persisted; a random 16-byte salt and PBKDF2-HMAC-SHA256 digest (120,000 iterations) are stored in local app preferences.
- Digest verification uses `MessageDigest.isEqual`.
- Five failed attempts trigger a 30-second delay.
- When app lock is enabled and a custom PIN is configured, launch presents the PIN gate. Phone biometric/device credential fallback remains available.
- Added a recovery path: authenticate with the Android device credential, then reset/remove a forgotten custom PIN without needing the old PIN.
- Runtime/cryptographic implementation review on a device is still pending; this is not a substitute for Android Keystore-backed secret storage.

### P03 — Shared Form Fields
- Migrated all existing `OutlinedTextField` call sites in the canonical source to a shared `AppTextField` wrapper.
- The wrapper standardizes shape, theme-aware colors, keyboard options, label/placeholder/icon slots, line limits and password transformation while preserving per-screen callbacks and validation.

### P06 — Shared Loading / Empty / Error / Success States
- Added `SharedStatePanel` supporting loading, empty, error, success and informational states.
- Applied to app startup/loading and startup error, the shared empty-card component, PIN/security errors and Backup/Restore status feedback.
- Inline field validation remains next to the affected field for usability; a full device-by-device state inventory remains a runtime acceptance task.

### Q01 — Feature Preservation Matrix
- Added `FEATURE_PRESERVATION_MATRIX_PHASE24.csv` with 291 action-level scenarios spanning all 97 requested point IDs.
- Each case has an expected result and explicitly states `NOT RUN — Android device/CI execution required`; no runtime result is fabricated.
- Retained all 135 tracker IDs and updated A02, P03, P06, Q01 and Q09 statuses.

### Q09 — Signed Release APK pipeline
- Updated GitHub Actions workflow to require the exact Phase 24 source ZIP, run the 23 existing audit scripts plus the Phase 24 audit, compile release Kotlin, run JVM accounting tests, assemble release, and validate package/signature/alignment before artifact upload.
- The workflow intentionally has no debug/temporary-signing fallback.
- A signed APK is **not included** because this environment cannot resolve `services.gradle.org` and permanent signing secrets are not available in this source archive. Configure these GitHub repository Actions secrets before expecting a signed artifact:
  - `RELEASE_KEYSTORE_BASE64`
  - `RELEASE_KEYSTORE_PASSWORD`
  - `RELEASE_KEY_ALIAS`
  - `RELEASE_KEY_PASSWORD`
- Do not commit the keystore or passwords into the source ZIP or repository.

## Static verification
- 23 audit scripts exited successfully, zero script failures.
- Phase 24 focused audit: 26/26 checks passed.
- Feature matrix: 291 cases, 97/97 requested IDs represented.
- GitHub Actions YAML parsed successfully.
- ZIP archive integrity verified after packaging.

## Not verified
- Android/Kotlin compile: NOT RUN successfully (Gradle distribution DNS resolution failed: `Could not resolve host: services.gradle.org`).
- JVM unit tests: added/retained but not executed locally.
- Device PIN/biometric, UI/accessibility, rotation, backup/restore and install tests: NOT TESTED.
- Signed Release APK: NOT BUILT; permanent signing secrets and successful CI run are required.
