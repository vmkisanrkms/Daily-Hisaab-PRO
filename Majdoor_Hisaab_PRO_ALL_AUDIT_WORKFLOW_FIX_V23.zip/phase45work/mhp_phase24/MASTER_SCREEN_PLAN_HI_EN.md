# MAJDOOR HISAAB PRO — A-to-Z UI/UX Redesign Master Plan
Version: 1.0
Date: 2026-10-11

## Goal
Redesign the entire app's UI/UX and screen architecture without losing existing features, local records, calculations, business rules, or the current Google Drive Backup/Restore flow.

## Locked requirements
- Preserve existing features, records, calculations, and workflows unless an explicitly approved change is necessary.
- Daily/local operations must work offline.
- Preserve the existing Google Drive sign-in/consent and Backup/Restore integration.
- Do not add Supabase, Firebase, or a new cloud-sync system.
- Do not add a new login/account requirement for ordinary local app use.
- Keep existing package name, Android/Gradle/Kotlin setup, signing setup, and GitHub Actions workflow compatible unless the audit proves a change is necessary.
- Preserve Daily Labour accounting and locked-month behavior.
- Do not alter Ganna Chhilayi or Ganna Parchi business logic merely for visual redesign.
- Do not declare PASS unless the specific test actually ran and passed.

## Design direction
- Professional agriculture/workforce management app.
- Deep green + white primary palette; restrained light-green highlights.
- Clear contrast, accessible text sizing, consistent spacing and reusable components.
- Light, Dark, System theme support where supported by current app and verified.
- Natural Hindi labels; preserve existing Hindi/English behavior where present.
- No decorative-only controls, fake data, dummy screens, or buttons without real actions.

## Proposed bottom navigation
1. Home — dashboard and quick actions.
2. Workers — worker list and worker accounts.
3. Fields — fields, crops, expenses, sales/revenue where existing.
4. More — attendance, reports, Ganna Chhilayi, Ganna Parchi, backup, settings, and other existing modules.

This is a proposed architecture; validate against the complete source audit before implementation.

## Sign-in and security plan
- App launch/loading: initialize local data and show a clear loading/error state.
- App lock: preserve current device-credential/PIN flow as implemented; do not invent a new login.
- Biometrics: preserve existing behavior and device capability checks.
- Google Drive sign-in/consent: only for Drive Backup/Restore; preserve existing OAuth scopes and consent handling.
- Local work: should remain available without Google account sign-in.
- Restore: validate backup, explain replacement impact, require confirmation, and protect existing data from partial/failed restore.
- Auto-lock/theme/notification/report settings: preserve only the options present in the existing app; verify actual behavior.

## Master screen inventory
Each screen ID should be tracked through audit, redesign, implementation, and testing. Inventory is a planning list, not proof that the screen already exists or is complete.

### A. Launch, security, and app foundation
- A01 App Launch / Loading
- A02 PIN / Device Lock
- A03 Biometric / Security Gate
- A04 Existing Data Initialization
- A05 Offline / Error State
- A06 Theme Selection (Light/Dark/System)

### B. Home Dashboard
- B01 Main Dashboard with real data
- B02 Today's attendance summary
- B03 Today's wages and payments
- B04 Outstanding balance
- B05 Recent work/payment records
- B06 Quick actions
- B07 Field/crop summary

### C. Workers
- C01 Worker list, search, sort, filters
- C02 Add worker
- C03 Edit worker
- C04 Worker detail
- C05 Attendance history
- C06 Work history
- C07 Payment/advance history
- C08 Full ledger
- C09 Deactivate/delete confirmation and data safety

### D. Daily Labour
- D01 Daily Labour home
- D02 Monthly account list
- D03 Monthly account detail (attendance, half-days, wages, payments, balance)
- D04 Month lock/unlock
- D05 Payment against old locked-month outstanding
- D06 Worker-wise Daily Labour ledger
- D07 Selected-date/worker PDF
- D08 Date/field report

### E. Attendance
- E01 Field selection where applicable
- E02 Date selection
- E03 Real worker attendance list
- E04 Present/Absent/Half-day
- E05 Bulk actions (All Full, Clear All, Previous Team) preserving existing behavior
- E06 Save/edit attendance with duplicate protection
- E07 Calendar with actual saved dates
- E08 Attendance history
- E09 Today's attendance
- E10 Conflict/confirmation handling

### F. Work, wage rates, and payments
- F01 Work entry
- F02 Work list/detail
- F03 Wage rate/rate history
- F04 Payment entry
- F05 Advance/partial payment and existing payment types
- F06 Payment history
- F07 Payment edit/delete safeguards
- F08 Outstanding balance

### G. Fields
- G01 Field list
- G02 Add/edit field
- G03 Field detail
- G04 Existing field ordering/reorder behavior
- G05 Field reports

### H. Crops
- H01 Crop list
- H02 Add/edit crop
- H03 Crop detail
- H04 Crop-wise expenses
- H05 Crop-wise sales

### I. Expenses
- I01 Expense list/search/filter
- I02 Add expense
- I03 Edit/delete expense
- I04 Expense detail/history
- I05 Cost summary using existing logic

### J. Sales / income
- J01 Sales list
- J02 Add/edit sale
- J03 Sale detail/delete
- J04 Revenue/profitability only where currently supported

### K. Reports, PDF, CSV, calendar
- K01 Report centre
- K02 Report type selection
- K03 Date range
- K04 Worker/field/crop selection where applicable
- K05 Preview
- K06 Professional green-white PDF ledger (not Excel-like)
- K07 CSV export
- K08 Attendance PDF
- K09 Worker ledger PDF
- K10 Export success/error
- K11 Empty results/filter state

### L. Ganna Chhilayi
- L01 Chhilayi home/dashboard
- L02 Fandi labour list
- L03 Add/edit Fandi labour
- L04 Fandi rate persistence
- L05 Chhilayi entry preserving current rate/calculation rules
- L06 Single-worker entry
- L07 Field-wise detail
- L08 Worker-wise detail
- L09 Chhilayi payment entry
- L10 Payment history/edit/delete
- L11 PDF/CSV exports where currently available
- L12 Duplicate/same-name worker protection

### M. Ganna Parchi
- M01 Parchi dashboard
- M02 Season filter
- M03 Add/edit parchi
- M04 Parchi detail
- M05 Delete confirmation/data safety
- M06 Parchi PDF/CSV where currently available

### N. Backup, restore, import
- N01 Backup centre
- N02 Google sign-in/consent
- N03 Google Drive backup
- N04 Backup selection/restore
- N05 Local backup
- N06 Restore validation
- N07 Restore confirmation
- N08 Rollback/failure safety
- N09 Import validation and duplicate checks
- N10 Backup metadata/history/results

### O. Settings and security
- O01 Settings/profile
- O02 Theme
- O03 App lock/device credential
- O04 Biometric
- O05 Auto-lock
- O06 Notification settings if present
- O07 Report settings if present
- O08 Data/backup settings
- O09 About/version

### P. Shared UI components and actions
- P01 Common header/back navigation
- P02 Buttons/icons/menus
- P03 Reusable forms/validation
- P04 Search/filter/sort
- P05 Dialogs/bottom sheets
- P06 Loading/empty/error/success
- P07 Delete/replace confirmation
- P08 Double-tap/duplicate-operation protection
- P09 Small screens/font scaling
- P10 Rotation/lifecycle state preservation

### Q. Regression and release
- Q01 Feature preservation matrix
- Q02 Wage/payment/balance regression
- Q03 Ganna module regression
- Q04 Backup/restore regression
- Q05 Offline test
- Q06 Restart/rotation tests
- Q07 Static code audit
- Q08 GitHub Actions build
- Q09 Signed Release APK
- Q10 Final ZIP and honest audit report

## Phase plan
1. Audit ZIP and all modules.
2. Build feature-preservation matrix mapping old screen/action/function/data source to new location and verification.
3. Finalize information architecture, screen map, navigation, and reusable design system.
4. Implement launch/security and main navigation.
5. Implement dashboard and workers.
6. Implement attendance, work, wages, payments, and ledger.
7. Implement fields, crops, expenses, sales.
8. Implement reports, PDF/CSV, calendar.
9. Implement backup/restore and settings.
10. Redesign Daily Labour, Ganna Chhilayi, and Ganna Parchi while preserving business logic.
11. End-to-end action/form/navigation verification.
12. Regression, build verification, final ZIP and audit report.

## Status definitions
- NOT STARTED: no implementation/audit evidence yet.
- IN PROGRESS: work started but incomplete.
- IMPLEMENTED: code change exists; not necessarily verified.
- PASS: a specific test actually ran and passed.
- FAIL: a specific test ran and failed.
- NOT TESTED: could not or did not run.
- BLOCKED: dependency or environment prevents progress.

## Current status at Phase 1 packaging (2026-10-11)
This ZIP contains the original source plus a partial main-navigation and dashboard redesign. It is not a completed A-to-Z redesign release.
- Source project included: yes.
- Main dashboard hierarchy: implemented, not Android-tested.
- App-wide Material 3 green/white palette: implemented, not Android-tested.
- Four-destination bottom navigation and More shortcuts: implemented, not Android-tested.
- Feature preservation matrix: partial Phase 1 matrix added; full matrix remains incomplete.
- Full source-level screen/action audit: in progress.
- Full A-to-Z UI implementation: in progress.
- Android Release build and signing: not tested in this environment.
- Real-device end-to-end verification: not tested.
- Ganna module regression and Backup/Restore regression after this UI change: not tested.


## Current status after Phase 8 batch (2026-10-11)
- Phase 8 validation/search/export/CI improvements are documented in `REDESIGN_PHASE8_BATCH_FIXES_20261011.md`.
- Static audit assertions across Phases 2, 4, 5, 6, 7 and 8: 113/113 PASS.
- Tracker still has 135 unique IDs: 30 design points implemented, 15 in progress, 90 not started. In-progress items are not counted as complete.
- Android compilation, signed APK build, device install/runtime, real backup/restore and end-to-end tests remain unverified.
