# Phase 16 — Settings and Security (O01–O09)

## Implemented in source
- O01: local profile label field with preference persistence.
- O02: Light/Dark/System selector retained.
- O03: persisted app-launch lock toggle; edit/delete/restore credential gates remain active.
- O04: persisted biometric-first preference; when off, the gate falls back to Android device credential.
- O05: timeout choices Immediate, 1, 5, 15, 30 minutes, Never; lifecycle observer re-locks on foreground return after the selected timeout.
- O06: persisted notification preference control.
- O07: persisted report summary/wage/payment preference controls.
- O08: entry to existing local/manual/Google Drive backup and restore screen plus persisted reminder preference.
- O09: About dialog displays version name, version code and package ID.

## Known incomplete wiring
- O06: this build does not implement a scheduled/push notification service; the setting is a saved preference only.
- O07: report preferences are saved but are not yet wired to hide/show PDF columns.
- O08: reminder preference is saved but does not schedule reminders.

## Validation
- Static checks validate settings controls, persistence, app-lock/biometric wiring, lifecycle timeout, backup route, version display, and preservation of cane/report navigation.
- Android compilation, device biometric behavior, background timeout timing, backup/restore execution, and visual UI testing are NOT TESTED in this environment.
