# Majdoor Hisaab PRO — Salary Employee and Daily Labour fixes

This patch keeps the existing dिहाड़ी labour, cane peeling, and cane parchi modules intact while making the following targeted fixes:

- Added a dedicated Daily Labour landing screen with primary actions `हाजिरी लगाएँ` and `हिसाब देखें` plus worker-list access.
- Included Salary Employee SharedPreferences in the ZIP backup and restore data; restore rollback now also restores the previous salary preferences.
- Added a month salary snapshot (`salaryAtMonth`) so changing the employee's current salary does not change a month that already has a saved salary snapshot.
- Added date-wise salary payments with amount and optional note, and included them in balance calculations and backup/restore.
- Validated salary attendance/payment dates and employee join date as real calendar dates.
- Updated the stale static audit expectation for the new Daily Labour landing screen and added a salary data integrity audit to the GitHub Actions workflow.

Validation performed in the working environment:
- `scripts_daily_labour_audit_check.py`: 26/26 PASS
- `scripts_redesign_phase9_remaining_audit.py`: 31/31 PASS
- `scripts_salary_employee_data_integrity_audit.py`: 9/9 PASS
- Several existing source audits passed; full Android Gradle compilation and APK signing remain unverified in this environment.
