from pathlib import Path
import csv
ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s = SRC.read_text(encoding='utf-8')
checks = {
    'worker add/edit and duplicate-name guard': 'fun addLabour(x:Labour):Boolean' in s and 'fun updateLabour(x:Labour):Boolean' in s and 'labourNameExists' in s,
    'worker delete protects linked history': 'fun deleteLabour(id:String):Boolean' in s and 'hasHistory' in s,
    'daily labour home exists': 'DailyLabourHomeScreen' in s and 'DailyLabourAccountsScreen' in s,
    'old outstanding ledger closure logic exists': 'fun closeLabourAccount' in s and 'latestClosure' in s,
    'attendance field selection exists': 'AttendanceFieldPickerScreen' in s,
    'attendance upsert and conflict checks exist': 'fun upsertAttendance(x:Attendance):String?' in s and 'attendanceConflict' in s,
    'locked-month attendance protection exists': 'if(isMonthLocked(x.date))' in s,
    'today attendance and history screens exist': 'TodayAttendanceScreen' in s and 'AttendanceHistoryScreen' in s,
    'attendance PDF export exists': 'exportAttendanceHistoryPdf' in s,
    'date-field report PDF exists': 'exportDateFieldReportPdf' in s,
    'worker ledger PDF exists': 'exportWorkerLedgerPdf' in s,
    'all-workers ledger PDF exists': 'exportAllWorkersLedgerPdf' in s,
    'field detail and ordering exist': 'FieldDetail' in s and 'fun moveField(id:String,delta:Int)' in s,
    'field delete preserves linked history': 'fun deleteField(id:String):Boolean' in s and 'Preserve field-linked financial and crop history' in s,
    'crop detail and crop-linked cost/sales navigation exist': 'CropDetail' in s and 'Screen.ExpenseList(store.crops.firstOrNull' in s,
    'expense search and empty state exist': 'इस खोज से कोई खर्च नहीं मिला।' in s,
    'sales search and empty state exist': 'इस खोज से कोई बिक्री नहीं मिली।' in s,
    'payment add/edit/delete paths exist': 'fun addPayment(x:Payment):Boolean' in s and 'fun updatePayment(x:Payment):Boolean' in s and 'fun deletePayment(id:String):Boolean' in s,
    'monthly lock mechanism exists': 'fun setLabourMonthLocked(month:String,locked:Boolean):Boolean' in s,
    'cane peeling module exists': 'CanePeelingScreen' in s and 'CanePeelingLabourScreen' in s,
    'cane peeling duplicate entry protection exists': 'इस मजदूर की इस तारीख और खेत की एंट्री पहले से है।' in s,
    'cane peeling PDF/CSV export exists': 'exportCanePeelingCsv' in s and 'exportReportPdf(context,"गन्ना_छिलाई_रिपोर्ट"' in s,
    'cane parchi dashboard and form exist': 'CaneParchiDashboardScreen' in s and 'CaneParchiFormScreen' in s,
    'season-scoped parchi duplicate protection exists': 'it.season==normalized.season && normalizedParchiCode(it.code)==normalized.code' in s and 'it.id!=normalized.id && it.season==normalized.season' in s,
    'backup screen and Drive API exist': 'BackupScreen' in s and 'class GoogleDriveDirect' in s,
    'backup restore validation and rollback code exists': 'rollback' in s.lower() and 'restoreBackupZip' in s,
    'CSV fields now escape quotes and line breaks': 'private fun csvCell(value:String)' in s and 'value.replace("\\\"", "\\\"\\\"")' in s,
    'date validation helper exists': 'fun validDate' in s,
    'app lock device credential gate exists': 'DeviceCredentialGate' in s and 'appUnlocked' in s,
    'GitHub Actions build and signature verification exists': (ROOT/'.github/workflows/majdoor-hisaab.yml').exists() and 'apksigner' in (ROOT/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8'),
}
tracker=ROOT.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
rows=list(csv.DictReader(tracker.open(encoding='utf-8-sig',newline='')))
checks['tracker has 135 unique IDs']=len(rows)==135 and len({r['ID'] for r in rows})==135
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
