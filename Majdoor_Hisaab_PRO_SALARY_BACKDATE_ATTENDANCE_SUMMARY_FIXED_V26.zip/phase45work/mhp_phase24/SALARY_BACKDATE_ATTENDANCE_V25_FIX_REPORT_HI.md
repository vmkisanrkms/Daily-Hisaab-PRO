# Salary Full-Date / Back-Date Attendance Fix V25

## User-requested behavior
- Replace month-only selector on Salary Employee List with a complete `YYYY-MM-DD` attendance date.
- Allow selecting any past date up to today using Android DatePickerDialog or entering the full date.
- Keep monthly salary/report calculations scoped to the month derived from the selected full date.
- Quick Present action writes attendance under the selected date, not always today's date.
- The employee card shows the selected date's attendance status.
- Quick Holiday uses the same selected date.
- Reject invalid/future dates and dates before employee joining date.
- Preserve existing salary storage format, reports, and unrelated Ganna Chhilayi / Ganna Parchi modules.

## Static verification
- 36 Python static audit scripts passed.
- New back-date attendance audit: 7/7 passed.
- Workflow YAML parsed successfully.
- Kotlin brace and parenthesis raw counts balanced.

## Not yet verified
- Android Gradle/Kotlin compilation has not been run in this environment.
- Release signing and on-device attendance save/restore tests remain pending GitHub Actions and phone verification.
