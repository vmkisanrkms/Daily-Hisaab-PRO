from pathlib import Path
s=(Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'home opens Salary Dashboard':'"salary_employees"->Screen.SalaryDashboard' in s,
 'Dashboard uses canonical salary calculation':'salaryEarnedForRange(employee, activeMonth, record)' in s,
 'Employee list uses canonical salary calculation':'salaryEarnedForRange(emp, activeMonth, rec)' in s,
 'Employee row uses canonical salary calculation':'salaryEarnedForRange(emp,activeMonth,record)' in s,
 'Detail uses canonical salary calculation':'salaryEarnedForRange(it,month,record)' in s,
 'Salary editor preview uses canonical calculation':'salaryEarnedForRange(employee,month,previewRecord)' in s,
 'Range report uses canonical calculation':'salaryEarnedForRange(emp,m,rec,rangeStart,rangeEnd)' in s,
 'only explicitly present days earn wages':'day.status=="उपस्थित"' in s and 'val present=record.daily.count' in s,
 'joining date bounds attendance wage':'val join=employee.joinDate.takeIf{validDate(it)}' in s and 'maxOf(monthStart, join' in s,
 'attendance editor rejects pre-joining dates':'attendanceDate<employee.joinDate' in s,
 'quick attendance rejects pre-joining dates':'date<emp.joinDate' in s and 'date>today()' in s,
 'quick holiday rejects pre-joining dates':'date<emp.joinDate' in s and 'date>today()' in s,
 'quick payment rejects pre-joining dates':'paymentDate<emp.joinDate' in s,
 'ledger payment rejects pre-joining dates':'paymentDate<employee.joinDate' in s,
 'duplicate employee identity guarded':'इस मोबाइल नंबर का कर्मचारी पहले से मौजूद है।' in s,
 'employee role preserved on edit':'old.copy(name=name,mobile=mobile,monthlySalary=salary,joinDate=date)' in s,
 'employee role serialized in preferences':'.put("role",e.role)' in s,
 'dated payment editing and deletion available':'editingPaymentIndex=index' in s and 'payments=payments.filterIndexed' in s,
 'salary employee backup export exists':'put("salaryData",salaryData)' in s,
 'salary restore rollback exists':'salaryRollback.commit()' in s,
 'Ganna modules remain separately implemented':'Screen.CaneParchi' in s and 'Screen.CanePeeling' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
