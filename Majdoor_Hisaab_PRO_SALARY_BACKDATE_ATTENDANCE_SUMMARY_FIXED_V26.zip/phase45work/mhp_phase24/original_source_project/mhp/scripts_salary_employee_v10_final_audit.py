#!/usr/bin/env python3
"""Static regression checks for Salary Employee V10 validation and persistence."""
from pathlib import Path

src = Path('app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks = {
    'Material3 text field alias declared': 'import androidx.compose.material3.OutlinedTextField as MaterialOutlinedTextField' in src,
    'Shared AppTextField calls aliased Material3 component': 'MaterialOutlinedTextField(' in src and 'private fun AppTextField(' in src,
    'No unresolved bare OutlinedTextField call remains': 'OutlinedTextField(' not in src.replace('MaterialOutlinedTextField(', ''),
    'Month format validates 01 through 12': 'Regex("\\\\d{4}-(0[1-9]|1[0-2])")' in src,
    'Selected full date safely determines report month': 'selectedAttendanceDate.takeIf { validDate(it) }?.take(7) ?: currentMonth' in src,
    'Salary calculations use validated active month': 'loadSalaryMonth(context,emp.id,activeMonth)' in src and 'monthDays(activeMonth)' in src,
    'Salary dialog saves against validated active month': 'saveSalaryMonth(context,emp.id,activeMonth,record)' in src,
    'Daily attendance restore filters valid month dates and statuses': 'validDate(k)&&k.startsWith(month)&&status in setOf("उपस्थित","अनुपस्थित","छुट्टी")' in src,
    'Date-wise payments filter by month and positive finite amount': 'it.amount.isFinite()&&it.amount>0.0' in src,
    'Payment input rejects NaN and infinity': 'amount==null||!amount.isFinite()||amount<=0' in src,
    'Advance and legacy paid amount reject NaN and infinity': 'adv==null||!adv.isFinite()||adv<0||pay==null||!pay.isFinite()||pay<0' in src,
    'Salary records validate month before persistence': 'require(isValidSalaryMonth(month))' in src,
    'Salary backup is included in backup JSON': 'put("salaryData",salaryData)' in src,
    'Salary restore reads and commits salary data': 'restoredSalaryData' in src and 'salaryEditor.commit()' in src,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + name)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
