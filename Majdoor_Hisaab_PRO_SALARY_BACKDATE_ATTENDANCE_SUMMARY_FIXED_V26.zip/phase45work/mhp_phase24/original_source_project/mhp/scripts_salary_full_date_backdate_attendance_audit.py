from pathlib import Path
src=Path("app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt").read_text()
checks={
 "full YYYY-MM-DD attendance date field": 'हाजिरी की पूरी तारीख (YYYY-MM-DD)' in src,
 "native calendar picker for selected date": 'DatePickerDialog(context' in src and 'selectedAttendanceDate=String.format' in src,
 "past date is used for quick attendance": 'pendingAttendanceSave=emp to selectedAttendanceDate' in src,
 "selected date stored in its own month bucket": 'val targetMonth = date.take(7)' in src and 'previous.daily + (date to SalaryDay("उपस्थित", ""))' in src,
 "future attendance is rejected": 'date > today()' in src and 'भविष्य की तारीख में हाजिरी नहीं लग सकती' in src,
 "date-specific attendance status shown": 'record.daily[selectedAttendanceDate]?.status' in src,
 "selected date is also used for holiday": 'val d=selectedAttendanceDate;pendingHolidaySave' in src,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+label)
print(f"RESULT: {sum(checks.values())}/{len(checks)} PASS")
raise SystemExit(0 if all(checks.values()) else 1)
