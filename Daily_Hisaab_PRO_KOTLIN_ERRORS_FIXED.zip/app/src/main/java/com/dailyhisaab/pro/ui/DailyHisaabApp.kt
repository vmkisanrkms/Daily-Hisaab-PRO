package com.dailyhisaab.pro.ui

import android.content.Context
import android.app.Activity
import android.database.sqlite.SQLiteDatabase
import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.content.FileProvider
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import com.dailyhisaab.pro.data.AppDatabase
import com.dailyhisaab.pro.data.Preferences
import com.dailyhisaab.pro.data.LockoutPolicy
import com.dailyhisaab.pro.data.Transaction
import com.dailyhisaab.pro.data.ReportMath
import com.dailyhisaab.pro.data.TransactionRepository
import com.dailyhisaab.pro.data.parseAmountPaise
import com.dailyhisaab.pro.data.filterTransactions
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

private val Green = Color(0xFF087A4B)
private val DarkGreen = Color(0xFF064E3B)
private val PaleGreen = Color(0xFFE5F5EC)
private val Red = Color(0xFFDC4545)
private val Blue = Color(0xFF2786C8)
private val ExpenseCats = listOf("घर","खाना","दूध","राशन","पेट्रोल","दवा","फीस","बिल","शॉपिंग","अन्य")
private val IncomeCats = listOf("वेतन","बिजनेस","फ्रीलांस","किराया","खेती","बिक्री","ब्याज","अन्य")
private val Payments = listOf("नकद","UPI","कार्ड","बैंक")
private val fmtDate = SimpleDateFormat("dd-MM-yyyy", Locale("hi","IN"))
private fun money(paise: Long) = "₹ " + String.format(Locale("en","IN"), "%,.2f", paise / 100.0)
private fun pinHash(pin: String, saltHex: String? = null): String {
    val salt = saltHex?.chunked(2)?.map { it.toInt(16).toByte() }?.toByteArray() ?: ByteArray(16).also { SecureRandom().nextBytes(it) }
    val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
    val hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    return salt.joinToString("") { "%02x".format(it) } + ":" + hash.joinToString("") { "%02x".format(it) }
}
private fun verifyPin(pin: String, stored: String?): Boolean {
    if (stored.isNullOrBlank()) return false
    val parts = stored.split(":")
    if (parts.size != 2) return false
    return MessageDigest.isEqual(pinHash(pin, parts[0]).substringAfter(":" ).toByteArray(), parts[1].toByteArray())
}

private enum class Screen(val title: String) {
    Login("PIN सुरक्षा"), Home("होम"), AddExpense("खर्च जोड़ें"), AddIncome("कमाई जोड़ें"),
    Transactions("लेन-देन सूची"), Detail("लेन-देन एडिट / डिलीट"), Monthly("मासिक रिपोर्ट"),
    Category("श्रेणीवार विवरण"), Pdf("PDF रिपोर्ट"), Backup("बैकअप और रिस्टोर"),
    Settings("सेटिंग्स"), Lockout("PIN सुरक्षा")
}

@Composable
fun DailyHisaabApp() {
    val context = LocalContext.current
    val db = remember { AppDatabase.get(context) }
    val prefs = remember { Preferences(context, db.appSettingDao()) }
    val dao = db.transactionDao()
    val repository = remember(db) { TransactionRepository(dao) }
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val all by repository.observeAll().collectAsState(initial = emptyList())
    val expenseCategoryRows by db.categoryDao().observeByType("EXPENSE").collectAsState(initial = emptyList())
    val incomeCategoryRows by db.categoryDao().observeByType("INCOME").collectAsState(initial = emptyList())
    val allCategoryRows by db.categoryDao().observeAll().collectAsState(initial = emptyList())
    val expenseCategoryNames = expenseCategoryRows.map { it.name }.ifEmpty { ExpenseCats }
    val incomeCategoryNames = incomeCategoryRows.map { it.name }.ifEmpty { IncomeCats }
    var screen by remember { mutableStateOf(Screen.Login) }
    var pin by remember { mutableStateOf("") }
    var pinVerifying by remember { mutableStateOf(false) }
    var pinSetup by remember { mutableStateOf(false) }
    var firstPin by remember { mutableStateOf("") }
    var wrong by remember { mutableIntStateOf(0) }
    var lockUntil by remember { mutableLongStateOf(0L) }
    var lockPulse by remember { mutableIntStateOf(0) }
    var listFilter by remember { mutableStateOf("ALL") }
    var filterPayment by remember { mutableStateOf("ALL") }
    var filterCategory by remember { mutableStateOf("ALL") }
    var dateFrom by remember { mutableLongStateOf(0L) }
    var dateTo by remember { mutableLongStateOf(Long.MAX_VALUE) }
    var pdfMode by remember { mutableStateOf("MONTHLY") }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showDeleteTransactionConfirm by remember { mutableStateOf(false) }
    var savingTransaction by remember { mutableStateOf(false) }
    var showRecoveryConfirm by remember { mutableStateOf(false) }
    var showRestoreConfirm by remember { mutableStateOf(false) }
    var showSqliteRestoreConfirm by remember { mutableStateOf(false) }
    var pendingSqliteRestore by remember { mutableStateOf<File?>(null) }
    var pendingRestore by remember { mutableStateOf<List<Transaction>?>(null) }
    var showPinChange by remember { mutableStateOf(false) }
    var showDiscardChangesConfirm by remember { mutableStateOf(false) }
    var pendingBackTarget by remember { mutableStateOf(Screen.Home) }
    var showCategoryEditor by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }
    var newCategoryType by remember { mutableStateOf("EXPENSE") }
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinDialogError by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Transaction?>(null) }
    var editId by remember { mutableLongStateOf(0L) }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("खाना") }
    var description by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(System.currentTimeMillis()) }
    var payment by remember { mutableStateOf("नकद") }
    var txType by remember { mutableStateOf("EXPENSE") }
    var query by remember { mutableStateOf("") }
    var txTypeFilter by remember { mutableStateOf("ALL") }
    var txCategoryFilter by remember { mutableStateOf("सभी श्रेणियाँ") }
    var txPaymentFilter by remember { mutableStateOf("सभी भुगतान") }
    var txFromDate by remember { mutableStateOf<Long?>(null) }
    var txToDate by remember { mutableStateOf<Long?>(null) }
    var theme by remember { mutableStateOf("System") }
    var autoLock by remember { mutableStateOf(true) }
    var biometricLogin by remember { mutableStateOf(false) }
    var monthOffset by remember { mutableIntStateOf(0) }
    var homeDate by remember { mutableLongStateOf(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis) }
    var pdfFromDate by remember { mutableStateOf<Long?>(null) }
    var pdfToDate by remember { mutableStateOf<Long?>(null) }
    var pdfCategory by remember { mutableStateOf("सभी श्रेणियाँ") }
    var pdfCategoryMenu by remember { mutableStateOf(false) }
    var pdfRefresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    val cal = remember(monthOffset) { Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset); set(Calendar.DAY_OF_MONTH,1); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) } }
    val monthStart = cal.timeInMillis
    val nextMonth = Calendar.getInstance().apply { timeInMillis = monthStart; add(Calendar.MONTH,1) }.timeInMillis
    val currentDay = Calendar.getInstance().apply { timeInMillis=System.currentTimeMillis(); set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }.timeInMillis
    val selectedDayStart = Calendar.getInstance().apply { timeInMillis=homeDate; set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }.timeInMillis
    val nextDay = Calendar.getInstance().apply { timeInMillis=selectedDayStart; add(Calendar.DAY_OF_MONTH,1) }.timeInMillis
    val monthTransactions = all.filter { it.dateMillis >= monthStart && it.dateMillis < nextMonth }
    val todayTransactions = all.filter { it.dateMillis >= selectedDayStart && it.dateMillis < nextDay }
    val todayIncome = todayTransactions.filter { it.type=="INCOME" }.sumOf { it.amountPaise }
    val todayExpense = todayTransactions.filter { it.type=="EXPENSE" }.sumOf { it.amountPaise }
    val monthIncome = monthTransactions.filter { it.type=="INCOME" }.sumOf { it.amountPaise }
    val monthExpense = monthTransactions.filter { it.type=="EXPENSE" }.sumOf { it.amountPaise }
    val categories = monthTransactions.filter { it.type=="EXPENSE" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amountPaise } }.toList().sortedByDescending { it.second }
    // Split the selected month into five 7-day buckets for the monthly chart.
    val weeklyTotals = (0..4).map { weekIndex ->
        val rows = monthTransactions.filter { transaction ->
            val dayOfMonth = Calendar.getInstance().apply { timeInMillis = transaction.dateMillis }.get(Calendar.DAY_OF_MONTH)
            (dayOfMonth - 1) / 7 == weekIndex
        }
        rows.filter { it.type == "INCOME" }.sumOf { it.amountPaise } to
            rows.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
    }

    LaunchedEffect(Unit) {
        val hash = prefs.pinHash()
        pinSetup = hash == null
        theme = prefs.theme()
        autoLock = prefs.autoLock()
        biometricLogin = prefs.biometricLogin()
        lockUntil = prefs.lockUntil()
        wrong = prefs.wrongAttempts().coerceIn(0, 4)
        // Re-check the persisted deadline at startup so process death/restart cannot bypass a live lockout.
        if (lockUntil > System.currentTimeMillis()) {
            screen = Screen.Lockout
        } else {
            lockUntil = 0L
            prefs.setLockUntil(0L)
            screen = Screen.Login
        }
    }
    val currentScreen by rememberUpdatedState(screen)
    DisposableEffect(lifecycleOwner, autoLock) {
        val observer = LifecycleEventObserver { _, event ->
            // Read the latest screen instead of the screen captured when this observer was created.
            if (event == Lifecycle.Event.ON_STOP && autoLock && currentScreen != Screen.Login && currentScreen != Screen.Lockout) { pin=""; screen = Screen.Login }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    fun toast(s: String) = Toast.makeText(context, s, Toast.LENGTH_SHORT).show()
    fun navigateBack() {
        when (screen) {
            Screen.AddExpense, Screen.AddIncome -> {
                if (amount.isNotBlank() || description.isNotBlank()) {
                    pendingBackTarget = Screen.Home
                    showDiscardChangesConfirm = true
                } else screen = Screen.Home
            }
            Screen.Detail -> {
                val original = selected
                val currentAmount = parseAmountPaise(amount)
                val changed = original == null || currentAmount != original.amountPaise || txType != original.type ||
                    category != original.category || description.trim() != original.description ||
                    date != original.dateMillis || payment != original.paymentMethod
                if (changed) {
                    pendingBackTarget = Screen.Transactions
                    showDiscardChangesConfirm = true
                } else {
                    selected = null; editId = 0L; screen = Screen.Transactions
                }
            }
            Screen.Transactions, Screen.Monthly, Screen.Category, Screen.Pdf, Screen.Backup, Screen.Settings -> screen = Screen.Home
            Screen.Login, Screen.Lockout, Screen.Home -> Unit
        }
    }
    BackHandler(enabled = screen != Screen.Login && screen != Screen.Lockout && screen != Screen.Home) {
        navigateBack()
    }
    fun resetForm(type: String) {
        txType=type; amount=""; category=if(type=="EXPENSE") expenseCategoryNames.first() else incomeCategoryNames.first()
        description=""; date=System.currentTimeMillis(); payment=Payments.first(); editId=0
    }
    fun beginEdit(t: Transaction) {
        selected=t; editId=t.id; txType=t.type; amount=(t.amountPaise/100.0).toString()
        category=t.category; description=t.description; date=t.dateMillis; payment=t.paymentMethod
        screen=Screen.Detail
    }
    fun saveTransaction() {
        if (savingTransaction) return
        val paise = parseAmountPaise(amount)
        if (paise == null) { toast("रकम सही दर्ज करें: 0 से अधिक और अधिकतम 2 दशमलव अंक"); return }
        if (category.isBlank() || payment !in Payments || txType !in listOf("EXPENSE", "INCOME") || date <= 0L) {
            toast("कृपया रकम, श्रेणी, भुगतान और तारीख सही भरें"); return
        }
        val editing = editId != 0L
        savingTransaction = true
        scope.launch {
            try {
                if (editing) {
                    val existing = repository.getById(editId)
                    if (existing == null) {
                        toast("यह लेन-देन अब मौजूद नहीं है। सूची फिर से खोलें।")
                        selected = null; editId = 0L; screen = Screen.Transactions
                        return@launch
                    }
                    val tx = Transaction(id=existing.id, type=txType, amountPaise=paise, category=category,
                        description=description.trim(), dateMillis=date, paymentMethod=payment,
                        createdAtMillis=existing.createdAtMillis)
                    repository.update(tx)
                } else {
                    val tx = Transaction(type=txType, amountPaise=paise, category=category,
                        description=description.trim(), dateMillis=date, paymentMethod=payment)
                    repository.insert(tx)
                }
                resetForm("EXPENSE"); selected=null; screen=Screen.Transactions
                toast(if (editing) "लेन-देन अपडेट हो गया" else "लेन-देन सेव हो गया")
            } catch (e: Exception) {
                toast("सेव नहीं हुआ। कृपया दोबारा प्रयास करें")
            } finally { savingTransaction = false }
        }
    }
    fun pdfReport() {
        var doc: PdfDocument? = null
        try {
            val pdfDoc = PdfDocument()
            doc = pdfDoc
            val records = all.filter { t ->
                t.dateMillis >= monthStart && t.dateMillis < nextMonth &&
                    (pdfFromDate == null || t.dateMillis >= pdfFromDate!!) &&
                    (pdfToDate == null || t.dateMillis < Calendar.getInstance().apply { timeInMillis=pdfToDate!!; add(Calendar.DAY_OF_MONTH,1) }.timeInMillis) &&
                    (pdfCategory == "सभी श्रेणियाँ" || t.category == pdfCategory)
            }.sortedWith(compareByDescending<Transaction> { it.dateMillis }.thenByDescending { it.id })
            val reportTotals = ReportMath.totals(records)
            val reportIncome = reportTotals.incomePaise
            val reportExpense = reportTotals.expensePaise
            val reportCategories = ReportMath.expenseByCategory(records).toList().sortedByDescending { it.second }
            val monthLabel = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(Date(monthStart))
            val reportTitle = when (pdfMode) {
                "CATEGORY" -> "श्रेणीवार रिपोर्ट"
                "TRANSACTIONS" -> "लेन-देन रिपोर्ट"
                else -> "मासिक सारांश"
            }
            val rows: List<String> = when (pdfMode) {
                "CATEGORY" -> if (reportCategories.isEmpty()) listOf("इस महीने कोई खर्च दर्ज नहीं है।") else reportCategories.mapIndexed { i, pair ->
                    "${i + 1}. श्रेणी: ${pair.first}\nखर्च: ${money(pair.second)}   |   कुल खर्च में हिस्सा: ${if (reportExpense > 0) pair.second * 100 / reportExpense else 0}%"
                }
                "MONTHLY" -> buildList {
                    add("कुल कमाई: ${money(reportIncome)}")
                    add("कुल खर्च: ${money(reportExpense)}")
                    add("बचत / शुद्ध अंतर: ${money(reportIncome - reportExpense)}")
                    add("श्रेणीवार खर्च")
                    if (reportCategories.isEmpty()) add("इस महीने कोई खर्च दर्ज नहीं है।")
                    else reportCategories.forEachIndexed { i, pair -> add("${i + 1}. ${pair.first} — ${money(pair.second)} (${if (reportExpense > 0) pair.second * 100 / reportExpense else 0}%)") }
                }
                else -> if (records.isEmpty()) listOf("इस महीने कोई लेन-देन दर्ज नहीं है।") else records.mapIndexed { i, t ->
                    "${i + 1}. तारीख: ${fmtDate.format(Date(t.dateMillis))}   |   प्रकार: ${if (t.type == "INCOME") "कमाई" else "खर्च"}\nश्रेणी: ${t.category}   |   भुगतान: ${t.paymentMethod}\nरकम: ${money(t.amountPaise)}\nविवरण: ${t.description.ifBlank { "—" }}"
                }
            }
            val pageWidth = 595
            val pageHeight = 842
            val left = 36f
            val right = 559f
            val bodyWidth = (right - left).toInt()
            val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 19f; color = android.graphics.Color.rgb(6, 78, 59); isFakeBoldText = true
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            }
            val subPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 10.5f; color = android.graphics.Color.DKGRAY
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            val bodyPaint = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 11.5f; color = android.graphics.Color.BLACK
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            val rulePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(190, 210, 198); strokeWidth = 1f
            }
            var pageNo = 0
            var page: PdfDocument.Page? = null
            var canvas: android.graphics.Canvas? = null
            var y = 0f
            fun drawHindiLine(text: String, x: Float, top: Float, width: Int, paint: TextPaint = bodyPaint): Int {
                val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(true)
                    .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE).build()
                canvas!!.save()
                canvas!!.translate(x, top)
                layout.draw(canvas!!)
                canvas!!.restore()
                return layout.height
            }
            fun startNewPage() {
                page?.let {
                    canvas!!.drawLine(left, 808f, right, 808f, rulePaint)
                    canvas!!.drawText("Daily Hisaab PRO", left, 826f, subPaint)
                    pdfDoc.finishPage(it)
                }
                pageNo++
                page = pdfDoc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
                canvas = page!!.canvas
                canvas!!.drawText("Daily Hisaab PRO", left, 32f, titlePaint)
                drawHindiLine("$reportTitle  •  $monthLabel", left, 39f, bodyWidth, subPaint.let { TextPaint(it) })
                drawHindiLine("कमाई: ${money(reportIncome)}     खर्च: ${money(reportExpense)}     बचत: ${money(reportIncome - reportExpense)}", left, 61f, bodyWidth, subPaint.let { TextPaint(it) })
                canvas!!.drawLine(left, 86f, right, 86f, rulePaint)
                y = 105f
            }
            startNewPage()
            rows.forEach { row ->
                val layout = StaticLayout.Builder.obtain(row, 0, row.length, bodyPaint, bodyWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setIncludePad(true)
                    .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                    .build()
                var firstLine = 0
                while (firstLine < layout.lineCount) {
                    if (y >= 785f) startNewPage()
                    val lineTop = layout.getLineTop(firstLine)
                    val available = (790f - y).toInt().coerceAtLeast(1)
                    var endLine = firstLine
                    while (endLine < layout.lineCount && layout.getLineBottom(endLine + 0) - lineTop <= available) endLine++
                    if (endLine == firstLine) {
                        startNewPage()
                        continue
                    }
                    val chunkBottom = layout.getLineBottom(endLine - 1)
                    val chunkHeight = (chunkBottom - lineTop).coerceAtLeast(1)
                    canvas!!.save()
                    canvas!!.clipRect(left, y, right, y + chunkHeight)
                    canvas!!.translate(left, y - lineTop)
                    layout.draw(canvas!!)
                    canvas!!.restore()
                    y += chunkHeight
                    firstLine = endLine
                    if (firstLine < layout.lineCount) startNewPage()
                }
                y += 8f
                if (y < 790f) canvas!!.drawLine(left, y - 3f, right, y - 3f, rulePaint)
            }
            page?.let {
                canvas!!.drawLine(left, 808f, right, 808f, rulePaint)
                canvas!!.drawText("Daily Hisaab PRO", left, 826f, subPaint)
                pdfDoc.finishPage(it)
            }
            val out = File(context.cacheDir, "Daily_Hisaab_${pdfMode.lowercase(Locale.US)}_${SimpleDateFormat("yyyy_MM_dd_HHmmss", Locale.US).format(Date())}.pdf")
            FileOutputStream(out).use { pdfDoc.writeTo(it) }
            pdfDoc.close(); doc = null
            val uri = FileProvider.getUriForFile(context, "com.dailyhisaab.pro.fileprovider", out)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(share, "PDF शेयर करें"))
            pdfRefresh++
            toast("PDF तैयार: ${out.name} (${pageNo} पेज)")
        } catch (e: Exception) {
            try { doc?.close() } catch (_: Exception) {}
            toast("PDF नहीं बन सका। कृपया दोबारा प्रयास करें")
        }
    }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val arr=JSONArray()
                all.forEach { t -> arr.put(JSONObject().put("id",t.id).put("type",t.type).put("amountPaise",t.amountPaise).put("category",t.category).put("description",t.description).put("dateMillis",t.dateMillis).put("paymentMethod",t.paymentMethod).put("createdAtMillis",t.createdAtMillis)) }
                val createdAt=System.currentTimeMillis()
                val payload=JSONObject()
                    .put("format","daily-hisaab-backup")
                    .put("version",1)
                    .put("createdAt",createdAt)
                    .put("recordCount",arr.length())
                    .put("transactions",arr)
                    .toString(2)
                val output=context.contentResolver.openOutputStream(uri,"wt") ?: error("फाइल नहीं खुली")
                output.bufferedWriter(Charsets.UTF_8).use { writer -> writer.write(payload); writer.flush() }
                toast("बैकअप सफल: ${all.size} रिकॉर्ड")
            } catch(e:Exception) { toast("बैकअप विफल: ${e.message}") }
        }
    }
    val sqliteBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.sqlite3")) { uri ->
        if (uri != null) scope.launch {
            try {
                // VACUUM INTO creates a consistent snapshot including committed WAL content,
                // avoiding a raw copy of the live database while writes may be in flight.
                val snapshot = File(context.cacheDir, "daily_hisaab_snapshot_${System.currentTimeMillis()}.db")
                try {
                    val escapedPath = snapshot.absolutePath.replace("'", "''")
                    db.openHelper.writableDatabase.execSQL("VACUUM INTO '$escapedPath'")
                    require(snapshot.isFile && snapshot.length() > 0L) { "सुरक्षित SQLite snapshot नहीं बना" }
                    SQLiteDatabase.openDatabase(snapshot.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { checkDb ->
                        val integrity = checkDb.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0) == "ok" }
                        require(integrity) { "बैकअप snapshot की integrity जाँच असफल" }
                        val count = checkDb.rawQuery("SELECT COUNT(*) FROM transactions", null).use { if (it.moveToFirst()) it.getLong(0) else -1L }
                        require(count >= 0L) { "बैकअप snapshot में transactions table नहीं है" }
                    }
                    context.contentResolver.openOutputStream(uri, "wt")?.use { output ->
                        snapshot.inputStream().use { input -> input.copyTo(output) }
                        output.flush()
                    } ?: error("चुनी हुई जगह पर फ़ाइल नहीं लिखी जा सकी")
                    toast("SQLite बैकअप सेव हो गया। इसे सुरक्षित जगह रखें।")
                } finally { snapshot.delete() }
            } catch (e: Exception) { toast("SQLite बैकअप विफल: ${e.message ?: "त्रुटि"}") }
        }
    }

    val sqliteRestoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            var candidate: File? = null
            try {
                val candidateFile = File(context.cacheDir, "sqlite_restore_candidate.db")
                candidate = candidateFile
                context.contentResolver.openInputStream(uri)?.use { input -> candidateFile.outputStream().use { output ->
                    val buffer = ByteArray(8192); var total = 0L
                    while (true) { val count = input.read(buffer); if (count < 0) break; total += count; require(total <= 100L * 1024 * 1024) { "SQLite बैकअप 100 MB से बड़ा है" }; output.write(buffer, 0, count) }
                } } ?: error("SQLite फ़ाइल नहीं पढ़ी जा सकी")
                require(candidateFile.length() > 0L) { "SQLite फ़ाइल खाली है" }
                val check = SQLiteDatabase.openDatabase(candidateFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
                try {
                    val integrity = check.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0) == "ok" }
                    require(integrity) { "SQLite फ़ाइल में corruption मिला" }
                    val unsafeObjects = check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type IN ('trigger','view')", null).use { if (it.moveToFirst()) it.getLong(0) else 1L }
                    require(unsafeObjects == 0L) { "SQLite बैकअप में unsupported trigger/view मिला" }
                    val version = check.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else -1 }
                    require(version == 3) { "SQLite बैकअप का database version समर्थित नहीं है (मिला: $version, चाहिए: 3)" }
                    val tableNames = check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { cursor -> buildSet { while (cursor.moveToNext()) add(cursor.getString(0)) } }
                    require(tableNames.containsAll(setOf("transactions", "categories", "app_settings", "room_master_table"))) { "SQLite में आवश्यक Room tables नहीं हैं" }
                    val allowedTables = setOf("transactions", "categories", "app_settings", "room_master_table", "android_metadata", "sqlite_sequence")
                    require(tableNames.all { it in allowedTables }) { "SQLite बैकअप में अनजान table मिला" }
                    val roomIdentity = check.rawQuery("SELECT identity_hash FROM room_master_table WHERE id = 42", null).use { if (it.moveToFirst()) it.getString(0) else null }
                    require(!roomIdentity.isNullOrBlank()) { "Room database identity hash नहीं मिला" }
                    val indexNames = check.rawQuery("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_autoindex%'", null).use { cursor -> buildSet { while (cursor.moveToNext()) add(cursor.getString(0)) } }
                    require(indexNames.containsAll(setOf("index_transactions_dateMillis", "index_transactions_type_dateMillis", "index_transactions_category_dateMillis", "index_transactions_paymentMethod_dateMillis", "index_categories_name_transactionType"))) { "SQLite backup में जरूरी indexes गायब हैं" }
                    val columns = check.rawQuery("PRAGMA table_info(transactions)", null).use { cursor -> buildSet { while (cursor.moveToNext()) add(cursor.getString(cursor.getColumnIndexOrThrow("name"))) } }
                    require(columns == setOf("id", "type", "amountPaise", "category", "description", "dateMillis", "paymentMethod", "createdAtMillis")) { "SQLite transactions schema मेल नहीं खाता" }
                    val invalidTransactions = check.rawQuery("SELECT COUNT(*) FROM transactions WHERE type NOT IN ('EXPENSE','INCOME') OR amountPaise <= 0 OR category IS NULL OR TRIM(category) = ''", null).use { if (it.moveToFirst()) it.getLong(0) else 1L }
                    require(invalidTransactions == 0L) { "SQLite बैकअप में अमान्य लेन-देन हैं" }
                    val categoryColumns = check.rawQuery("PRAGMA table_info(categories)", null).use { cursor -> buildSet { while (cursor.moveToNext()) add(cursor.getString(cursor.getColumnIndexOrThrow("name"))) } }
                    require(categoryColumns == setOf("id", "name", "transactionType", "isDefault", "createdAtMillis")) { "SQLite categories schema मेल नहीं खाता" }
                    val invalidCategories = check.rawQuery("SELECT COUNT(*) FROM categories WHERE transactionType NOT IN ('EXPENSE','INCOME') OR TRIM(name) = ''", null).use { if (it.moveToFirst()) it.getLong(0) else 1L }
                    require(invalidCategories == 0L) { "SQLite बैकअप में अमान्य श्रेणियाँ हैं" }
                    val settingColumns = check.rawQuery("PRAGMA table_info(app_settings)", null).use { cursor -> buildSet { while (cursor.moveToNext()) add(cursor.getString(cursor.getColumnIndexOrThrow("name"))) } }
                    require(settingColumns == setOf("key", "value", "updatedAtMillis")) { "SQLite settings schema मेल नहीं खाता" }
                    val fkErrors = check.rawQuery("PRAGMA foreign_key_check", null).use { it.count }
                    require(fkErrors == 0) { "SQLite बैकअप में foreign-key त्रुटि है" }
                    val count = check.rawQuery("SELECT COUNT(*) FROM transactions", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
                    require(count <= 100_000L) { "SQLite बैकअप में रिकॉर्ड सीमा से अधिक हैं" }
                } finally { check.close() }
                pendingSqliteRestore = candidateFile
                showSqliteRestoreConfirm = true
            } catch (e: Exception) {
                candidate?.delete()
                toast("SQLite रिस्टोर असफल; मौजूदा डेटा नहीं बदला: ${e.message ?: "फ़ाइल अमान्य"}")
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= 10_000_000) { "बैकअप फाइल 10 MB से बड़ी है" }
                        output.write(buffer, 0, count)
                    }
                    String(output.toByteArray(), Charsets.UTF_8)
                } ?: error("फाइल नहीं पढ़ी जा सकी")
                val root=JSONObject(raw)
                require(root.optString("format")=="daily-hisaab-backup" && root.optInt("version")==1) { "बैकअप फॉर्मेट/वर्जन सही नहीं है" }
                val array=root.getJSONArray("transactions")
                require(array.length() <= 100_000) { "रिकॉर्ड सीमा से अधिक है" }
                if(root.has("recordCount")) require(root.optInt("recordCount",-1)==array.length()) { "बैकअप रिकॉर्ड संख्या मेल नहीं खाती" }
                val restored=ArrayList<Transaction>(array.length())
                val now=System.currentTimeMillis()
                for(i in 0 until array.length()) {
                    val o=array.getJSONObject(i)
                    val type=o.getString("type")
                    val amountPaise=o.getLong("amountPaise")
                    val category=o.getString("category").trim()
                    val description=o.optString("description","")
                    val payment=o.optString("paymentMethod","नकद").trim()
                    val date=o.getLong("dateMillis")
                    val created=o.optLong("createdAtMillis",now)
                    require(type=="INCOME" || type=="EXPENSE") { "रिकॉर्ड ${i+1}: लेन-देन प्रकार अमान्य है" }
                    require(amountPaise in 1L..9_000_000_000_000L) { "रिकॉर्ड ${i+1}: रकम अमान्य है" }
                    require(category.isNotEmpty() && category.length<=80) { "रिकॉर्ड ${i+1}: श्रेणी अमान्य है" }
                    require(description.length<=500) { "रिकॉर्ड ${i+1}: विवरण बहुत लंबा है" }
                    require(payment in Payments) { "रिकॉर्ड ${i+1}: भुगतान का तरीका अमान्य है" }
                    require(date>0L && date<=now+86_400_000L) { "रिकॉर्ड ${i+1}: तारीख अमान्य है" }
                    require(created>0L && created<=now+86_400_000L) { "रिकॉर्ड ${i+1}: निर्माण तारीख अमान्य है" }
                    restored.add(Transaction(id=0,type=type,amountPaise=amountPaise,category=category,description=description,dateMillis=date,paymentMethod=payment,createdAtMillis=created))
                }
                pendingRestore=restored
                showRestoreConfirm=true
            } catch(e:Exception) { toast("रिस्टोर असफल; डेटा नहीं बदला: ${e.message}") }
        }
    }

    fun backupJson() { backupLauncher.launch("Daily_Hisaab_backup_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.json") }
    fun openPdf(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "com.dailyhisaab.pro.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            context.startActivity(intent)
        } catch (_: Exception) { toast("PDF खोलने वाला ऐप नहीं मिला। शेयर करके खोलें।") }
    }
    fun sharePdf(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "com.dailyhisaab.pro.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply { type="application/pdf"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            context.startActivity(Intent.createChooser(intent,"PDF शेयर करें"))
        } catch (_: Exception) { toast("PDF शेयर नहीं हो सकी") }
    }
    val cachedPdfFiles = remember(pdfRefresh) { context.cacheDir.listFiles()?.filter { it.isFile && it.extension.equals("pdf", true) }?.sortedByDescending { it.lastModified() } ?: emptyList() }

    val useDarkTheme = theme=="Dark" || (theme=="System" && isSystemInDarkTheme())
    MaterialTheme(colorScheme=if(useDarkTheme) darkColorScheme(primary=Color(0xFF52D49A), secondary=Color(0xFF8ADBB6), background=Color(0xFF101714), surface=Color(0xFF18211C)) else lightColorScheme(primary=Green, secondary=DarkGreen, background=Color(0xFFF6F8F7), surface=Color.White)) {
        Surface(Modifier.fillMaxSize(), color=MaterialTheme.colorScheme.background) {
            when(screen) {
                Screen.Login, Screen.Lockout -> PinScreen(
                    setup=pinSetup, pin=pin, lockRemaining=(LockoutPolicy.remainingSeconds(lockUntil, System.currentTimeMillis()) + lockPulse*0),
                    onDigit={ d ->
                        if (lockUntil > System.currentTimeMillis() || pinVerifying || pin.length >= 4) return@PinScreen
                        pin += d
                        if (pin.length == 4) {
                            pinVerifying = true
                            val submittedPin = pin
                            scope.launch {
                                try {
                                    if (pinSetup) {
                                        if (firstPin.isEmpty()) {
                                            firstPin = submittedPin; pin = ""; message = "PIN फिर दर्ज करें"
                                        } else if (firstPin == submittedPin) {
                                            prefs.setPinHash(pinHash(submittedPin)); pinSetup = false; pin = ""; firstPin = ""; message = "PIN सेट हो गया"; screen = Screen.Home
                                        } else {
                                            firstPin = ""; pin = ""; message = "PIN मेल नहीं खाता, फिर कोशिश करें"
                                        }
                                    } else if (verifyPin(submittedPin, prefs.pinHash())) {
                                        wrong = 0; prefs.setWrongAttempts(0); prefs.setLockUntil(0L); lockUntil = 0L; pin = ""; screen = Screen.Home; message = ""
                                    } else {
                                        wrong++; prefs.setWrongAttempts(wrong); pin = ""; message = "गलत PIN"
                                        if (LockoutPolicy.shouldLock(wrong)) {
                                            lockUntil = System.currentTimeMillis() + LockoutPolicy.LOCK_DURATION_MILLIS
                                            prefs.setLockUntil(lockUntil); prefs.setWrongAttempts(0); screen = Screen.Lockout; wrong = 0
                                        }
                                    }
                                } catch (e: Exception) {
                                    pin = ""
                                    message = "सुरक्षा सेटिंग सेव नहीं हुई। दोबारा प्रयास करें"
                                } finally {
                                    pinVerifying = false
                                }
                            }
                        }
                    },
                    onDelete={ if (!pinVerifying) pin=pin.dropLast(1) }, onForgot={ showRecoveryConfirm=true },
                    onBiometric={
                        if (!pinSetup && biometricLogin && lockUntil <= System.currentTimeMillis()) {
                            val activity = context as? FragmentActivity
                            if (activity == null) toast("बायोमेट्रिक इस स्क्रीन पर उपलब्ध नहीं है") else {
                                val manager = BiometricManager.from(context)
                                if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) toast("फोन में मजबूत बायोमेट्रिक सेटअप उपलब्ध नहीं है") else {
                                    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
                                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                            super.onAuthenticationSucceeded(result)
                                            scope.launch { wrong=0; prefs.setWrongAttempts(0); prefs.setLockUntil(0L); lockUntil=0L; pin=""; screen=Screen.Home; message="" }
                                        }
                                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { super.onAuthenticationError(errorCode, errString); message=errString.toString() }
                                        override fun onAuthenticationFailed() { super.onAuthenticationFailed(); message="बायोमेट्रिक पहचान नहीं हुई; PIN डालें" }
                                    })
                                    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Daily Hisaab PRO").setSubtitle("पहचान सत्यापित करें").setNegativeButtonText("PIN इस्तेमाल करें").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
                                }
                            }
                        }
                    },
                    message=message, onTick={ lockPulse++; if(lockUntil<=System.currentTimeMillis() && screen==Screen.Lockout) { screen=Screen.Login; scope.launch { prefs.setLockUntil(0L) }; lockUntil=0L } },
                    biometricEnabled=biometricLogin
                )
                Screen.Home -> Scaffold(bottomBar={ BottomNav(Screen.Home){ screen=it } }) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        item { Header("Daily Hisaab PRO", "आपका निजी वित्तीय साथी") }
                        item { Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(if(selectedDayStart==currentDay) "आज का हिसाब" else "चुनी तारीख का हिसाब",fontWeight=FontWeight.Bold); Text(fmtDate.format(Date(selectedDayStart)),color=Color.Gray,fontSize=12.sp) }
                            OutlinedButton(onClick={ val c=Calendar.getInstance().apply { timeInMillis=homeDate }; android.app.DatePickerDialog(context,{_,y,m,d -> homeDate=Calendar.getInstance().apply { set(y,m,d,0,0,0);set(Calendar.MILLISECOND,0) }.timeInMillis },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }) { Icon(Icons.Default.CalendarMonth,null); Spacer(Modifier.width(5.dp)); Text("तारीख चुनें") }
                            TextButton(onClick={homeDate=currentDay}) { Text("आज") }
                        } }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            StatCard("चुनी तारीख की कमाई",money(todayIncome),PaleGreen,Modifier.weight(1f))
                            StatCard("चुनी तारीख का खर्च",money(todayExpense),Color(0xFFFFE7E7),Modifier.weight(1f))
                            StatCard("बचत",money(todayIncome-todayExpense),Color(0xFFE4F2FF),Modifier.weight(1f))
                        } }
                        item { Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(16.dp)) {
                            Text("इस महीने का सारांश",fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Row { StatText("कुल कमाई",money(monthIncome),Green,Modifier.weight(1f)); StatText("कुल खर्च",money(monthExpense),Red,Modifier.weight(1f)); StatText("बचत",money(monthIncome-monthExpense),Blue,Modifier.weight(1f)) }
                        } } }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            Button(onClick={ resetForm("EXPENSE");screen=Screen.AddExpense },modifier=Modifier.weight(1f)) { Icon(Icons.Default.Add,null);Text("खर्च जोड़ें") }
                            Button(onClick={ resetForm("INCOME");screen=Screen.AddIncome },modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Blue)) { Icon(Icons.Default.Add,null);Text("कमाई जोड़ें") }
                        } }
                        item { Text("कैटेगरी शॉर्टकट",fontWeight=FontWeight.Bold) }
                        item { CategoryGrid(expenseCategoryNames) { name -> query=name; txTypeFilter="EXPENSE"; txCategoryFilter="सभी श्रेणियाँ"; txPaymentFilter="सभी भुगतान"; txFromDate=null; txToDate=null; screen=Screen.Transactions } }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={screen=Screen.Category},modifier=Modifier.weight(1f)){Text("श्रेणी रिपोर्ट")} ; OutlinedButton(onClick={screen=Screen.Pdf},modifier=Modifier.weight(1f)){Text("PDF रिपोर्ट")} } }
                        item { Text("हाल के लेन-देन",fontWeight=FontWeight.Bold) }
                        items(all.take(5)) { TxRow(it) { beginEdit(it) } }
                    }
                }
                Screen.AddExpense, Screen.AddIncome, Screen.Detail -> {
                    val isEdit=screen==Screen.Detail
                    Scaffold(topBar={ TopBar(if(isEdit) "लेन-देन एडिट" else screen.title){navigateBack()} }) { padding ->
                        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected=txType=="EXPENSE",onClick={txType="EXPENSE";category=expenseCategoryNames.first()},label={Text("खर्च")})
                                FilterChip(selected=txType=="INCOME",onClick={txType="INCOME";category=incomeCategoryNames.first()},label={Text("कमाई")})
                            } }
                            item { OutlinedTextField(value=amount,onValueChange={amount=it.filter { c -> c.isDigit() || c=='.' }.take(12)},label={Text("रकम (₹)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth()) }
                            item { Text("श्रेणी चुनें",fontWeight=FontWeight.Bold) }
                            item { CategoryGrid(if(txType=="EXPENSE") expenseCategoryNames else incomeCategoryNames) { category=it } }
                            item { OutlinedTextField(value=description,onValueChange={description=it},label={Text("विवरण (वैकल्पिक)")},modifier=Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(
                                value=fmtDate.format(Date(date)), onValueChange={}, readOnly=true,
                                label={Text("तारीख")}, modifier=Modifier.fillMaxWidth().clickable {
                                    val c=Calendar.getInstance().apply{timeInMillis=date}
                                    android.app.DatePickerDialog(context,{_,y,m,d -> val cc=Calendar.getInstance().apply{set(y,m,d,12,0,0);set(Calendar.MILLISECOND,0)};date=cc.timeInMillis},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
                                },
                                trailingIcon={ IconButton(onClick={
                                    val c=Calendar.getInstance().apply{timeInMillis=date}
                                    android.app.DatePickerDialog(context,{_,y,m,d -> val cc=Calendar.getInstance().apply{set(y,m,d,12,0,0);set(Calendar.MILLISECOND,0)};date=cc.timeInMillis},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
                                }) { Icon(Icons.Default.CalendarMonth,"तारीख चुनें") } }
                            ) }
                            item { Text("भुगतान का तरीका",fontWeight=FontWeight.Bold) }
                            item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { Payments.forEach { p -> FilterChip(selected=payment==p,onClick={payment=p},label={Text(p)}) } } }
                            item { Button(onClick={saveTransaction()},enabled=!savingTransaction,modifier=Modifier.fillMaxWidth()) { Text(if(savingTransaction) "सेव हो रहा है…" else if(isEdit) "अपडेट करें" else "सेव करें") } }
                            if(isEdit) item { OutlinedButton(onClick={showDeleteTransactionConfirm=true},enabled=!savingTransaction,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=Red)) { Icon(Icons.Default.Delete,null);Text("लेन-देन हटाएँ") } }
                        }
                    }
                }
                Screen.Transactions -> {
                    val categoryOptions = listOf("सभी श्रेणियाँ") + (all.map { it.category }.filter { it.isNotBlank() } + expenseCategoryNames + incomeCategoryNames).distinct().sorted()
                    val filteredTransactions = filterTransactions(
                        transactions=all,
                        query=query,
                        type=txTypeFilter,
                        category=txCategoryFilter,
                        paymentMethod=txPaymentFilter,
                        fromDateMillis=txFromDate,
                        toDateMillis=txToDate
                    )
                    Scaffold(topBar={TopBar("लेन-देन सूची"){navigateBack()}},bottomBar={BottomNav(Screen.Transactions){screen=it}}) { padding ->
                        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=12.dp, vertical=8.dp)) {
                            OutlinedTextField(value=query,onValueChange={query=it},label={Text("नाम, विवरण, रकम या श्रेणी खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Text("प्रकार",fontWeight=FontWeight.SemiBold,fontSize=13.sp)
                            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                FilterChip(selected=txTypeFilter=="ALL",onClick={txTypeFilter="ALL"},label={Text("सभी")})
                                FilterChip(selected=txTypeFilter=="EXPENSE",onClick={txTypeFilter="EXPENSE"},label={Text("खर्च")})
                                FilterChip(selected=txTypeFilter=="INCOME",onClick={txTypeFilter="INCOME"},label={Text("कमाई")})
                            }
                            var categoryMenu by remember { mutableStateOf(false) }
                            var paymentMenu by remember { mutableStateOf(false) }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
                                Box(Modifier.weight(1f)) {
                                    OutlinedButton(onClick={categoryMenu=true},modifier=Modifier.fillMaxWidth()) { Text(txCategoryFilter,maxLines=1); Icon(Icons.Default.ArrowDropDown,null) }
                                    DropdownMenu(expanded=categoryMenu,onDismissRequest={categoryMenu=false},modifier=Modifier.heightIn(max=320.dp)) {
                                        categoryOptions.forEach { option -> DropdownMenuItem(text={Text(option)},onClick={txCategoryFilter=option;categoryMenu=false}) }
                                    }
                                }
                                Box(Modifier.weight(1f)) {
                                    OutlinedButton(onClick={paymentMenu=true},modifier=Modifier.fillMaxWidth()) { Text(txPaymentFilter,maxLines=1); Icon(Icons.Default.ArrowDropDown,null) }
                                    DropdownMenu(expanded=paymentMenu,onDismissRequest={paymentMenu=false}) {
                                        (listOf("सभी भुगतान") + Payments + all.map { it.paymentMethod }.distinct()).distinct().forEach { option -> DropdownMenuItem(text={Text(option)},onClick={txPaymentFilter=option;paymentMenu=false}) }
                                    }
                                }
                            }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick={
                                    val initial=Calendar.getInstance().apply { timeInMillis=txFromDate ?: System.currentTimeMillis() }
                                    android.app.DatePickerDialog(context,{_,y,m,d -> txFromDate=Calendar.getInstance().apply { set(y,m,d,0,0,0);set(Calendar.MILLISECOND,0) }.timeInMillis },initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
                                },modifier=Modifier.weight(1f)) { Text("से: ${txFromDate?.let { fmtDate.format(Date(it)) } ?: "कोई भी तारीख"}",maxLines=1) }
                                OutlinedButton(onClick={
                                    val initial=Calendar.getInstance().apply { timeInMillis=txToDate ?: System.currentTimeMillis() }
                                    android.app.DatePickerDialog(context,{_,y,m,d -> txToDate=Calendar.getInstance().apply { set(y,m,d,0,0,0);set(Calendar.MILLISECOND,0) }.timeInMillis },initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
                                },modifier=Modifier.weight(1f)) { Text("तक: ${txToDate?.let { fmtDate.format(Date(it)) } ?: "कोई भी तारीख"}",maxLines=1) }
                            }
                            Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                                Text("${filteredTransactions.size} लेन-देन",fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f))
                                TextButton(onClick={query="";txTypeFilter="ALL";txCategoryFilter="सभी श्रेणियाँ";txPaymentFilter="सभी भुगतान";txFromDate=null;txToDate=null}) { Icon(Icons.Default.Refresh,null);Text("रीसेट") }
                            }
                            if(txFromDate!=null && txToDate!=null && txFromDate!!>txToDate!!) {
                                Text("तारीख की सीमा गलत है: 'से' तारीख, 'तक' तारीख से बाद की नहीं हो सकती।",color=Red,fontSize=12.sp)
                            }
                            if(filteredTransactions.isEmpty()) {
                                Column(Modifier.fillMaxWidth().weight(1f),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                                    Icon(Icons.Default.ReceiptLong,null,tint=Color.Gray,modifier=Modifier.size(44.dp));Text("कोई लेन-देन नहीं मिला",fontWeight=FontWeight.SemiBold);Text("फ़िल्टर बदलें या रीसेट दबाएँ",color=Color.Gray,fontSize=12.sp)
                                }
                            } else {
                                val groupedByDay = filteredTransactions.groupBy { t -> Calendar.getInstance().apply { timeInMillis=t.dateMillis; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis }.toSortedMap(compareByDescending { it })
                                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)) {
                                    groupedByDay.forEach { (dayMillis, dayRows) ->
                                        item(key="date_$dayMillis") { Text(fmtDate.format(Date(dayMillis)),fontWeight=FontWeight.Bold,color=DarkGreen,modifier=Modifier.fillMaxWidth().background(PaleGreen,RoundedCornerShape(8.dp)).padding(horizontal=12.dp,vertical=7.dp)) }
                                        items(dayRows,key={it.id}) { TxRow(it) { beginEdit(it) } }
                                    }
                                }
                            }
                        }
                    }
                }
                Screen.Monthly -> Scaffold(topBar={TopBar("मासिक रिपोर्ट"){navigateBack()}},bottomBar={BottomNav(Screen.Monthly){screen=it}}) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        item { MonthPicker(monthOffset){monthOffset=it} }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { StatCard("कमाई",money(monthIncome),PaleGreen,Modifier.weight(1f));StatCard("खर्च",money(monthExpense),Color(0xFFFFE7E7),Modifier.weight(1f));StatCard("बचत",money(monthIncome-monthExpense),Color(0xFFE4F2FF),Modifier.weight(1f)) } }
                        item { Text("सप्ताह के अनुसार कमाई बनाम खर्च",fontWeight=FontWeight.Bold) }
                        item { WeeklyBarChart(weeklyTotals) }
                        item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick={screen=Screen.Category}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.PieChart,null); Spacer(Modifier.width(6.dp)); Text("श्रेणीवार रिपोर्ट") }
                            Button(onClick={screen=Screen.Pdf}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.PictureAsPdf,null); Spacer(Modifier.width(6.dp)); Text("PDF रिपोर्ट") }
                        } }
                        item { Text("श्रेणी अनुसार खर्च",fontWeight=FontWeight.Bold) }
                        items(categories) { (name,total) -> Row(Modifier.fillMaxWidth().padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically) { Text(name,Modifier.weight(1f));Text("${if(monthExpense>0) (total*100/monthExpense) else 0}%",color=Green);Spacer(Modifier.width(12.dp));Text(money(total),fontWeight=FontWeight.Bold) } }
                    }
                }
                Screen.Category -> Scaffold(topBar={TopBar("श्रेणीवार विवरण"){navigateBack()}},bottomBar={BottomNav(Screen.Category){screen=it}}) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        item { MonthPicker(monthOffset){monthOffset=it} }
                        item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick={screen=Screen.Monthly}, modifier=Modifier.weight(1f)) { Text("मासिक रिपोर्ट") }
                            Button(onClick={screen=Screen.Pdf}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.PictureAsPdf,null); Spacer(Modifier.width(6.dp)); Text("PDF बनाएं") }
                        } }
                        item { Text("कैटेगरी चार्ट",fontWeight=FontWeight.Bold) }
                        item { if (categories.isEmpty()) Text("इस महीने कोई खर्च दर्ज नहीं है।", color=Color.Gray) else DonutChart(categories.map{it.second}) }
                        if (categories.isNotEmpty()) items(categories) { (name,total) -> Card(Modifier.fillMaxWidth().clickable { query="";txTypeFilter="EXPENSE";txCategoryFilter=name;txPaymentFilter="सभी भुगतान";txFromDate=null;txToDate=null;screen=Screen.Transactions }) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { Text(name,Modifier.weight(1f));Text("${if(monthExpense>0) total*100/monthExpense else 0}%");Spacer(Modifier.width(12.dp));Text(money(total),fontWeight=FontWeight.Bold) } } }
                    }
                }
                Screen.Pdf -> Scaffold(topBar={TopBar("PDF रिपोर्ट बनाएं"){navigateBack()}},bottomBar={BottomNav(Screen.Pdf){screen=it}}) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        item { MonthPicker(monthOffset){monthOffset=it} }
                        item { Text("वैकल्पिक तारीख फ़िल्टर",fontWeight=FontWeight.Bold) }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick={ val c=Calendar.getInstance().apply { timeInMillis=pdfFromDate ?: monthStart }; android.app.DatePickerDialog(context,{_,y,m,d -> pdfFromDate=Calendar.getInstance().apply { set(y,m,d,0,0,0);set(Calendar.MILLISECOND,0) }.timeInMillis },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() },modifier=Modifier.weight(1f)) { Text("से: ${pdfFromDate?.let { fmtDate.format(Date(it)) } ?: "कोई भी"}",maxLines=1) }
                            OutlinedButton(onClick={ val c=Calendar.getInstance().apply { timeInMillis=pdfToDate ?: monthStart }; android.app.DatePickerDialog(context,{_,y,m,d -> pdfToDate=Calendar.getInstance().apply { set(y,m,d,0,0,0);set(Calendar.MILLISECOND,0) }.timeInMillis },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() },modifier=Modifier.weight(1f)) { Text("तक: ${pdfToDate?.let { fmtDate.format(Date(it)) } ?: "कोई भी"}",maxLines=1) }
                        } }
                        item { Row(verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(onClick={pdfCategoryMenu=true},modifier=Modifier.fillMaxWidth()) { Text("श्रेणी: $pdfCategory",maxLines=1); Icon(Icons.Default.ArrowDropDown,null) }
                                DropdownMenu(expanded=pdfCategoryMenu,onDismissRequest={pdfCategoryMenu=false}) {
                                    (listOf("सभी श्रेणियाँ") + (all.map { it.category }.filter { it.isNotBlank() } + expenseCategoryNames + incomeCategoryNames).distinct().sorted()).forEach { option -> DropdownMenuItem(text={Text(option)},onClick={pdfCategory=option;pdfCategoryMenu=false}) }
                                }
                            }
                            TextButton(onClick={pdfFromDate=null;pdfToDate=null;pdfCategory="सभी श्रेणियाँ"}) { Text("रीसेट") }
                        } }
                        item { if(pdfFromDate!=null && pdfToDate!=null && pdfFromDate!!>pdfToDate!!) Text("तारीख सीमा गलत है",color=Red) }
                        item { ReportOption("मासिक सारांश PDF","चुने महीने के कुल और श्रेणी सारांश") { pdfMode="MONTHLY"; if(pdfFromDate==null || pdfToDate==null || pdfFromDate!!<=pdfToDate!!) pdfReport() else toast("तारीख सीमा सही चुनें") } }
                        item { ReportOption("लेन-देन सूची PDF","तारीख और श्रेणी फ़िल्टर सहित रिकॉर्ड") { pdfMode="TRANSACTIONS"; if(pdfFromDate==null || pdfToDate==null || pdfFromDate!!<=pdfToDate!!) pdfReport() else toast("तारीख सीमा सही चुनें") } }
                        item { ReportOption("श्रेणीवार रिपोर्ट PDF","चुने महीने और फ़िल्टर के अनुसार खर्च") { pdfMode="CATEGORY"; if(pdfFromDate==null || pdfToDate==null || pdfFromDate!!<=pdfToDate!!) pdfReport() else toast("तारीख सीमा सही चुनें") } }
                        item { Text("हाल की PDF फ़ाइलें",fontWeight=FontWeight.Bold) }
                        if(cachedPdfFiles.isEmpty()) item { Text("अभी कोई PDF नहीं बनी है।",color=Color.Gray) }
                        items(cachedPdfFiles,key={it.absolutePath}) { file ->
                            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(file.name,fontWeight=FontWeight.SemiBold); Text("${file.length()/1024} KB",style=MaterialTheme.typography.bodySmall,color=Color.Gray) }
                                IconButton(onClick={openPdf(file)}) { Icon(Icons.Default.OpenInNew,"PDF खोलें") }
                                IconButton(onClick={sharePdf(file)}) { Icon(Icons.Default.Share,"PDF शेयर करें") }
                            }
                        }
                    }
                }
                Screen.Backup -> Scaffold(topBar={TopBar("बैकअप और रिस्टोर"){navigateBack()}},bottomBar={BottomNav(Screen.Backup){screen=it}}) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        ReportOption("बैकअप फ़ाइल बनाएं","JSON बैकअप को मोबाइल, डाउनलोड या चुनी हुई लोकेशन पर सेव करें"){backupJson()}
                        ReportOption("SQLite डेटाबेस बैकअप","पूरा Room/SQLite डेटाबेस फ़ाइल के रूप में सेव करें"){sqliteBackupLauncher.launch("Daily_Hisaab_SQLite_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.sqlite")}
                        ReportOption("SQLite बैकअप से रिस्टोर","केवल इस ऐप के version 3 SQLite backup को जाँचकर रिस्टोर करें"){sqliteRestoreLauncher.launch(arrayOf("application/vnd.sqlite3", "application/octet-stream", "application/x-sqlite3", "*/*"))}
                        ReportOption("बैकअप से रिस्टोर","मोबाइल या Drive फ़ाइल पिकर से JSON बैकअप चुनें"){restoreLauncher.launch(arrayOf("application/json","text/json"))}
                        ReportOption("Drive / फ़ाइल ऐप में सेव करें","सेव लोकेशन चुनें; Drive उपलब्ध हो तो वहाँ सेव कर सकते हैं"){backupJson()}
                        ReportOption("Drive / फ़ाइल ऐप से रिस्टोर","चुने हुए स्थान से JSON बैकअप खोलें"){restoreLauncher.launch(arrayOf("application/json","text/json"))}
                        Text("JSON और SQLite दोनों तरह का लोकल बैकअप उपलब्ध है। JSON रिस्टोर मौजूदा लेन-देन बदलता है; SQLite रिस्टोर केवल इस ऐप के database version 3 की integrity/schema जाँच के बाद होता है और ऐप डेटाबेस को बदलता है। Android फ़ाइल पिकर में Drive दिखे तो इस्तेमाल कर सकते हैं; native Google OAuth कनेक्शन नहीं है। नियमित बैकअप अलग सुरक्षित जगह रखें।",style=MaterialTheme.typography.bodySmall)
                    }
                }
                Screen.Settings -> Scaffold(topBar={TopBar("सेटिंग्स"){navigateBack()}},bottomBar={BottomNav(Screen.Settings){screen=it}}) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        item { ReportOption("PIN बदलें","मौजूदा PIN सत्यापित करके नया PIN सेट करें"){oldPin="";newPin="";pinDialogError="";showPinChange=true}}
                        item { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Auto Lock",fontWeight=FontWeight.SemiBold); Text(if(autoLock) "ऐप बैकग्राउंड में जाने पर PIN स्क्रीन खुलेगी" else "Auto Lock बंद है",style=MaterialTheme.typography.bodySmall,color=Color.Gray) };Switch(checked=autoLock,onCheckedChange={value -> autoLock=value;scope.launch { prefs.setAutoLock(value); toast(if(value) "Auto Lock चालू" else "Auto Lock बंद") }}) } }
                        item { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("बायोमेट्रिक लॉगिन",fontWeight=FontWeight.SemiBold); Text("PIN सेट होने के बाद फिंगरप्रिंट/डिवाइस बायोमेट्रिक से खोलें",style=MaterialTheme.typography.bodySmall,color=Color.Gray) }; Switch(checked=biometricLogin,onCheckedChange={value ->
                            val supported=BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS
                            if(value && !supported) toast("पहले फोन की सेटिंग में बायोमेट्रिक सेट करें") else { biometricLogin=value; scope.launch { prefs.setBiometricLogin(value); toast(if(value) "बायोमेट्रिक लॉगिन चालू" else "बायोमेट्रिक लॉगिन बंद") } }
                        }) } }
                        item { Text("थीम",fontWeight=FontWeight.Bold) }
                        item { Row { listOf("Light","Dark","System").forEach { option -> FilterChip(selected=theme==option,onClick={theme=option;scope.launch { prefs.setTheme(option); toast("थीम सेव: $option") }},label={Text(option)},modifier=Modifier.padding(end=6.dp)) } } }
                        item { Text("आपकी थीम और Auto Lock की पसंद इस डिवाइस पर सेव रहती है।",style=MaterialTheme.typography.bodySmall,color=Color.Gray) }
                        item { ReportOption("डेटा निर्यात (CSV)","लेन-देन की CSV फाइल शेयर करें"){exportCsv(context,all);val csv=File(context.cacheDir,"Daily_Hisaab_transactions.csv");val uri=FileProvider.getUriForFile(context,"com.dailyhisaab.pro.fileprovider",csv);val intent=Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};context.startActivity(Intent.createChooser(intent,"CSV शेयर करें"))}}
                        item { ReportOption("सभी डेटा हटाएँ","यह क्रिया वापस नहीं हो सकती"){showClearConfirm=true}}
                        item { ReportOption("श्रेणियाँ प्रबंधित करें","अपनी खर्च और कमाई की श्रेणियाँ जोड़ें या हटाएँ"){newCategoryName="";newCategoryType="EXPENSE";showCategoryEditor=true} }
                        item { ReportOption("भाषा: हिंदी","इस संस्करण में इंटरफ़ेस हिंदी में उपलब्ध है"){toast("अभी केवल हिंदी इंटरफ़ेस उपलब्ध है")}}
                        item { ReportOption("हमारे बारे में","Daily Hisaab PRO • 1.0.0"){toast("Daily Hisaab PRO • संस्करण 1.0.0")}}
                        item { ReportOption("ऐप शेयर करें","परिवार या मित्रों के साथ ऐप शेयर करें"){val intent=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"Daily Hisaab PRO — निजी आय-खर्च का हिसाब रखने वाला ऐप।")};context.startActivity(Intent.createChooser(intent,"ऐप शेयर करें"))}}
                    }
                }
            }
            if (showDiscardChangesConfirm) AlertDialog(
                onDismissRequest = { showDiscardChangesConfirm = false },
                title = { Text("बिना सेव किए वापस जाएँ?") },
                text = { Text("आपके बदलाव सेव नहीं हुए हैं। वापस जाने पर ये बदलाव हट जाएंगे।") },
                confirmButton = { TextButton(onClick = {
                    showDiscardChangesConfirm = false
                    if (pendingBackTarget == Screen.Transactions) { selected = null; editId = 0L }
                    if (pendingBackTarget == Screen.Home) { resetForm("EXPENSE") }
                    screen = pendingBackTarget
                }) { Text("बदलाव छोड़ें", color = Red) } },
                dismissButton = { TextButton(onClick = { showDiscardChangesConfirm = false }) { Text("रुकें") } }
            )
            if(showRestoreConfirm) AlertDialog(onDismissRequest={showRestoreConfirm=false;pendingRestore=null},title={Text("बैकअप रिस्टोर करें?")},text={Text("${pendingRestore?.size ?: 0} रिकॉर्ड रिस्टोर होंगे। वर्तमान लेन-देन बदल दिए जाएंगे। पहले बैकअप सुनिश्चित करें।")},confirmButton={TextButton(onClick={scope.launch { val restored=pendingRestore; if(restored!=null) { try { repository.replaceAll(restored);toast("रिस्टोर सफल: ${restored.size} रिकॉर्ड") } catch(e:Exception) { toast("रिस्टोर असफल: ${e.message}") } };pendingRestore=null;showRestoreConfirm=false }}){Text("रिस्टोर करें",color=Red)}},dismissButton={TextButton(onClick={showRestoreConfirm=false;pendingRestore=null}){Text("रद्द करें")}})
            if(showSqliteRestoreConfirm) AlertDialog(
                onDismissRequest={ showSqliteRestoreConfirm=false; pendingSqliteRestore?.delete(); pendingSqliteRestore=null },
                title={Text("SQLite डेटाबेस रिस्टोर करें?")},
                text={Text("जाँची गई SQLite फ़ाइल मौजूदा ऐप डेटाबेस को पूरी तरह बदल देगी। रिस्टोर से पहले वर्तमान डेटा का अलग बैकअप रखें। ऐप फिर से शुरू होगा।")},
                confirmButton={TextButton(onClick={
                    val candidate=pendingSqliteRestore
                    if(candidate==null) { showSqliteRestoreConfirm=false; toast("SQLite फ़ाइल नहीं मिली") }
                    else try {
                        AppDatabase.replaceFromValidatedBackup(context, candidate)
                        candidate.delete()
                        pendingSqliteRestore=null; showSqliteRestoreConfirm=false; toast("SQLite रिस्टोर सफल; ऐप फिर खुल रहा है")
                        (context as? Activity)?.recreate()
                    } catch(e:Exception) { toast("SQLite रिस्टोर विफल: ${e.message ?: "त्रुटि"}"); showSqliteRestoreConfirm=false; pendingSqliteRestore?.delete(); pendingSqliteRestore=null }
                }) { Text("डेटाबेस बदलें", color=Red) } },
                dismissButton={TextButton(onClick={showSqliteRestoreConfirm=false; pendingSqliteRestore?.delete(); pendingSqliteRestore=null}) { Text("रद्द करें") }}
            )
            if(showRecoveryConfirm) AlertDialog(onDismissRequest={showRecoveryConfirm=false},title={Text("PIN भूल गए?")},text={Text("सुरक्षा के कारण PIN को वापस नहीं देखा जा सकता। नया PIN बनाने के लिए सभी लेन-देन हटाने होंगे। पहले बैकअप बना लें।")},confirmButton={TextButton(onClick={scope.launch { repository.deleteAll();prefs.clearPin();prefs.setWrongAttempts(0);prefs.setLockUntil(0L);pinSetup=true;pin="";firstPin="";lockUntil=0L;showRecoveryConfirm=false;screen=Screen.Login;toast("डेटा हट गया। नया PIN सेट करें") }}){Text("डेटा मिटाएँ और PIN रीसेट करें",color=Red)}},dismissButton={TextButton(onClick={showRecoveryConfirm=false}){Text("रद्द करें")}})
            if(showDeleteTransactionConfirm) AlertDialog(
                onDismissRequest={showDeleteTransactionConfirm=false},
                title={Text("यह लेन-देन हटाएँ?", fontWeight=FontWeight.Bold)},
                text={Text("${selected?.category ?: "लेन-देन"} • ${selected?.let { money(it.amountPaise) } ?: ""}\nयह रिकॉर्ड स्थायी रूप से हट जाएगा। यह क्रिया वापस नहीं होगी।")},
                confirmButton={TextButton(onClick={
                    if (!savingTransaction) scope.launch {
                        savingTransaction=true
                        try {
                            val targetId=editId
                            val existing=if(targetId>0L) repository.getById(targetId) else null
                            if(existing==null) toast("यह लेन-देन पहले ही हट चुका है")
                            else { repository.delete(existing); toast("लेन-देन हटाया गया") }
                            showDeleteTransactionConfirm=false; selected=null; editId=0L; screen=Screen.Transactions
                        } catch(e:Exception) { toast("हटाया नहीं जा सका। दोबारा प्रयास करें") }
                        finally { savingTransaction=false }
                    }
                }) { Text("स्थायी रूप से हटाएँ", color=Red) }},
                dismissButton={TextButton(onClick={showDeleteTransactionConfirm=false}){Text("रद्द करें")}}
            )
            if(showClearConfirm) AlertDialog(onDismissRequest={showClearConfirm=false},title={Text("सभी डेटा हटाएँ?")},text={Text("सभी लेन-देन स्थायी रूप से हट जाएंगे। पहले बैकअप बना लें।")},confirmButton={TextButton(onClick={scope.launch { repository.deleteAll(); showClearConfirm=false; toast("सभी लेन-देन हटाए गए") }}){Text("हटाएँ",color=Red)}},dismissButton={TextButton(onClick={showClearConfirm=false}){Text("रद्द करें")}})
            if(showCategoryEditor) AlertDialog(
                onDismissRequest={showCategoryEditor=false},
                title={Text("श्रेणियाँ प्रबंधित करें")},
                text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value=newCategoryName,onValueChange={newCategoryName=it.take(50)},label={Text("नई श्रेणी का नाम")},singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=newCategoryType=="EXPENSE",onClick={newCategoryType="EXPENSE"},label={Text("खर्च")})
                        FilterChip(selected=newCategoryType=="INCOME",onClick={newCategoryType="INCOME"},label={Text("कमाई")})
                    }
                    Text("मौजूदा श्रेणियाँ",fontWeight=FontWeight.Bold)
                    Column(Modifier.heightIn(max=240.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        allCategoryRows.forEach { row ->
                            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(row.name); Text(if(row.transactionType=="EXPENSE") "खर्च" else "कमाई",style=MaterialTheme.typography.bodySmall,color=Color.Gray) }
                                if(!row.isDefault) IconButton(onClick={scope.launch { val deleted=db.categoryDao().deleteCustom(row.id); if(deleted>0) toast("श्रेणी हटाई गई") else toast("श्रेणी हटाई नहीं जा सकी") }}) { Icon(Icons.Default.Delete,"श्रेणी हटाएँ",tint=Red) }
                            }
                        }
                    }
                }},
                confirmButton={TextButton(onClick={scope.launch {
                    val name=newCategoryName.trim()
                    if(name.length !in 1..50) toast("श्रेणी का नाम 1 से 50 अक्षर का रखें")
                    else {
                        val id=db.categoryDao().insert(com.dailyhisaab.pro.data.CategoryEntity(name=name,transactionType=newCategoryType,isDefault=false))
                        if(id==-1L) toast("यह श्रेणी पहले से मौजूद है") else { toast("श्रेणी जोड़ दी गई");newCategoryName="";showCategoryEditor=false }
                    }
                }}) { Text("श्रेणी जोड़ें") } },
                dismissButton={TextButton(onClick={showCategoryEditor=false}) { Text("बंद करें") }}
            )
            if(showPinChange) AlertDialog(onDismissRequest={showPinChange=false},title={Text("PIN बदलें")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(oldPin,{oldPin=it.filter(Char::isDigit).take(4)},label={Text("मौजूदा PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword)); OutlinedTextField(newPin,{newPin=it.filter(Char::isDigit).take(4)},label={Text("नया 4-अंकों का PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword)); if(pinDialogError.isNotBlank()) Text(pinDialogError,color=Red) }},confirmButton={TextButton(onClick={scope.launch { if(oldPin.length!=4 || !verifyPin(oldPin,prefs.pinHash())) pinDialogError="मौजूदा PIN सही नहीं है" else if(newPin.length!=4) pinDialogError="नया PIN 4 अंक का होना चाहिए" else { prefs.setPinHash(pinHash(newPin));showPinChange=false;toast("PIN बदल गया") } }}){Text("बदलें")}},dismissButton={TextButton(onClick={showPinChange=false}){Text("रद्द करें")}})
        }
    }
}

@Composable private fun Header(title:String,subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).background(Green,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center) { Icon(Icons.Default.AccountBalanceWallet,null,tint=Color.White,modifier=Modifier.size(38.dp)) }
        Spacer(Modifier.height(8.dp));Text(title,fontSize=24.sp,fontWeight=FontWeight.Bold,color=DarkGreen);Text(subtitle,color=Color.Gray)
    }
}
@Composable private fun TopBar(title:String,onBack:()->Unit) { Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(14.dp),verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)};Text(title,fontWeight=FontWeight.Bold,fontSize=18.sp) } }
@Composable private fun StatCard(title:String,value:String,bg:Color,modifier:Modifier=Modifier) { Card(modifier,colors=CardDefaults.cardColors(containerColor=bg),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(12.dp)) { Text(title,fontSize=12.sp);Spacer(Modifier.height(5.dp));Text(value,fontWeight=FontWeight.Bold,color=DarkGreen,fontSize=15.sp) } } }
@Composable private fun StatText(title:String,value:String,color:Color,modifier:Modifier=Modifier) { Column(modifier) { Text(title,fontSize=12.sp,color=Color.Gray);Text(value,fontWeight=FontWeight.Bold,color=color) } }
@Composable private fun CategoryGrid(items:List<String>,onClick:(String)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { items.chunked(5).forEach { row -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) { row.forEach { name ->
        Column(Modifier.weight(1f).clickable { onClick(name) }.background(MaterialTheme.colorScheme.surface,RoundedCornerShape(12.dp)).padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.size(32.dp).background(PaleGreen,CircleShape),contentAlignment=Alignment.Center) { Icon(Icons.Default.Category,null,tint=Green,modifier=Modifier.size(18.dp)) }
            Text(name,fontSize=11.sp,maxLines=1)
        }
    }; repeat(5-row.size) { Spacer(Modifier.weight(1f)) } } } }
}
@Composable private fun TxRow(t:Transaction,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable { onClick() },colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).background(if(t.type=="INCOME") PaleGreen else Color(0xFFFFE8E8),CircleShape),contentAlignment=Alignment.Center) { Icon(if(t.type=="INCOME") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,tint=if(t.type=="INCOME") Green else Red) }
            Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)) { Text(t.description.ifBlank{t.category},fontWeight=FontWeight.SemiBold);Text("${t.category} • ${t.paymentMethod}",fontSize=12.sp,color=Color.Gray);Text("${fmtDate.format(Date(t.dateMillis))} • ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t.dateMillis))}",fontSize=11.sp,color=Color.Gray) }
            Text("${if(t.type=="INCOME") "+" else "−"} ${money(t.amountPaise)}",fontWeight=FontWeight.Bold,color=if(t.type=="INCOME") Green else Red)
        }
    }
}
@Composable private fun BottomNav(current:Screen,onSelect:(Screen)->Unit) {
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface) {
        val items=listOf(Triple("होम",Icons.Default.Home,Screen.Home),Triple("लेन-देन",Icons.Default.ReceiptLong,Screen.Transactions),Triple("रिपोर्ट",Icons.Default.BarChart,Screen.Monthly),Triple("बैकअप",Icons.Default.Cloud,Screen.Backup),Triple("सेटिंग्स",Icons.Default.Settings,Screen.Settings))
        items.forEach { (label,icon,target) ->
            val selected = current == target || (target == Screen.Monthly && current in listOf(Screen.Category, Screen.Pdf))
            NavigationBarItem(selected=selected,onClick={onSelect(target)},icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)})
        }
    }
}
@Composable private fun ReportOption(title:String,subtitle:String,onClick:()->Unit) { Card(Modifier.fillMaxWidth().clickable { onClick() },colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Description,null,tint=Green,modifier=Modifier.size(34.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,fontSize=12.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null) } } }
@Composable private fun MonthPicker(offset:Int,onChange:(Int)->Unit) {
    val cal=Calendar.getInstance().apply{add(Calendar.MONTH,offset)}
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface,RoundedCornerShape(14.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
        IconButton(onClick={onChange(offset-1)}){Icon(Icons.Default.ChevronLeft,null)}
        Text(SimpleDateFormat("MMMM yyyy",Locale("hi","IN")).format(cal.time),fontWeight=FontWeight.Bold)
        IconButton(onClick={onChange(offset+1)}){Icon(Icons.Default.ChevronRight,null)}
    }
}
@Composable private fun WeeklyBarChart(weeks: List<Pair<Long, Long>>) {
    val maxValue = weeks.flatMap { listOf(it.first, it.second) }.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val bottom = size.height - 4.dp.toPx()
            val chartHeight = size.height - 8.dp.toPx()
            val groupWidth = size.width / 5f
            val barWidth = (groupWidth * 0.23f).coerceAtLeast(4.dp.toPx())
            weeks.forEachIndexed { index, values ->
                val center = groupWidth * (index + 0.5f)
                val incomeHeight = (values.first.toFloat() / maxValue.toFloat()) * chartHeight
                val expenseHeight = (values.second.toFloat() / maxValue.toFloat()) * chartHeight
                drawRoundRect(Green, androidx.compose.ui.geometry.Offset(center - barWidth - 2.dp.toPx(), bottom - incomeHeight), androidx.compose.ui.geometry.Size(barWidth, incomeHeight), androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()))
                drawRoundRect(Red, androidx.compose.ui.geometry.Offset(center + 2.dp.toPx(), bottom - expenseHeight), androidx.compose.ui.geometry.Size(barWidth, expenseHeight), androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("1–7", "8–14", "15–21", "22–28", "29–31").forEach { label ->
                Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).background(Green, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(4.dp)); Text("कमाई", fontSize = 11.sp)
            Spacer(Modifier.width(14.dp))
            Box(Modifier.size(9.dp).background(Red, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(4.dp)); Text("खर्च", fontSize = 11.sp)
        }
    }
}

@Composable private fun BarChart(income:Long,expense:Long) {
    val maxV=maxOf(income,expense,1L).toFloat()
    Canvas(Modifier.fillMaxWidth().height(170.dp).background(MaterialTheme.colorScheme.surface,RoundedCornerShape(16.dp))) {
        val bottom=size.height-24.dp.toPx();val barW=size.width/5
        val h1=(income/maxV)*(size.height-45.dp.toPx());val h2=(expense/maxV)*(size.height-45.dp.toPx())
        drawRoundRect(Green,androidx.compose.ui.geometry.Offset(barW,bottom-h1),androidx.compose.ui.geometry.Size(barW,h1),androidx.compose.ui.geometry.CornerRadius(12f))
        drawRoundRect(Red,androidx.compose.ui.geometry.Offset(barW*3,bottom-h2),androidx.compose.ui.geometry.Size(barW,h2),androidx.compose.ui.geometry.CornerRadius(12f))
    }
}
@Composable private fun DonutChart(values:List<Long>) {
    val colors=listOf(Green,Red,Blue,Color(0xFF7E57C2),Color(0xFFF9A825),Color(0xFF00897B),Color.Gray)
    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val total=values.sum().coerceAtLeast(1).toFloat();var start=-90f
        values.forEachIndexed { i,v -> val sweep=v/total*360f;drawArc(colors[i%colors.size],start,sweep,true,topLeft=androidx.compose.ui.geometry.Offset(size.width*.24f,size.height*.04f),size=androidx.compose.ui.geometry.Size(size.width*.52f,size.height*.92f));start+=sweep }
        drawCircle(Color.White,radius=size.minDimension*.22f,center=androidx.compose.ui.geometry.Offset(size.width/2,size.height/2))
    }
}
@Composable private fun PinScreen(setup:Boolean,pin:String,lockRemaining:Int,onDigit:(String)->Unit,onDelete:()->Unit,onForgot:()->Unit,message:String,onTick:()->Unit,biometricEnabled:Boolean,onBiometric:()->Unit) {
    LaunchedEffect(lockRemaining) {
        // Never spin when the countdown reaches zero; tick only while a lock is active.
        if (lockRemaining > 0) {
            kotlinx.coroutines.delay(1000)
            onTick()
        }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Box(Modifier.size(74.dp).background(Green,RoundedCornerShape(22.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.AccountBalanceWallet,null,tint=Color.White,modifier=Modifier.size(42.dp))}
        Spacer(Modifier.height(12.dp));Text("Daily Hisaab PRO",fontSize=24.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground);Text("आपका निजी वित्तीय साथी",color=MaterialTheme.colorScheme.onBackground.copy(alpha=.7f))
        Spacer(Modifier.height(24.dp));Text(if(setup) "नया 4-अंकों का PIN बनाएँ" else "PIN दर्ज करें",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground)
        Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){repeat(4){i->Box(Modifier.size(13.dp).background(if(i<pin.length) Green else MaterialTheme.colorScheme.outlineVariant,CircleShape))}}
        if(lockRemaining>0) {
            Text("सुरक्षा लॉक सक्रिय है",fontWeight=FontWeight.SemiBold,color=Red)
            Text("कृपया ${lockRemaining} सेकंड प्रतीक्षा करें",color=Red)
        }
        if(message.isNotBlank()) Text(message,color=if(message.contains("गलत")) Red else Green,fontSize=12.sp)
        Spacer(Modifier.height(14.dp))
        (listOf("1","2","3","4","5","6","7","8","9","","0","⌫")).chunked(3).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { row.forEach { key ->
            Box(Modifier.weight(1f).padding(4.dp).height(54.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape).clickable {
                if(key=="⌫") onDelete() else if(key.isNotBlank()) onDigit(key)
            },contentAlignment=Alignment.Center){Text(key,fontSize=22.sp,fontWeight=FontWeight.Medium,color=MaterialTheme.colorScheme.onSurfaceVariant)}
        } } }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick=onForgot){Text("PIN भूल गए?")}
            if (!setup && biometricEnabled && lockRemaining == 0) TextButton(onClick=onBiometric){ Icon(Icons.Default.Fingerprint,null); Spacer(Modifier.width(4.dp)); Text("बायोमेट्रिक") }
        }
    }
}
private fun exportCsv(context:Context,items:List<Transaction>) {
    val file=File(context.cacheDir,"Daily_Hisaab_transactions.csv")
    val header = ReportMath.csvRow(listOf("id","type","amount_rupees","category","description","date","payment"))
    val rows = items.joinToString("\r\n") { t ->
        ReportMath.csvRow(listOf(t.id.toString(),t.type,ReportMath.csvAmount(t.amountPaise),t.category,t.description,fmtDate.format(Date(t.dateMillis)),t.paymentMethod))
    }
    // UTF-8 BOM improves Hindi text detection in common spreadsheet apps.
    file.writeText("\uFEFF" + header + "\r\n" + rows + "\r\n", Charsets.UTF_8)
}
