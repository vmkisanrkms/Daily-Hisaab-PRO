#!/usr/bin/env python3
from pathlib import Path
ui = Path('app/src/main/java/com/dailyhisaab/pro/ui/DailyHisaabApp.kt').read_text(encoding='utf-8')
filters = Path('app/src/main/java/com/dailyhisaab/pro/data/TransactionFilters.kt').read_text(encoding='utf-8')
tests = Path('app/src/test/java/com/dailyhisaab/pro/data/TransactionFiltersTest.kt').read_text(encoding='utf-8')
prefs = Path('app/src/main/java/com/dailyhisaab/pro/data/Preferences.kt').read_text(encoding='utf-8')
lockout = Path('app/src/main/java/com/dailyhisaab/pro/data/LockoutPolicy.kt').read_text(encoding='utf-8')
lockout_tests = Path('app/src/test/java/com/dailyhisaab/pro/data/LockoutPolicyTest.kt').read_text(encoding='utf-8')
manifest = Path('app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
workflow = Path('.github/workflows/android-release.yml').read_text(encoding='utf-8')
app_gradle = Path('app/build.gradle.kts').read_text(encoding='utf-8')
root_gradle = Path('build.gradle.kts').read_text(encoding='utf-8')
settings_gradle = Path('settings.gradle.kts').read_text(encoding='utf-8')
repository = Path('app/src/main/java/com/dailyhisaab/pro/data/TransactionRepository.kt').read_text(encoding='utf-8')
database = Path('app/src/main/java/com/dailyhisaab/pro/data/AppDatabase.kt').read_text(encoding='utf-8')
categories = Path('app/src/main/java/com/dailyhisaab/pro/data/CategoryDao.kt').read_text(encoding='utf-8')
settings_dao = Path('app/src/main/java/com/dailyhisaab/pro/data/AppSettingDao.kt').read_text(encoding='utf-8')
money_validation = Path('app/src/main/java/com/dailyhisaab/pro/data/MoneyValidation.kt').read_text(encoding='utf-8')
money_tests = Path('app/src/test/java/com/dailyhisaab/pro/MoneyValidationTest.kt').read_text(encoding='utf-8')
transaction = Path('app/src/main/java/com/dailyhisaab/pro/data/Transaction.kt').read_text(encoding='utf-8')
filters_tests = tests
checks = {
    'offline-only app: no INTERNET permission or online database SDK': 'android.permission.INTERNET' not in manifest and all(x not in (app_gradle + root_gradle + settings_gradle) for x in ['firebase-database', 'firebase-firestore', 'supabase-kt', 'room-remote']),
    'database is Room SQLite local file': 'Room.databaseBuilder' in database and 'daily_hisaab.db' in database,
    '12 screen routes': all(x in ui for x in ['Login(', 'Home(', 'AddExpense(', 'AddIncome(', 'Transactions(', 'Detail(', 'Monthly(', 'Category(', 'Pdf(', 'Backup(', 'Settings(', 'Lockout(']),
    'monthly to category': 'onClick={screen=Screen.Category}' in ui,
    'monthly to PDF': 'onClick={screen=Screen.Pdf}' in ui,
    'category to monthly': 'onClick={screen=Screen.Monthly}' in ui,
    'transactions screen uses combined filter helper': 'filterTransactions(' in ui,
    'transaction filter AND semantics and date boundaries': all(x in filters for x in ['searchMatches && typeMatches && categoryMatches && paymentMatches && fromMatches && toMatches', 'fromDateMillis > toDateMillis', 'toExclusive']),
    'transaction list reset clears every filter': all(x in ui for x in ['txTypeFilter="ALL"', 'txCategoryFilter="सभी श्रेणियाँ"', 'txPaymentFilter="सभी भुगतान"', 'txFromDate=null;txToDate=null']),
    'transaction list count and empty state': 'कोई लेन-देन नहीं मिला' in ui and 'लेन-देन' in ui,
    'filter unit tests authored for combined filters, dates, reset, search': all(x in tests for x in ['allFiltersCombineWithAndSemantics', 'dateRangeIncludesBothWholeDays', 'wrongDateRangeReturnsNoRows', 'resetDefaultsReturnAllSortedRows', 'searchIsCaseInsensitiveAndMatchesAmount']),
    'restore validates backup format, size, version, count and records': all(x in ui for x in ['daily-hisaab-backup', 'array.length() <= 100_000', '10_000_000', 'recordCount', 'category.isNotEmpty()', 'payment in Payments', 'date>0L']),
    'backup export includes format version and record count': all(x in ui for x in ['.put("format","daily-hisaab-backup")', '.put("version",1)', '.put("recordCount",arr.length())']),
    'Drive backup uses system document picker without claiming native OAuth': all(x in ui for x in ['ActivityResultContracts.CreateDocument("application/json")', 'ActivityResultContracts.OpenDocument()', 'native Google OAuth कनेक्शन नहीं है']),
    'restore confirmation and atomic Room replace': 'if(showRestoreConfirm) AlertDialog' in ui and '@RoomTransaction' in Path('app/src/main/java/com/dailyhisaab/pro/data/TransactionDao.kt').read_text(encoding='utf-8'),
    'edit validates amount/category/payment/date and guards duplicate taps': all(x in ui for x in ['if (savingTransaction) return', 'paise == null', 'category.isBlank()', 'payment !in Payments', 'date <= 0L']),
    'edit updates existing row and preserves original created timestamp': 'repository.update(tx)' in ui and 'createdAtMillis=existing.createdAtMillis' in ui and 'repository.getById(editId)' in ui,
    'delete has explicit confirmation and re-fetches current row': 'if(showDeleteTransactionConfirm) AlertDialog' in ui and 'repository.getById(targetId)' in ui and 'स्थायी रूप से हटाएँ' in ui,
    'delete handles errors and cancellation': 'हटाया नहीं जा सका' in ui and 'onDismissRequest={showDeleteTransactionConfirm=false}' in ui,
    'PIN hashing': 'PBKDF2WithHmacSHA256' in ui,
    'PDF uses Android StaticLayout for Hindi shaping and wrapped text': all(x in ui for x in ['import android.text.StaticLayout', 'import android.text.TextPaint', 'StaticLayout.Builder.obtain(row', 'drawHindiLine']),
    'PDF pagination checks remaining vertical space and starts pages dynamically': 'if (y >= 785f) startNewPage()' in ui and 'PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo)' in ui,
    'PDF includes monthly totals and category/transaction detail': all(x in ui for x in ['कुल कमाई:', 'कुल खर्च:', 'बचत / शुद्ध अंतर:', 'भुगतान: ${t.paymentMethod}', 'विवरण: ${t.description.ifBlank']),
    'PDF empty-state and safe share URI': 'इस महीने कोई लेन-देन दर्ज नहीं है।' in ui and 'FileProvider.getUriForFile' in ui and 'FLAG_GRANT_READ_URI_PERMISSION' in ui,
    'settings persist theme and auto-lock through DataStore': all(x in prefs for x in ['themeKey', 'autoLockKey', 'setTheme(value: String)', 'setAutoLock(value: Boolean)']) and all(x in ui for x in ['theme = prefs.theme()', 'autoLock = prefs.autoLock()']),
    'auto-lock lifecycle reads latest screen state': 'val currentScreen by rememberUpdatedState(screen)' in ui and 'currentScreen != Screen.Login' in ui,
    'theme selection saves and confirms choice': 'prefs.setTheme(option)' in ui and 'थीम सेव: $option' in ui,
    'auto-lock toggle saves and confirms choice': 'prefs.setAutoLock(value)' in ui and 'Auto Lock चालू' in ui and 'Auto Lock बंद' in ui,
    'CSV safely quotes all fields and supports Hindi spreadsheet encoding': 'ReportMath.csvRow' in ui and 'ReportMath.csvAmount' in ui and 'Charsets.UTF_8' in ui and 'FEFF' in ui,
    'PDF totals use shared integer-paise report calculations': 'ReportMath.totals(records)' in ui and 'ReportMath.expenseByCategory(records)' in ui,
    'Report export consistency tests cover totals categories CSV precision and restore copy': Path('app/src/test/java/com/dailyhisaab/pro/ReportExportConsistencyTest.kt').exists() and 'csvAmountKeepsPaisePrecisionWithoutDoubleRounding' in Path('app/src/test/java/com/dailyhisaab/pro/ReportExportConsistencyTest.kt').read_text(encoding='utf-8'),
    'clear-data operation remains behind confirmation': 'if(showClearConfirm) AlertDialog' in ui and 'showClearConfirm=true' in ui,
    'PIN lockout triggers at five failures for 30 seconds': 'LockoutPolicy.shouldLock(wrong)' in ui and 'LOCK_DURATION_MILLIS' in lockout and 'MAX_FAILED_ATTEMPTS = 5' in lockout,
    'lockout deadline persisted and restored on app startup': all(x in ui for x in ['lockUntil = prefs.lockUntil()', 'if (lockUntil > System.currentTimeMillis())', 'prefs.setLockUntil(0L)']),
    'lockout countdown rounds up and never goes negative': all(x in lockout for x in ['coerceAtLeast(0L)', '(remaining + 999L) / 1_000L']),
    'countdown does not busy-loop after expiry': 'if (lockRemaining > 0)' in ui and 'if(lockRemaining>0) kotlinx.coroutines.delay(1000);onTick()' not in ui,
    'PIN lockout unit tests cover threshold restart expiry and countdown': all(x in lockout_tests for x in ['locksOnFifthFailureOnly', 'deadlineSurvivesRestartBecauseItIsAnAbsoluteTimestamp', 'roundsRemainingSecondsUpAndExpiresAtDeadline', 'expiredDeadlineHasNoNegativeCountdown']),
    'recovery is confirmed before data deletion and clears lock state': 'if(showRecoveryConfirm) AlertDialog' in ui and 'repository.deleteAll();prefs.clearPin();prefs.setWrongAttempts(0);prefs.setLockUntil(0L)' in ui,
    'Room observer': 'repository.observeAll()' in ui,
    'Home dashboard date picker': 'चुनी तारीख का हिसाब' in ui and 'DatePickerDialog(context' in ui and 'homeDate=currentDay' in ui,
    'Transaction list grouped by local date': 'groupedByDay' in ui and 'date_$dayMillis' in ui,
    'Transaction list shows date and time': 'SimpleDateFormat("HH:mm"' in ui,
    'PDF supports optional date/category filters': all(x in ui for x in ['pdfFromDate', 'pdfToDate', 'pdfCategory', 'reportCategories']),
    'PDF history lists open/share actions': all(x in ui for x in ['cachedPdfFiles', 'openPdf(file)', 'sharePdf(file)', 'ACTION_VIEW']),
    'PDF splits long single records across pages': all(x in ui for x in ['layout.getLineTop(firstLine)', 'layout.getLineBottom(endLine - 1)', 'canvas!!.clipRect(left, y, right, y + chunkHeight)']),
    'Restore reads bounded stream before parsing': all(x in ui for x in ['ByteArrayOutputStream()', 'total <= 10_000_000', 'String(output.toByteArray(), Charsets.UTF_8)']),
    'CSV/PDF sharing provider grants read access': 'android:grantUriPermissions="true"' in manifest and 'FLAG_GRANT_READ_URI_PERMISSION' in ui,
    'Launcher adaptive icon configured': 'android:icon="@mipmap/ic_launcher"' in manifest and Path('app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml').exists(),
    'Workflow runs clean build and tests through launcher': './gradlew --no-daemon clean test assembleRelease' in workflow,
    'Workflow distinguishes signed and unsigned artifacts': all(x in workflow for x in ['Daily-Hisaab-PRO-Signed-Release-APK', 'Daily-Hisaab-PRO-UNSIGNED-Release-APK', 'UNSIGNED: Signing secrets were not configured']),
    'Workflow verifies signature and alignment': 'verify --verbose --print-certs' in workflow and '-c -v 4 output/Daily-Hisaab-PRO.apk' in workflow,
    'Gradle launcher executable': Path('gradlew').exists() and bool(Path('gradlew').stat().st_mode & 0o111),
    'Repository layer mediates Room access': all(x in repository for x in ['observeAll()', 'getById(id: Long)', 'replaceAll(transactions']),
    'Transaction table has date/type/category/payment indexes': all(x in transaction for x in ['Index(value = ["dateMillis"])', 'Index(value = ["type", "dateMillis"])', 'Index(value = ["category", "dateMillis"])', 'Index(value = ["paymentMethod", "dateMillis"])']),
    'Existing version-1 and version-2 databases have explicit migrations': all(x in database for x in ['Migration(1, 2)', 'Migration(2, 3)', 'addMigrations(MIGRATION_1_2, MIGRATION_2_3)', 'CREATE INDEX IF NOT EXISTS']),
    'Room includes category and settings tables with DAOs': all(x in database for x in ['CategoryEntity::class', 'AppSettingEntity::class', 'categoryDao()', 'appSettingDao()', 'CREATE TABLE IF NOT EXISTS categories', 'CREATE TABLE IF NOT EXISTS app_settings']) and all(x in categories for x in ['observeByType', 'insert(category: CategoryEntity)', 'deleteCustom']) and all(x in settings_dao for x in ['observeAll()', 'suspend fun get', 'suspend fun put']),
    'Category records seed on fresh install and drive transaction form choices': all(x in ui for x in ['observeByType(\"EXPENSE\")', 'observeByType(\"INCOME\")', 'expenseCategoryNames', 'incomeCategoryNames', 'श्रेणियाँ प्रबंधित करें']) and 'override fun onCreate(db: SupportSQLiteDatabase)' in database,
    'Settings mirror non-secret preferences to Room': all(x in prefs for x in ['settingsDao?.put(AppSettingEntity', 'mirror(\"theme\"', 'mirror(\"auto_lock\"', 'mirror(\"biometric_login\"', 'mirror(\"lock_until\"', 'mirror(\"wrong_attempts\"']),
    'Biometric login is optional, guarded by availability and lockout': all(x in ui for x in ['BiometricManager.from(context)', 'BiometricPrompt(activity', 'BIOMETRIC_STRONG', 'lockUntil <= System.currentTimeMillis()', 'onBiometric=']) and all(x in prefs for x in ['biometricKey', 'biometricLogin()', 'setBiometricLogin']),
    'SQLite backup and restore validate integrity, version and schema': all(x in ui for x in ['sqliteBackupLauncher', 'sqliteRestoreLauncher', 'VACUUM INTO', 'Room database identity hash नहीं मिला', 'index_transactions_paymentMethod_dateMillis', 'PRAGMA quick_check', 'version == 3', 'invalidTransactions', 'invalidCategories', 'foreign_key_check', 'replaceFromValidatedBackup']) and 'fun replaceFromValidatedBackup' in database,
    'Money input validation is pure and unit-tested': all(x in money_validation for x in ['longValueExact()', 'maxPaise', 'text.matches']) and all(x in money_tests for x in ['rejectsEmptyZeroNegativeAndMalformedInput', 'rejectsOverflowAndTooLargeValues']),
    'Workflow bootstraps official wrapper in CI before build': all(x in workflow for x in ['gradle/actions/setup-gradle@v4', 'gradle --no-daemon wrapper --gradle-version 8.11.1', 'test -f gradle/wrapper/gradle-wrapper.jar']),
    'UI mutations use repository layer': 'repository.update(tx)' in ui and 'repository.insert(tx)' in ui and 'repository.delete(existing)' in ui,
    'Language option does not claim unsupported translation': 'अभी केवल हिंदी इंटरफ़ेस उपलब्ध है' in ui,
    'Android Back navigation handles secondary screens and protects unsaved form changes': 'BackHandler(enabled = screen != Screen.Login && screen != Screen.Lockout && screen != Screen.Home)' in ui and 'showDiscardChangesConfirm' in ui and 'pendingBackTarget = Screen.Transactions' in ui,
    'Monthly chart shows weekly income and expense bars with labels and legend': 'WeeklyBarChart(weeklyTotals)' in ui and 'सप्ताह के अनुसार कमाई बनाम खर्च' in ui and 'listOf("1–7", "8–14", "15–21", "22–28", "29–31")' in ui,
    'Edit screen back route returns to transaction list': 'Screen.Detail -> {' in ui and 'selected = null; editId = 0L; screen = Screen.Transactions' in ui,
    'PIN submission cannot trigger multiple checks from repeated taps': 'pinVerifying' in ui and 'pin.length >= 4' in ui and 'val submittedPin = pin' in ui,
    'Transaction date picker has explicit calendar button affordance': 'Icon(Icons.Default.CalendarMonth,"तारीख चुनें")' in ui,
    'Biometric button only appears when user enables biometric login': 'biometricEnabled=biometricLogin' in ui and 'if (!setup && biometricEnabled && lockRemaining == 0)' in ui,
    'Category report has explicit no-expense empty state': 'इस महीने कोई खर्च दर्ज नहीं है।' in ui and 'if (categories.isNotEmpty()) items(categories)' in ui,
    'Reports bottom navigation stays selected on category and PDF sub-screens': 'current in listOf(Screen.Category, Screen.Pdf)' in ui,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()):
    raise SystemExit(1)
