package com.dailyhisaab.pro.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.store by preferencesDataStore("daily_hisaab_settings")
class Preferences(private val context: Context, private val settingsDao: AppSettingDao? = null) {
    private suspend fun mirror(key: String, value: String) {
        settingsDao?.put(AppSettingEntity(key = key, value = value))
    }
    private val pinKey = stringPreferencesKey("pin_hash")
    private val themeKey = stringPreferencesKey("theme")
    private val autoLockKey = booleanPreferencesKey("auto_lock")
    private val biometricKey = booleanPreferencesKey("biometric_login")
    private val lockUntilKey = longPreferencesKey("lock_until")
    private val wrongAttemptsKey = intPreferencesKey("wrong_attempts")
    suspend fun pinHash(): String? = context.store.data.first()[pinKey]
    suspend fun setPinHash(value: String) { context.store.edit { it[pinKey] = value } }
    suspend fun clearPin() { context.store.edit { it.remove(pinKey) } }
    suspend fun theme(): String = context.store.data.first()[themeKey] ?: "System"
    suspend fun setTheme(value: String) { context.store.edit { it[themeKey] = value }; mirror("theme", value) }
    suspend fun autoLock(): Boolean = context.store.data.first()[autoLockKey] ?: true
    suspend fun setAutoLock(value: Boolean) { context.store.edit { it[autoLockKey] = value }; mirror("auto_lock", value.toString()) }
    suspend fun biometricLogin(): Boolean = context.store.data.first()[biometricKey] ?: false
    suspend fun setBiometricLogin(value: Boolean) { context.store.edit { it[biometricKey] = value }; mirror("biometric_login", value.toString()) }
    suspend fun lockUntil(): Long = context.store.data.first()[lockUntilKey] ?: 0L
    suspend fun setLockUntil(value: Long) { context.store.edit { it[lockUntilKey] = value }; mirror("lock_until", value.toString()) }
    suspend fun wrongAttempts(): Int = context.store.data.first()[wrongAttemptsKey] ?: 0
    suspend fun setWrongAttempts(value: Int) { context.store.edit { it[wrongAttemptsKey] = value }; mirror("wrong_attempts", value.toString()) }
}
