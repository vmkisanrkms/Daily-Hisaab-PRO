# Daily Hisaab PRO V23 — बाकी सुधार

- होम स्क्रीन का “मासिक PDF” बटन अब हमेशा MONTHLY रिपोर्ट मोड सेट करता है; इससे पहले श्रेणीवार/लेन-देन PDF बनाने के बाद होम बटन दबाने पर गलत प्रकार की PDF बनने का जोखिम हटता है।
- सेटिंग्स में सक्रिय सुरक्षा मोड (PIN लॉक या पैटर्न लॉक) सही नाम से दिखता है।
- V22 के दोनों शामिल source trees में समान बदलाव लागू किए गए ताकि duplicate project copy में अंतर न रहे।

## शेष सत्यापन
- ZIP integrity जाँची जाएगी; Kotlin compilation/APK build और वास्तविक Android परीक्षण इस वातावरण में नहीं चलाए गए।
- अलग-अलग PDF लेआउट, Google Drive वास्तविक round-trip, सभी 12 स्क्रीन का visual matching और responsive/accessibility परीक्षण अभी बाकी हैं।
