Daily Hisaab PRO V25: localized home month label, recent transaction sorting, CSV export from Settings. Android build/runtime tests remain pending. See FIXES_V25_HINDI.md.
