package com.dailyhisaab.pro

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Insert
    suspend fun insert(item: Transaction): Long

    @Insert
    suspend fun insertAll(items: List<Transaction>): List<Long>

    @Delete
    suspend fun delete(item: Transaction)

    @Update
    suspend fun update(item: Transaction)

    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC, id DESC")
    fun observeAll(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE dateMillis >= :start AND dateMillis < :end ORDER BY dateMillis DESC, id DESC")
    suspend fun forPeriod(start: Long, end: Long): List<Transaction>

    @Query("SELECT * FROM transactions")
    suspend fun allNow(): List<Transaction>

    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}
