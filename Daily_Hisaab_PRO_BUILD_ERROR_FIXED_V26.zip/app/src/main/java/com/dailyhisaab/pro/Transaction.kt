package com.dailyhisaab.pro

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // EXPENSE or INCOME
    val amountPaise: Long,
    val category: String,
    val note: String,
    val paymentMethod: String,
    val dateMillis: Long,
    val createdAt: Long = System.currentTimeMillis()
)
