package com.dailyhisaab.pro

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Path
import android.view.MotionEvent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64

class MainActivity : AppCompatActivity() {
    private val db by lazy { AppDatabase.get(this) }
    private lateinit var content: LinearLayout
    private lateinit var headerBalance: TextView
    private var currentItems: List<Transaction> = emptyList()
    private var selectedDate = System.currentTimeMillis()
    private var reportMonthOffset = 0
    private var pdfReportMode = "MONTHLY"
    private var currentScreen = "HOME"
    private var uiReady = false
    private var requiresUnlock = false
    private var externalPickerOpen = false
    private var pinPromptShowing = false
    private val green = Color.rgb(23, 107, 87)
    private val pale = Color.rgb(235, 246, 241)
    private val ink = Color.rgb(30, 48, 43)
    private val fmt = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))

    private val backupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        externalPickerOpen = false
        if (uri != null) exportBackup(uri)
    }
    private val restoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        externalPickerOpen = false
        if (uri != null) restoreBackup(uri)
    }
    private val pdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        externalPickerOpen = false
        if (uri != null) exportPdf(uri)
    }
    private val csvLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        externalPickerOpen = false
        if (uri != null) exportCsv(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!ensurePin()) return
        buildUi()
        lifecycleScope.launch {
            db.transactionDao().observeAll().collectLatest {
                currentItems = it
                renderDashboard()
            }
        }
    }

    private fun ensurePin(): Boolean {
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        val savedHash = prefs.getString("pin_hash", null)
        val savedSalt = prefs.getString("pin_salt", null)
        if (savedHash == null || savedSalt == null) {
            val input = EditText(this).apply {
                hint = "4 से 6 अंकों का PIN"
                inputType = 18
            }
            val setupDialog = AlertDialog.Builder(this).setTitle("अपना PIN बनाएँ")
                .setMessage("आपके हिसाब को सुरक्षित रखने के लिए PIN सेट करें।")
                .setView(input).setCancelable(false)
                .setPositiveButton("सेव करें", null)
                .create()
            setupDialog.setOnShowListener {
                setupDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val pin = input.text.toString()
                    if (pin.length in 4..6 && pin.all { it.isDigit() }) {
                        savePin(pin)
                        setupDialog.dismiss()
                        openMainUi()
                    } else {
                        input.error = "PIN 4 से 6 अंकों का रखें"
                        input.requestFocus()
                    }
                }
            }
            setupDialog.show()
            return false
        }
        promptPin(savedSalt, savedHash)
        return false
    }

    private fun promptPin(savedSalt: String, savedHash: String) {
        if (pinPromptShowing || isFinishing) return
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        if (prefs.getString("lock_mode", "PIN") == "PATTERN") {
            promptPatternUnlock()
            return
        }
        val lockoutUntil = prefs.getLong("pin_lockout_until", 0L)
        val now = System.currentTimeMillis()
        if (lockoutUntil > now) {
            val seconds = ((lockoutUntil - now + 999) / 1000)
            AlertDialog.Builder(this).setTitle("PIN अस्थायी रूप से लॉक है")
                .setMessage("कई गलत प्रयास हुए। कृपया $seconds सेकंड बाद दोबारा कोशिश करें।")
                .setCancelable(false).setPositiveButton("ठीक है") { _, _ -> finish() }.show()
            return
        }
        val input = EditText(this).apply { hint = "PIN दर्ज करें"; inputType = 18 }
        pinPromptShowing = true
        AlertDialog.Builder(this).setTitle("Daily Hisaab PRO — लॉगिन / स्क्रीन लॉक")
            .setMessage("अपना PIN डालकर ऐप खोलें").setView(input).setCancelable(false)
            .setPositiveButton("खोलें") { _, _ ->
                pinPromptShowing = false
                if (verifyPin(input.text.toString(), savedSalt, savedHash)) {
                    prefs.edit().remove("pin_failed_attempts").remove("pin_lockout_until").apply()
                    requiresUnlock = false
                    openMainUi()
                } else {
                    if (!recordFailedUnlock()) window.decorView.post { promptPin(savedSalt, savedHash) }
                }
            }.setNegativeButton("बंद करें") { _, _ ->
                pinPromptShowing = false
                finish()
            }.setOnCancelListener {
                pinPromptShowing = false
                finish()
            }.show()
    }

    private fun recordFailedUnlock(): Boolean {
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        val attempts = prefs.getInt("pin_failed_attempts", 0) + 1
        val editor = prefs.edit().putInt("pin_failed_attempts", attempts)
        if (attempts >= 5) {
            editor.putLong("pin_lockout_until", System.currentTimeMillis() + 30_000L)
                .putInt("pin_failed_attempts", 0)
            editor.apply()
            Toast.makeText(this, "5 गलत प्रयास। 30 सेकंड के लिए लॉक किया गया।", Toast.LENGTH_LONG).show()
            finish()
            return true
        }
        editor.apply()
        Toast.makeText(this, "गलत पैटर्न/PIN। बाकी प्रयास: ${5 - attempts}", Toast.LENGTH_LONG).show()
        return false
    }

    private fun promptPatternUnlock() {
        if (pinPromptShowing || isFinishing) return
        val prefs = getSharedPreferences("secure", MODE_PRIVATE)
        val until = prefs.getLong("pin_lockout_until", 0L)
        if (until > System.currentTimeMillis()) {
            val seconds = (until - System.currentTimeMillis() + 999) / 1000
            AlertDialog.Builder(this).setTitle("अस्थायी लॉक")
                .setMessage("कई गलत प्रयास हुए। $seconds सेकंड बाद कोशिश करें।")
                .setCancelable(false).setPositiveButton("ठीक है") { _, _ -> finish() }.show()
            return
        }
        val salt = prefs.getString("pattern_salt", null)
        val hash = prefs.getString("pattern_hash", null)
        if (salt == null || hash == null) {
            prefs.edit().putString("lock_mode", "PIN").apply()
            val pinSalt = prefs.getString("pin_salt", null)
            val pinHash = prefs.getString("pin_hash", null)
            if (pinSalt != null && pinHash != null) promptPin(pinSalt, pinHash)
            return
        }
        val patternView = PatternInputView(this)
        pinPromptShowing = true
        val dialog = AlertDialog.Builder(this).setTitle("पैटर्न से ऐप खोलें")
            .setMessage("कम से कम 4 डॉट जोड़कर अपना पैटर्न बनाएँ")
            .setView(patternView).setCancelable(false)
            .setPositiveButton("खोलें", null)
            .setNegativeButton("रद्द करें") { _, _ -> pinPromptShowing = false; finish() }.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pattern = patternView.patternValue()
                if (pattern.split(",").distinct().size < 4) {
                    Toast.makeText(this, "कम से कम 4 डॉट चुनें", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (verifyPin(pattern, salt, hash)) {
                    prefs.edit().remove("pin_failed_attempts").remove("pin_lockout_until").apply()
                    pinPromptShowing = false; requiresUnlock = false
                    dialog.dismiss(); openMainUi()
                } else {
                    pinPromptShowing = false; dialog.dismiss()
                    if (!recordFailedUnlock()) window.decorView.post { promptPatternUnlock() }
                }
            }
        }
        dialog.setOnCancelListener { pinPromptShowing = false; finish() }
        dialog.show()
    }

    private fun setupPatternLock() {
        val first = PatternInputView(this)
        AlertDialog.Builder(this).setTitle("नया पैटर्न बनाएँ")
            .setMessage("कम से कम 4 डॉट जोड़ें") .setView(first)
            .setNegativeButton("रद्द", null).setPositiveButton("आगे", null).create().also { firstDialog ->
                firstDialog.setOnShowListener {
                    firstDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val value = first.patternValue()
                        if (value.split(",").distinct().size < 4) {
                            Toast.makeText(this, "कम से कम 4 डॉट चुनें", Toast.LENGTH_SHORT).show(); return@setOnClickListener
                        }
                        val second = PatternInputView(this)
                        AlertDialog.Builder(this).setTitle("पैटर्न की पुष्टि करें")
                            .setMessage("वही पैटर्न दोबारा बनाएँ") .setView(second)
                            .setNegativeButton("रद्द", null).setPositiveButton("सेव", null).create().also { confirm ->
                                confirm.setOnShowListener {
                                    confirm.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                                        if (second.patternValue() != value) {
                                            Toast.makeText(this, "दोनों पैटर्न अलग हैं", Toast.LENGTH_SHORT).show()
                                            second.clearPattern()
                                        } else {
                                            val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
                                            val saltText = Base64.encodeToString(saltBytes, Base64.NO_WRAP)
                                            val hashText = Base64.encodeToString(pinHash(value, saltBytes), Base64.NO_WRAP)
                                            getSharedPreferences("secure", MODE_PRIVATE).edit()
                                                .putString("pattern_salt", saltText).putString("pattern_hash", hashText)
                                                .putString("lock_mode", "PATTERN").apply()
                                            Toast.makeText(this, "पैटर्न लॉक चालू हो गया", Toast.LENGTH_LONG).show()
                                            confirm.dismiss()
                                        }
                                    }
                                }
                                confirm.show()
                            }
                        firstDialog.dismiss()
                    }
                }
                firstDialog.show()
            }
    }

    private inner class PatternInputView(context: android.content.Context) : View(context) {
        private val points = mutableListOf<Int>()
        private val path = Path()
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat() }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green; style = Paint.Style.STROKE; strokeWidth = dp(4).toFloat(); strokeCap = Paint.Cap.ROUND }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green; style = Paint.Style.FILL }
        private fun cx(i: Int) = width * (0.18f + (i % 3) * 0.32f)
        private fun cy(i: Int) = height * (0.18f + (i / 3) * 0.32f)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (points.isNotEmpty()) {
                path.reset(); path.moveTo(cx(points[0]), cy(points[0]))
                points.drop(1).forEach { path.lineTo(cx(it), cy(it)) }
                canvas.drawPath(path, linePaint)
            }
            for (i in 0..8) {
                canvas.drawCircle(cx(i), cy(i), dp(13).toFloat(), dotPaint)
                if (i in points) canvas.drawCircle(cx(i), cy(i), dp(6).toFloat(), fillPaint)
            }
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                var best = -1; var dist = Float.MAX_VALUE
                for (i in 0..8) {
                    val d = kotlin.math.hypot((event.x - cx(i)).toDouble(), (event.y - cy(i)).toDouble()).toFloat()
                    if (d < dist) { dist = d; best = i }
                }
                if (dist < dp(32) && best !in points) { points.add(best); invalidate() }
                return true
            }
            if (event.action == MotionEvent.ACTION_UP) { invalidate(); return true }
            return true
        }
        fun patternValue() = points.joinToString(",")
        fun clearPattern() { points.clear(); invalidate() }
    }

    private fun openMainUi() {
        if (!uiReady) {
            buildUi()
            uiReady = true
            lifecycleScope.launch {
                db.transactionDao().observeAll().collectLatest {
                    currentItems = it
                    renderDashboard()
                }
            }
        } else {
            renderDashboard()
        }
    }

    override fun onStop() {
        super.onStop()
        if (uiReady && !externalPickerOpen && !isChangingConfigurations) {
            val lockEnabled = getSharedPreferences("secure", MODE_PRIVATE)
                .getBoolean("screen_lock_enabled", true)
            requiresUnlock = lockEnabled
        }
    }

    override fun onResume() {
        super.onResume()
        if (requiresUnlock && uiReady && !externalPickerOpen) {
            requiresUnlock = false
            val prefs = getSharedPreferences("secure", MODE_PRIVATE)
            val salt = prefs.getString("pin_salt", null)
            val hash = prefs.getString("pin_hash", null)
            if (salt != null && hash != null) promptPin(salt, hash)
        }
    }

    private fun savePin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = pinHash(pin, salt)
        getSharedPreferences("secure", MODE_PRIVATE).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .remove("pin")
            .apply()
    }

    private fun pinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun verifyPin(pin: String, saltText: String, hashText: String): Boolean {
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            val expected = Base64.decode(hashText, Base64.NO_WRAP)
            java.security.MessageDigest.isEqual(pinHash(pin, salt), expected)
        } catch (_: Exception) { false }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 250, 248))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(13), dp(18), dp(13))
            setBackgroundColor(green)
        }
        top.addView(label("Daily Hisaab PRO", 21f, Color.WHITE, true))
        top.addView(label("आपकी कमाई और खर्च — एक ही जगह", 12f, Color.rgb(220, 240, 232), false))
        root.addView(top)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Persistent bottom navigation, matching the agreed five-tab app flow.
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(4), dp(5), dp(4), dp(5))
            elevation = dp(8).toFloat()
        }
        listOf(
            "⌂\nहोम" to "HOME",
            "▤\nलेन-देन" to "TRANSACTIONS",
            "▥\nरिपोर्ट" to "REPORT",
            "☁\nबैकअप" to "BACKUP",
            "⚙\nसेटिंग" to "SETTINGS"
        ).forEach { pair ->
            val b = TextView(this).apply {
                text = pair.first
                gravity = Gravity.CENTER
                textSize = 11f
                setPadding(dp(2), dp(5), dp(2), dp(5))
                setTextColor(if (currentScreen == pair.second) green else Color.rgb(95, 105, 101))
                if (currentScreen == pair.second) setTypeface(typeface, Typeface.BOLD)
                isClickable = true
                isFocusable = true
                setOnClickListener { currentScreen = pair.second; renderDashboard(); buildBottomNavRefresh() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        renderDashboard()
    }

    private fun buildBottomNavRefresh() {
        // Rebuild only the view tree so the selected bottom tab receives the active color.
        buildUi()
    }

    private fun renderDashboard() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        if (currentScreen != "HOME") {
            renderSecondaryScreen()
            return
        }
        val now = Calendar.getInstance()
        now.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(now)
        val start = now.timeInMillis
        val endCal = Calendar.getInstance(); endCal.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(endCal); endCal.add(Calendar.MONTH, 1)
        val monthItems = currentItems.filter { it.dateMillis >= start && it.dateMillis < endCal.timeInMillis }
        val income = monthItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
        val expense = monthItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
        val todayCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val todayStart = todayCal.timeInMillis
        todayCal.add(Calendar.DAY_OF_MONTH, 1)
        val todayItems = currentItems.filter { it.dateMillis >= todayStart && it.dateMillis < todayCal.timeInMillis }
        val todayIncome = todayItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
        val todayExpense = todayItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }

        val greeting = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(8))
        }
        greeting.addView(label("नमस्ते! आज का हिसाब", 23f, ink, true))
        greeting.addView(label(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(Date()), 13f, Color.rgb(105, 116, 111), false))
        content.addView(greeting)
        val todayCards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        todayCards.addView(summaryCard("आज की कमाई", money(todayIncome), Color.rgb(18, 122, 81)), LinearLayout.LayoutParams(0, dp(86), 1f))
        todayCards.addView(summaryCard("आज का खर्च", money(todayExpense), Color.rgb(190, 72, 60)), LinearLayout.LayoutParams(0, dp(86), 1f).apply { leftMargin = dp(6) })
        todayCards.addView(summaryCard("आज का शेष", money(todayIncome - todayExpense), Color.rgb(35, 105, 165)), LinearLayout.LayoutParams(0, dp(86), 1f).apply { leftMargin = dp(6) })
        content.addView(todayCards)

        content.addView(label("इस महीने की स्थिति • ${SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(Date())}", 17f, ink, true).apply { setPadding(dp(2), dp(16), 0, dp(7)) })
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cards.addView(summaryCard("कुल कमाई", money(income), Color.rgb(18, 122, 81)), LinearLayout.LayoutParams(0, dp(82), 1f))
        cards.addView(summaryCard("कुल खर्च", money(expense), Color.rgb(190, 72, 60)), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(6) })
        cards.addView(summaryCard("बचत", money(income - expense), green), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(6) })
        content.addView(cards)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("+ खर्च जोड़ें") { showTransactionDialog("EXPENSE") }, LinearLayout.LayoutParams(0, dp(52), 1f))
        actions.addView(actionButton("+ कमाई जोड़ें") { showTransactionDialog("INCOME") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(8) })
        content.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(smallButton("मासिक PDF") { pdfReportMode = "MONTHLY"; reportMonthOffset = 0; currentScreen = "PDF"; renderDashboard() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(smallButton("बैकअप") { externalPickerOpen = true; backupLauncher.launch("Daily_Hisaab_Backup.json") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        tools.addView(smallButton("रिस्टोर") { externalPickerOpen = true; restoreLauncher.launch(arrayOf("application/json", "text/*")) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        content.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        content.addView(label("सभी सुविधाएँ", 18f, ink, true).apply { setPadding(0, dp(18), 0, dp(7)) })
        val navRows = listOf(
            listOf("📒  लेन-देन सूची" to "TRANSACTIONS", "📊  मासिक रिपोर्ट" to "REPORT"),
            listOf("🧾  श्रेणीवार रिपोर्ट" to "CATEGORIES", "📄  PDF रिपोर्ट" to "PDF"),
            listOf("☁  बैकअप / रिस्टोर" to "BACKUP", "⚙  सेटिंग्स" to "SETTINGS")
        )
        navRows.forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEachIndexed { index, pair ->
                row.addView(smallButton(pair.first) { currentScreen = pair.second; renderDashboard() },
                    LinearLayout.LayoutParams(0, dp(54), 1f).apply { if (index > 0) leftMargin = dp(9) })
            }
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }

        content.addView(label("हाल के लेन-देन", 18f, ink, true).apply { setPadding(dp(2), dp(20), 0, dp(8)) })
        if (currentItems.isEmpty()) {
            content.addView(label("अभी कोई हिसाब नहीं है। ‘खर्च जोड़ें’ या ‘कमाई जोड़ें’ दबाकर शुरुआत करें।", 14f, Color.GRAY, false))
        } else {
            currentItems.sortedByDescending { it.dateMillis }.take(50).forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(13), dp(10), dp(13), dp(10))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = dp(12).toFloat()
                    }
                }
                val line1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val title = "${if (item.type == "EXPENSE") "खर्च" else "कमाई"} • ${item.category}"
                line1.addView(label(title, 15f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
                val amountColor = if (item.type == "EXPENSE") Color.rgb(190, 72, 60) else Color.rgb(18, 122, 81)
                line1.addView(label("${if (item.type == "EXPENSE") "−" else "+"}${money(item.amountPaise)}", 15f, amountColor, true))
                row.addView(line1)
                row.addView(label("${fmt.format(Date(item.dateMillis))} • ${item.paymentMethod}${if (item.note.isNotBlank()) " • ${item.note}" else ""}", 12f, Color.GRAY, false))
                row.isClickable = true
                row.setOnClickListener { showTransactionDialog(item.type, item) }
                row.setOnLongClickListener {
                    AlertDialog.Builder(this)
                        .setTitle("लेन-देन हटाएँ?")
                        .setMessage("${item.category} • ${money(item.amountPaise)} को हटाना चाहते हैं?")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("हटाएँ") { _, _ ->
                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    db.transactionDao().delete(item)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड नहीं हट पाया: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.show()
                    true
                }
                content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
        }
        content.addView(smallButton("PIN बदलें") { changePin() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(12) })
    }

    private fun renderSecondaryScreen() {
        val title = when (currentScreen) {
            "TRANSACTIONS" -> "सभी लेन-देन"
            "REPORT" -> "मासिक रिपोर्ट"
            "CATEGORIES" -> "श्रेणीवार रिपोर्ट"
            "PDF" -> "PDF रिपोर्ट"
            "BACKUP" -> "बैकअप और रिस्टोर"
            "SETTINGS" -> "सेटिंग्स"
            else -> "Daily Hisaab PRO"
        }
        content.addView(actionButton("← होम स्क्रीन") { currentScreen = "HOME"; renderDashboard() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        content.addView(label(title, 22f, ink, true))
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            startOfMonth(this)
            if (currentScreen == "REPORT" || currentScreen == "CATEGORIES") add(Calendar.MONTH, reportMonthOffset)
        }
        val reportMonthStart = cal.clone() as Calendar
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val end = cal.timeInMillis
        val monthItems = currentItems.filter { it.dateMillis >= start && it.dateMillis < end }
        val income = monthItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
        val expense = monthItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
        when (currentScreen) {
            "TRANSACTIONS" -> {
                content.addView(actionButton("+ खर्च जोड़ें") { showTransactionDialog("EXPENSE") })
                content.addView(actionButton("+ कमाई जोड़ें") { showTransactionDialog("INCOME") }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })

                content.addView(label("लेन-देन खोजें", 15f, ink, true).apply {
                    setPadding(0, dp(14), 0, dp(5))
                })
                val search = EditText(this).apply {
                    hint = "श्रेणी, विवरण या रकम लिखें"
                    singleLine = true
                    textSize = 15f
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    setBackgroundColor(Color.WHITE)
                }
                content.addView(search, LinearLayout.LayoutParams(-1, dp(48)))

                val filters = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val typeFilter = Spinner(this).apply {
                    adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                        listOf("सभी प्रकार", "केवल खर्च", "केवल कमाई"))
                }
                val sortFilter = Spinner(this).apply {
                    adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                        listOf("नई तारीख पहले", "पुरानी तारीख पहले", "रकम अधिक पहले", "रकम कम पहले"))
                }
                filters.addView(typeFilter, LinearLayout.LayoutParams(0, dp(48), 1f))
                filters.addView(sortFilter, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
                content.addView(filters, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

                val totalLabel = label("", 14f, ink, true)
                content.addView(totalLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(5) })
                val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                content.addView(listContainer, LinearLayout.LayoutParams(-1, -2))

                fun renderFilteredTransactions() {
                    listContainer.removeAllViews()
                    val query = search.text.toString().trim().lowercase(Locale.ROOT)
                    var filtered = currentItems.filter { item ->
                        val matchesType = when (typeFilter.selectedItemPosition) {
                            1 -> item.type == "EXPENSE"
                            2 -> item.type == "INCOME"
                            else -> true
                        }
                        val searchable = "${item.category} ${item.note} ${money(item.amountPaise)} ${item.paymentMethod} ${fmt.format(Date(item.dateMillis))}".lowercase(Locale.ROOT)
                        matchesType && (query.isEmpty() || searchable.contains(query))
                    }
                    filtered = when (sortFilter.selectedItemPosition) {
                        1 -> filtered.sortedBy { it.dateMillis }
                        2 -> filtered.sortedByDescending { it.amountPaise }
                        3 -> filtered.sortedBy { it.amountPaise }
                        else -> filtered.sortedByDescending { it.dateMillis }
                    }
                    val totalIncome = filtered.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                    val totalExpense = filtered.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                    totalLabel.text = "${filtered.size} रिकॉर्ड  •  कमाई ${money(totalIncome)}  •  खर्च ${money(totalExpense)}  •  शेष ${money(totalIncome - totalExpense)}"
                    if (filtered.isEmpty()) {
                        listContainer.addView(label(if (currentItems.isEmpty()) "अभी कोई लेन-देन नहीं है। ऊपर से खर्च या कमाई जोड़ें।" else "इस खोज या फ़िल्टर से कोई रिकॉर्ड नहीं मिला।", 14f, Color.GRAY, false).apply {
                            setPadding(dp(8), dp(18), dp(8), dp(18))
                        })
                    }
                    filtered.forEach { item ->
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(dp(13), dp(11), dp(13), dp(11))
                            background = android.graphics.drawable.GradientDrawable().apply {
                                setColor(Color.WHITE)
                                cornerRadius = dp(12).toFloat()
                                setStroke(dp(1), Color.rgb(225, 235, 230))
                            }
                            isClickable = true
                            isFocusable = true
                            setOnClickListener { showTransactionDialog(item.type, item) }
                            setOnLongClickListener {
                                AlertDialog.Builder(this@MainActivity)
                                    .setTitle("लेन-देन हटाएँ?")
                                    .setMessage("${item.category} • ${money(item.amountPaise)}\n${fmt.format(Date(item.dateMillis))}\nइस रिकॉर्ड को हटाना चाहते हैं?")
                                    .setNegativeButton("रद्द करें", null)
                                    .setPositiveButton("हटाएँ") { _, _ ->
                                        lifecycleScope.launch(Dispatchers.IO) {
                                            try {
                                                db.transactionDao().delete(item)
                                                withContext(Dispatchers.Main) {
                                                    Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (e: Exception) {
                                                withContext(Dispatchers.Main) {
                                                    Toast.makeText(this@MainActivity, "रिकॉर्ड नहीं हट पाया", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    }.show()
                                true
                            }
                        }
                        val topLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                        val typeText = if (item.type == "EXPENSE") "खर्च" else "कमाई"
                        val title = label("$typeText  •  ${item.category}", 15f, ink, true)
                        topLine.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
                        val amountColor = if (item.type == "EXPENSE") Color.rgb(190, 72, 60) else Color.rgb(18, 122, 81)
                        topLine.addView(label("${if (item.type == "EXPENSE") "−" else "+"}${money(item.amountPaise)}", 16f, amountColor, true))
                        row.addView(topLine)
                        row.addView(label("${fmt.format(Date(item.dateMillis))}  •  ${item.paymentMethod}", 12f, Color.GRAY, false).apply { setPadding(0, dp(4), 0, 0) })
                        if (item.note.isNotBlank()) row.addView(label(item.note, 13f, Color.rgb(75, 85, 80), false).apply { setPadding(0, dp(3), 0, 0) })
                        val recordActions = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            setPadding(0, dp(8), 0, 0)
                        }
                        val editButton = Button(this).apply {
                            text = "✏ एडिट करें"
                            isAllCaps = false
                            setOnClickListener { showTransactionDialog(item.type, item) }
                        }
                        val deleteButton = Button(this).apply {
                            text = "🗑 डिलीट करें"
                            isAllCaps = false
                            setTextColor(Color.rgb(175, 45, 45))
                            setOnClickListener { confirmDeleteTransaction(item) }
                        }
                        recordActions.addView(editButton, LinearLayout.LayoutParams(0, dp(44), 1f))
                        recordActions.addView(deleteButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
                        row.addView(recordActions, LinearLayout.LayoutParams(-1, -2))
                        listContainer.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
                    }
                }
                val refresh = { renderFilteredTransactions() }
                search.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
                    override fun afterTextChanged(s: android.text.Editable?) {}
                })
                typeFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
                }
                sortFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
                }
                renderFilteredTransactions()
            }
            "REPORT" -> {
                val monthLabel = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(reportMonthStart.time)
                val monthNav = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(10), 0, dp(8))
                }
                monthNav.addView(actionButton("‹ पिछला") {
                    reportMonthOffset--
                    renderDashboard()
                }, LinearLayout.LayoutParams(0, dp(46), 1f))
                monthNav.addView(label(monthLabel, 17f, ink, true).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(0, dp(46), 1.5f))
                monthNav.addView(actionButton("अगला ›") {
                    if (reportMonthOffset < 0) {
                        reportMonthOffset++
                        renderDashboard()
                    } else {
                        Toast.makeText(this@MainActivity, "भविष्य के महीने की रिपोर्ट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                    }
                }, LinearLayout.LayoutParams(0, dp(46), 1f))
                content.addView(monthNav, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

                val monthSummary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                monthSummary.addView(summaryCard("कुल कमाई", money(income), Color.rgb(18,122,81)),
                    LinearLayout.LayoutParams(0, dp(92), 1f))
                monthSummary.addView(summaryCard("कुल खर्च", money(expense), Color.rgb(190,72,60)),
                    LinearLayout.LayoutParams(0, dp(92), 1f).apply { leftMargin = dp(7) })
                content.addView(monthSummary, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                content.addView(summaryCard("महीने की बचत / शेष", money(income-expense), green),
                    LinearLayout.LayoutParams(-1, dp(78)).apply { topMargin = dp(8) })
                content.addView(label("साप्ताहिक कमाई और खर्च", 16f, ink, true).apply {
                    setPadding(dp(2), dp(14), 0, dp(6))
                })
                val weeklyTotals = (1..5).map { week ->
                    val records = monthItems.filter { item ->
                        val day = Calendar.getInstance().apply { timeInMillis = item.dateMillis }.get(Calendar.DAY_OF_MONTH)
                        ((day - 1) / 7 + 1) == week
                    }
                    week to (records.filter { it.type == "INCOME" }.sumOf { it.amountPaise } to
                        records.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise })
                }
                val chart = object : View(this@MainActivity) {
                    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    override fun onDraw(canvas: Canvas) {
                        super.onDraw(canvas)
                        val maxVal = maxOf(1L, weeklyTotals.maxOf { maxOf(it.second.first, it.second.second) }).toFloat()
                        val bottom = height - dp(25).toFloat()
                        val top = dp(8).toFloat()
                        val plotHeight = bottom - top
                        p.color = Color.rgb(225, 232, 228); p.strokeWidth = dp(1).toFloat()
                        canvas.drawLine(dp(8).toFloat(), bottom, width - dp(8).toFloat(), bottom, p)
                        val slot = (width - dp(24)).toFloat() / 5f
                        weeklyTotals.forEachIndexed { index, pair ->
                            val center = dp(12).toFloat() + slot * index + slot / 2f
                            val barWidth = minOf(dp(13).toFloat(), slot * .24f)
                            val incH = plotHeight * pair.second.first / maxVal
                            val expH = plotHeight * pair.second.second / maxVal
                            p.color = Color.rgb(18, 122, 81)
                            canvas.drawRoundRect(center - barWidth - dp(2), bottom - incH, center - dp(2), bottom, dp(3).toFloat(), dp(3).toFloat(), p)
                            p.color = Color.rgb(190, 72, 60)
                            canvas.drawRoundRect(center + dp(2), bottom - expH, center + barWidth + dp(2), bottom, dp(3).toFloat(), dp(3).toFloat(), p)
                            p.color = ink; p.textSize = dp(11).toFloat(); p.textAlign = Paint.Align.CENTER
                            canvas.drawText("सप्ताह ${pair.first}", center, height - dp(6).toFloat(), p)
                        }
                    }
                }
                content.addView(chart, LinearLayout.LayoutParams(-1, dp(170)))
                val chartLegend = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
                chartLegend.addView(label("● कमाई", 12f, Color.rgb(18, 122, 81), true))
                chartLegend.addView(label("     ● खर्च", 12f, Color.rgb(190, 72, 60), true))
                content.addView(chartLegend, LinearLayout.LayoutParams(-1, -2))
                content.addView(label("कुल ${monthItems.size} लेन-देन", 15f, ink, true).apply {
                    setPadding(dp(2), dp(14), 0, dp(8))
                })

                val dailyGroups = monthItems.groupBy { item ->
                    Calendar.getInstance().apply { timeInMillis = item.dateMillis }.let {
                        String.format(Locale.US, "%04d-%02d-%02d", it.get(Calendar.YEAR), it.get(Calendar.MONTH)+1, it.get(Calendar.DAY_OF_MONTH))
                    }
                }.toSortedMap(compareByDescending { it })

                if (dailyGroups.isEmpty()) {
                    content.addView(label("इस महीने का कोई रिकॉर्ड नहीं है। पिछले महीने देखने या नया खर्च/कमाई जोड़ने के लिए ऊपर जाएँ।", 14f, Color.GRAY, false).apply {
                        setPadding(dp(8), dp(12), dp(8), dp(12))
                    })
                } else {
                    dailyGroups.forEach { (dayKey, items) ->
                        val dayIncome = items.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                        val dayExpense = items.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                        val dayCal = Calendar.getInstance().apply {
                            val parts = dayKey.split("-")
                            set(parts[0].toInt(), parts[1].toInt()-1, parts[2].toInt(), 12, 0, 0)
                        }
                        content.addView(label("${fmt.format(dayCal.time)}  •  ${items.size} रिकॉर्ड", 15f, ink, true).apply {
                            setPadding(dp(2), dp(12), 0, dp(4))
                        })
                        content.addView(label("कमाई ${money(dayIncome)}     खर्च ${money(dayExpense)}     शेष ${money(dayIncome-dayExpense)}", 13f, green, false).apply {
                            setPadding(dp(2), 0, 0, dp(5))
                        })
                        items.sortedByDescending { it.dateMillis }.forEach { item ->
                            val row = LinearLayout(this).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                setPadding(dp(12), dp(10), dp(12), dp(10))
                                background = android.graphics.drawable.GradientDrawable().apply {
                                    setColor(Color.WHITE)
                                    cornerRadius = dp(10).toFloat()
                                    setStroke(dp(1), Color.rgb(225,235,230))
                                }
                                isClickable = true
                                isFocusable = true
                                setOnClickListener { showTransactionDialog(item.type, item) }
                            }
                            val desc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                            desc.addView(label("${if (item.type == "INCOME") "कमाई" else "खर्च"} • ${item.category}", 14f, ink, true))
                            if (item.note.isNotBlank()) desc.addView(label(item.note, 12f, Color.GRAY, false))
                            row.addView(desc, LinearLayout.LayoutParams(0, -2, 1f))
                            val color = if (item.type == "INCOME") Color.rgb(18,122,81) else Color.rgb(190,72,60)
                            row.addView(label("${if (item.type == "INCOME") "+" else "−"}${money(item.amountPaise)}", 14f, color, true))
                            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
                        }
                    }
                }
                content.addView(actionButton("📄 इस महीने की PDF बनाएँ") {
                    externalPickerOpen = true
                    pdfLauncher.launch("Daily_Hisaab_${SimpleDateFormat("yyyy_MM", Locale.US).format(reportMonthStart.time)}.pdf")
                }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
            }
            "CATEGORIES" -> {
                val monthLabel = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(reportMonthStart.time)
                val monthNav = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                monthNav.addView(actionButton("‹ पिछला") {
                    reportMonthOffset--
                    renderDashboard()
                }, LinearLayout.LayoutParams(0, dp(44), 1f))
                monthNav.addView(label(monthLabel, 16f, ink, true).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(0, dp(44), 1.5f))
                monthNav.addView(actionButton("अगला ›") {
                    if (reportMonthOffset < 0) {
                        reportMonthOffset++
                        renderDashboard()
                    } else {
                        Toast.makeText(this@MainActivity, "भविष्य के महीने की रिपोर्ट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show()
                    }
                }, LinearLayout.LayoutParams(0, dp(44), 1f))
                content.addView(monthNav, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })

                val categoryIncome = monthItems.filter { it.type == "INCOME" }
                val categoryExpense = monthItems.filter { it.type == "EXPENSE" }
                val totalCategoryIncome = categoryIncome.sumOf { it.amountPaise }
                val totalCategoryExpense = categoryExpense.sumOf { it.amountPaise }
                content.addView(label("इस महीने का श्रेणीवार सारांश", 16f, ink, true).apply {
                    setPadding(0, dp(5), 0, dp(8))
                })
                val summaryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                summaryRow.addView(summaryCard("कुल कमाई", money(totalCategoryIncome), Color.rgb(18, 122, 81)),
                    LinearLayout.LayoutParams(0, dp(88), 1f))
                summaryRow.addView(summaryCard("कुल खर्च", money(totalCategoryExpense), Color.rgb(190, 72, 60)),
                    LinearLayout.LayoutParams(0, dp(88), 1f).apply { leftMargin = dp(7) })
                content.addView(summaryRow, LinearLayout.LayoutParams(-1, -2))
                content.addView(summaryCard("शेष / बचत", money(totalCategoryIncome - totalCategoryExpense), green),
                    LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(7); bottomMargin = dp(10) })

                // Visual category pie chart, matching the reference screen. The chart is
                // derived from the same month-filtered expense records shown below.
                if (categoryExpense.isNotEmpty() && totalCategoryExpense > 0L) {
                    content.addView(label("श्रेणी अनुसार खर्च", 17f, ink, true).apply {
                        setPadding(dp(2), dp(10), 0, dp(6))
                    })
                    val pieColors = intArrayOf(
                        Color.rgb(239, 78, 83), Color.rgb(45, 154, 210),
                        Color.rgb(35, 166, 111), Color.rgb(245, 177, 42),
                        Color.rgb(119, 91, 190), Color.rgb(130, 139, 145),
                        Color.rgb(237, 126, 55), Color.rgb(34, 151, 153)
                    )
                    val pieGroups = categoryExpense.groupBy { it.category.ifBlank { "अन्य" } }
                        .entries.sortedByDescending { it.value.sumOf { item -> item.amountPaise } }
                    val pieView = object : View(this@MainActivity) {
                        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                        override fun onDraw(canvas: Canvas) {
                            super.onDraw(canvas)
                            val size = minOf(width.toFloat(), height.toFloat()) - dp(24)
                            val left = (width - size) / 2f
                            val top = (height - size) / 2f
                            val oval = android.graphics.RectF(left, top, left + size, top + size)
                            var startAngle = -90f
                            pieGroups.forEachIndexed { index, entry ->
                                val value = entry.value.sumOf { it.amountPaise }.toFloat()
                                val sweep = (value / totalCategoryExpense.toFloat()) * 360f
                                paint.color = pieColors[index % pieColors.size]
                                paint.style = Paint.Style.FILL
                                canvas.drawArc(oval, startAngle, sweep, true, paint)
                                startAngle += sweep
                            }
                        }
                    }
                    content.addView(pieView, LinearLayout.LayoutParams(-1, dp(190)))
                    pieGroups.forEachIndexed { index, entry ->
                        val amount = entry.value.sumOf { it.amountPaise }
                        val pct = amount * 100.0 / totalCategoryExpense
                        val legend = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            setPadding(dp(4), dp(3), dp(4), dp(3))
                        }
                        val swatch = View(this).apply {
                            background = android.graphics.drawable.GradientDrawable().apply {
                                shape = android.graphics.drawable.GradientDrawable.OVAL
                                setColor(pieColors[index % pieColors.size])
                            }
                        }
                        legend.addView(swatch, LinearLayout.LayoutParams(dp(12), dp(12)))
                        legend.addView(label(entry.key, 13f, ink, false), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
                        legend.addView(label("${String.format(Locale.US, "%.0f", pct)}%  •  ${money(amount)}", 12f, Color.DKGRAY, true))
                        content.addView(legend, LinearLayout.LayoutParams(-1, -2))
                    }
                }

                fun addCategorySection(sectionTitle: String, records: List<Transaction>, total: Long, color: Int) {
                    content.addView(label(sectionTitle, 17f, color, true).apply {
                        setPadding(dp(2), dp(12), 0, dp(5))
                    })
                    if (records.isEmpty()) {
                        content.addView(label("इस महीने इस प्रकार का कोई रिकॉर्ड नहीं है।", 14f, Color.GRAY, false).apply {
                            setPadding(dp(8), dp(8), dp(8), dp(12))
                        })
                        return
                    }
                    val groups = records.groupBy { it.category.ifBlank { "अन्य" } }
                        .entries.sortedByDescending { entry -> entry.value.sumOf { it.amountPaise } }
                    groups.forEach { entry ->
                        val amount = entry.value.sumOf { it.amountPaise }
                        val percent = if (total > 0L) amount * 100.0 / total else 0.0
                        val card = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(dp(13), dp(10), dp(13), dp(10))
                            background = android.graphics.drawable.GradientDrawable().apply {
                                setColor(Color.WHITE)
                                cornerRadius = dp(12).toFloat()
                                setStroke(dp(1), Color.rgb(225, 235, 230))
                            }
                            isClickable = true
                            isFocusable = true
                            setOnClickListener {
                                val detail = entry.value.sortedByDescending { it.dateMillis }
                                val lines = detail.joinToString("\n") { item ->
                                    "${fmt.format(Date(item.dateMillis))} • ${money(item.amountPaise)}" +
                                        if (item.note.isNotBlank()) "\n${item.note}" else ""
                                }
                                AlertDialog.Builder(this@MainActivity)
                                    .setTitle("${entry.key} • ${money(amount)}")
                                    .setMessage("${detail.size} रिकॉर्ड\n\n$lines")
                                    .setPositiveButton("ठीक है", null)
                                    .show()
                            }
                        }
                        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                        top.addView(label(entry.key, 15f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
                        top.addView(label(money(amount), 15f, color, true))
                        card.addView(top)
                        card.addView(label("${entry.value.size} रिकॉर्ड • ${String.format(Locale.US, "%.1f", percent)}%", 12f, Color.GRAY, false).apply {
                            setPadding(0, dp(4), 0, dp(7))
                        })
                        val progress = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                            max = 1000
                            progress = (percent.coerceIn(0.0, 100.0) * 10).toInt()
                            progressTintList = android.content.res.ColorStateList.valueOf(color)
                            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(232, 238, 234))
                        }
                        card.addView(progress, LinearLayout.LayoutParams(-1, dp(6)))
                        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
                    }
                }
                addCategorySection("🔴 खर्च की श्रेणियाँ", categoryExpense, totalCategoryExpense, Color.rgb(190, 72, 60))
                addCategorySection("🟢 कमाई की श्रेणियाँ", categoryIncome, totalCategoryIncome, Color.rgb(18, 122, 81))
                content.addView(label("किसी श्रेणी पर टैप करके उसके रिकॉर्ड देखें।", 12f, Color.GRAY, false).apply {
                    setPadding(dp(2), dp(8), 0, dp(8))
                })
            }
            "PDF" -> {
                val pdfMonthLabel = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(reportMonthStart.time)
                val pdfMonthNav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(8)) }
                pdfMonthNav.addView(actionButton("‹ पिछला") { reportMonthOffset--; renderDashboard() }, LinearLayout.LayoutParams(0, dp(44), 1f))
                pdfMonthNav.addView(label(pdfMonthLabel, 16f, ink, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, dp(44), 1.5f))
                pdfMonthNav.addView(actionButton("अगला ›") { if (reportMonthOffset < 0) { reportMonthOffset++; renderDashboard() } else Toast.makeText(this@MainActivity, "भविष्य के महीने की रिपोर्ट उपलब्ध नहीं है", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(44), 1f))
                content.addView(pdfMonthNav, LinearLayout.LayoutParams(-1, -2))
                content.addView(label("PDF का प्रकार चुनें। रिपोर्ट चुने हुए महीने के रिकॉर्ड से बनेगी।", 15f, Color.DKGRAY, false))
                content.addView(actionButton("📄 मासिक सारांश PDF") {
                    pdfReportMode = "MONTHLY"
                    externalPickerOpen = true
                    pdfLauncher.launch("Daily_Hisaab_Summary_${SimpleDateFormat("yyyy_MM", Locale.US).format(reportMonthStart.time)}.pdf")
                }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
                content.addView(label("महीने का सारांश और लेन-देन की सूची", 12f, Color.GRAY, false))
                content.addView(actionButton("🧾 पूरी लेन-देन सूची PDF") {
                    pdfReportMode = "TRANSACTIONS"
                    externalPickerOpen = true
                    pdfLauncher.launch("Daily_Hisaab_Transactions_${SimpleDateFormat("yyyy_MM", Locale.US).format(reportMonthStart.time)}.pdf")
                }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
                content.addView(label("कमाई और खर्च के सभी रिकॉर्ड तारीख के अनुसार", 12f, Color.GRAY, false))
                content.addView(actionButton("📊 श्रेणीवार रिपोर्ट PDF") {
                    pdfReportMode = "CATEGORY"
                    externalPickerOpen = true
                    pdfLauncher.launch("Daily_Hisaab_Category_${SimpleDateFormat("yyyy_MM", Locale.US).format(reportMonthStart.time)}.pdf")
                }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
                content.addView(label("हर विकल्प अलग रिपोर्ट तैयार करता है।", 12f, Color.rgb(18, 122, 81), false).apply {
                    setPadding(dp(2), dp(10), dp(2), dp(4))
                })
            }
            "BACKUP" -> {
                content.addView(label("बैकअप फ़ाइल मोबाइल में सेव करें या Android फ़ाइल पिकर में Google Drive चुनें।", 14f, Color.DKGRAY, false))
                content.addView(actionButton("⬇ मोबाइल / Drive में बैकअप") { externalPickerOpen = true; backupLauncher.launch("Daily_Hisaab_Backup.json") }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
                content.addView(actionButton("⬆ बैकअप रिस्टोर करें") { externalPickerOpen = true; restoreLauncher.launch(arrayOf("application/json", "text/*")) }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
                content.addView(label("ध्यान दें: रिस्टोर करने पर मौजूदा रिकॉर्ड बैकअप के रिकॉर्ड से बदलेंगे।", 13f, Color.rgb(160,75,35), false))
            }
            "SETTINGS" -> {
                val prefs = getSharedPreferences("secure", MODE_PRIVATE)
                content.addView(summaryCard("⚙️  ऐप सेटिंग्स", "आपकी सुरक्षा और हिसाब का नियंत्रण", green), LinearLayout.LayoutParams(-1, dp(78)).apply { topMargin = dp(8); bottomMargin = dp(8) })

                content.addView(label("🔐 सुरक्षा", 16f, ink, true).apply { setPadding(dp(2), dp(10), 0, dp(4)) })
                val activeLockMode = if (prefs.getString("lock_mode", "PIN") == "PATTERN") "पैटर्न लॉक" else "PIN लॉक"
                content.addView(summaryCard(activeLockMode, "ऐप खोलने से पहले चुनी हुई सुरक्षा आवश्यक", green), LinearLayout.LayoutParams(-1, dp(66)).apply { topMargin = dp(4) })
                val lockSwitch = CheckBox(this).apply {
                    text = "ऐप से बाहर जाने या स्क्रीन बंद होने पर दोबारा ${if (prefs.getString("lock_mode", "PIN") == "PATTERN") "पैटर्न" else "PIN"} माँगें"
                    textSize = 14f
                    setTextColor(ink)
                    isChecked = prefs.getBoolean("screen_lock_enabled", true)
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                    setOnCheckedChangeListener { _, checked ->
                        prefs.edit().putBoolean("screen_lock_enabled", checked).apply()
                        Toast.makeText(this@MainActivity,
                            if (checked) "स्क्रीन लॉक चालू कर दिया गया" else "स्क्रीन लॉक बंद; ऐप खोलने पर PIN फिर भी माँगा जाएगा",
                            Toast.LENGTH_LONG).show()
                    }
                }
                content.addView(lockSwitch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                content.addView(actionButton("🔒  PIN बदलें") { changePin() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6); bottomMargin = dp(8) })
                content.addView(actionButton("🔷  पैटर्न लॉक सेट / चालू करें") { setupPatternLock() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(8) })
                content.addView(actionButton("🔢  PIN लॉक पर वापस जाएँ") {
                    prefs.edit().putString("lock_mode", "PIN").apply()
                    Toast.makeText(this@MainActivity, "PIN लॉक चालू हो गया", Toast.LENGTH_SHORT).show()
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(8) })
                content.addView(label("PIN 4 से 6 अंकों का होता है। इसे सुरक्षित रखें और किसी से साझा न करें।", 12f, Color.GRAY, false))

                content.addView(label("📁 डेटा और रिपोर्ट", 16f, ink, true).apply { setPadding(dp(2), dp(18), 0, dp(4)) })
                content.addView(actionButton("⬇️  बैकअप बनाएँ") { currentScreen = "BACKUP"; renderDashboard() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
                content.addView(actionButton("⬆️  बैकअप रिस्टोर करें") {
                    AlertDialog.Builder(this@MainActivity).setTitle("बैकअप रिस्टोर")
                        .setMessage("रिस्टोर करने से पहले सुनिश्चित करें कि आपके पास मौजूदा हिसाब का बैकअप है। आगे बढ़कर बैकअप फ़ाइल चुनें?")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("फ़ाइल चुनें") { _, _ -> externalPickerOpen = true; restoreLauncher.launch(arrayOf("application/json", "text/*")) }
                        .show()
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
                content.addView(actionButton("📄  PDF रिपोर्ट बनाएँ") { currentScreen = "PDF"; renderDashboard() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
                content.addView(actionButton("📊  सभी लेन-देन CSV में निर्यात करें") {
                    externalPickerOpen = true
                    csvLauncher.launch("Daily_Hisaab_Transactions.csv")
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

                content.addView(label("ℹ️  ऐप की जानकारी", 16f, ink, true).apply { setPadding(dp(2), dp(18), 0, dp(4)) })
                content.addView(summaryCard("Daily Hisaab PRO", "संस्करण 1.0.0 • डेटा इस डिवाइस में सेव होता है", Color.rgb(75, 100, 120)), LinearLayout.LayoutParams(-1, dp(68)).apply { topMargin = dp(6) })
                content.addView(label("महत्वपूर्ण: ऐप हटाने या फ़ोन बदलने से पहले बैकअप फ़ाइल सुरक्षित जगह पर सेव कर लें।", 12f, Color.rgb(160,75,35), false).apply { setPadding(dp(2), dp(10), dp(2), dp(12) }))
            }
        }
    }

    private fun startOfMonth(cal: Calendar) {
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    }

    private fun confirmDeleteTransaction(item: Transaction) {
        AlertDialog.Builder(this)
            .setTitle("लेन-देन डिलीट करें?")
            .setMessage("${if (item.type == "EXPENSE") "खर्च" else "कमाई"} • ${item.category} • ${money(item.amountPaise)}\n${fmt.format(Date(item.dateMillis))}\n\nयह रिकॉर्ड हटाने के बाद वापस नहीं आएगा।")
            .setNegativeButton("नहीं, रहने दें", null)
            .setPositiveButton("हाँ, डिलीट करें") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        db.transactionDao().delete(item)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@MainActivity, "लेन-देन डिलीट हो गया", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@MainActivity, "डिलीट नहीं हुआ: ${e.message ?: "त्रुटि"}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .show()
    }

    private fun showTransactionDialog(type: String, existing: Transaction? = null) {
        // Full, scrollable transaction form. Keep the dialog open when validation fails.
        selectedDate = existing?.dateMillis ?: System.currentTimeMillis()

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(12))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(form)
        }

        fun fieldTitle(text: String) {
            form.addView(TextView(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(ink)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(5))
            })
        }

        val amount = EditText(this).apply {
            hint = if (type == "INCOME") "कमाई की रकम, जैसे 5000 या 125.50" else "जैसे 350 या 125.50"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 20f
            setSingleLine(true)
            setTextColor(if (type == "INCOME") Color.rgb(18, 122, 81) else ink)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            if (existing != null) setText(String.format(Locale.US, "%.2f", existing.amountPaise / 100.0))
        }

        val expenseCategories = listOf(
            "घर / राशन", "दूध / सब्ज़ी", "बिजली / पानी", "पेट्रोल / यात्रा",
            "दवा / स्वास्थ्य", "मोबाइल / इंटरनेट", "बच्चे / शिक्षा", "कपड़े", "मनोरंजन", "अन्य"
        )
        val incomeCategories = listOf(
            "खेती की बिक्री", "गन्ना भुगतान", "गेहूँ / धान बिक्री", "दूध बिक्री",
            "मजदूरी / दिहाड़ी", "वेतन", "व्यापार", "किराया", "ब्याज",
            "वापसी / रिफंड", "अन्य"
        )
        val defaults = if (type == "EXPENSE") expenseCategories else incomeCategories
        val options = if (existing != null && existing.category !in defaults) defaults + existing.category else defaults
        val category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, options).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            if (existing != null) setSelection(options.indexOf(existing.category).coerceAtLeast(0))
        }
        val note = EditText(this).apply {
            hint = if (type == "EXPENSE") "किस चीज़ पर खर्च हुआ? (वैकल्पिक)" else "उदाहरण: गन्ना भुगतान, फसल बिक्री या किससे कमाई हुई (वैकल्पिक)"
            setSingleLine(false)
            minLines = 2
            maxLines = 3
            if (existing != null) setText(existing.note)
        }
        val methods = listOf("नकद", "UPI", "बैंक", "कार्ड", "अन्य")
        val method = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, methods).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            if (existing != null) setSelection(methods.indexOf(existing.paymentMethod).coerceAtLeast(0))
        }
        val dateBtn = Button(this).apply {
            text = "📅  तारीख: ${fmt.format(Date(selectedDate))}"
            isAllCaps = false
        }
        dateBtn.setOnClickListener {
            val c = Calendar.getInstance().apply { timeInMillis = selectedDate }
            DatePickerDialog(this@MainActivity, { _, y, m, d ->
                val picked = Calendar.getInstance().apply {
                    set(Calendar.YEAR, y); set(Calendar.MONTH, m); set(Calendar.DAY_OF_MONTH, d)
                    set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                selectedDate = picked.timeInMillis
                dateBtn.text = "📅  तारीख: ${fmt.format(Date(selectedDate))}"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }

        if (type == "INCOME") {
            form.addView(TextView(this).apply {
                text = "कमाई का नया रिकॉर्ड"
                textSize = 18f
                setTextColor(Color.rgb(18, 122, 81))
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(4), 0, dp(6))
            })
            form.addView(TextView(this).apply {
                text = "कमाई का स्रोत चुनें, रकम भरें और तारीख के साथ सेव करें।"
                textSize = 13f
                setTextColor(Color.GRAY)
                setPadding(0, 0, 0, dp(8))
            })
        }
        fieldTitle("रकम (₹) *")
        form.addView(amount, LinearLayout.LayoutParams(-1, dp(56)))
        fieldTitle(if (type == "EXPENSE") "खर्च की श्रेणी" else "कमाई की श्रेणी")
        form.addView(category, LinearLayout.LayoutParams(-1, dp(52)))
        fieldTitle("विवरण")
        form.addView(note, LinearLayout.LayoutParams(-1, -2))
        fieldTitle("भुगतान का तरीका")
        form.addView(method, LinearLayout.LayoutParams(-1, dp(52)))
        fieldTitle("तारीख")
        form.addView(dateBtn, LinearLayout.LayoutParams(-1, dp(48)))
        form.addView(TextView(this).apply {
            text = "* रकम भरना ज़रूरी है। बाकी विवरण बाद में भी देख सकते हैं।"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(8), 0, 0)
        })

        val title = when {
            existing != null -> "लेन-देन सुधारें"
            type == "EXPENSE" -> "खर्च जोड़ें"
            else -> "कमाई जोड़ें"
        }
        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setNegativeButton("रद्द करें", null)
            .setPositiveButton("सेव करें", null)
        if (existing != null) builder.setNeutralButton("हटाएँ", null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                // Accept ordinary decimal input and pasted Indian-style amounts such as 1,250.50.
                val rawInput = amount.text.toString().trim().replace("₹", "").replace(" ", "")
                val normalized = if (rawInput.contains('.') && rawInput.count { it == ',' } > 0) {
                    rawInput.replace(",", "")
                } else if (!rawInput.contains('.') && rawInput.count { it == ',' } == 1) {
                    rawInput.replace(',', '.')
                } else {
                    rawInput.replace(",", "")
                }
                val value = normalized.toDoubleOrNull()
                if (value == null || !value.isFinite() || value <= 0.0 || value > 1000000000.0) {
                    amount.error = "सही रकम दर्ज करें"
                    amount.requestFocus()
                    Toast.makeText(this@MainActivity, "कृपया शून्य से अधिक सही रकम भरें", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
                cal.set(Calendar.HOUR_OF_DAY, 12); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                val item = Transaction(
                    id = existing?.id ?: 0,
                    type = existing?.type ?: type,
                    amountPaise = (value * 100.0).toLong(),
                    category = category.selectedItem?.toString() ?: "अन्य",
                    note = note.text.toString().trim(),
                    paymentMethod = method.selectedItem?.toString() ?: "नकद",
                    dateMillis = cal.timeInMillis,
                    createdAt = existing?.createdAt ?: System.currentTimeMillis()
                )
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        if (existing == null) db.transactionDao().insert(item) else db.transactionDao().update(item)
                        withContext(Dispatchers.Main) {
                            selectedDate = System.currentTimeMillis()
                            Toast.makeText(this@MainActivity, if (existing == null) "${if (type == "EXPENSE") "खर्च" else "कमाई"} सेव हो गई" else "हिसाब अपडेट हो गया", Toast.LENGTH_SHORT).show()
                            dialog.dismiss()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true
                            Toast.makeText(this@MainActivity, "हिसाब सेव नहीं हुआ: ${e.message ?: "त्रुटि"}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            if (existing != null) {
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("लेन-देन हटाएँ?")
                        .setMessage("${existing.category} • ${money(existing.amountPaise)} का रिकॉर्ड हमेशा के लिए हट जाएगा।")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("हाँ, हटाएँ") { _, _ ->
                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    db.transactionDao().delete(existing)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड हटा दिया गया", Toast.LENGTH_SHORT).show()
                                        dialog.dismiss()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिकॉर्ड नहीं हट सका: ${e.message ?: "त्रुटि"}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.show()
                }
            }
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), (resources.displayMetrics.heightPixels * 0.82).toInt())
    }

    private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    private fun exportCsv(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val records = db.transactionDao().allNow().sortedBy { it.dateMillis }
                val csv = buildString {
                    append("\uFEFF")
                    appendLine("तारीख,प्रकार,श्रेणी,रकम रुपये,भुगतान तरीका,विवरण")
                    records.forEach { item ->
                        val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(item.dateMillis))
                        val type = if (item.type == "INCOME") "कमाई" else "खर्च"
                        val amount = String.format(Locale.US, "%.2f", item.amountPaise / 100.0)
                        appendLine(listOf(date, type, item.category, amount, item.paymentMethod, item.note).joinToString(",") { csvEscape(it) })
                    }
                }
                val output = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("चुनी गई जगह पर CSV नहीं बनाई जा सकी")
                output.use { it.write(csv.toByteArray(Charsets.UTF_8)); it.flush() }
                val verified = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("CSV फ़ाइल दोबारा नहीं खुली")
                require(verified.isNotEmpty()) { "CSV फ़ाइल खाली है" }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "${records.size} रिकॉर्ड CSV में सेव हुए", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "CSV निर्यात विफल: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun makeBackupPayload(transactions: List<Transaction>): String {
        val arr = JSONArray()
        transactions.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id); put("type", t.type); put("amountPaise", t.amountPaise)
                put("category", t.category); put("note", t.note); put("paymentMethod", t.paymentMethod)
                put("dateMillis", t.dateMillis); put("createdAt", t.createdAt)
            })
        }
        return JSONObject().put("app", "Daily Hisaab PRO").put("version", 1)
            .put("exportedAt", System.currentTimeMillis()).put("transactions", arr).toString(2)
    }

    private fun exportBackup(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val payload = makeBackupPayload(db.transactionDao().allNow())
                val bytes = payload.toByteArray(Charsets.UTF_8)
                require(bytes.isNotEmpty()) { "बैकअप खाली है" }
                val output = contentResolver.openOutputStream(uri, "wt")
                    ?: throw IllegalStateException("चुनी गई जगह पर फ़ाइल नहीं बनाई जा सकी")
                output.use { it.write(bytes); it.flush() }
                // Read the saved document back before reporting success.
                val saved = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("सेव की गई बैकअप फ़ाइल दोबारा नहीं खुली")
                val checked = JSONObject(String(saved, Charsets.UTF_8))
                require(checked.optString("app") == "Daily Hisaab PRO" && checked.has("transactions")) {
                    "सेव की गई बैकअप फ़ाइल की जाँच असफल"
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "बैकअप सेव और जाँच हो गया (${checked.getJSONArray("transactions").length()} रिकॉर्ड)", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "बैकअप नहीं बन पाया: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun restoreBackup(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val raw = contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                } ?: throw IllegalStateException("फ़ाइल नहीं खुली")
                val obj = JSONObject(raw)
                if (obj.optString("app") != "Daily Hisaab PRO") {
                    throw IllegalArgumentException("यह Daily Hisaab PRO की बैकअप फ़ाइल नहीं है")
                }
                val version = obj.optInt("version", -1)
                if (version != 1) throw IllegalArgumentException("बैकअप वर्जन समर्थित नहीं है")
                val arr = obj.getJSONArray("transactions")
                if (arr.length() > 100000) throw IllegalArgumentException("बैकअप में बहुत अधिक रिकॉर्ड हैं")
                val items = mutableListOf<Transaction>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val type = o.optString("type", "")
                    val amount = o.optLong("amountPaise", -1L)
                    val date = o.optLong("dateMillis", -1L)
                    val category = o.optString("category", "अन्य").trim()
                    val note = o.optString("note", "")
                    val paymentMethod = o.optString("paymentMethod", "नकद").trim()
                    if (type !in listOf("INCOME", "EXPENSE") || amount <= 0L || date <= 0L || amount > 9_000_000_000_000L || category.isBlank() || category.length > 120 || note.length > 4000 || paymentMethod.isBlank() || paymentMethod.length > 80) {
                        throw IllegalArgumentException("बैकअप में गलत रिकॉर्ड है (क्रम ${i + 1})")
                    }
                    items.add(Transaction(
                        type = type,
                        amountPaise = amount,
                        category = category,
                        note = note,
                        paymentMethod = paymentMethod,
                        dateMillis = date,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
                withContext(Dispatchers.Main) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("बैकअप रिस्टोर करें?")
                        .setMessage("${items.size} रिकॉर्ड रिस्टोर होंगे। मौजूदा हिसाब हटकर बैकअप का हिसाब आ जाएगा। पहले मौजूदा डेटा का बैकअप ले लें।")
                        .setNegativeButton("रद्द करें", null)
                        .setPositiveButton("रिस्टोर करें") { _, _ ->
                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    // Keep a private emergency snapshot before replacing current records.
                                    val current = db.transactionDao().allNow()
                                    val safetyDir = java.io.File(filesDir, "backup_safety").apply { if (!exists() && !mkdirs()) throw IllegalStateException("सुरक्षा बैकअप फ़ोल्डर नहीं बन पाया") }
                                    val safetyFile = java.io.File(safetyDir, "before_restore_${System.currentTimeMillis()}.json")
                                    safetyFile.writeText(makeBackupPayload(current), Charsets.UTF_8)
                                    val safetyCheck = JSONObject(safetyFile.readText(Charsets.UTF_8))
                                    require(safetyCheck.optString("app") == "Daily Hisaab PRO" && safetyCheck.getJSONArray("transactions").length() == current.size) { "सुरक्षा बैकअप सत्यापित नहीं हुआ; रिस्टोर रोक दिया गया" }
                                    db.withTransaction {
                                        db.transactionDao().clearAll()
                                        if (items.isNotEmpty()) db.transactionDao().insertAll(items)
                                    }
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "${items.size} रिकॉर्ड रिस्टोर हुए। पुराने डेटा का सुरक्षा बैकअप ऐप में रखा गया।", Toast.LENGTH_LONG).show()
                                        renderDashboard()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(this@MainActivity, "रिस्टोर असफल: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "रिस्टोर असफल: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun exportPdf(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val cal = Calendar.getInstance()
                cal.set(Calendar.DAY_OF_MONTH, 1); startOfMonth(cal)
                cal.add(Calendar.MONTH, reportMonthOffset)
                val reportCal = cal.clone() as Calendar
                val start = cal.timeInMillis
                cal.add(Calendar.MONTH, 1)
                val end = cal.timeInMillis
                val rawItems = db.transactionDao().forPeriod(start, end).sortedBy { it.dateMillis }
                val income = rawItems.filter { it.type == "INCOME" }.sumOf { it.amountPaise }
                val expense = rawItems.filter { it.type == "EXPENSE" }.sumOf { it.amountPaise }
                val items: List<Transaction> = when (pdfReportMode) {
                    "CATEGORY" -> rawItems.groupBy { it.type to it.category }.map { (key, group) ->
                        Transaction(type = key.first, amountPaise = group.sumOf { it.amountPaise }, category = key.second,
                            note = "${group.size} रिकॉर्ड", paymentMethod = "सभी", dateMillis = reportCal.timeInMillis)
                    }.sortedWith(compareBy<Transaction> { it.type }.thenByDescending { it.amountPaise })
                    else -> rawItems
                }
                val displayItems: List<Transaction> = if (pdfReportMode == "MONTHLY") emptyList() else items
                val pdf = PdfDocument()
                val pageWidth = 595
                val pageHeight = 842
                val margin = 32f
                val rowHeight = 24f
                val rowsPerPage = 26
                val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(23, 107, 87); textSize = 20f
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.DKGRAY; textSize = 9.5f
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                }
                val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(235, 246, 241); textSize = 9f
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.LTGRAY; strokeWidth = 0.7f
                }
                data class PdfLine(val item: Transaction, val detail: String, val firstLine: Boolean)
                val detailWidth = 220f
                val pdfLines = mutableListOf<PdfLine>()
                for (item in displayItems) {
                    val fullDetail = item.category + if (item.note.isNotBlank()) " / " + item.note else ""
                    val words = fullDetail.split(Regex("\\s+"))
                    val wrapped = mutableListOf<String>()
                    var current = ""
                    for (word in words) {
                        var remaining = word
                        while (remaining.isNotEmpty() && bodyPaint.measureText(remaining) > detailWidth) {
                            var cut = remaining.length
                            while (cut > 1 && bodyPaint.measureText(remaining.substring(0, cut)) > detailWidth) cut--
                            if (current.isNotEmpty()) { wrapped.add(current); current = "" }
                            wrapped.add(remaining.substring(0, cut))
                            remaining = remaining.substring(cut)
                        }
                        if (remaining.isNotEmpty()) {
                            val candidate = if (current.isEmpty()) remaining else "$current $remaining"
                            if (current.isNotEmpty() && bodyPaint.measureText(candidate) > detailWidth) {
                                wrapped.add(current)
                                current = remaining
                            } else current = candidate
                        }
                    }
                    if (current.isNotEmpty()) wrapped.add(current)
                    if (wrapped.isEmpty()) wrapped.add("")
                    wrapped.forEachIndexed { index, line -> pdfLines.add(PdfLine(item, line, index == 0)) }
                }
                val pages = maxOf(1, (pdfLines.size + rowsPerPage - 1) / rowsPerPage)
                for (pageNumber in 0 until pages) {
                    val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber + 1).create()
                    val page = pdf.startPage(info)
                    val canvas = page.canvas
                    canvas.drawText("Daily Hisaab PRO", margin, 42f, titlePaint)
                    bodyPaint.textSize = 10f
                    val reportTitle = when (pdfReportMode) {
                        "TRANSACTIONS" -> "पूरी लेन-देन सूची"
                        "CATEGORY" -> "श्रेणीवार रिपोर्ट"
                        else -> "मासिक सारांश"
                    }
                    canvas.drawText("$reportTitle: ${SimpleDateFormat("MMMM yyyy", Locale("hi", "IN")).format(reportCal.time)}    पृष्ठ ${pageNumber + 1}/$pages", margin, 62f, bodyPaint)
                    if (pageNumber == 0) {
                        bodyPaint.textSize = 10f
                        canvas.drawText("कुल कमाई: ${money(income)}", margin, 84f, bodyPaint)
                        canvas.drawText("कुल खर्च: ${money(expense)}", 220f, 84f, bodyPaint)
                        canvas.drawText("शेष: ${money(income - expense)}", 400f, 84f, bodyPaint)
                    }
                    var y = if (pageNumber == 0) 112f else 82f
                    if (pdfReportMode == "MONTHLY") {
                        bodyPaint.textSize = 12f
                        canvas.drawText("इस महीने कुल ${rawItems.size} लेन-देन दर्ज हैं।", margin, y + 16f, bodyPaint)
                        canvas.drawText("कमाई और खर्च का सारांश ऊपर दिया गया है।", margin, y + 40f, bodyPaint)
                    } else {
                        canvas.drawRect(margin, y - 14f, pageWidth - margin, y + 5f, headerPaint)
                        bodyPaint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                        if (pdfReportMode == "CATEGORY") {
                            canvas.drawText("प्रकार", margin + 3f, y, bodyPaint)
                            canvas.drawText("श्रेणी / विवरण", margin + 85f, y, bodyPaint)
                            canvas.drawText("रकम", margin + 445f, y, bodyPaint)
                        } else {
                            canvas.drawText("तारीख", margin + 3f, y, bodyPaint)
                            canvas.drawText("प्रकार", margin + 73f, y, bodyPaint)
                            canvas.drawText("श्रेणी / विवरण", margin + 135f, y, bodyPaint)
                            canvas.drawText("तरीका", margin + 365f, y, bodyPaint)
                            canvas.drawText("रकम", margin + 445f, y, bodyPaint)
                        }
                        y += 22f
                        bodyPaint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    }
                    val from = pageNumber * rowsPerPage
                    val to = minOf(pdfLines.size, from + rowsPerPage)
                    for (i in from until to) {
                        val line = pdfLines[i]
                        val t = line.item
                        if (line.firstLine) {
                            val typeText = if (t.type == "INCOME") "कमाई" else "खर्च"
                            if (pdfReportMode == "CATEGORY") {
                                canvas.drawText(typeText, margin + 3f, y, bodyPaint)
                                canvas.drawText(line.detail, margin + 85f, y, bodyPaint)
                            } else {
                                val dateText = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(t.dateMillis))
                                canvas.drawText(dateText, margin + 3f, y, bodyPaint)
                                canvas.drawText(typeText, margin + 73f, y, bodyPaint)
                                canvas.drawText(t.paymentMethod.take(10), margin + 365f, y, bodyPaint)
                                canvas.drawText(money(t.amountPaise), margin + 445f, y, bodyPaint)
                                canvas.drawText(line.detail, margin + 135f, y, bodyPaint)
                            }
                            if (pdfReportMode == "CATEGORY") canvas.drawText(money(t.amountPaise), margin + 445f, y, bodyPaint)
                        } else {
                            canvas.drawText(line.detail, if (pdfReportMode == "CATEGORY") margin + 85f else margin + 135f, y, bodyPaint)
                        }
                        canvas.drawLine(margin, y + 7f, pageWidth - margin, y + 7f, linePaint)
                        y += rowHeight
                    }
                    if (rawItems.isEmpty()) {
                        canvas.drawText("इस महीने कोई रिकॉर्ड नहीं है।", margin + 3f, y, bodyPaint)
                    }
                    pdf.finishPage(page)
                }
                val output = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("चुनी गई जगह पर PDF नहीं बनाई जा सकी")
                output.use { pdf.writeTo(it) }
                pdf.close()
                withContext(Dispatchers.Main) {
                    val savedLabel = when (pdfReportMode) { "TRANSACTIONS" -> "लेन-देन सूची"; "CATEGORY" -> "श्रेणीवार रिपोर्ट"; else -> "मासिक सारांश" }
                    Toast.makeText(this@MainActivity, "$savedLabel PDF सेव हो गई (${pages} पृष्ठ)", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "PDF नहीं बनी: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun changePin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        val oldPin = EditText(this).apply { hint = "मौजूदा PIN"; inputType = 18 }
        val newPin = EditText(this).apply { hint = "नया 4–6 अंकों का PIN"; inputType = 18 }
        box.addView(oldPin); box.addView(newPin)
        AlertDialog.Builder(this).setTitle("PIN बदलें").setView(box)
            .setNegativeButton("रद्द", null).setPositiveButton("सेव") { _, _ ->
                val prefs = getSharedPreferences("secure", MODE_PRIVATE)
                val savedHash = prefs.getString("pin_hash", null)
                val savedSalt = prefs.getString("pin_salt", null)
                val newValue = newPin.text.toString()
                if (savedHash == null || savedSalt == null || !verifyPin(oldPin.text.toString(), savedSalt, savedHash)) {
                    Toast.makeText(this, "मौजूदा PIN गलत है", Toast.LENGTH_LONG).show()
                } else if (newValue.length in 4..6 && newValue.all { it.isDigit() }) {
                    savePin(newValue)
                    Toast.makeText(this, "PIN सुरक्षित रूप से बदल गया", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN 4 से 6 अंकों का होना चाहिए", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun summaryCard(title: String, value: String, color: Int): LinearLayout {
        val tint = when (color) {
            Color.rgb(190, 72, 60) -> Color.rgb(255, 241, 239)
            Color.rgb(35, 105, 165) -> Color.rgb(237, 246, 255)
            else -> Color.rgb(235, 248, 241)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(11), dp(8), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(tint)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.argb(28, color shr 16 and 0xff, color shr 8 and 0xff, color and 0xff))
            }
            elevation = dp(1).toFloat()
        }
        card.addView(label(title, 12f, Color.rgb(76, 88, 82), false))
        card.addView(label(value, 16f, color, true))
        return card
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(green)
            cornerRadius = dp(11).toFloat()
        }
        setOnClickListener { action() }
    }
    private fun smallButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        setTextColor(Color.rgb(35, 83, 67))
        minHeight = dp(46)
        setPadding(dp(5), dp(5), dp(5), dp(5))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), Color.rgb(215, 231, 222))
        }
        elevation = dp(1).toFloat()
        setOnClickListener { action() }
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun money(paise: Long): String = "₹ " + String.format(Locale.US, "%,.2f", paise / 100.0)
    private fun monthName(): String = SimpleDateFormat("yyyy_MM", Locale.US).format(Date())
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
