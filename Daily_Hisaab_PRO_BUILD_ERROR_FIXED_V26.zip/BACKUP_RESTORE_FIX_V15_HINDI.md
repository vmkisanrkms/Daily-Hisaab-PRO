# Daily Hisaab PRO — Backup / Restore Fix V15

## Source changes
- Backup export now writes the selected document, reads it back, and validates its app marker and transaction collection before showing success.
- Restore validates app marker, supported schema version, record count, type, amount and date before prompting for replacement.
- Before restore replaces current transactions, the app writes and verifies a private emergency JSON snapshot under the app's internal `files/backup_safety` directory.
- Actual database replacement remains in a Room transaction so failed inserts roll back.
- Empty backup restore is allowed only when it is a valid Daily Hisaab PRO version-1 archive containing an empty transactions array.

## Not yet verified
- Android Gradle/Kotlin build, APK installation, SAF provider behavior, and real backup → clear/change data → restore round trip were not run in this environment.
- Emergency snapshots are private to the app installation and are not automatically exported to Drive; uninstalling/clearing app data can remove them. Keep an external backup too.
