# Daily Hisaab PRO — V18 Fixes

## इस संस्करण में किए गए source fixes
- PIN बनाते समय गलत PIN डालने पर ऐप बंद नहीं होगा; उसी डायलॉग में त्रुटि दिखेगी और दोबारा सुधार सकते हैं।
- Restore में category, note और payment method के खाली/अत्यधिक लंबे मानों की validation जोड़ी गई।
- PDF रिपोर्ट में category/note को काटने के बजाय शब्दों के आधार पर कई पंक्तियों में wrap किया जाता है; लंबा विवरण आगे की पंक्तियों में जारी रहता है।
- V17 में चुने हुए महीने की PDF वाली व्यवस्था और लेन-देन सूची में नोट की दोहरी प्रस्तुति न होने वाली स्थिति को रखा गया।

## अभी भी बाकी / सत्यापित नहीं
- अलग 3×3 pattern lock और PIN/Pattern lock-mode selector अभी इस पैच में लागू नहीं है।
- Android APK build, signing, installation और वास्तविक डिवाइस परीक्षण नहीं किए गए।
- PDF Hindi glyph rendering और बहुत लंबे बिना-space शब्दों का visual test बाकी है।
- Backup/restore round-trip और failure rollback का device test बाकी है।

यह source patch है, verified release APK नहीं।
