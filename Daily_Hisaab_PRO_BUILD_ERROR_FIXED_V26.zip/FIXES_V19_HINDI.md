# Daily Hisaab PRO V19 — सुरक्षा और PDF सुधार

## Source changes
- पैटर्न लॉक बनाने के लिए 3×3 डॉट UI, दो बार पैटर्न मिलान, salted PBKDF2 hash storage.
- Settings से पैटर्न लॉक चालू करने और PIN लॉक पर लौटने का विकल्प.
- PIN और पैटर्न दोनों के गलत प्रयास एक साझा 5-attempt / 30-second lockout में गिने जाते हैं.
- लंबे बिना-space शब्द भी PDF में detail column की चौड़ाई के भीतर विभाजित होते हैं.
- Root project और `dhfix` snapshot में MainActivity source समान रखा.

## Limitations / audit
- ZIP integrity check ही इस environment में किया जा सकता है; Gradle Android build और device tests नहीं किए गए.
- पैटर्न setup flow और unlock flow को वास्तविक Android device पर अवश्य टेस्ट करें, विशेषकर activity lifecycle, dialog dismissal और 5 failed attempts.
- Android View pattern UI simple custom implementation है; यह OS lockscreen/biometric का विकल्प नहीं है.
- PIN setup remains required for initial app setup and fallback.
