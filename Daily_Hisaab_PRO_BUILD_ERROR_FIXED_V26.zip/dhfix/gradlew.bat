@echo off
REM Generate wrapper with: gradle wrapper --gradle-version 8.11.1
gradle %*
