Daily Hisaab PRO V23: PDF mode consistency and active lock-mode label fixes. Android build/runtime testing remains pending.
