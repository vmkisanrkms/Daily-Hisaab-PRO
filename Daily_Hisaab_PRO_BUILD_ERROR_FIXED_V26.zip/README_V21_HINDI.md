# Daily Hisaab PRO V21

V20 पर आधारित incremental UI change: PDF स्क्रीन पर तीन report-type entry points और चुने हुए महीने के अनुसार filenames। यह पूरा UI redesign नहीं है। अलग-अलग PDF content layouts और Android runtime verification अभी बाकी हैं।
