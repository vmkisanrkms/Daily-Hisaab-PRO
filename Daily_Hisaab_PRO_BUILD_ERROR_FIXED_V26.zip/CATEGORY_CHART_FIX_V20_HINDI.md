# V20 — श्रेणीवार चार्ट सुधार

- श्रेणीवार स्क्रीन में महीने के खर्च रिकॉर्ड से बनने वाला पाई चार्ट जोड़ा।
- चार्ट के नीचे श्रेणी, प्रतिशत और रकम की लीजेंड जोड़ी।
- चार्ट उसी `categoryExpense` और `totalCategoryExpense` डेटा का उपयोग करता है जो रिपोर्ट के बाकी हिस्से में उपयोग होता है।

सीमाएँ: ZIP integrity जाँची जा सकती है, लेकिन Android/Kotlin compilation, APK build और वास्तविक मोबाइल पर visual परीक्षण अभी नहीं हुआ है। Google Drive backup अलग से Drive API integration नहीं है; Android document picker के माध्यम से उपयोगकर्ता Drive चुन सकता है, यदि Drive ऐप/provider उपलब्ध हो।
