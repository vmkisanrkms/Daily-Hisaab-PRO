Daily Hisaab PRO V20 — श्रेणीवार पाई चार्ट

यह V19 स्रोत पर आधारित incremental update है। श्रेणीवार रिपोर्ट में खर्च का pie chart और प्रतिशत/रकम legend जोड़ा गया है। Android APK build और device test लंबित हैं।
