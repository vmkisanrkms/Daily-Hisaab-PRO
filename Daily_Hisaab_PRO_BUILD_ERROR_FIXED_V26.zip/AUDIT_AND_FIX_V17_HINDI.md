# Daily Hisaab PRO V17 — Audit & Fix

## इस पैच में किए गए वास्तविक source बदलाव
- लेन-देन सूची में एक ही नोट/विवरण दो बार जोड़ने वाली duplicate UI line हटाई।
- PDF स्क्रीन में पिछला/अगला महीना चुनने का नियंत्रण जोड़ा। भविष्य के महीने पर जाने से रोका।
- PDF फ़ाइल का नाम चुने हुए महीने से बनता है।
- PDF export अब `reportMonthOffset` के अनुसार उसी चुने हुए महीने का डेटा लेता है और शीर्षक में सही महीना दिखाता है।

## अभी बाकी / runtime test
- PIN के साथ अलग 3x3 pattern lock और lock-mode selector अभी इस पैच में implement नहीं किया गया है।
- PDF में लंबे विवरण का wrap/pagination और हिंदी glyph rendering वास्तविक PDF खोलकर जाँचना बाकी है।
- Backup/restore hostile-input और rollback का Android runtime test बाकी है।
- Gradle/Kotlin compile, signed APK, install, device lifecycle, font scaling और सभी स्क्रीन का end-to-end test नहीं चला है।

## सत्यापन
- ZIP integrity: build के बाद `unzip -t` से जाँची जाएगी।
- यह source ZIP है, verified APK नहीं।
