package com.videodownloader.app

import android.app.Activity
import android.app.DownloadManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var linkInput: EditText
    private lateinit var status: TextView
    private lateinit var qualityGroup: RadioGroup
    private lateinit var hdUrlInput: EditText
    private lateinit var normalUrlInput: EditText
    private var selectedQuality = "HD"
    private var activeDownloadId: Long = -1L
    private var downloadReceiverRegistered = false

    private val downloadCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id <= 0L || id != activeDownloadId) return
            verifyCompletedDownload(id)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 91, 214)
        window.navigationBarColor = android.graphics.Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        registerDownloadReceiver()
        buildHome()
    }

    override fun onDestroy() {
        if (downloadReceiverRegistered) {
            runCatching { unregisterReceiver(downloadCompleteReceiver) }
            downloadReceiverRegistered = false
        }
        super.onDestroy()
    }

    private fun registerDownloadReceiver() {
        if (downloadReceiverRegistered) return
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadCompleteReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(downloadCompleteReceiver, filter)
        }
        downloadReceiverRegistered = true
    }

    private fun verifyCompletedDownload(id: Long) {
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        var cursor: Cursor? = null
        try {
            cursor = manager.query(DownloadManager.Query().setFilterById(id))
            if (cursor == null || !cursor.moveToFirst()) {
                showStatus("डाउनलोड की स्थिति नहीं मिल सकी। Downloads ऐप में जाँचें।")
                return
            }
            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
            val mimeIndex = cursor.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
            val sizeIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val statusValue = if (statusIndex >= 0) cursor.getInt(statusIndex) else -1
            val reason = if (reasonIndex >= 0) cursor.getInt(reasonIndex) else 0
            val mime = if (mimeIndex >= 0) cursor.getString(mimeIndex).orEmpty() else ""
            val size = if (sizeIndex >= 0) cursor.getLong(sizeIndex) else -1L

            when (statusValue) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val downloadedUri = manager.getUriForDownloadedFile(id)
                    val actualMime = downloadedUri?.let { contentResolver.getType(it) }.orEmpty().ifBlank { mime }
                    val verifiedSize = downloadedUri?.let { uri ->
                        runCatching { contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L }.getOrDefault(-1L)
                    } ?: -1L
                    if (downloadedUri != null && (actualMime.startsWith("video/") || mime.startsWith("video/")) &&
                        (size > 0L || verifiedSize > 0L)) {
                        showStatus("डाउनलोड सफल और वीडियो फ़ाइल के रूप में सत्यापित। आकार: ${if (size > 0L) size else verifiedSize} bytes। फ़ाइल Movies/VideoDownloader में देखें।")
                    } else {
                        showStatus("डाउनलोड पूरा हुआ, लेकिन वीडियो MIME type/फ़ाइल आकार की पुष्टि नहीं हुई। फ़ाइल को वीडियो न मानें; Downloads में जाँचें।")
                    }
                }
                DownloadManager.STATUS_FAILED ->
                    showStatus("डाउनलोड विफल हुआ (त्रुटि कोड $reason)। लिंक, नेटवर्क या सर्वर अनुमति जाँचें।")
                else -> showStatus("डाउनलोड की स्थिति अभी पूरी नहीं है। कुछ देर बाद Downloads में जाँचें।")
            }
        } catch (e: Exception) {
            showStatus("डाउनलोड परिणाम सत्यापित नहीं हो सका: ${e.localizedMessage ?: "Downloads में जाँचें"}")
        } finally {
            cursor?.close()
        }
    }

    private fun buildHome() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF4F7FC.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(20))
        }

        val header = TextView(this).apply {
            text = "▶  Video Downloader"
            textSize = 27f
            setTextColor(0xFF075BD6.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }
        content.addView(header)
        content.addView(TextView(this).apply {
            text = "Facebook वीडियो लिंक पेस्ट करें"
            textSize = 16f
            setTextColor(0xFF283548.toInt())
            setPadding(0, 0, 0, dp(14))
        })

        linkInput = EditText(this).apply {
            hint = "https://..."
            textSize = 16f
            singleLine = false
            minLines = 2
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(linkInput, matchWidth(dp(94)))

        val paste = Button(this).apply {
            text = "लिंक पेस्ट करें"
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) linkInput.setText(clip.getItemAt(0).coerceToText(this@MainActivity))
                else showStatus("क्लिपबोर्ड में कोई लिंक नहीं मिला।")
            }
        }
        content.addView(paste, matchWidth())

        val check = Button(this).apply {
            text = "लिंक चेक करें"
            setOnClickListener { checkLink() }
        }
        content.addView(check, matchWidth())

        content.addView(TextView(this).apply {
            text = "क्वालिटी चुनें"
            textSize = 18f
            setTextColor(0xFF17243A.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(18), 0, dp(6))
        })
        qualityGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val hd = RadioButton(this).apply { text = "HD"; id = View.generateViewId(); isChecked = true }
        val normal = RadioButton(this).apply { text = "नॉर्मल"; id = View.generateViewId() }
        qualityGroup.addView(hd)
        qualityGroup.addView(normal)
        qualityGroup.setOnCheckedChangeListener { _, id -> selectedQuality = if (id == hd.id) "HD" else "नॉर्मल" }
        content.addView(qualityGroup)

        content.addView(TextView(this).apply {
            text = "वैकल्पिक: वीडियो की सीधी डाउनलोड लिंक"
            textSize = 15f
            setTextColor(0xFF17243A.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(4))
        })
        content.addView(TextView(this).apply {
            text = "Facebook शेयर लिंक अपने-आप वीडियो फ़ाइल नहीं देता। यदि आपके पास अनुमति प्राप्त HD और नॉर्मल direct video URL हैं, तो यहाँ डालें।"
            textSize = 13f
            setTextColor(0xFF536176.toInt())
        })
        hdUrlInput = EditText(this).apply {
            hint = "HD direct video URL (वैकल्पिक)"
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(hdUrlInput, matchWidth(dp(52)))
        normalUrlInput = EditText(this).apply {
            hint = "Normal direct video URL (वैकल्पिक)"
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(normalUrlInput, matchWidth(dp(52)))

        val openFacebook = Button(this).apply {
            text = "Facebook लिंक खोलें"
            setOnClickListener { openFacebookLink() }
        }
        content.addView(openFacebook, matchWidth())

        val download = Button(this).apply {
            text = "⬇  डाउनलोड करें"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF10AE5B.toInt()))
            setOnClickListener { downloadDirectVideo() }
        }
        val downloadParams = matchWidth(dp(58))
        downloadParams.topMargin = dp(12)
        content.addView(download, downloadParams)

        status = TextView(this).apply {
            text = "वीडियो केवल तभी डाउनलोड होगा जब लिंक सीधे वीडियो फ़ाइल तक पहुँचता हो या वैध डाउनलोड उपलब्ध हो।"
            textSize = 14f
            setTextColor(0xFF46556B.toInt())
            setPadding(dp(10), dp(14), dp(10), dp(14))
        }
        content.addView(status)
        content.addView(TextView(this).apply {
            text = "सुरक्षा: ऐप Facebook पासवर्ड या OTP नहीं माँगता। निजी/प्रतिबंधित वीडियो की सुरक्षा को बायपास नहीं करता।"
            textSize = 13f
            setTextColor(0xFF536176.toInt())
            setPadding(dp(10), dp(8), dp(10), dp(8))
        })
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun isFacebookHost(host: String): Boolean {
        val h = host.lowercase()
        return h == "facebook.com" || h.endsWith(".facebook.com") ||
            h == "fb.watch" || h.endsWith(".fb.watch")
    }

    private fun parseHttpsUri(raw: String): Uri? {
        val uri = runCatching { Uri.parse(raw.trim()) }.getOrNull() ?: return null
        if (!uri.scheme.equals("https", ignoreCase = true)) return null
        if (uri.host.isNullOrBlank() || uri.userInfo != null) return null
        return uri
    }

    private fun openFacebookLink() {
        val uri = parseHttpsUri(linkInput.text.toString())
        if (uri == null || !isFacebookHost(uri.host.orEmpty())) {
            showStatus("Facebook का सही HTTPS शेयर लिंक पहले पेस्ट करें।")
            return
        }
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
            showStatus("Facebook लिंक खोला जा रहा है। यदि वीडियो पर डाउनलोड विकल्प उपलब्ध हो, तो Facebook का आधिकारिक विकल्प इस्तेमाल करें।")
        } catch (_: Exception) {
            showStatus("Facebook लिंक नहीं खुला। कृपया ब्राउज़र में खोलें।")
        }
    }

    private fun checkLink() {
        val mainRaw = linkInput.text.toString().trim()
        val hdRaw = hdUrlInput.text.toString().trim()
        val normalRaw = normalUrlInput.text.toString().trim()
        val chosenRaw = if (selectedQuality == "HD") hdRaw else normalRaw

        if (chosenRaw.isNotBlank()) {
            val mediaUri = parseHttpsUri(chosenRaw)
            if (mediaUri == null || isFacebookHost(mediaUri.host.orEmpty()) || !isLikelyVideoFile(mediaUri)) {
                showStatus("$selectedQuality के लिए सही HTTPS direct MP4/WebM/M4V URL डालें।")
                return
            }
            showStatus("$selectedQuality URL का प्रारूप सही दिखता है। सर्वर की वास्तविक वीडियो फ़ाइल डाउनलोड शुरू होने पर ही जाँची जा सकेगी।")
            return
        }

        val mainUri = parseHttpsUri(mainRaw)
        if (mainUri == null) {
            showStatus("Facebook शेयर लिंक या चुनी गई क्वालिटी का HTTPS direct video URL डालें।")
            return
        }
        if (isFacebookHost(mainUri.host.orEmpty())) {
            showStatus("Facebook शेयर लिंक पहचाना गया, लेकिन यह direct video फ़ाइल नहीं है। ‘Facebook लिंक खोलें’ दबाएँ या $selectedQuality का अनुमति-प्राप्त direct video URL डालें।")
            return
        }
        if (isLikelyVideoFile(mainUri)) {
            showStatus("Direct video URL का प्रारूप सही दिखता है। डाउनलोड शुरू करने के लिए ‘डाउनलोड करें’ दबाएँ।")
        } else {
            showStatus("यह direct MP4/WebM/M4V URL नहीं लगता। कृपया सही वीडियो फ़ाइल लिंक डालें।")
        }
    }

    private fun selectedDirectUrl(): String {
        val hd = hdUrlInput.text.toString().trim()
        val normal = normalUrlInput.text.toString().trim()
        return if (selectedQuality == "HD") hd.ifBlank { linkInput.text.toString().trim() }
               else normal.ifBlank { linkInput.text.toString().trim() }
    }

    private fun isLikelyVideoFile(uri: Uri): Boolean {
        val path = uri.path?.lowercase().orEmpty()
        return path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".m4v")
    }

    private fun downloadDirectVideo() {
        val hdRaw = hdUrlInput.text.toString().trim()
        val normalRaw = normalUrlInput.text.toString().trim()
        val chosenRaw = if (selectedQuality == "HD") hdRaw else normalRaw
        val raw = chosenRaw.ifBlank { linkInput.text.toString().trim() }
        val uri = parseHttpsUri(raw)
        if (uri == null) {
            showStatus("कृपया सही HTTPS वीडियो URL डालें।")
            return
        }
        if (isFacebookHost(uri.host.orEmpty())) {
            showStatus("Facebook शेयर लिंक को सीधे वीडियो फ़ाइल की तरह डाउनलोड नहीं किया जा सकता। ‘Facebook लिंक खोलें’ इस्तेमाल करें या अनुमति-प्राप्त direct video URL डालें।")
            return
        }
        if (!isLikelyVideoFile(uri)) {
            showStatus("यह direct MP4/WebM/M4V फ़ाइल URL नहीं लगता। पेज/शेयर URL डाउनलोड नहीं किया जाएगा।")
            return
        }
        try {
            val rawName = uri.lastPathSegment.orEmpty().substringAfterLast('/')
            val cleaned = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                .trim('.', '_', '-').take(100)
            val extension = when {
                cleaned.endsWith(".webm", ignoreCase = true) -> ".webm"
                cleaned.endsWith(".m4v", ignoreCase = true) -> ".m4v"
                else -> ".mp4"
            }
            val stem = cleaned.substringBeforeLast('.', cleaned).take(80).ifBlank { "video" }
            val safeName = "${stem}_${selectedQuality.lowercase()}_${System.currentTimeMillis()}$extension"
            val mime = if (extension == ".webm") "video/webm" else "video/mp4"
            val request = DownloadManager.Request(uri)
                .setTitle("$selectedQuality video")
                .setDescription("वीडियो Movies/VideoDownloader में सेव हो रहा है")
                .setMimeType(mime)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "VideoDownloader/$safeName")
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = manager.enqueue(request)
            activeDownloadId = downloadId
            showStatus("डाउनलोड शुरू हुआ (ID: $downloadId)। पूरा होने पर ऐप वीडियो MIME type और फ़ाइल आकार जाँचने की कोशिश करेगा।")
        } catch (e: Exception) {
            showStatus("डाउनलोड शुरू नहीं हो पाया: ${e.localizedMessage ?: "लिंक या नेटवर्क जाँचें"}")
        }
    }

    private fun showStatus(message: String) { status.text = message }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWidth(height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply { topMargin = dp(7) }
}
