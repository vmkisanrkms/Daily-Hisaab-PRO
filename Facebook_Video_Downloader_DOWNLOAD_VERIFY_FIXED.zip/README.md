# Video Downloader Android Starter

- Native Android app written in Kotlin
- Hindi-friendly UI with link paste, validation, HD/normal selector and download button
- No Facebook password or OTP collection
- Custom vector launcher icon included
- GitHub Actions builds debug and unsigned release APK artifacts

## Important functional limits

Facebook share/page URLs are not automatically converted into downloadable media URLs. This starter deliberately does not scrape Facebook pages or bypass private/restricted content. It downloads only direct public video-file URLs whose paths end in MP4, WebM, or M4V. The HD/normal selector is currently a UI selection only; real quality switching requires a permitted source that exposes separate streams.

## Build APK

1. Push the repository files to a GitHub repository's `main` or `master` branch.
2. Open **Actions → Build Android APK → Run workflow**.
3. Download `Video-Downloader-Debug-APK` from the run's Artifacts. This debug APK is signed with the standard debug key and can be installed for testing.
4. `Video-Downloader-Release-Unsigned` is a release build output but is **not release-signed**. Configure signing secrets and a signing step before distribution.

The workflow downloads Gradle 8.9 during the run; a checked-in Gradle Wrapper JAR is not included in this starter.

## File-name and download safety update
- Accepts HTTPS links only and rejects URLs containing user-info credentials.
- Sanitizes the downloaded basename and never uses the raw URL path as a destination path.
- Adds a timestamp suffix to reduce accidental filename collisions.
- Sets a video MIME type and stores files under `Movies/VideoDownloader/`.
- Facebook share/page links are intentionally not scraped or bypassed; direct public video-file URLs are required.

## Share links and quality selection
Facebook share/page URLs are recognized and can be opened in the browser, but this app does not scrape Facebook pages, use undocumented endpoints, bypass private content, or ask for Facebook credentials. A share URL is not itself a media file URL.
For genuine quality selection, paste authorized direct HTTPS media URLs into the optional HD and Normal fields. The selected quality uses the corresponding URL. If a quality URL is blank, the app falls back to the main link only if it is itself a direct supported video file URL. The app does not transcode or discover quality variants automatically.

## Audit fix V2
- Link check validates the selected HD/Normal direct URL first, so an optional Facebook share URL no longer blocks checking a supplied quality URL.
- If no quality URL is supplied, Facebook share URLs are identified clearly as share pages, not direct media files.
- Download status reports that the request was queued and that server-side HTML/error responses can still cause failure.
- This remains a direct-URL downloader; it does not extract media from Facebook share pages or automatically discover quality variants.

## Download verification fix
The app now listens for completion of its active Android DownloadManager job, queries the final status and error code, and checks the resulting content URI, MIME type, and nonzero file size before reporting a verified video download. If MIME/file checks do not pass, the app reports that the file is not verified as video. Gallery visibility and device-specific MediaStore indexing still require on-device testing.
